import csv
import os
import shutil
import logging
import json
import re
import sys
import filecmp
from datetime import datetime
from io import StringIO
from collections import defaultdict
from abc import ABC, abstractmethod

# ==============================================================================
#
#                         사용자 설정 (USER SETTINGS)
#
# ==============================================================================
# 이 파일은 스크립트의 모든 동작을 제어하는 중앙 설정 구역입니다.
# 각 설정을 신중하게 검토하고, 자신의 작업 환경에 맞게 수정하십시오.
# ------------------------------------------------------------------------------

# ┏──────────────────────────────────────────────────────────────────────────┐
# ┃ [ 1. 전역 설정 ]
# ┃ 스크립트의 모든 기능에 공통적으로 영향을 미치는 최상위 설정입니다.
# ┗──────────────────────────────────────────────────────────────────────────┘
# 1a. 스크립트 버전 정보
# ┃    현재 스크립트의 버전을 나타냅니다.
SCRIPT_VERSION = "0.37.0"
# ┃
# ┏──────────────────────────────────────────────────────────────────────────┐
# ┃
# ┃     [ 데이터 배포 (Deploy) ]
# ┃
# ┗──────────────────────────────────────────────────────────────────────────┘
# ┏━ 최종 배포 목적지 경로
# ┃    실제 게임이 설치된 경로의 'mods' 폴더를 지정합니다. Deploy 기능은 이곳에
# ┃    번역된 'data' 폴더를 복사합니다.
# ┃
# ┃    !!! 중요: 경로 구분자는 백슬래시(\) 대신 슬래시(/)를 사용하세요 !!!
# ┃    (예: "C:/Games/Starsector/mods")
DESTINATION_BASE_PATH = ""
# ┃
# ┏━ 'Apply'를 통해 생성된 번역 결과물('data' 폴더)을 실제 게임의 모드 폴더로
# ┃    복사한 결과 로그 파일이 생성될 이름.
COPY_LOG_FILENAME = 'log_copy.txt'
# ┃
# ┃
# ┏━ 배포 방식 선택
# ┃    'OVERWRITE': 대상 폴더(예: 'MyMod/data')가 이미 존재할 경우, 그 내용을 유지한 채
# ┃               소스 폴더의 파일들을 덮어씁니다. 소스에 없는 파일은 대상 폴더에
# ┃               그대로 남아있게 됩니다.
# ┃    'DELETE':    대상 폴더가 이미 존재할 경우, 폴더 전체를 **깨끗하게 삭제**한 후
# ┃               소스 폴더의 모든 내용을 새로 복사합니다. 가장 확실하고 깔끔한 방식입니다. (권장)
DEPLOY_METHOD = 'OVERWRITE' # 'OVERWRITE' 또는 'DELETE'
# ┃
# ┏━ 선택적 배포 설정 파일
# ┃    3번 '선택적 배포' 기능이 사용자가 선택한 모드 목록을 저장하는 파일입니다.
# ┃    이 파일은 스크립트에 의해 자동으로 관리되므로, 보통 직접 수정할 필요가 없습니다.
SELECTIVE_DEPLOY_CONFIG = 'selective_deploy.json'

# ┏──────────────────────────────────────────────────────────────────────────┐
# ┃
# ┃ [ 0a. 핵심 경로 및 모드 탐색 설정 ]
# ┃ 스크립트가 어떤 폴더를 대상으로, 어떻게 파일을 찾을지 결정하는 기본 설정입니다.
# ┃
# ┗──────────────────────────────────────────────────────────────────────────┘
# ┏━ 0a. 모드 탐색 루트 경로
# ┃    다중 모드 처리 시, 탐색을 시작할 최상위 폴더를 지정합니다.
# ┃    '.' (기본값): 스크립트가 실행된 현재 폴더를 기준으로 탐색합니다.
# ┃    절대 경로 (예: "C:/Games/StarsectorMods"): 스크립트를 어디서 실행하든
# ┃              항상 지정된 폴더부터 하위의 모든 모드를 탐색합니다.
MOD_SEARCH_ROOT_PATH = '.'
# ┃
# ┏━ 0b. 원본 데이터 폴더 이름
# ┃    번역할 텍스트를 추출하거나(Export), 번역을 적용할(Apply) 원본 영문 파일들이
# ┃    담겨 있는 폴더의 이름입니다. 모든 모드 폴더는 내부에 이 이름의 폴더를 가져야 합니다.
SOURCE_DATA_FOLDER = './data_en'
# ┃
# ┏━ 0c. 다중 모드 자동 처리 기능
# ┃    True:  스크립트가 위치한 곳의 모든 하위 폴더를 개별 모드로 간주하여 순차적으로 처리합니다. (기본값)
# ┃    False: 스크립트가 위치한 현재 폴더 내에서만 단일 모드로 작동합니다.
PROCESS_MULTIPLE_MODS_AUTO = True
# ┃
# ┏━ 0c-1. 다중 모드 처리 시 제외할 폴더 목록
# ┃     여기에 명시된 이름의 폴더는 다중 모드 처리 대상에서 제외됩니다.
MOD_FOLDERS_TO_EXCLUDE = {'.git', '__pycache__', 'backups', '.vscode'}
# ┃
# ┏━ 0d. 다중 모드 폴더 이름 필터링
# ┃    True로 설정하면, 아래 MOD_FOLDER_PREFIX로 시작하는 폴더만 처리 대상으로 간주합니다.
# ┃    False로 설정하면, 제외 목록 외의 모든 하위 폴더를 처리합니다.
MOD_USE_PREFIX_FILTER = True
MOD_FOLDER_PREFIX = 'mod_'
# ┃
# ┏━ 0e. 동적 파일 경로 생성 방식
# ┃    True:  모드 폴더 이름(예: 'mod_MyMod')을 기반으로 'mod_MyMod_... .csv' 와 같이
# ┃           동적으로 파일 이름을 생성합니다. (다중 모드 환경에서 강력히 권장)
# ┃    False: 각 기능에 개별 지정된 고정된 파일 이름(예: 'mod_... .csv')을 사용합니다.
USE_DYNAMIC_FILE_PATHS = True

# ┏───────────────────────────────────────────────────────────────────────────
# ┃ [ 데이터 처리 방식 설정 ]
# ┃ 텍스트를 비교하거나 저장하기 위해 정규화하는 방식을 선택합니다.
# ┗───────────────────────────────────────────────────────────────────────────
# ┏━ 1a.1 텍스트 처리 모드
# ┃    향후 다양한 처리 방식을 지원하기 위한 설정입니다.
# ┃    - 'LEGACY_HYBRID': 기본적으로 줄바꿈(\n)을 '\\n' 문자열로 변환하지만,
# ┃                       'type: text' 항목에 대해서는 예외적으로 '|n|' 태그를 사용합니다.
# ┃                       (현재 버전의 유일한 옵션이며, 기존 동작을 보장합니다.)
TEXT_PROCESSING_MODE = 'LEGACY_HYBRID' # 현재 'LEGACY_HYBRID'만 지원
# ┃
# ┏━ 1a-2. 텍스트 처리 모드가 LEGACY_HYBRID 일 때 'type: text' 항목의 줄바꿈 태그
# ┃      'type'이 'text'로 시작하는 항목에 대해 줄바꿈('\n')을 대체할 태그입니다.
# ┃      (예: '|n|', '<br>', '<newline>' 등)
NEWLINE_TAG_FOR_TEXT_TYPE = '\\n' # 사용자가 원하는 태그로 설정
# ┃
# ┃
# ┏───────────────────────────────────────────────────────────────────────────
# ┃ [ 1b. 줄바꿈 태그 설정 ]
# ┃     Export 시, 텍스트 타입별로 줄바꿈 문자를 어떤 태그로 치환할지 설정합니다.
# ┃     - 허용되는 값: '|n|' (스프레드시트 호환용 태그) 또는 '\\n' (JSON/표준 이스케이프)
# ┗───────────────────────────────────────────────────────────────────────────
# ┃
# ┏━ 1b-1. 'type: text' 계열 항목의 줄바꿈 태그
# ┃     (예: 'campaign/reports.csv', 'strings/descriptions.csv' 등)
NEWLINE_TAG_TEXT_TYPE = '\\n' # 기본값: '|n|'
# ┃
# ┏━ 1b-2. 'type: json' 계열 항목의 줄바꿈 태그
# ┃     (예: 'strings/strings.json', 'strings/tips.json' 등)
NEWLINE_TAG_JSON_TYPE = '\\n' # 기본값: '\\n'
# ┃
# ┏━ 1b-3. 그 외 모든 항목의 줄바꿈 태그
# ┃     (명시적인 규칙이 없는 모든 일반 텍스트)
NEWLINE_TAG_DEFAULT_TYPE = '\\n' # 기본값: '\\n'
# ┏───────────────────────────────────────────────────────────────────────────
# ┃
# ┃ [ 로깅 및 디버그 설정 ]
# ┃ 스크립트의 모든 로깅 관련 설정을 이곳에서 관리합니다.
# ┃
# ┗───────────────────────────────────────────────────────────────────────────
# ┏━ 1c-1. 메인 로깅 레벨 설정
# ┃    스크립트 실행 시 콘솔에 표시되는 정보의 상세 수준을 결정합니다.
# ┃
# ┃    'NORMAL': 작업 시작/종료와 같은 필수적인 진행 상황만 표시합니다. (일반 사용자 권장)
# ┃    'DETAIL': 어떤 파일이 처리되는지와 같은 상세 정보를 추가로 표시합니다. (진행 과정 확인 시 유용)
# ┃    'DEBUG':  문제 해결을 위한 모든 내부 동작 정보를 기록합니다. (매우 상세함)
LOGGING_LEVEL = 'DEBUG' # 'NORMAL', 'DETAIL', 'DEBUG' 중 선택
# ┃
# ┏━ 1c-2. tips.json 전용 상세 디버깅 설정
# ┃    True로 설정하면, 'tips.json' 파일 처리 과정에 대한 매우 상세한
# ┃    디버그 로그를 콘솔에 출력합니다. 일반 DEBUG 레벨보다 더 깊은 정보를
# ┃    제공하여, 복잡한 'tips.json' 문제 해결에 특화되어 있습니다.
TIPS_JSON_DEBUG_MODE = True # True 또는 False
# ┃
# ┏━ 1c-3. tips.json 디버그 로그 파일 출력
# ┃     TIPS_JSON_DEBUG_MODE가 True일 때, 디버그 로그를 콘솔뿐만 아니라
# ┃     'log_tips_debug.txt' 파일에도 별도로 저장할지 여부를 결정합니다.
TIPS_JSON_DEBUG_LOG_TO_FILE = True # True 또는 False
TIPS_JSON_DEBUG_FILENAME = 'log_tips_debug.txt'
# ┃
# ┏━ c-4. tips.json 주석 처리 옵션
# ┃    Apply 실행 시, 최종적으로 생성되는 'tips.json' 파일에서 원본의 '#' 주석을
# ┃    어떻게 처리할지 결정합니다.
# ┃
# ┃    True (기본값): 최종 파일에서 모든 '#' 주석을 제거하여 깔끔하게 만듭니다.
# ┃    False: 원본 파일에 있던 모든 '#' 주석을 그대로 보존합니다.
TIPS_JSON_REMOVE_COMMENTS = True # True 또는 False
# ┃
# ┏━ 1c-5. 인코딩 폴백 상세 로그 출력
# ┃    True로 설정하면, 파일 읽기 시 기본 인코딩(INPUT_FILE_ENCODING) 실패 후
# ┃    다른 인코딩으로 읽기에 성공했을 때, 어떤 인코딩이 사용되었는지에 대한
# ┃    상세한 경고와 권장 사항을 출력합니다.
# ┃    False로 설정하면 (기본값), 성공한 인코딩 이름만 간결하게 정보 로그로 표시합니다.
LOG_ENCODING_FALLBACK_DETAILS = False # True 또는 False
# ┃
# ┏━ 1c-6. 고아 데이터 text_en 역추적 상세 디버깅
# ┃      True로 설정하면, '고아 데이터 text_en 역추적' 기능의
# ┃      모든 내부 동작(어떤 키로 조회하는지, 매칭 성공/실패 여부 등)을
# ┃      매우 상세하게 콘솔과 별도 로그 파일에 기록합니다.
ORPHAN_RECOVERY_DEBUG_MODE = True # True 또는 False
# ┃
# ┏━ 1c-7. 역추적 디버그 로그 파일 출력
# ┃      ORPHAN_RECOVERY_DEBUG_MODE가 True일 때, 디버그 로그를
# ┃      콘솔뿐만 아니라 별도의 파일에도 저장할지 여부를 결정합니다.
ORPHAN_RECOVERY_DEBUG_LOG_TO_FILE = True # True 또는 False
ORPHAN_RECOVERY_DEBUG_FILENAME = 'log_orphan_recovery_debug.txt'

# ┏──────────────────────────────────────────────────────────────────────────
# ┃ [ JSON 출력 서식 설정 ]
# ┃ Apply 기능으로 JSON 파일을 생성/업데이트할 때 적용되는 서식 규칙입니다.
# ┃
# ┃ [ 권장 설정 (원문 형태와 가장 유사) ]
# ┃ - JSON_OUTPUT_INDENT = 2       : 원본처럼 들여쓰기 공백 2칸 유지
# ┃ - JSON_OUTPUT_SEPARATORS = (',', ':') : 원본처럼 쉼표/콜론 뒤 공백 제거
# ┗──────────────────────────────────────────────────────────────────────────
JSON_OUTPUT_INDENT = 2       # JSON 출력 들여쓰기 공백 수 (None 설정 시 한 줄로 압축)
JSON_OUTPUT_SORT_KEYS = False # JSON 출력 시 키를 알파벳 순으로 정렬할지 여부 (기본값 : False)
JSON_OUTPUT_SEPARATORS = (',', ':') # JSON 출력 시 키와 값, 항목 사이 구분자 ('(정의되지 않음)' 설정 시 기본값인 (', ', ': ') 사용)
JSON_COMPACT_OBJECTS_IN_ARRAYS = True # 배열 내의 짧은 객체(id, text, replyToId 패턴)를 한 줄로 압축할지 여부
JSON_COMPACT_SIMPLE_ARRAYS = True     # 배열 내에 객체가 없는 단순 배열(예: ["a","b"])을 한 줄로 압축할지 여부

# ┏──────────────────────────────────────────────────────────────────────────
# ┃ [ 2. 파일 처리 및 구문 분석 규칙 ]
# ┃ 파일을 읽고 쓸 때 적용되는 인코딩, CSV/JSON 분석 방식 등 기술적인 규칙입니다.
# ┗──────────────────────────────────────────────────────────────────────────
# ┃
# ┏━ 2a. 파일 인코딩 설정 ---
# ┃    INPUT_FILE_ENCODING:  'data_en' 폴더의 원본 파일을 읽을 때 사용할 인코딩입니다.
# ┃                        - 'utf-8-sig': BOM이 있는 UTF-8
# ┃                        - 'utf-8':     BOM이 없는 표준 UTF-8
# ┃
# ┃    OUTPUT_FILE_ENCODING: 스크립트가 생성하는 모든 파일(csv, log 등)에 적용할 인코딩입니다.
# ┃                        - 'utf-8': 호환성이 가장 좋은 표준 방식입니다. (강력히 권장)
INPUT_FILE_ENCODING = 'utf-8-sig'
OUTPUT_FILE_ENCODING = 'utf-8' # 'utf-8' 또는 'utf-8'
# ┃
# ┏━ 2b. 일반 CSV 분석 규칙 (주로 Export에서 사용) ---
# ┃    스크립트가 CSV 파일의 각 열(column)이 어떤 종류의 데이터인지 판단하는 기준입니다.
# ┃
# ┏━ 고유 ID로 사용할 열 이름 목록
ID_COLUMNS_TO_CHECK = ['id', 'fieldID']
# ┏━ '이름' 타입으로 간주할 열 이름 목록
NAME_COLUMNS_TO_CHECK = ['name', 'fieldName']
# ┏━ '제작자/작가' 타입으로 간주할 열 이름 목록
AUTHOR_COLUMNS_TO_CHECK = ['author']
# ┏━ '일반 텍스트' 타입으로 간주할 열 이름 목록
TEXT_COLUMNS_TO_CHECK = ['defaultValue', 'text', 'description', 'desc', 'text1', 'text2', 'text3', 'fieldDescription', 'short']
# ┏━ 'defaultValue' 열에서 번역 대상으로 추출하지 않을 특정 값들입니다.
DEFAULT_VALUE_EXCLUSIONS = {'true', 'false'}

# ┏─----------------------------------------------------------------------------
# ┃
# ┃ [신설] 3. 범용 파서 규칙 (규칙 중심)
# ┃
# ┣─----------------------------------------------------------------------------
# ┃
# ┃ ▼ 범용 파서 규칙 (규칙 중심)
# ┃
# ┗─----------------------------------------------------------------------------
# 이 설정은 여러 파일에 동일한 추출/적용 규칙을 재사용하기 위해 설계되었습니다.
# 스크립트는 이 리스트를 위에서부터 순서대로 확인하여, `target_files`에
# 현재 처리 중인 파일 경로가 포함된 첫 번째 규칙을 사용합니다.
GENERIC_PARSER_RULES = [
    {
        '_description': 'JSON 파일 내에서 "name": "..." 패턴의 값을 추출합니다.',
        'target_files': [
            # 'campaign/channels.json',
            # 만약 다른 파일도 이 규칙을 쓴다면 여기에 추가:
            # 'data/config/another_file.json' 
        ],
        'parser': 'process_tips_json', # 범용 정규식 파서
        'applier': 'apply_tips_json',   # 짝이 맞는 적용기
        'regex_pattern': '"name"\\s*:\\s*"((?:[^"\\\\]|\\\\["\\\\])*)"',
        'id_prefix': '{FILENAME_PLACEHOLDER}', # 파일별로 고유 ID를 갖도록 설정
        'type': 'generic_name'
    },
    # {
    #     '_description': '또 다른 범용 규칙 세트',
    #     'target_files': [ ... ],
    #     ...
    # }
]

# ┏─ [ 3a. JSON 구조 분석 패턴 ] ──────────────────────────────────
# ┃    이 설정은 json_scan_process 함수가 JSON 파일의 내부 구조를
# ┃    판단하는 기준이 되는 '패턴 라이브러리'입니다.
# ┃    새로운 구조의 JSON 파일을 지원해야 할 경우, 여기에 새 패턴을 추가하면
# ┃    코드 수정 없이도 Export/Apply가 자동으로 대응할 수 있습니다.
# ┗───────────────────────────────────────────────────────────────
JSON_STRUCTURE_PATTERNS = [
    {
        '_description': '최상위 카테고리 키 아래에 Key-Value 쌍이 중첩된 구조 (예: "ui": {"cancel":"Cancel"})',
        'name': 'category_key_nested',
        
        # [감지기] "key": { 형태의 패턴이 파일 내에 존재하는지 빠르게 검사하여 이 구조임을 특정합니다.
        'detector_regex': r'"\w+"\s*:\s*\{',
        
        # [Export용 정규식 1: 카테고리 블록 추출]
        'export_category_regex': r'"([a-zA-Z0-9_]+)"\s*:\s*\{([\s\S]*?)(?=\s*"\w+"\s*:\s*\{|\s*\Z)',
        
        # [Export용 정규식 2: 카테고리 내 Key-Value 추출]
        'export_kv_regex': r'"([a-zA-Z0-9_]+)"\s*:\s*"((?:\\.|[^"\\])*)"',
        
        # [Apply용 정규식 1 (템플릿): 카테고리 블록 탐색]
        'apply_category_regex': r'"{category}"\s*:\s*{{([\s\S]*?)(?=\s*"\w+"\s*:\s*{{|\s*}})',
        
        # [Apply용 정규식 2 (템플릿): 교체할 최종 위치 탐색]
        'apply_kv_regex': r'"{key}"\s*:\s*"((?:\\.|[^"\\])*)"',
    },
    
    # --- tips.json (PAGSM 형식) - 문자열 배열 ---
    {
        '_description': 'tips.json - PAGSM 스타일 (문열 배열 직접 포함)',
        'name': 'tips_string_array',
        'detector_regex': r'(?:"tips"|tips)\s*:\s*\[\s*\"((?:[^"\\\\]|\\.)*)\"', 
        
        # 배열 블록을 더 견고하게 찾기 위한 정규식
        'export_category_regex': r'(?:"tips"|tips)\s*:\s*\[([\s\S]*?)(?=\s*\]\s*,?\s*\}|\s*\]\s*\Z)',
        'export_kv_regex': r'\"((?:[^"\\\\]|\\.)*)\"', 

        # 배열 블록을 더 견고하게 찾기 위한 정규식
        'apply_category_regex': r'(?:"tips"|tips)\s*:\s*\[([\s\S]*?)(?=\s*\]\s*,?\s*\}|\s*\]\s*\Z)',
        'apply_kv_regex': r'"{text_en_escaped}"',
        'id_prefix': 'tips_pagsm_{MOD_NAME_PLACEHOLDER}', 
        'item_type': 'tip_json_str',                     
    },
    
    # --- tips.json (UAF 형식) - 객체 배열 내 "tip" 키 ---
    {
        '_description': 'tips.json - UAF 스타일 (객체 배열 내 "tip" 키)',
        'name': 'tips_object_array',
        'detector_regex': r'(?:"tips"|tips)\s*:\s*\[\s*\{.*?"tip":\s*\"((?:[^"\\\\]|\\.)*)\"', 
        
        # 배열 블록을 더 견고하게 찾기 위한 정규식
        'export_category_regex': r'(?:"tips"|tips)\s*:\s*\[([\s\S]*?)(?=\s*\]\s*,?\s*\}|\s*\]\s*\Z)',
        # 이중 이스케이프 오류 수정
        'export_kv_regex': r'"tip"\s*:\s*"((?:\\.|[^"\\])*)"',

        # 배열 블록을 더 견고하게 찾기 위한 정규식
        'apply_category_regex': r'(?:"tips"|tips)\s*:\s*\[([\s\S]*?)(?=\s*\]\s*,?\s*\}|\s*\]\s*\Z)',
        # 이중 이스케이프 오류 수정
        'apply_kv_regex': r'("tip"\s*:\s*)"{text_en_escaped}"', 
        'id_prefix': 'tips_{MOD_NAME_PLACEHOLDER}',
        'item_type': 'tip_json',                         
    },
    
    # --- tips.json (기본 폴백) ---
    {
        '_description': 'tips.json - 어떤 특정 패턴에도 맞지 않는 경우의 기본 폴백',
        'name': 'tips_generic_fallback',
        'detector_regex': r'(?:"tips"|tips)\s*:\s*\[', 
        
        # [핵심 수정] 배열 블록을 더 견고하게 찾기 위한 정규식
        'export_category_regex': r'(?:"tips"|tips)\s*:\s*\[([\s\S]*?)(?=\s*\]\s*,?\s*\}|\s*\]\s*\Z)',
        'export_kv_regex': r'\"((?:[^"\\\\]|\\.)*)\"', 

        # [핵심 수정] 배열 블록을 더 견고하게 찾기 위한 정규식
        'apply_category_regex': r'(?:"tips"|tips)\s*:\s*\[([\s\S]*?)(?=\s*\]\s*,?\s*\}|\s*\]\s*\Z)',
        'apply_kv_regex': r'"{text_en_escaped}"',
        'id_prefix': 'tips_generic_{MOD_NAME_PLACEHOLDER}', 
        'item_type': 'tip_json',
    },

    # --- strings/ship_names.json (단순 문자열 배열) ---
    {
        '_description': 'strings/ship_names.json - 단순 문자열 배열',
        'name': 'ship_names_string_array',
        'detector_regex': r'"FUEL"\s*:\s*\[\s*\"', # "FUEL":[ "..."
        
        # 배열 블록을 견고하게 찾기 위한 정규식 (FUEL 키에 맞게 조정)
        'export_category_regex': r'"FUEL"\s*:\s*\[([\s\S]*?)(?=\s*\]\s*,?\s*\}|\s*\]\s*\Z)',
        'export_kv_regex': r'\"((?:[^"\\\\]|\\.)*)\"', 

        'apply_category_regex': r'"FUEL"\s*:\s*\[([\s\S]*?)(?=\s*\]\s*,?\s*\}|\s*\]\s*\Z)',
        'apply_kv_regex': r'"{text_en_escaped}"',
        'id_prefix': 'ship_name_{MOD_NAME_PLACEHOLDER}', 
        'item_type': 'ship_name_str',                     
    },    
    # 특정 키만 선택적으로 추출하는 JSON 패턴
    # 이 패턴 자체는 추출 로직을 정의하지 않음. GeneralJsonParser가 target_keys를 참조하여 동작
    
    {
        '_description': '범용 JSON - 특정 키만 선택적으로 추출하는 모드',
        'name': 'json_selective_key_value',
        'detector_regex': r'^\s*\{', # 모든 JSON 객체 시작을 감지
        'export_category_regex': r'([\s\S]*)', # 파일 전체를 하나의 블록으로 간주
        'export_kv_regex': r'\"(\w+)\"\\s*:\\s*\"((?:[^"\\\\]|\\.)*)\"', # 일반적인 키-값 쌍 패턴
        'apply_category_regex': r'([\s\S]*)',
        'apply_kv_regex': r'"{key}"\\s*:\\s*"((?:[^"\\\\]|\\.)*)"',
        'id_prefix': 'json_selective_{FILENAME_PLACEHOLDER}',
        'item_type': 'json_selective',
    },
]

# ┏──────────────────────────────────────────────────────────────────────────┐
# ┃ --- 3b. 특수 파일 처리 규칙 (고급) ---
# ┃ 이 설정은 스크립트의 기본 분석 규칙을 따르지 않는 특정 파일들을 위한
# ┃ 매우 강력한 '예외 처리' 규칙을 정의하는 곳입니다.
# ┃ 이 규칙을 사용하면, 파이썬 코드를 직접 수정하지 않고도 거의 모든 종류의
# ┃ 텍스트 기반 파일에서 원하는 내용을 정확하게 추출할 수 있습니다.
# ┃
# ┃ [ 기본 구조 ]
# ┃ - 딕셔너리의 '키'에는 예외를 적용할 파일의 상대 경로를 입력합니다. (예: 'strings/tips.json')
# ┃ - '값'에는 해당 파일에 적용할 규칙들을 지정합니다. 규칙은 아래 두 가지 방식 중 하나를 사용합니다.
# ┃
# ┃ [ 1. 일반 규칙: 딕셔너리( {} ) 사용 ]
# ┃ - 가장 기본적인 방식으로, 모든 모드에 동일하게 적용될 단일 규칙을 정의합니다.
# ┃ - 예: 'campaign/reports.csv': { ... 규칙 내용 ... }
# ┃
# ┃ [ 2. 조건부 규칙: 리스트( [] ) 사용 ]
# ┃ - [매우 강력함] 하나의 파일 경로에 대해 여러 개의 규칙을 정의하고,
# ┃   '어떤 조건에서 어떤 규칙을 사용할지'를 지정할 수 있습니다.
# ┃ - 예: 'strings/tips.json': [ {규칙 A}, {규칙 B}, ... ]
# ┃ - 스크립트는 리스트의 첫 번째 규칙부터 순서대로 조건을 확인하여,
# ┃   가장 먼저 조건이 일치하는 규칙 하나만을 사용합니다.
# ┃
# ------------------------------------------------------------------------------
# ┃ ▼ 사용 가능한 규칙 속성들 (상세 설명)
# ------------------------------------------------------------------------------
#
# ┣─ '_conditions': {'mod_folder_name': '모드폴더이름'}
# ┃   └─ [조건부 규칙 전용] 이 규칙이 적용될 특정 모드 폴더의 이름을 지정합니다.
# ┃      이 속성이 없는 규칙은 모든 조건에 맞지 않았을 때 사용될 '기본값(fallback)'으로 취급됩니다.
#
# ┣─ 'mode': '모드 이름'
# ┃   └─ 파일을 처리할 방식을 결정하는 가장 중요한 속성입니다.
# ┃
# ┃      ├─ 'simple_kv' (단순 키-값 추출):
# ┃      │  - 가장 쉽고 권장되는 방식입니다. 정규식을 몰라도 됩니다.
# ┃      │  - 'key_name' 속성과 함께 사용하여 "키": "값" 형태에서 '값'을 추출합니다.
# ┃      │
# ┃      ├─ 'generic_regex' (범용 정규식 추출):
# ┃      │  - 'simple_kv'로 처리할 수 없는 복잡한 패턴을 위해 사용합니다.
# ┃      │  - 'regex_pattern' 속성에 정의된 정규식을 사용하여 텍스트를 추출합니다.
# ┃      │
# ┃      └─ 'regex_extract' (특수 CSV 파서):
# ┃         - 'campaign/rules.csv'처럼 하나의 셀 안에 여러 줄의 코드와 텍스트가
# ┃           복잡하게 얽힌 특수한 CSV 파일을 처리하기 위한 전용 파서입니다.
#
# ┣─ 'key_name': '찾을 키 이름'
# ┃   └─ ['simple_kv' 모드 전용] 추출하려는 값(value) 바로 앞에 오는 키(key)의 이름을 지정합니다.
# ┃      예: 'key_name': 'tip'  ->  "tip" : "이 부분을 추출"
#
# ┣─ 'regex_pattern': '정규식 패턴'
# ┃   └─ ['generic_regex' 모드 전용] 텍스트를 추출할 정규식 패턴을 지정합니다.
# ┃      [중요!] 추출하려는 내용(번역 대상)은 반드시 캡처 그룹 괄호 '()' 안에 있어야 합니다.
# ┃      예: '"tip"\\s*:\\s*"((?:\\"|[^"])*)"'  ->  첫 번째 (...) 안의 내용을 추출
#
# ┣─ 'id_source': 'auto_index'
# ┃   └─ [범용 파서용] 추출된 항목의 ID를 어떻게 생성할지 지정합니다. 현재 'auto_index'만 지원하며,
# ┃      0, 1, 2, ... 순서로 자동으로 번호를 매깁니다.
#
# ┣─ 'id_prefix': 'ID 접두사'
# ┃   └─ ['auto_index' 사용 시] 자동으로 생성된 번호 앞에 붙일 접두사를 지정합니다.
# ┃      예: 'id_prefix': 'tips'  ->  ID가 'tips[0]', 'tips[1]' ... 형태로 생성됩니다.
#
# ┣─ 'type': '타입 이름'
# ┃   └─ [범용 파서용] 추출된 항목에 부여할 고정된 'type' 필드 값을 지정합니다.
#
# ┣─ 'key_columns': ['열1', '열2']
# ┃   └─ [일반/특수 CSV용] CSV 파일의 고유 ID로 사용할 열들을 지정합니다.
#
# ┗─ 'translatable_columns': ['열A', '열B']
#     └─ [일반/특수 CSV용] 번역을 추출할 대상 열들을 지정합니다.
#
# ------------------------------------------------------------------------------
# ┃ ▼ 실제 사용 예시 (Cookbook)
# ------------------------------------------------------------------------------
SPECIAL_FILE_HANDLING = {
    # --- 예시 1: 일반 규칙 (모든 모드에 공통 적용) ---
    # 'campaign/rules.csv' 파일은 항상 복잡한 'regex_extract' 파서를 사용하도록 강제합니다.
    'campaign/rules.csv': {
        'parser': 'process_regex_csv', # parser/applier 방식으로 통일
        'applier': 'apply_regex_csv',
        'key_columns': ['id'],
        'translatable_columns': ['text', 'options', 'script'],
        'also_check_unnamed_columns_for': ['options', 'script'],
        'exclude_columns': {'conditions'}
    },
    'campaign/reports.csv': {
        'parser': 'process_general_csv', # parser/applier 방식으로 통일
        'applier': 'apply_translation_to_csv_file',
        'key_columns': ['event_type', 'event_stage'],
        'translatable_columns': ['subject', 'summary', 'assessment']
    },
    'config/chatter/characters/*.json': {
        'parser': 'process_json_file', # GeneralJsonParser를 사용
        'applier': 'apply_general_json',
        'json_pattern_name': 'json_selective_key_value',
        'target_keys': ['name', 'text'], # <--- 'name'과 'text' 키만 추출하도록 지정
    },
    'strings/descriptions.csv': {
        'parser': 'process_general_csv', # parser/applier 방식으로 통일
        'applier': 'apply_translation_to_csv_file',
        'key_columns': ['id'],
        'translatable_columns': ['text1', 'text2', 'text3', 'notes']
    },
    'characters/skills/*.skill': {
        'parser': 'process_skill_file',
        'applier': 'apply_tips_json',
        'regex_pattern': '"scopeStr"\\s*:\\s*"([^"]*)"',
        'id_prefix': '{FILENAME_PLACEHOLDER}_scope', 
        'type': 'scopeStr'
    },

    #     'config/paintjobs/magic_paintjobs.csv': { # [추가] Export/Apply에 영향 주지 않는다고 명시된 파일
    #     'parser': 'process_general_csv',
    #     'applier': 'apply_translation_to_csv_file',
    #     'key_columns': ['id'],
    #     'translatable_columns': ['name']
    # },
    
    'strings/strings.json': [
        {
            '_conditions': {'mod_folder_name': ['mod_UAF']},
            'parser': 'json_export_process', # JsonPolymorphicParser (기존 Export 방식) 유지
            'applier': 'apply_general_json',   # <-- GeneralJsonApplier 사용
            'json_pattern_name': 'category_key_nested', # 기존 패턴 이름 참조 (GeneralJsonApplier는 직접 안 쓰지만 명시)
        },
        {
            '_conditions': {'mod_folder_name': ['mod_PAGSM']},
            'parser': 'process_json_file',
            'applier': 'json_apply_strings',
            'reformat_on_apply': True, # <-- 서식 재구성 플래그 추가
        },
        {
            'parser': 'process_json_file',
            'applier': 'json_apply_process',
        }
    ],
    'campaign/channels.json': {
        'parser': 'process_json_file', # 'name': 'value' 형태에 적합한 파서
        'applier': 'apply_general_json', # JSON 적용에 적합한 어플라이어
    },
    
    # strings/ship_names.json 규칙 추가
    'strings/ship_names.json': {
        'parser': 'process_tips_polymorphic', # TipsPolymorphicParser를 사용
        'applier': 'apply_tips_polymorphic',   # TipsPolymorphicApplier를 사용
        'json_pattern_name': 'ship_names_string_array', # 새로 정의한 패턴 이름 참조
    },

# ┏──────────────────────────────────────────────────────────────────────────┐
# ┃ ▼ 'strings/tips.json' 파일에 대한 조건부 처리 규칙 (심화)
# ┃ 이 섹션은 'tips.json' 파일의 유동적인 특성을 처리하기 위한 핵심 설정입니다.
# ┃
# ┃ [문제 정의]
# ┃ - Starsector 모드의 'tips.json' 파일은 모드마다 내부 데이터 구조가 다를 수 있습니다.
# ┃ (예: {"tip": "내용"} 형식 vs ["내용1", "내용2"] 형식)
# ┃ - 이 리스트 구조는 현재 모드 폴더(_conditions)를 확인하여,
# ┃ 각 모드에 맞는 최적의 'regex_pattern' 및 'pre_process' 규칙을 동적으로 선택합니다.
# ┃ - 'parser'와 'applier'로 지정된 함수들(예: process_tips_json, apply_tips_json)은
# ┃ 이 규칙들을 읽고 스스로 동작을 조정하는 '지능형 범용 엔진' 역할을 합니다.
# ┃
# ┃ [해결 원리: 조건부 설정 및 범용 엔진]
# ┃ - 이 리스트 구조는 현재 작업 중인 모드 폴더의 이름(_conditions)을 확인하여,
# ┃ 각 모드에 맞는 최적의 'regex_pattern' 및 'pre_process' 규칙을 동적으로 선택합니다.
# ┃ - 'process_tips_json' (Export용)과 'apply_tips_json' (Apply용) 함수는
# ┃ 이 규칙들을 읽고 스스로 동작을 조정하는 '지능형 범용 엔진' 역할을 합니다.
# ┃ - 결과적으로, 파이썬 코드를 수정하지 않고 설정 변경만으로 모든 'tips.json'을 처리합니다.
# ┃
# ┃ [새로운 모드의 tips.json 규칙을 추가하는 방법]
# ┃ 1. 새로운 모드 폴더(예: 'mod_NewMod')의 'data_en/strings/tips.json' 구조를 파악합니다.
# ┃ 2. 아래 레시피 중 가장 유사한 규칙 블록을 복사합니다.
# ┃ 3. 복사한 규칙 블록을 이 리스트의 **가장 상단 (기존 레시피 A 이전)**에 붙여넣습니다.
# ┃ 4. 복사한 규칙 블록을 다음과 같이 수정합니다:
# ┃ 5. 복사한 규칙 블록을 다음과 같이 수정합니다:
# ┃  - '_conditions': {'mod_folder_name': 'mod_NewMod'}  <- 새 모드 폴더 이름으로 변경.
# ┃     (참고: 여러 모드에 동일 규칙 적용 시, ['mod_A', 'mod_B'] 와 같이 리스트로 지정 가능)
# ┃  - 'regex_pattern': 추출하려는 텍스트 패턴에 맞게 정규식을 수정합니다.
# ┃     (중요: 추출 대상 텍스트는 반드시 캡처 그룹 '()' 안에 있어야 합니다.)
# ┃  - 'pre_process': (선택 사항) Apply 전에 후행 쉼표 제거 등이 필요하면 추가합니다.
# ┃  - 'id_prefix': 새 모드에 맞는 고유한 ID 접두사로 변경합니다 (예: 'tips_newmod').
# ┃     (예: 'tips' 또는 'tips_{MOD_NAME_PLACEHOLDER}' <- 스크립트가 '{MOD_NAME_PLACEHOLDER}'를 현재 모드 ID로 자동 교체)
# ┃  - 'type': 새 모드에 맞는 고유한 타입 이름으로 변경합니다 (예: 'json_tip_newmod').
# ┃ 6. 'Export'를 실행하여 새로운 'merged_kr.csv' 파일을 생성하고, 번역을 확인/추가합니다.
# ┃ 7. 'Apply'를 실행하여 번역이 올바르게 적용되는지 검증합니다.
# ------------------------------------------------------------------------------

    # --- 예시 2: 조건부 규칙 (가장 강력한 기능) ---
    # 'strings/tips.json' 파일은 현재 작업 중인 모드 폴더에 따라 다른 규칙을 적용합니다.

    'strings/tips.json': [  # <--- [중요] 파일 경로의 값을 딕셔너리가 아닌 '리스트'로 변경!
    
    # --- 레시피 A: 문자열 배열 내 직접 문자열 팁 (PAGSM 형식) ---
    {
        '_conditions': {'mod_folder_name': ['mod_PAGSM', 'mod_Nexerelin', 'mod_Interstellar Imperium', 'mod_starsectorkorean - 작업중']},
        'parser': 'process_tips_polymorphic',
        'applier': 'apply_tips_polymorphic',
        'json_pattern_name': 'tips_string_array',
    },

    # --- 레시피 B: JSON 객체 배열 내 "tip" 키에 저장된 팁 (UAF 형식) ---
    {
        '_conditions': {'mod_folder_name': ['mod_UAF', 'mod_MyMod_B']}, 
        'parser': 'process_tips_polymorphic',
        'applier': 'apply_tips_polymorphic',
        'pre_process': ['remove_trailing_comma'],
        'json_pattern_name': 'tips_object_array',
    },
    
    # --- 레시피 C: 기본값 (Fallback) 규칙 ---
    {
        # fallback 규칙도 이제 json_pattern_name을 사용합니다.
        'parser': 'process_tips_polymorphic',
        'applier': 'apply_tips_polymorphic',
        'json_pattern_name': 'tips_generic_fallback',
    }
    ]
        # 'strings/tips.json': {
        # 'parser': 'process_tips_polymorphic',
        # 'applier': 'apply_tips_polymorphic',
        # },
}

# ┏──────────────────────────────────────────────────────────────────────────┐
# ┃ [ 3c. 파일 확장자 그룹 정의 ] (신규)
# ┃      스크립트가 파일 유형을 식별하는 데 사용할 확장자 그룹을 정의합니다.
# ┃      이는 파서/어플라이어 라우팅 로직의 중앙 집중식 관리를 돕습니다.
# ┗──────────────────────────────────────────────────────────────────────────┘
JSON_FILE_EXTENSIONS = ('.json', '.jsonc')
CSV_FILE_EXTENSIONS = ('.csv',) # 현재 .csv만 있지만, 확장성을 위해 튜플로 정의
SKILL_FILE_EXTENSIONS = ('.skill',) # .skill 파일 확장자 정의
SYSTEM_FILE_EXTENSIONS = ('.system',) # .system 파일 확장자 정의
# ┃
# ┏━ 3c-1. JSON 처리 규칙 (주로 Export/Apply에서 사용) ---
# ┃    게임이 요구하는 비표준 JSON 형식을 지원하기 위한 예외 규칙입니다.
# ┃    (예: 키에 따옴표가 없는 경우 등)
JSON_PREPROCESSING_EXCEPTIONS = {
    # 'strings/tips.json': {'skip_unquoted_key_correction'}
    }
# ┏━ 3c-1. JSON 후처리 규칙 (주로 Apply에서 사용) 
JSON_POSTPROCESSING_RULES = {
    'strings/tips.json': {'restore_unquoted_keys': ['tips']}
}


# ┏──────────────────────────────────────────────────────────────────────────┐
# ┃
# ┃ --- 3d. 후처리 필터링 규칙 (고급) ---
# ┃
# ┃ Export 완료 후, 추출된 text_en이 아래 규칙과 일치하면 '검토 필요' 항목으로 분류됩니다.
# ┃ 이는 코드나 개발자용 텍스트가 번역 대상에 포함되는 것을 방지하기 위한 안전장치입니다.
# ┃
POST_FILTER_EXCLUSION_RULES = {
    
    # 키: 'type' 필드의 값 (소문자)
    # 값: 정규식 패턴 리스트 (대소문자 무시, re.DOTALL 활성화)
    'options': [
        r'^\s*(set|jump|go|return|fire|unset|removeoption)\s*$', # 문자열 전체가 명령어 하나로만 구성된 경우
        r'^\s*dev\s', # DEV로 시작
        r'page\s\d+', # 'page 1' 과 같은 패턴 포함
        r'>> \(dev\)', # '>> (dev)' 포함
    ],
    'text': [
        # --- 기존 규칙 (유지) ---
        r'^\s*\$?[a-zA-Z0-9_.]+\s*=\s*.+', # 'player.met... = true' 같은 할당문
        r'^\s*dev\s', # DEV로 시작
        r'RaoDevOptionHub\d', # 'RaoDevOptionHub1' 같은 ID성 텍스트
        r'^\s*done\s*$', # "done"만 있는 경우

        # --- 수정 및 추가된 규칙 (안전성 강화) ---
        r'done\s*\(but', # 'done (but...' 같은 디버그 메시지 (문자열 중간에서도 감지)
        r'did \\nunset', # 이스케이프된 멀티라인 unset (정확한 데이터 형식 매칭)
        r'player\.gaveStandfastGuns\+\+', # "player.gaveStandfastGuns++"
        r'(player\.[a-zA-Z0-9_]+\s+set\s+to\s+(true|false))', # 'player.metStandfast set to true' 같은 패턴
        r'Set the following:', # 명백한 개발자용 지시문
        r'player set to have given', # 개발자용 상태 설정 메시지
        r'made \s+[A-Z_]+\s+visible', # [핵심 수정] 'made ZGR visible'과 같이 더 구체적인 패턴으로 변경
        r'Set player encountered Weird', # "Set player encountered Weird..."
    ],
    'script': [
        # 스크립트 코드 패턴 (최후의 방어선)
        r'^\s*\$[a-zA-Z0-9_.]+\s*=\s*.+$', # $변수 = 값 할당
        r'^\s*(Call|FireAll|FireBest|AdjustRep|RemoveOption|AddRemoveAnyItem|BeginMission|EndConversation|ShowPersonVisual|SetPersonHidden|AddCredits|RemoveCommodity|DoCanAffordCheck)\s+.*', # 함수 호출/명령어
        r'^\s*\$global\..*$', # $global 변수 단독 사용
        r'^\s*\$player\..*$', # $player 변수 단독 사용
        r'^\s*BeginConversation\s', # BeginConversation으로 시작
        r'^\s*SetOptionColor\s', # SetOptionColor로 시작
        r'^\s*ShowImageVisual\s', # ShowImageVisual로 시작
        r'T\sH\sR\sE\sA\sT', # 'T H R E A T' 패턴
        r'^[\d,]+$', # 쉼표로 구성된 숫자 (예: 1,000)
        # --- [신규 추가] 추출된 "텍스트 조각(snippet)" 필터링을 위한 규칙 ---
        r'^(music|sound|sfx|ruka|runi)_',            # 리소스 ID 패턴 (예: music_...)
        r'\n',                                      # 멀티라인 스크립트 코드 (예: sfcmayflycmd kaboom\n...)
        # r'^[A-Z][a-z]+[A-Z][a-zA-Z]{5,}$',          # 카멜/파스칼 케이스 변수명 (예: AskOmiProbeOcuDestroy)
        r'^[a-zA-Z_]+,[a-zA-Z_]+$',                 # 쉼표로 구분된 명령어 목록 (예: hire,remove)
    ],
    'tip_json': [
        r'frequency of tips', # 기능 설명 팁
        r'json object instead of a string', # 기능 설명 팁
    ],
}

# ┏━ 후처리 필터에 의해 '검토 필요'로 분류된 항목을 저장할 파일의 접미사입니다.
REVIEW_NEEDED_FILENAME_SUFFIX = '_《0》_TODO_review_and_confirm.csv'

# ┏━ 모든 종류의 "검토 파일"에서 공통으로 사용할 단일 헤더
REVIEW_NEEDED_HEADERS = ['source_file', 'Translatable', 'id', 'type', 'text_en', 'text_kr']


# ┏──────────────────────────────────────────────────────────────────────────┐
# ┃
# ┃[ 4. 주요 기능 - EXPORT ]
# ┃
# ┃           메인 메뉴의 각 기능에 직접적으로 관련된 설정입니다.
# ┃
# ┏━ 4a. ▼ 다음 파일들이 수정될 때 백업 파일을 생성할지 여부:
# ┃     - _merged_kr.csv (Export 및 스테이징 작업 결과물)
# ┃     - _master_kr.csv (마스터 번역 파일)
# ┃     - _TODO_missing_translations.csv (번역 필요 항목)
# ┃     - _staging_master_kr.csv (스테이징 파일)
# ┃     백업 파일은 '파일이름_날짜시간.csv' 형식으로 생성됩니다.
# ┃     예시: mod_translation_source_kr_20240427_1530.csv
CREATE_BACKUP_FILE = True
# ┃
# ┏━ Export 종합 빌드 리포트의 콘솔 및 파일 출력 여부
# ┃  True: 리포트를 출력합니다.
# ┃  False: 리포트를 출력하지 않고 관련 로그를 건너뜁니다.
ENABLE_EXPORT_REPORT_OUTPUT = True
# ┃
# ┏━ [ 텍스트 추출 (Export) ] ─────────────────────────────────────────────
EXPORT_LOG_FILENAME = 'log_export.txt'
# ┃
# ┏━ 기본 데이터 헤더
OUTPUT_HEADERS = ['source_file', 'id', 'type', 'text_en', 'text_kr']
# ┃
# ┏━ 최종 마스터 파일 전용 헤더 (Translatable 포함)
MASTER_FILE_HEADERS = ['source_file', 'Translatable', 'id', 'type', 'text_en', 'text_kr']
# ┃
# ┏━ 스테이징 파일 전용 헤더 (Translatable 포함)
STAGING_FILE_HEADERS = ['source_file', 'Translatable', 'id', 'type', 'text_en', 'text_kr']
# ┃
# ┏━ [ 4b. Export 입력 파일 ( 마스터 번역 파일 ) ] ──────────────────────────────
# ┃    (현재 사용) 스크립트가 작업 시 기존 번역을 가져오기 위해 참고하는 '번역 라이브러리' 파일입니다.
# ┃    사용자가 수동으로 번역을 추가하거나 다른 소스에서 가져온 내용을 저장하는 용도입니다.
# ┃    모든 기능은 이 설정을 기준으로 마스터 파일을 찾습니다.
MASTER_FILENAME_SUFFIX = '_MASTER_LIB_kr.csv'
MASTER_FILENAME_SUFFIX_STATIC = 'mod__MASTER_LIB_kr.csv'
# ┃
# ┏━ 4c. (이름 변경 시 사용) '이름 일괄 변경' 기능이 찾을 '이전' 마스터 파일의 접미사입니다.
# ┃     아래에 설정된 이름의 마스터 파일은 'MASTER_FILENAME_SUFFIX'로 자동 변경 됩니다.
OLD_MASTER_FILENAME_SUFFIX = '_translation_source_kr.csv'
# ┃
# ┃
# ┏━ [ 4d. Export 출력 파일 (사용자 작업 대상) ] ─────────────────────────────────
# ┃    Export 실행 후, 사용자가 직접 내용을 수정해야 하는 파일들입니다.
# ┃
# ┏━ [ 4e. _missing_translations.csv: [번역 작업] 새로 번역이 필요한 항목 목록
# ┃    이 파일의 'text_kr' 열을 채우는 것이 주된 번역 작업입니다.
# MISSING_TRANSLATION_FILENAME = '_NEW_untranslated_from_data_en.csv'
MISSING_TRANSLATION_FILENAME = '_《11》_EMPTY_KR_from_EXPORT.csv'
MISSING_TRANSLATION_FILENAME_STATIC = 'mod_missing_translations.csv'
# ┃
# ┏━ ['마스터 파일 필터링' 기능이 생성할 검토 파일 접미사입니다.]
MASTER_REVIEW_NEEDED_FILENAME_SUFFIX = '_《0》_REVIEW_need_MASTER_LIB.csv'

# ┏━ ['마스터 파일 필터링' 기능이 생성할 '삭제된 항목' 백업 파일 접미사입니다.]
MASTER_PURGED_FILENAME_SUFFIX = '_《0》_MASTER_LIB_PURGED_items.csv'

# ┏━ ['승인 항목 재검토' 기능이 생성할 검토 파일 접미사입니다.]
MASTER_TRUE_REVIEW_FILENAME_SUFFIX = '_《0》_MASTER_TRUE_review.csv'

# ┏━ ['상태별 검토' 기능이 생성할 'False' 상태 검토 파일 접미사입니다.]
MASTER_FALSE_REVIEW_FILENAME_SUFFIX = '_《0》_MASTER_FALSE_review.csv'

# ┏━ ['마스터 파일 필터링' 기능의 로그 파일 이름입니다.]
MASTER_REVIEW_LOG_FILENAME = 'log_master_review.txt'
# ┃
# ┏━ _format_mismatches.csv: [수정 작업] 형식 변경으로 인해 검토가 필요한 항목 목록
# ┃     'text_en' 열 에서 [ESC] 태그 도입 등으로 인해 기존 번역과 형식이 맞지 않는 항목이 이곳에 분리됩니다.
MISMATCHED_FORMAT_FILENAME_SUFFIX = '_format_mismatches.csv'
MISMATCHED_FORMAT_HEADERS = ['source_file', 'id', 'type', 'new_text_en', 'old_text_en', 'text_kr']

# ┏━[ 4f.▼ Export 최종 결과물 ] ─────────────────────────────────────────────
# ┃    모든 번역 소스(작업 파일, 개인 라이브러리 등)가 통합된 최종 결과 파일입니다.
# ┃    코드가 추출하는 영어 원문, id, type은 이 파일이 최신 상태가 되므로, 매우 중요합니다.
# ┃    특별한 이유가 없는한 True로 설정해 두어야 합니다.
ENABLE_MERGE_OUTPUT = True
MERGED_FILENAME_SUFFIX = '_merged_kr.csv'
# ┃
# ┏━[True: Export 시 기존 _merged_kr.csv 파일을 번역 소스로 참고합니다. (데이터 보존에 유리)]
# ┃    False: 참고하지 않습니다. (과거의 잘못된 추출로부터 완전히 새로 시작할 때 유용)
EXPORT_REFERENCE_EXISTING_MERGED_FILE = False 

# ┏━[_TODO_... 파일에 번역을 채운 후 Export 실행 시, 해당 번역이 임시로 저장될 파일의 접미사입니다.]
PENDING_MERGE_FILENAME_SUFFIX = '_PENDING_merge.csv'

# ┏━[`USE_DYNAMIC_FILE_PATHS = False`일 때 사용할 고정된 병합 대기 파일 이름입니다.]
PENDING_MERGE_FILENAME_STATIC = 'mod_pending_merge.csv'

# ┏━[ 스테이징 마스터 파일의 접미사입니다.]
STAGING_MASTER_FILENAME_SUFFIX = '_STAGING_kr.csv'

# ┏━[1번 기능 Export 후 마스터 파일과의 차이점만 별도로 저장할 파일의 접미사입니다.]
# ┃    이 파일은 마스터 파일에 없는 신규 항목이나, 기존 항목과 내용이 달라진 항목을 기록만 합니다.
CHANGES_FILENAME_SUFFIX = '_※REPORT_Changes_for_MASTER.csv'

# ┏━[1번 Export 시, 마스터 파일에 이미 존재하지만 번역이 비어있는 항목을 저장할 파일의 접미사입니다.]
# ┃    이 파일은 마스터 파일에 번역이 비어있는 항목을 별도로 기록하여, 사용자가 나중에 검토할 수 있도록 돕습니다.
EMPTY_KR_FILENAME_SUFFIX = '_!!!_EMPTY_KR_from_MASTER_LIB.csv'

# ┏━[마스터 파일 메뉴의 '번역 없는 항목 추출' 기능이 생성할 파일의 접미사입니다.]
MASTER_EMPTY_KR_FILENAME_SUFFIX = '_《0》_EMPTY_KR.csv'

# ┏━[ Export 후 발견된 신규 항목 저장 파일 (사용자 편의용) ]
# ┃    Export 완료 후, 마스터 번역 파일에 없는 '새로운' 항목들을 이 파일에 기록합니다.
NEWLY_FOUND_ITEMS_FILENAME_SUFFIX = '_NEW_found_items.csv'

# ┏━[ Export 시 is_translatable() 필터에 의해 제외된 항목을 별도로 저장할 보고서 파일의 접미사입니다. ]
# ┃    이 파일은 번역 대상에서 제외된 항목들을 기록하여, 사용자가 나중에 검토할 수 있도록 돕습니다.
# ┃    오직 보고서 목적이며 추출/적용 및 다른 과정에서 사용되지 않습니다.
FILTERED_ITEMS_FILENAME_SUFFIX = '_《0》_FILTERED_from_EXPORT.csv'

# ┏━[ Export 시 [ESC] 태그 또는 따옴표 개수가 불일치하는 항목을 저장할 보고서 파일의 접미사입니다.
STRING_INTEGRITY_REPORT_SUFFIX = '_※REPORT_String_Integrity.csv'

# ┏━[ Apply 후 스킵된 항목을 기록할 파일의 접미사입니다.
APPLY_SKIPPED_REPORT_SUFFIX = '_※REPORT_APPLY_SKIPPED.csv'

# ┏━[ 마스터 파일 지능형 병합(Intelligent Merge) 실행 전 변경될 항목을 미리 보여줄 파일의 접미사입니다.
MASTER_MERGE_PREVIEW_FILENAME_SUFFIX = '_마스터 파일 지능형 병합 항목.csv'

# ┏━[4g. Export 필터링 규칙] ─────────────────────────────────────────────────
# ┃    추출 과정에서 특정 파일, 경로, 문자열 등을 번역 대상에서 제외하기 위한 규칙입니다.
PROCESSING_RULES = {
    # (Whitelist) 여기에 명시된 JSON 파일만 처리 대상으로 삼습니다.
    'INCLUDE_ONLY_JSON_FILES': {
        'strings/strings.json',
        'strings/ship_names.json',
        'strings/tips.json',
        'config/paintjobs/magic_paintjobs.csv',
        'campaign/channels.json',
        'config/chatter/characters/*.json'
        },

    # (Blacklist) 여기에 명시된 파일은 종류에 관계없이 통째로 건너뜁니다.
    'EXCLUDE_FILES': {
        'campaign/rules_backup.csv',
        'campaign/market_conditions_CN.csv',
        'campaign/special_items_CN.csv',
        'hulls/ship_data_bak (2).csv',
        'hulls/ship_data_with_English.csv',
        'shipsystems/ship_systems_backup.csv',
        '*_CN.*',
        'campaign/example.csv'
        },
    # 파일 내에 이미지/사운드 경로 같은 문자열이 있으면 해당 문자열만 제외합니다.
    'EXCLUDE_PATH_LIKE_STRINGS': {'.png', '.jpg', '.jpeg', '.fnt', '.wav', 'ogg', '.mp3'}
}
# 이 확장자를 가진 파일은 처리 대상에서 완전히 제외합니다.
EXCLUDE_EXTENSIONS_FROM_EXPORT = {'.py', '.exe', '.dll', '.zip'}
# 여기에 포함된 단어나 기호만으로 이루어진 문자열은 추출하지 않습니다.
NON_TRANSLATABLE_STRINGS = {",", "%", "su", "op", "/", "-", "+", ".", "(", ")", "is", "are", "has", "have", "it", "they", ":"}
# True로 설정 시, "50%", "-10.5%" 와 같이 숫자와 %로만 이루어진 문자열을 제외합니다.
EXCLUDE_PERCENTAGE_ONLY_STRINGS = True
# True로 설정 시, 파일 경로처럼 보이는 문자열(예: 'graphics/icons/...')을 제외합니다.
EXCLUDE_FILE_PATH_LIKE_STRINGS = True

# ┏───────────────────────────────────────────────────────
# ┃
# ┃            [ 5. Export 스크립트 처리 규칙 ]
# ┃
# ┃
# ┃    'rules.csv' 파일의 'script' 열처럼 코드와 텍스트가 섞인 데이터를
# ┃     안전하게 처리하기 위한 설정입니다.
# ┃
# ┣───────────────────────────────────────────────────────
# ┃
# ┣─ ▼ (안전장치) 이 목록에 있는 명령어로 시작하는 줄의 텍스트만 번역 대상으로 추출합니다.
# ┃    이를 통해 순수한 코드가 번역되는 것을 방지합니다.
COMMANDS_WITH_TRANSLATABLE_TEXT = {
    'addtext',
    'addtextsmall',
    'setstoryoption',
    'sfcoptionconfirm',
    'settexthighlights',
    'SetTooltipHighlights',
    'addbarevent',
    'settooltip',
    'highlight',
    'settext'
}
# ┣━ ▼ 하나의 셀에서 여러 텍스트가 추출될 때, 이를 구분하기 위한 내부 구분자입니다.
# ┃     번역 텍스트에 절대 포함되지 않을 고유한 문자열이어야 합니다.
SCRIPT_TEXT_DELIMITER = '|||'
# ┃
# ┏━ [ 5a. Export 기타 옵션 ]
# ┃
# ┏━ ▼ True: data_en에서 순수하게 텍스트만 추출한 원본(_translation_source.csv) 생성 (디버깅용)
EXPORT_CREATE_PRISTINE_EXTRACT = False
EXPORT_OUTPUT_FILENAME = '_translation_source.csv'
EXPORT_OUTPUT_FILENAME_STATIC = 'mod_translation_source.csv'
# ┃
# ┏━ ▼ (오래된 설정 - 현재 로직에서 사용되지 않을 수 있음. 향후 제거 고려)
ENSURE_QUOTES_IN_TRANSLATION = True
# ┏━ ▼ (오래된 설정 - 현재 로직에서 사용되지 않을 수 있음. 향후 제거 고려)
UNESCAPE_DOLLAR_VARIABLES_IN_KR = True


# ┏───────────────────────────────────────────────────────
# ┃
# ┃     6. 'data'에서 번역 역추출 관련 설정 (Reverse-Extract)
# ┃
# ┃
# ┃    기존에 번역된 'data' 폴더 등을 분석하여 마스터 번역 파일을 생성/업데이트하는 데
# ┃    사용될 검토용 파일들을 추출하는 기능입니다.
# ┃
# ┣───────────────────────────────────────────────────────
# ┃
# ┏━ (선택 사항) 'data' 폴더 대신 역추출할 대체 번역 폴더의 이름을 지정합니다.
# ┃     (예: './data_kr') 비워두면 기본 'data' 폴더를 사용합니다.
REVERSE_EXTRACT_ALT_SOURCE_FOLDER = './data_kr'
# ┃
# ┏━ (성공) 구조적으로 완벽히 일치하는 번역 항목을 저장할 파일 접미사
REVERSE_EXTRACT_SUCCESS_SUFFIX = '_rev_SUCCESS_kr.csv'
# ┃
# ┏━ [ True: 역추출 시 _rev_mismatched_kr.csv 파일을 생성합니다. ]
# ┃    False: 해당 파일 생성을 건너뜁니다.
REVERSE_EXTRACT_GENERATE_MISMATCH_FILE = False
# ┏━ (불일치) 원본 영문이 변경된 것으로 의심되는 항목을 저장할 파일 접미사
REVERSE_EXTRACT_MISMATCH_SUFFIX = '_rev_mismatched_kr.csv'
# ┃
# ┏━ (고아) 원본(data_en)에 더 이상 존재하지 않는 과거 번역 항목을 저장할 파일 접미사
REVERSE_EXTRACT_ORPHAN_SUFFIX = '_rev_orphans_kr.csv'
# ┃
# ┏━ [ 고아 데이터 text_en 복원 결과 파일 ]
# ┃  '고아 데이터 text_en 역추적' 기능이 생성하는 두 가지 결과 파일의 이름 접미사입니다.
# ┃  
# ┃  (복원 성공) 역추적에 성공하여 text_en 필드가 올바르게 복원된 고아 항목 목록
# ┃  이 파일의 내용을 검토하여 마스터 번역 파일에 병합하는 것을 권장합니다.
REVERSE_EXTRACT_RECOVERED_SUFFIX = '_rev_orphans_recovered_en.csv'
# ┏━ (복원 실패) _rev_orphans_kr.csv에 위치 정보는 있었으나, data_en 폴더에서
# ┃  일치하는 text_en을 찾지 못한 '진짜' 고아 항목 목록
REVERSE_EXTRACT_UNRECOVERED_SUFFIX = '_rev_orphans_unrecovered.csv'


# ┏──────────────────────────────────────────────────────────────────────────┐
# ┃
# ┃     7. 번역 적용 (Apply)
# ┃
# ┗──────────────────────────────────────────────────────────────────────────┘
APPLY_LOG_FILENAME = 'log_apply.txt'
TRANSLATED_DATA_FOLDER = './data' # 번역 결과물이 생성될 폴더 이름
# │
# ┏━ 4g. Apply 입력 파일
# ┃  어떤 파일을 번역의 주 소스로 사용할지 지정합니다.
# ┃  동적 이름 생성, USE_DYNAMIC_FILE_PATHS = True 인 경우
# ┃  ※[주의] 안정성을 위해 'MASTER_FILENAME_SUFFIX' 사용을 권장합니다.
APPLY_TRANSLATION_FILENAME_SUFFIX = MASTER_FILENAME_SUFFIX 
# │
# ┏━ 정적 이름 사용, USE_DYNAMIC_FILE_PATHS = False 인 경우
# ┃  ※[주의] 안정성을 위해 'mod_merged_kr.csv' 사용을 권장합니다.
APPLY_TRANSLATION_FILENAME_STATIC = 'mod_merged_kr.csv'
# │
# ┏━ 77번 기능의 스테이징 결과물이 출력될 폴더 이름입니다.
STAGING_OUTPUT_FOLDER = './data_staging'
# │
# ┏━ Apply 처리 규칙
# ┃  번역문을 최종 파일에 쓸 때 적용되는 형식 변환 규칙입니다.
# ┃
# ┃  True: 번역문의 '\n' 텍스트를 실제 줄바꿈 문자로 복원하여 게임 내에서 올바르게 표시되도록 합니다.
APPLY_RESTORE_NEWLINES = True
# │
# ┏━ True: 모든 비-ASCII 문자(한글 등)를 \uXXXX 형태로 변환합니다. (구형 시스템 호환용)
APPLY_JSON_ENSURE_ASCII = False
# │
# ┏━ True: 타이포그래피용 둥근 따옴표(“ ”)를 프로그래밍 표준 직선 따옴표(")로 자동 변환합니다.
APPLY_NORMALIZE_QUOTES = True
# │
# ┏━ APPLY_JSON_ENSURE_ASCII가 False일 때, 특정 문자만 강제로 이스케이프하여 원본 스타일을 유지합니다.
CHARS_TO_ESCAPE_IN_JSON = {
    '—': '\\u2014', # em dash
    '“': '\\u201c', # left double quotation mark
    '”': '\\u201d', # right double quotation mark
    '…': '\\u2026', # horizontal ellipsis
}


# ┏──────────────────────────────────────────────────────────────────────────┐
# ┃
# ┃ [ 지정 파일 테스트 전용 설정 ]  <-- 새로 추가
# ┃
# ┗──────────────────────────────────────────────────────────────────────────┘
# 지정 파일 테스트시 출력되는 로그 파일 이름
FILE_SPECIFIC_TEST_LOG_FILENAME = 'log_file_specific_test.txt'




# ┏──────────────────────────────────────────────────────────────────────────┐
# ┃
# ┃     9. 데이터 검사 및 유지보수 (Check & Update)
# ┃
# ┗──────────────────────────────────────────────────────────────────────────┘
# ┃    번역 데이터의 일관성을 유지하고, 시간이 지나면서 불필요해진 데이터를
# ┃    안전하게 정리하는 기능과 관련된 설정입니다.
# ┃
# ┏━ 9a. 'Check' 기능이 생성하는 상세 보고서 파일의 이름입니다.
# ┃  텍스트 불일치(mismatch)와 고아 데이터(orphan)의 전체 목록이 기록됩니다.
CONSISTENCY_CHECK_LOG_FILENAME = 'log_consistency_check.txt'
# ┃
# ┏━ 9b. 메인 메뉴의 5번 기능 Check와 8/9번 기능 Update/Sync 간의 데이터 전달 방식을 선택합니다.
# ┃  True:  분석 결과를 _check_cache.json 파일에 저장합니다. 
# ┃         스크립트를 재시작해도 데이터가 유지되어 더 안전하지만 약간 느릴 수 있습니다. (권장)
# ┃  False: 분석 결과를 메모리(전역 변수)에 저장합니다. 
# ┃         더 빠르지만, 스크립트가 종료되면 데이터가 사라집니다.
USE_FILE_BASED_CACHE = False # True 또는 False
# ┏━ 9c. Check 기능이 생성하는 임시 캐시 파일의 접미사입니다.
CHECK_CACHE_FILENAME_SUFFIX = '_check_cache.json'
# ┃
# ┏━ 9d. 'Check' 기능 실행 시, 검토가 필요한 고아 데이터(원본에 없는 과거 번역)를
# ┃  따로 저장할 파일의 이름 접미사입니다. 이 파일을 검토하여 8번 'Update' 기능으로
# ┃  정리할 항목을 결정할 수 있습니다.
ORPHAN_FILENAME_SUFFIX = '_orphans.csv'
# ┃
# ┏━ 9e. '마스터 파일 관리' 기능이 숫자 전용 항목을 분리하여 저장할 '트래시' 파일의 이름 접미사입니다.
PURGE_TRASH_FILENAME_SUFFIX = '_TRASH_and_BLACKLIST.csv'
# ┃
# ┏━ 9e-1. True로 설정 시, 위에서 정의된 트래시 파일이 Export/Apply 작업에서 자동으로 제외됩니다. (권장)
EXCLUDE_TRASH_FILE_FROM_PROCESSING = True

# ┏──────────────────────────────────────────────────────────────────────────┐
# ┃ [ 스테이징 및 데이터 Push 관리자 설정 (신규 섹션) ]
# ┃ 메인 메뉴 7번 기능과 관련된 모든 설정을 이곳에서 관리합니다.
# ┗──────────────────────────────────────────────────────────────────────────┘
# ┏━ [ 따옴표 정규화 대상 타입 (7-9-1번 기능용) ]
# ┃    7-9-1번 기능('type: text' 항목 정규화)이 적용될 'type' 컬럼의 값 목록입니다.
# ┃    여기에 포함된 타입들은 text_en의 따옴표 형태를 text_kr이 모방하게 됩니다.
NORMALIZE_QUOTES_TARGET_TYPES = ['text', 'desc', 'description', 'short', 'text1', 'text2', 'text3', 'name']


# ┏──────────────────────────────────────────────────────────────────────────┐
# ┃
# ┃ [ f, r. 파일 시스템 동기화 (FS Sync) ]
# ┃
# ┗──────────────────────────────────────────────────────────────────────────┘
# ┃    로컬 작업 폴더와 실제 게임의 모드 폴더 간에 원본 데이터('data_en' 또는 'data')를
# ┃    직접 복사하여 동기화하는 강력한 기능입니다.
# ┃    [!!] 주의: 이 기능들은 파일을 직접 덮어쓰므로, 용도를 정확히 이해하고 사용하십시오.
# ┃
# ┏━ 'r' Reverse Sync: 게임 폴더의 최신 원본('data')을 로컬('data_en')로 가져옵니다.
# ┃    (용도: 모드가 업데이트되었을 때, 최신 원본 파일을 받아오는 데 사용)
REVERSE_SYNC_LOG_FILENAME = 'log_reverse_sync.txt'
# ┃
# ┏━ 'f' Forward Sync: 로컬의 원본('data_en')을 게임 폴더('data')에 덮어씁니다.
# ┃    [!!] 위험: 이 기능은 실제 게임 모드 파일을 덮어쓰므로, 모드 개발자나 고급 사용자만
# ┃         사용하는 것을 권장합니다.
FORWARD_SYNC_LOG_FILENAME = 'log_forward_sync.txt'


# ┏───────────────────────────────────────────────────┐
# ┃
# ┃           [ 동적 설정 적용 - 시작 ]
# ┃

# 사용자 설정에 따라 처리 규칙을 동적으로 수정합니다.
if 'PURGE_TRASH_FILENAME_SUFFIX' in globals() and EXCLUDE_TRASH_FILE_FROM_PROCESSING:
    # 모든 모드 폴더 내의 트래시 파일을 제외하기 위해 와일드카드 패턴을 사용합니다.
    # 예: */mod_MyMod_TRASH_from_MASTER.csv
    trash_file_pattern = f"*{PURGE_TRASH_FILENAME_SUFFIX}"
    
    # 'EXCLUDE_FILES' 키가 없으면 새로 생성합니다.
    if 'EXCLUDE_FILES' not in PROCESSING_RULES:
        PROCESSING_RULES['EXCLUDE_FILES'] = set()
        
    PROCESSING_RULES['EXCLUDE_FILES'].add(trash_file_pattern)


# ┏───────────────────────────────────────────────────┐
# ┃
# ┃               [ 통합 캐시 변수 ]
# ┃

TAG_QUOTE_DOUBLE = '[Q2]'
TAG_QUOTE_TRIPLE = '[Q3]'

    
# ==============================================================================
#
#                         범용 리포팅 프레임워크 설정
#
# ==============================================================================

# 리포트에서 사용할 번역 키-값 사전
REASON_TRANSLATIONS = {
    'NumericOnly': '순수 숫자',
    'PercentageOnly': '퍼센트 형식',
    'RgbColorCode': 'RGB 색상 코드',
    'Assignment': '변수 할당문',
    'FunctionCall': '스크립트 함수 호출',
    'GlobalVar': '전역 변수 사용',
    'PlayerVar': '플레이어 변수 사용',
    'BeginConversation': '대화 시작 명령어',
    'SetOptionColor': '옵션 색상 설정 명령어',
    'ShowImageVisual': '이미지 표시 명령어',
    'ThreatPattern': '위협 패턴 텍스트',
    'PureNumberString': '순수 숫자 문자열',
    'SingleDollarVariable': '단일 $변수',
    'NonTranslatableString': '비번역 가능 단어/기호',
    'Unknown': '알 수 없음'
}

  
class AppState:
    """
    [신규 서비스] 스크립트의 전역 상태(캐시, 커맨드 히스토리 등)를
    중앙에서 관리하는 클래스.
    """
    def __init__(self):
        self.cache = {}
        self.command_history = []
        self.history_index = -1

    def get_cache(self):
        return self.cache

    def set_cache(self, data):
        self.cache = data

    def clear_cache(self):
        self.cache.clear()

# 전역 상태 관리 인스턴스 생성
app_state = AppState()

# ┏───────────────────────────────────────────────────┐
# ┃
# ┃               [ 중앙 로깅 서비스 ]
# ┃
class LoggerService:
    _logger = None
    _aux_loggers = {}
    
    @staticmethod
    def setup(log_filename, level='NORMAL', is_test_run=False, log_dir=None):
        """[수정] 이 함수는 이제 오직 메인 로거만 설정합니다."""
        if log_dir is None:
            log_dir = os.getcwd()

        logger = logging.getLogger('TranslationTool')
        
        if logger.hasHandlers():
            logger.handlers.clear()
            
        level_map = {'NORMAL': logging.INFO, 'DETAIL': logging.DEBUG, 'DEBUG': logging.DEBUG}
        log_level = level_map.get(str(level).upper(), logging.INFO)
        logger.setLevel(log_level)
        
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

        if not is_test_run and log_filename:
            log_path = os.path.join(log_dir, log_filename)
            file_handler = logging.FileHandler(log_path, mode='w', encoding='utf-8')
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        
        LoggerService._logger = logger
        return logger

    @staticmethod
    def get_logger():
        if LoggerService._logger is None:
            print("경고: LoggerService가 setup()되지 않았습니다. 기본 콘솔 로거를 사용합니다.")
            return LoggerService.setup(log_filename=None, level='DEBUG', is_test_run=True)
        return LoggerService._logger

    @staticmethod
    def get_or_create_aux_logger(name, filename, base_path):
        """
        [복원 및 완성] 지정된 이름의 독립적인 보조 로거를 가져오거나 새로 생성합니다.
        이 로거는 메인 LOGGING_LEVEL과 무관하게 항상 DEBUG 레벨로 작동합니다.
        """
        if name in LoggerService._aux_loggers:
            return LoggerService._aux_loggers[name]

        logger = logging.getLogger(name)
        logger.setLevel(logging.DEBUG)
        logger.propagate = False # [매우 중요] 메시지가 메인 로거로 전파되는 것을 방지

        if logger.hasHandlers():
            logger.handlers.clear()

        # 보조 로거는 파일 핸들러만 가집니다.
        log_path = os.path.join(base_path, filename)
        formatter = logging.Formatter('%(asctime)s [TIPS-DEBUG] - %(message)s', datefmt='%H:%M:%S')
        file_handler = logging.FileHandler(log_path, mode='w', encoding='utf-8')
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

        LoggerService._aux_loggers[name] = logger

        # 즉각적인 피드백
        main_logger = LoggerService.get_logger()
        main_logger.info("="*60)
        main_logger.info(f"[알림] TIPS.JSON 전용 디버그 파일 로깅이 활성화되었습니다.")
        main_logger.info(f" -> 로그 파일: {os.path.abspath(log_path)}")
        main_logger.info("="*60)
        
        header_message = f"TIPS.JSON Debug Log Session Started at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        logger.debug("-" * len(header_message))
        logger.debug(header_message)
        logger.debug("-" * len(header_message))
        return logger
        
    @staticmethod
    def close_aux_loggers():
        """[신규] 모든 보조 로거의 핸들러를 닫고 정리하여 파일 핸들을 해제합니다."""
        logger = LoggerService.get_logger()
        logger.debug("모든 보조 로거를 정리하고 파일 핸들을 해제합니다...")
        
        for name, aux_logger in list(LoggerService._aux_loggers.items()):
            for handler in list(aux_logger.handlers):
                try:
                    handler.close()
                    aux_logger.removeHandler(handler)
                except Exception as e:
                    logger.warning(f"  -> 보조 로거 '{name}'의 핸들러 정리 중 오류 발생: {e}")
        
        LoggerService._aux_loggers.clear()
        logger.debug(" -> 보조 로거 정리가 완료되었습니다.")

# 1. 전략 인터페이스 (ITextProcessingStrategy)
# (abc 모듈 import는 파일 상단에 이미 있으므로 생략)
class ITextProcessingStrategy(ABC):
    """모든 텍스트 처리 전략이 따라야 하는 공통 인터페이스입니다."""
    @abstractmethod
    def process(self, text, item_type=''):
        pass


############################################################################
#
#        [ ARCHITECTURAL DIRECTIVE - TEXT_PROCESSOR_V3_PRESERVE_WHITESPACE ]
#
# TARGET: text_processor_service.process(), LegacyHybridStrategy._process_legacy(), LegacyHybridStrategy.process()
# STATUS: FINALIZED (Type-aware Whitespace Handling Applied)
# ROLE: Central text normalization engine with type-aware whitespace handling.
#
# BEHAVIOR:
#   이 프로세서는 `item_type`에 따라 동작을 구분해야 한다. `item_type`이 'json' 또는 'tip_json' 등 JSON 관련 타입일 경우,
#   문자열 값 내부의 앞/뒤 공백(.strip())을 **제거해서는 안 된다.** 그 외 다른 모든 타입(예: 'text', 'script', 'options')에 대해서는
#   기존과 같이 `.strip()`을 적용하여 데이터를 정리해야 한다.
#
# DESIGN_CHOICE:
#   `config/chatter/characters/sfcarthur.json`의 `sfc_solarlivery4` 사례에서 확인된 바와 같이, JSON 문자열 값 내의 공백은 의도적인 서식일 수 있다.
#   따라서 JSON 타입에 한해 공백을 보존하여 데이터 무결성을 확보한다. 다른 타입에 대해서는 불필요한 공백을 제거하는 기존의 정리(sanitization) 동작을 유지하여,
#   '타입별 차등 처리' 원칙을 적용한다.
#
# MODIFICATION_PROTOCOL:
#   향후 공백 보존이 필요한 새로운 파일 타입이 추가될 경우, 해당 `item_type`을 `LegacyHybridStrategy.process()` 내부의 공백 보존 타입 목록에 추가해야 한다.
#
############################################################################
class LegacyHybridStrategy(ITextProcessingStrategy):
    """
    [v2.3 - 공백 보존] 'json' 계열 타입에 대해 앞/뒤 공백을 보존하도록 수정합니다.
    'type: text' 줄바꿈 태그를 사용자 설정에서 가져옵니다.
    """
    def _process_legacy(self, text):
        """[v2.2] JSON/CSV 텍스트를 위한 중앙 정규화 엔진 (공백 제거 제외)."""
        if not isinstance(text, str):
            return ""
        
        text = text.lstrip('\ufeff') # BOM 문자 제거

        # 1단계: JSON 값 문자열에 사용되는 이스케이프 시퀀스를 실제 문자로 변환
        text = text.replace('\\"', '"').replace('\\\\', '\\').replace('\\/', '/')
        # 2단계: 주요 유니코드 이스케이프 시퀀스를 실제 문자로 변환
        text = text.replace('\\u2014', '—').replace('\\u201c', '“').replace('\\u201d', '”').replace('\\u2026', '…')
        # 3단계: 모든 줄바꿈 문자를 통일하고, CSV 저장을 위해 다시 이스케이프
        text = text.replace('\r\n', '\n').replace('\r', '\n')
        text = text.replace('\n', '\\n')

        # 최종 공백 제거 로직을 이 함수에서 제거하고, process() 메서드로 책임을 이전합니다.
        return text

    def process(self, text, item_type=''):
        """
        [v2.3] item_type에 따라 차등적으로 공백을 처리하는 중앙 처리 메서드.
        """
        if not isinstance(text, str):
            return ""
        
        # 공백 보존이 필요한 JSON 관련 타입 목록
        # .startswith() 대신 정확한 매칭을 위해 집합(set) 사용
        WHITESPACE_PRESERVING_TYPES = {
            'json', 'tip_json', 'tip_json_str', 'generic_name', 'scopeStr', 
            'json_selective', 'generic_regex' # 다른 JSON 관련 타입도 추가
        }
        
        # 'item_type'에서 'script:1'과 같은 접미사를 제거하고 기본 타입만 사용
        base_type = (item_type or '').lower().split(':')[0]

        # 1. 'text' 타입의 CSV 컬럼에 대한 특별 처리 (기존 로직 유지)
        if base_type == 'text':
            processed_text = standardize_newlines(text, tag=NEWLINE_TAG_FOR_TEXT_TYPE)
            # 'text' 타입은 항상 공백을 제거합니다.
            return processed_text.strip()
        
        # 2. 그 외 모든 타입(json, script 등)에 대한 일반 처리
        processed_text = self._process_legacy(text)

        # 3. 타입에 따라 조건부로 최종 공백 제거 적용
        if base_type in WHITESPACE_PRESERVING_TYPES:
            return processed_text  # 공백 보존
        else:
            return processed_text.strip() # 기본적으로 공백 제거

# 3. 중앙 서비스 클래스 (TextProcessorService)
class TextProcessorService:
    """
    텍스트 처리의 '단일 진실 공급원' 역할을 하는 서비스 클래스입니다.
    설정에 맞는 전략을 선택하고 실행을 위임합니다.
    """
    def __init__(self, mode):
        self._strategy = self._select_strategy(mode)
        self.logger = LoggerService.get_logger()
        self.logger.info(f" -> 텍스트 처리 엔진 초기화 완료 (모드: {mode})")

    def _select_strategy(self, mode):
        if mode == 'LEGACY_HYBRID':
            return LegacyHybridStrategy()
        else:
            self.logger.error(f" [!] 치명적 오류: USER SETTINGS에 알 수 없는 텍스트 처리 모드('{mode}')가 지정되었습니다.")
            raise ValueError(f"알 수 없는 텍스트 처리 모드입니다: {mode}")

    def process(self, text, item_type=''):
        """선택된 전략을 사용하여 텍스트를 처리합니다."""
        return self._strategy.process(text, item_type)

    def restore_newlines(self, text, item_type=''):
        """
        [신규 메서드] 텍스트 내의 줄바꿈 태그를 실제 줄바꿈('\n') 문자로 복원합니다.
        (Apply 시 사용)
        """
        if not isinstance(text, str):
            return ""
        
        # 1. 공백 제거 (text_processor_service.process에서 strip()된 것을 복구)
        # Apply 시점에 text_kr은 이미 processed 상태로 넘어오므로, 
        # 복원 단계에서는 공백 처리가 필요 없습니다.
        
        # 2. 'type: text' 항목의 NEWLINE_TAG_FOR_TEXT_TYPE 태그 복원
        if item_type.lower().startswith('text'):
            return text.replace(NEWLINE_TAG_FOR_TEXT_TYPE, '\n')
        
        # 3. 그 외 항목의 '\\n' 문자열 복원
        else:
            return text.replace('\\n', '\n')

# 4. 전역 서비스 인스턴스 생성
text_processor_service = TextProcessorService(mode=TEXT_PROCESSING_MODE)

# ┏───────────────────────────────────────────────────┐
# ┃
# ┃ [ 특정 기능 범위(Scope)에 대한 상세 디버그 로깅 클래스 ]
# ┃
class ScopedLogger:
    """
    특정 기능 범위(Scope)에 대한 상세 디버그 로깅을 담당하는 클래스.
    활성화 플래그, 파일 로깅 여부 등의 상태를 캡슐화합니다.
    """
    def __init__(self, name, debug_flag, log_to_file_flag, filename):
        self.name = name
        self.is_enabled = debug_flag
        self.log_to_file = log_to_file_flag
        self.filename = filename
        self.base_path = None
        self.logger_instance = None
        self.console_prefix = f"[{self.name.upper()}-DEBUG-CONSOLE]"

    def log(self, message, base_path=None):
        """지정된 메시지를 콘솔 및/또는 파일에 기록합니다."""
        if not self.is_enabled:
            return

        if base_path and self.base_path != base_path:
            self.base_path = base_path
            # base_path가 변경되면 로거 인스턴스를 재생성해야 할 수 있으므로 초기화
            self.logger_instance = None
        
        print(f"{self.console_prefix} {message}")

        if self.log_to_file:
            if not self.base_path:
                print(f"치명적 오류: {self.name} 디버그 로거 최초 초기화 시 base_path가 필요합니다.")
                return
            
            if not self.logger_instance:
                self.logger_instance = LoggerService.get_or_create_aux_logger(
                    name=self.name, 
                    filename=self.filename, 
                    base_path=self.base_path
                )
            self.logger_instance.debug(message)
# ┃
# ┗───────────────────────────────────────────────────┘

# ┏───────────────────────────────────────────────────┐
# ┃
# ┃            [ 파일 I/O 서비스 클래스 ]
# ┃
class CsvFileService:
    """
    (v4.26.28 신규) 모든 CSV 파일 읽기/쓰기/추가 작업을 중앙에서 관리하는 서비스 클래스.
    자동 헤더 감지, 중복 없는 추가, 자동 백업 기능을 제공하여 파일 I/O의 안정성과 유연성을 높입니다.
    """
    def __init__(self, output_encoding, input_encoding, create_backup=True):
        self.output_encoding = output_encoding
        self.input_encoding = input_encoding
        self.create_backup_enabled = create_backup # 전역 설정 CREATE_BACKUP_FILE 사용
        self.logger = LoggerService.get_logger()
        # [신규 추가] _main_cache는 이제 CsvFileService 내부에 포함되지 않습니다.

    def _create_timestamped_backup(self, file_path, is_test_run=False):
        """
        주어진 파일에 대한 타임스탬프 기반 백업을 'backups' 하위 폴더에 생성합니다.
        self.create_backup_enabled 설정에 따라 동작합니다.
        """
        if not self.create_backup_enabled:
            return

        if is_test_run:
            self.logger.debug(f" -> [테스트 모드] '{os.path.basename(file_path)}'의 타임스탬프 백업 생성을 건너뜁니다.")
            return

        if not os.path.exists(file_path):
            self.logger.debug(f" -> 백업 원본 파일 '{os.path.basename(file_path)}'이(가) 없어 백업을 건너뜁니다.")
            return

        try:
            base_dir = os.path.dirname(file_path)
            backup_dir = os.path.join(base_dir, 'backups')
            os.makedirs(backup_dir, exist_ok=True) # backups 폴더가 없으면 생성

            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            original_name, extension = os.path.splitext(os.path.basename(file_path))
            
            backup_filename = f"{original_name}_{timestamp}{extension}"
            backup_path = os.path.join(backup_dir, backup_filename)
            
            shutil.copy2(file_path, backup_path)
            self.logger.info(f" -> 기존 파일을 '{os.path.join('backups', backup_filename)}'(으)로 백업했습니다.")
        except Exception as e:
            self.logger.error(f"  [오류] 파일 백업 중 오류가 발생했습니다: {e}")

    def load_rows_from_csv(self, file_path, encoding=None):
        """
        (구 _load_csv_to_list_of_dicts 대체) CSV 파일을 읽어 [{}, {}, ...] 형태의 리스트로 반환합니다.
        헤더가 없는 경우 빈 리스트를 반환합니다.
        """
        if encoding is None:
            encoding = self.input_encoding
        
        if not os.path.exists(file_path):
            return []
        try:
            with open(file_path, 'r', encoding=encoding, newline='') as f:
                reader = csv.DictReader(f)
                if reader.fieldnames: # 헤더가 있는 경우에만 데이터를 로드
                    return list(reader)
                return []
        except Exception as e:
            self.logger.error(f" [!] '{os.path.basename(file_path)}' 파일 로드 중 오류: {e}")
            return []

    def write_rows_to_csv(self, file_path, data_list, headers=None, auto_detect_headers=True, create_backup_on_write=False, is_test_run=False, sort_data=True):
        """
        (v2 - sort_data 인자 추가) 주어진 데이터를 CSV 파일에 안전하게 씁니다.
        자동 헤더 감지, 백업 생성, 테스트 모드 지원.
        """
        if is_test_run:
            self.logger.info(f"테스트 모드: '{os.path.basename(file_path)}'({len(data_list)} 행) 쓰기 건너뜀.")
            return

        if create_backup_on_write:
            self._create_timestamped_backup(file_path, is_test_run)

        if not data_list:
            if os.path.exists(file_path):
                os.remove(file_path)
                self.logger.debug(f" -> 항목이 없어 '{os.path.basename(file_path)}' 파일을 삭제했습니다.")
            return
        
        # 헤더 결정
        final_headers = headers
        if auto_detect_headers and not final_headers and data_list:
            # 첫 번째 행에서 모든 키를 헤더로 사용
            final_headers = list(data_list[0].keys())

        if not final_headers:
            self.logger.warning(f" [!] '{os.path.basename(file_path)}'에 쓸 헤더가 없어 파일 쓰기를 건너뜁니다.")
            return

        try:
            # sort_data 플래그에 따라 조건부로 정렬 수행
            data_to_write = data_list
            if sort_data:
                # 쓰기 전에 데이터를 정렬하여 파일 내용의 일관성을 유지합니다.
                data_to_write = sorted(data_list, key=lambda x: (x.get('source_file', ''), x.get('id', '')))
            
            with open(file_path, 'w', encoding=self.output_encoding, newline='') as f:
                writer = csv.DictWriter(f, fieldnames=final_headers)
                writer.writeheader()
                writer.writerows(data_to_write) # 정렬되었거나, 원본 순서 그대로의 데이터를 씀
            self.logger.debug(f" -> '{os.path.basename(file_path)}' 파일에 {len(data_list)}개 항목 쓰기 완료 (정렬: {sort_data}).")
        except Exception as e:
            self.logger.error(f" [!] '{os.path.basename(file_path)}' 파일 쓰기 중 오류 발생: {e}")

    def append_rows_to_csv_without_duplicates(self, file_path, data_list, headers=None, auto_detect_headers=True, create_backup_on_write=False, is_test_run=False):
        """
        (구 append_csv_without_duplicates 대체) 지정된 CSV 파일에 중복되지 않는 데이터만 안전하게 추가(append)합니다.
        헤더 자동 감지, 백업 생성, 테스트 모드 지원.
        """
        if is_test_run:
            self.logger.info(f"테스트 모드: '{os.path.basename(file_path)}'에 {len(data_list)} 행 추가 작업을 건너뜀.")
            return 0

        if not data_list:
            return 0

        existing_rows_set = set()
        file_exists = os.path.isfile(file_path)

        # 1. 기존 파일이 있으면, 중복 검사를 위해 내용을 메모리에 로드
        existing_data = self.load_rows_from_csv(file_path)
        for row in existing_data:
            # [수정] 모든 키와 값을 문자열로 변환하여 해시 가능하게 만듦
            hashable_row = {str(k): str(v) for k, v in row.items()}
            existing_rows_set.add(tuple(sorted(hashable_row.items())))

        # 2. 추가할 데이터 중 정말 새로운 항목만 필터링
        new_rows_to_write = []
        for row in data_list:
            # [수정] 모든 키와 값을 문자열로 변환하여 해시 가능하게 만듦
            hashable_row_to_add = {str(k): str(v) for k, v in row.items()}
            row_tuple = tuple(sorted(hashable_row_to_add.items()))
            if row_tuple not in existing_rows_set:
                new_rows_to_write.append(row) # 원본 row를 추가 (문자열 변환된 것 말고)
                existing_rows_set.add(row_tuple)

        if not new_rows_to_write:
            self.logger.info(f" -> '{os.path.basename(file_path)}'에 추가할 새로운 항목이 없습니다 (모두 중복).")
            return 0
        
        # 헤더 결정
        final_headers = headers
        if auto_detect_headers and not final_headers and (existing_data or new_rows_to_write):
            if existing_data:
                # [안전장치] 헤더에 None이 포함될 경우를 대비
                final_headers = [str(h) for h in existing_data[0].keys()]
            elif new_rows_to_write:
                final_headers = list(new_rows_to_write[0].keys())
        
        if not final_headers:
            self.logger.warning(f" [!] '{os.path.basename(file_path)}'에 추가할 헤더가 없어 파일 추가를 건너뜁니다.")
            return 0

        # 3. 필터링된 새 데이터만 파일에 추가
        try:
            if create_backup_on_write:
                self._create_timestamped_backup(file_path, is_test_run)

            with open(file_path, 'a', encoding=self.output_encoding, newline='') as f:
                writer = csv.DictWriter(f, fieldnames=final_headers)
                if not file_exists or not existing_data:
                    writer.writeheader()
                writer.writerows(new_rows_to_write)
            
            self.logger.info(f" -> '{os.path.basename(file_path)}'에 {len(new_rows_to_write)}개의 새로운 항목을 추가했습니다.")
            return len(new_rows_to_write)
        except Exception as e:
            self.logger.error(f" [!] 파일 '{os.path.basename(file_path)}'에 쓰는 중 오류 발생: {e}")
            return 0

class SelectiveDeployService:
    """
    [신규 서비스] 선택적 배포(selective_deploy.json)에 대한 모든 읽기/쓰기 및
    유효 모드 스캔 로직을 중앙에서 관리하는 전담 서비스 클래스입니다.
    """
    def __init__(self, search_root_path: str, config_filename: str):
        self.search_root = os.path.abspath(search_root_path)
        self.config_path = os.path.join(self.search_root, config_filename)
        self.logger = LoggerService.get_logger()

    def load_targets(self) -> list:
        """selective_deploy.json 파일에서 배포 대상 모드 목록을 불러옵니다."""
        if not os.path.exists(self.config_path):
            return []
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                targets = json.load(f)
                return targets if isinstance(targets, list) else []
        except (json.JSONDecodeError, IOError) as e:
            self.logger.error(f" [!] '{os.path.basename(self.config_path)}' 파일 로딩 중 오류: {e}")
            return []

    def save_targets(self, mod_list: list):
        """배포 대상 모드 목록을 selective_deploy.json 파일에 저장합니다."""
        try:
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(sorted(mod_list), f, indent=4)
            self.logger.debug(f" -> 선택적 배포 목록을 '{os.path.basename(self.config_path)}'에 저장했습니다.")
        except IOError as e:
            self.logger.error(f" [!] '{os.path.basename(self.config_path)}' 파일 저장 중 오류 발생: {e}")

    def get_deployable_mods(self) -> list:
        """주어진 경로에서 배포 가능한 모든 유효한 모드 폴더 목록을 스캔하여 반환합니다."""
        valid_mods = []
        if not os.path.isdir(self.search_root):
            return []
            
        subdirs = [d for d in os.listdir(self.search_root) 
                   if os.path.isdir(os.path.join(self.search_root, d)) and d not in MOD_FOLDERS_TO_EXCLUDE]

        for mod_name in sorted(subdirs):
            mod_path = os.path.join(self.search_root, mod_name)
            # ValidationService를 직접 사용하여 유효성 검사
            if ValidationService(mod_path).for_deploy():
                valid_mods.append(mod_name)
                
        return valid_mods

class ApplyAnalyzer:
    """
    'Apply' 과정의 데이터 로딩을 분석하고 디버깅 정보를 수집하는
    중앙 분석기 클래스입니다.
    """
    def __init__(self, base_path):
        self.base_path = base_path
        self.logger = LoggerService.get_logger()
        
        # tips.json 관련 데이터
        self.tips_json_row_count = 0
        self.tips_translation_map_by_id = {}
        
        # strings.json 관련 데이터
        self.strings_json_x_count = 0

    def process_row(self, row, row_num, cleaned_source_file, cleaned_text_en, processed_text_kr):
        """
        CSV의 각 행을 입력받아, 파일 종류에 따라 분석 및 데이터 수집을 수행합니다.
        """
        translatable_status = row.get('Translatable', '').strip().lower()
        row_id = row.get('id', '')
        
        # --- tips.json 분석 로직 ---
        is_tips_file = 'tips.json' in cleaned_source_file
        if is_tips_file:
            self.tips_json_row_count += 1
            tips_scoped_logger.log(f"[LOAD_DATA] 행 #{row_num}: 'tips.json' 데이터 발견. ID: '{row_id}'", base_path=self.base_path)
            
            if processed_text_kr.strip() and translatable_status != 'x':
                self.tips_translation_map_by_id[row_id] = (cleaned_text_en, processed_text_kr)
        
        # --- strings.json 분석 로직 ---
        if "strings.json" in cleaned_source_file and translatable_status == 'x':
            self.strings_json_x_count += 1
                
    def generate_final_log_reports(self, translated_files, excluded_keys_by_file):
        """
        모든 데이터 처리가 끝난 후, 최종 분석/디버깅 로그를 출력합니다.
        """
        # [정밀 디버깅 로그]
        self.logger.debug("="*20 + " [ DEBUG: ApplyAnalyzer 최종 분석 ] " + "="*20)
        self.logger.debug(f"  - strings.json에서 'x'로 집계된 항목 수: {self.strings_json_x_count}")
        # 교차 검증을 위한 로그
        strings_json_excluded_keys = excluded_keys_by_file.get('strings/strings.json', set())
        self.logger.debug(f"  - excluded_keys_by_file['strings/strings.json']에 저장된 키 수: {len(strings_json_excluded_keys)}")
        self.logger.debug("="*75)

        # [tips.json 디버깅 로그]
        if self.tips_json_row_count > 0:
            tips_scoped_logger.log(f"[LOAD_DATA] 총 {self.tips_json_row_count}개의 'tips.json' 관련 행을 처리했습니다.", base_path=self.base_path)
            if 'strings/tips.json' in translated_files:
                tips_scoped_logger.log("[LOAD_DATA] 성공: 'strings/tips.json'이(가) 최종 Apply 대상 목록에 포함되었습니다.", base_path=self.base_path)
            else:
                tips_scoped_logger.log("[LOAD_DATA] 실패: 'strings.json' 관련 행은 있었지만, 유효한 번역 데이터가 없어 Apply 대상에서 제외되었습니다.", base_path=self.base_path)
            
            if self.tips_translation_map_by_id:
                tips_scoped_logger.log(f"[LOAD_DATA] tips_translation_map_by_id 최종 예시 (첫 5개):", base_path=self.base_path)
                for k, v in list(self.tips_translation_map_by_id.items())[:5]:
                    tips_scoped_logger.log(f"  -> Key: '{k}'", base_path=self.base_path)
                    tips_scoped_logger.log(f"    EN: '{v[0][:60].replace(chr(10), ' ')}...'", base_path=self.base_path)
                    tips_scoped_logger.log(f"    KR: '{v[1][:60].replace(chr(10), ' ')}...'", base_path=self.base_path)

    def get_tips_map(self):
        """tips.json Applier가 사용할 맵을 반환합니다."""
        return self.tips_translation_map_by_id

# ┏───────────────────────────────────────────────────┐
# ┃
# ┃          [ 필터 감사 서비스 클래스 ]
# ┃
class FilterAuditService:
    """
    (신규 모듈) Export 과정에서 필터링되는 모든 항목을 중앙에서 수집하고,
    작업 완료 후 CSV 보고서로 생성하는 책임을 갖는 서비스 클래스입니다.
    """
    _filtered_items = []

    @staticmethod
    def clear():
        """새로운 Export 작업을 위해 이전에 수집된 모든 기록을 초기화합니다."""
        FilterAuditService._filtered_items = []
        LoggerService.get_logger().debug(" -> 필터 감사 기록이 초기화되었습니다.")

    @staticmethod
    def record(source_file, item_id, item_type, text_en, reason):
        """필터링되어 제외된 항목을 기록합니다."""
        FilterAuditService._filtered_items.append({
            'source_file': source_file,
            'id': item_id,
            'type': item_type,
            'text_en': text_en,
            'filter_reason': reason
        })

    @staticmethod
    def save_report(path_manager, is_test_run):
        """
        수집된 모든 필터링 항목을 CSV 파일로 저장합니다.
        (수정) Translatable 열을 추가하여 0번 메뉴에서 처리할 수 있도록 변경합니다.
        """
        logger = LoggerService.get_logger()
        if not FilterAuditService._filtered_items:
            logger.info(" -> 필터링되어 제외된 항목이 없어 보고서 파일을 생성하지 않습니다.")
            return

        report_path = path_manager.get_filtered_items_file()
        
        # [수정] 보고서 데이터를 검토 파일 형식에 맞게 가공
        report_data_for_review = []
        for item in FilterAuditService._filtered_items:
            # text_kr 필드는 없으므로 빈 문자열로 추가하고, Translatable 열 추가
            report_data_for_review.append({
                'source_file': item['source_file'],
                'Translatable': '', # <--- [핵심 추가]
                'id': item['id'],
                'type': item['type'],
                'text_en': item['text_en'],
                'text_kr': '', # <--- [핵심 추가] text_kr 열 확보
                # filter_reason은 이 파일의 목적상 더 이상 필요하지 않으므로 제외
            })

        # CsvFileService를 사용하여 보고서 파일 쓰기
        # [수정] 헤더를 REVIEW_NEEDED_HEADERS로 통일
        csv_file_service.write_rows_to_csv(
            report_path, 
            report_data_for_review, 
            headers=REVIEW_NEEDED_HEADERS, 
            is_test_run=is_test_run,
            sort_data=True
        )
        
        if not is_test_run:
            logger.info(f" -> 총 {len(FilterAuditService._filtered_items)}개의 필터링된 항목을 '{os.path.basename(report_path)}'에 기록했습니다.")
# ┃
# ┗───────────────────────────────────────────────────┘
# ┏───────────────────────────────────────────────────┐
# ┃
# ┃          [ 신규: Apply 감사 서비스 클래스 ]
# ┃
class ApplyAuditService:
    """
    Apply 과정에서 스킵된 항목을 중앙에서 수집하고,
    작업 완료 후 CSV 보고서로 생성하는 책임을 갖는 서비스 클래스입니다.
    """
    # { key: (4-tuple), 'reason': '이유', 'text_kr_exists': bool }
    _skipped_records = []

    @staticmethod
    def clear():
        """새로운 Apply 작업을 위해 이전에 수집된 모든 기록을 초기화합니다."""
        ApplyAuditService._skipped_records = []
        LoggerService.get_logger().debug(" -> Apply 감사 기록이 초기화되었습니다.")

    @staticmethod
    def record_skip(skipped_key, translation_map, reason="번역 없음"):
        """
        스킵된 항목을 기록합니다.
        :param skipped_key: 실패한 4-튜플 키 (source_file, id, type, cleaned_en)
        :param translation_map: 전체 번역 맵 (text_kr 존재 여부 확인용)
        :param reason: 스킵 사유 (기본값: "번역 없음")
        """
        # 스킵된 키로 translation_map을 조회할 경우 None이 반환되어야 하지만,
        # Apply 로직 자체가 translation_map에서 찾지 못한 경우(번역 없음)만
        # skipped_keys에 넣기 때문에, 여기서는 key 자체의 유효성만 확인합니다.
        
        # 현재는 모든 스킵이 '번역 없음'으로 기록되므로, 이 함수는 4-tuple을 받아서
        # 보고서에 필요한 딕셔너리로 변환하여 저장합니다.
        
        # 참고: Apply 로직 상, skipped_keys에 포함된 항목은 text_kr이 비어 있거나
        # 번역 키가 불일치한 경우입니다. 여기서는 간결하게 키의 정보만 기록합니다.
        
        source, item_id, item_type, text_en = skipped_key
        
        # text_kr이 마스터에 있는지 확인 (리포트 정확도 향상 목적, 선택 사항)
        # Apply 로직은 text_kr이 없는 경우에도 key를 만들지 않으므로, 이 체크는
        # 주로 키 불일치로 인해 스킵된 경우에 유용합니다.
        
        ApplyAuditService._skipped_records.append({
            'source_file': source,
            'id': item_id,
            'type': item_type,
            'text_en': text_en,
            'skip_reason': reason
        })


    @staticmethod
    def save_report(path_manager, is_test_run):
        """
        수집된 모든 스킵 항목을 CSV 파일로 저장합니다.
        """
        logger = LoggerService.get_logger()
        if not ApplyAuditService._skipped_records:
            logger.info(" -> Apply 중 스킵된 항목이 없어 보고서 파일을 생성하지 않습니다.")
            return

        report_path = path_manager.get_apply_skipped_report_file()
        
        # 보고서 데이터 준비
        report_data_for_csv = []
        for item in ApplyAuditService._skipped_records:
            # Audit 파일은 Export/Apply에 사용되지 않으므로, 자세한 내용 포함
            report_data_for_csv.append({
                'source_file': item['source_file'],
                'id': item['id'],
                'type': item['type'],
                'text_en': item['text_en'],
                'skip_reason': item['skip_reason'],
                'text_kr': '' # 공백으로 유지
            })

        # CsvFileService를 사용하여 보고서 파일 쓰기
        headers = ['source_file', 'id', 'type', 'text_en', 'text_kr', 'skip_reason']
        csv_file_service.write_rows_to_csv(
            report_path, 
            report_data_for_csv, 
            headers=headers, 
            is_test_run=is_test_run,
            sort_data=True
        )
        
        if not is_test_run:
            logger.info(f" -> [AUDIT] 총 {len(ApplyAuditService._skipped_records)}개의 스킵된 항목을 '{os.path.basename(report_path)}'에 기록했습니다.")
# ┃
# ┗───────────────────────────────────────────────────┘


class MasterFileService:
    """
    [신규 서비스] 마스터 파일(_MASTER_LIB_kr.csv)에 대한 모든 읽기, 쓰기,
    수정 작업을 중앙에서 관리하는 전담 서비스 클래스입니다.
    """
    def __init__(self, base_path, csv_service: CsvFileService, target_file_path=None):
        self.paths = PathManager(base_path)
        self.base_path = base_path
        
        if target_file_path:
            self._target_path = target_file_path
        else:
            self._target_path = self.paths.get_master_file()

        self._csv_service = csv_service
        self._data = None
        self.logger = LoggerService.get_logger() # <-- LoggerService 인스턴스를 __init__에서 가져옵니다.

    def load_data(self, force_reload=False):
        """대상 파일을 로드하여 내부 데이터 캐시를 채웁니다."""
        if self._data is None or force_reload:
            self._data = self._csv_service.load_rows_from_csv(self._target_path)
        return self._data

    def get_data(self):
        """캐시된 데이터를 반환합니다. 데이터가 없으면 먼저 로드합니다."""
        if self._data is None:
            self.load_data()
        return self._data
        
    def get_path(self):
        """대상 파일의 전체 경로를 반환합니다."""
        return self._target_path

    def save_data(self, data_list, is_test_run=False, sort_data=True):
        """
        제공된 데이터로 대상 파일을 안전하게 덮어씁니다.
        """
        if self._target_path == self.paths.get_master_file():
            headers = MASTER_FILE_HEADERS
        elif self._target_path == self.paths.get_staging_master_file():
            headers = STAGING_FILE_HEADERS
        else:
            headers = MASTER_FILE_HEADERS

        self._csv_service.write_rows_to_csv(
            self._target_path, data_list, headers=headers,
            create_backup_on_write=True, is_test_run=is_test_run, sort_data=sort_data
        )
        self._data = data_list
        LoggerService.get_logger().info(f" -> 대상 파일('{os.path.basename(self._target_path)}')이 성공적으로 업데이트되었습니다.")

    def purge_by_blacklist(self, blacklist_keys):
        """
        [신규 엔진] 현재 마스터 데이터에서 블랙리스트에 포함된 항목을 제거하고,
        분석 결과를 반환합니다. (파일 쓰기 없음)
        """
        master_data = self.get_data()
        kept_rows, removed_count = [], 0
        
        for row in master_data:
            row_key = (
                row.get('source_file', ''), row.get('id', ''), row.get('type', ''),
                text_processor_service.process(row.get('text_en', ''))
            )
            if row_key in blacklist_keys:
                removed_count += 1
            else:
                kept_rows.append(row)
        
        analysis_report = {
            'initial_count': len(master_data), 'kept_count': len(kept_rows), 'removed_count': removed_count
        }
        return kept_rows, analysis_report
    
    # --- [내부 엔진: 분석] ---
    def _analyze_merge_changes(self, items_to_process, target_data):
        """
        [v2.1-PERF] 두 데이터셋을 비교하여 변경 내역(report)을 계산하고 반환합니다.
        `is_moved` 로직을 최적화하여 성능을 대폭 개선합니다.
        """
        report = defaultdict(int)
        report['total_processed_source'] = len(items_to_process)
        
        # 1. 대상(Master)과 소스(Staging) 데이터를 3-튜플 키 맵으로 변환
        target_map_by_loc = { (row['source_file'], row['id'], row['type']): row for row in target_data }
        source_map_by_loc = { (row['source_file'], row['id'], row['type']): row for row in items_to_process }
        
        # 2. 소스(Staging) 데이터를 (source_file, processed_text_en, item_type) 키 맵으로 역인덱스 생성 (성능 최적화용)
        #    이 맵의 값은 해당 키를 가진 3-튜플 위치 키들의 집합입니다.
        source_map_by_content_loc = defaultdict(set)
        for row in items_to_process:
            loc_key_3tuple = (row['source_file'], row['id'], row['type'])
            processed_en = text_processor_service.process(row.get('text_en', ''), row.get('type',''))
            item_type = row.get('type', '')
            source_map_by_content_loc[(loc_key_3tuple[0], processed_en, item_type)].add(loc_key_3tuple)

        all_location_keys = set(target_map_by_loc.keys()) | set(source_map_by_loc.keys())

        report['preview_items_data'] = [] 

        for loc_key in sorted(list(all_location_keys)): # loc_key는 3-튜플 (source_file, id, type)
            target_row = target_map_by_loc.get(loc_key)
            source_row = source_map_by_loc.get(loc_key)

            if source_row and not target_row: # Case 1: 스테이징에만 존재 (신규)
                report['new_items_data'] = report.get('new_items_data', []) + [source_row]
                preview_row = source_row.copy()
                preview_row['status'] = 'NEW'
                report['preview_items_data'].append(preview_row)
            elif target_row and not source_row: # Case 2: 마스터에만 존재 (유지 또는 Orphan 처리)
                # [핵심 최적화] is_moved 로직: source_map_by_content_loc를 활용하여 O(1)에 가깝게 조회
                target_processed_en = text_processor_service.process(target_row.get('text_en', ''), target_row.get('type',''))
                target_item_type = target_row.get('type', '')
                
                # 동일한 content를 가진 항목이 스테이징에 존재하는지 확인
                # 단, source_file이 같고 loc_key 자체가 아닌 다른 loc_key로 이동한 경우만 감지
                content_key_for_lookup = (loc_key[0], target_processed_en, target_item_type)
                
                is_moved_to_different_loc = False
                if content_key_for_lookup in source_map_by_content_loc:
                    # 동일한 content를 가진 3-튜플 위치 키들의 집합
                    matching_loc_keys_in_source = source_map_by_content_loc[content_key_for_lookup]
                    # 이 중 현재 loc_key와 다른 loc_key가 존재하는지 확인
                    if any(l_key != loc_key for l_key in matching_loc_keys_in_source):
                        is_moved_to_different_loc = True

                if is_moved_to_different_loc and (target_row.get('Translatable') or '').strip().lower() != 'orphan':
                    report['loc_changed_orphan_candidates_data'] = report.get('loc_changed_orphan_candidates_data', []) + [target_row]
                    preview_row = target_row.copy()
                    preview_row['status'] = 'ORPHAN_LOC_CHANGED'
                    report['preview_items_data'].append(preview_row)
                else:
                    # 이동하지 않았거나 이미 orphan인 경우, 변경 없이 유지 (preview_data에는 추가하지 않음)
                    # No_Change 항목은 _execute_merge에서 final_data_map_4tuple에 추가될 때 함께 처리됩니다.
                    # 여기서는 변경이 없는 항목은 preview_items_data에 추가하지 않아서 리포트 파일을 간소화합니다.
                    # 만약 NO_CHANGE 항목도 미리보기에 포함하려면 여기에 추가합니다.
                    pass 

            elif source_row and target_row: # Case 3: 양쪽 모두에 존재
                target_en_processed = text_processor_service.process(target_row.get('text_en', ''), target_row.get('type',''))
                source_en_processed = text_processor_service.process(source_row.get('text_en', ''), source_row.get('type',''))
                
                target_kr_processed = text_processor_service.process(target_row.get('text_kr', ''), target_row.get('type',''))
                source_kr_processed = text_processor_service.process(source_row.get('text_kr', ''), source_row.get('type',''))

                if target_en_processed == source_en_processed:
                    if (target_row.get('Translatable') or '').strip().lower() == 'orphan':
                        report['orphans_to_restore_data'] = report.get('orphans_to_restore_data', []) + [target_row]
                        preview_row = target_row.copy()
                        preview_row['status'] = 'RESTORED'
                        report['preview_items_data'].append(preview_row)
                    elif target_kr_processed != source_kr_processed:
                        report['kr_updated_items_data'] = report.get('kr_updated_items_data', []) + [source_row]
                        preview_row = source_row.copy()
                        preview_row['status'] = 'KR_UPDATED'
                        report['preview_items_data'].append(preview_row)
                    else: # 모든 내용이 동일 (No_Change)
                        # 변경이 없으므로 preview_items_data에 추가하지 않습니다.
                        pass
                else: # text_en이 다름 (Orphan 처리 + 새로운 항목 추가)
                    if (target_row.get('Translatable') or '').strip().lower() != 'orphan':
                        report['en_changed_orphan_candidates_data'] = report.get('en_changed_orphan_candidates_data', []) + [target_row]
                        preview_row_orphan = target_row.copy()
                        preview_row_orphan['status'] = 'ORPHAN_EN_CHANGED'
                        report['preview_items_data'].append(preview_row_orphan)
                    
                    report['en_changed_new_items_data'] = report.get('en_changed_new_items_data', []) + [source_row]
                    preview_row_new = source_row.copy()
                    preview_row_new['status'] = 'NEW_EN_CHANGED'
                    report['preview_items_data'].append(preview_row_new)
        
        report['added_count'] = len(report.get('new_items_data', []))
        report['updated_kr_count'] = len(report.get('kr_updated_items_data', []))
        report['orphaned_by_en_change_count'] = len(report.get('en_changed_orphan_candidates_data', []))
        report['orphaned_by_loc_change_count'] = len(report.get('loc_changed_orphan_candidates_data', []))
        report['restored_orphan_count'] = len(report.get('orphans_to_restore_data', []))
        
        return report

    # --- [내부 엔진: 실행] ---
    def _execute_merge(self, report, target_data, is_test_run=False):
        """
        [v2.0-FIX] `text_en` 변경 시 `Orphan` 처리 및 새로운 항목 추가가
        올바르게 작동하도록 `final_data_map`의 키를 4-튜플로 변경합니다.
        """
        # 1. 원본 마스터 데이터를 4-튜플 키 맵으로 변환
        #    (src, id, type, processed_en)을 키로 사용
        final_data_map_4tuple = {
            (row['source_file'], row['id'], row['type'], text_processor_service.process(row['text_en'], row['type'])): row.copy()
            for row in target_data
        }
        
        # 2. Orphan 처리 후보 항목들을 Translatable: 'Orphan'으로 마킹
        for row in report.get('en_changed_orphan_candidates_data', []) + report.get('loc_changed_orphan_candidates_data', []):
            key_4tuple = (row['source_file'], row['id'], row['type'], text_processor_service.process(row['text_en'], row['type']))
            if key_4tuple in final_data_map_4tuple:
                final_data_map_4tuple[key_4tuple]['Translatable'] = 'Orphan'

        # 3. Orphan 상태 복원 항목들을 Translatable: ''으로 마킹
        for row in report.get('orphans_to_restore_data', []):
            key_4tuple = (row['source_file'], row['id'], row['type'], text_processor_service.process(row['text_en'], row['type']))
            if key_4tuple in final_data_map_4tuple:
                final_data_map_4tuple[key_4tuple]['Translatable'] = ''

        # 4. KR 업데이트 항목 반영
        for row in report.get('kr_updated_items_data', []):
            key_4tuple = (row['source_file'], row['id'], row['type'], text_processor_service.process(row['text_en'], row['type']))
            if key_4tuple in final_data_map_4tuple:
                final_data_map_4tuple[key_4tuple]['text_kr'] = row['text_kr']
            else:
                # KR 업데이트 항목이 master에 4-tuple 키로 없는 경우는 없어야 하지만, 방어 로직.
                # 이는 새로운 항목으로 처리되어야 함.
                new_row = row.copy()
                new_row['Translatable'] = ''
                final_data_map_4tuple[key_4tuple] = new_row


        # 5. 신규 항목 (text_en 변경으로 인한 신규 포함) 추가
        for row in report.get('new_items_data', []) + report.get('en_changed_new_items_data', []):
            key_4tuple = (row['source_file'], row['id'], row['type'], text_processor_service.process(row['text_en'], row['type']))
            new_row = row.copy()
            
            # Translatable 상태 처리: 'q'나 'quote'는 ''으로 변경
            if (new_row.get('Translatable') or '').strip().lower() in ('q', 'quote'):
                new_row['Translatable'] = ''
            elif not new_row.get('Translatable'):
                new_row['Translatable'] = '' # 신규 항목은 기본적으로 Translatable을 비워둠

            final_data_map_4tuple[key_4tuple] = new_row # <--- 4-튜플 키를 사용하여 새로운 항목 추가/업데이트

        # 6. 최종 데이터 리스트 구성 (중복 제거 및 정렬은 save_data가 처리)
        final_data_list = list(final_data_map_4tuple.values())
        
        # save_data 메서드가 중복 제거 및 정렬을 수행하도록 위임
        self.save_data(final_data_list, is_test_run=is_test_run, sort_data=True)
        
        return final_data_list # 최종 데이터 리스트 반환

    def _generate_merge_preview_file(self, preview_items_data, is_test_run):
        """
        [v2.0] intelligent_merge()의 미리보기 데이터를 CSV 파일로 출력하는 내부 헬퍼 메서드.
        """
        output_file_path = self.paths.get_master_merge_preview_file() # <-- self.paths를 사용하여 경로를 가져옵니다.

        if not preview_items_data:
            if os.path.exists(output_file_path) and not is_test_run:
                os.remove(output_file_path)
                self.logger.info(f" -> 미리보기 항목이 없어 '{os.path.basename(output_file_path)}' 파일을 삭제했습니다.")
            return

        headers = ['status', 'source_file', 'Translatable', 'id', 'type', 'text_en', 'text_kr']
        
        reorganized_data = []
        for item in preview_items_data:
            row_copy = item.copy()
            status = row_copy.pop('status', 'UNKNOWN')
            reorganized_data.append({
                'status': status,
                'source_file': row_copy.get('source_file', ''),
                'Translatable': row_copy.get('Translatable', ''),
                'id': row_copy.get('id', ''),
                'type': row_copy.get('type', ''),
                'text_en': row_copy.get('text_en', ''),
                'text_kr': row_copy.get('text_kr', '')
            })

        self._csv_service.write_rows_to_csv( # <-- self._csv_service를 사용하여 파일 쓰기
            output_file_path, 
            reorganized_data, 
            headers=headers, 
            is_test_run=is_test_run,
            sort_data=True
        )
        if not is_test_run:
            self.logger.info(f" -> 총 {len(preview_items_data)}개의 병합 미리보기 항목을 '{os.path.basename(output_file_path)}'에 기록했습니다.")

    # --- [컨트롤러] ---
    def intelligent_merge(self, source_data, is_test_run=False, target_is_staging=False, 
                          preview_only=False, suppress_output=False, shared_state=None, skip_confirmation=False):
        """
        [v3.0 - 컨트롤러] 지능형 병합의 전체 워크플로우(분석, UI, 실행)를 지휘합니다.
        """
        logger = LoggerService.get_logger()
        target_data = self.get_data()
        
        operation_title = "스테이징 파일 지능형 동기화" if target_is_staging else "마스터 파일 지능형 자동 병합"
        
        items_to_process = source_data
        if not target_is_staging:
            items_to_process = [row for row in source_data if row.get('Translatable', '').strip().lower() != 's']
            
        if not items_to_process:
            logger.info(f"\n -> {operation_title}을(를) 위한 처리 대상 항목이 없습니다.")
            return (None, False) if preview_only else False

        # --- 1. 분석 (내부 엔진 호출) ---
        if not suppress_output:
            logger.info(f"\n -> [1단계] 데이터 분석을 시작합니다... (항목이 많으면 시간이 걸릴 수 있습니다)")
        
        report = self._analyze_merge_changes(items_to_process, target_data)
        total_changes = sum(report.get(k, 0) for k in ['added_count', 'updated_kr_count', 'orphaned_by_en_change_count', 'orphaned_by_loc_change_count', 'restored_orphan_count'])

        if total_changes == 0:
            if not suppress_output:
                self.logger.info(" -> ※ 분석 결과, 적용할 새로운 변경 사항이 없습니다.")
            return (_display_push_to_master_report(dict(report), self.base_path, operation_title), False) if preview_only else False

        # --- 2. 사용자 확인 (UI 및 상호작용) ---
        report_bundle_preview = _display_push_to_master_report(dict(report), self.base_path, operation_title)
        
        # [핵심 수정 1] 미리보기 파일 생성 (self._generate_merge_preview_file 호출)
        preview_file_path = self.paths.get_master_merge_preview_file() # 경로를 미리 가져와서 삭제 로직에서 사용
        self._generate_merge_preview_file(report['preview_items_data'], is_test_run) # <-- self. 호출 및 인자 변경
        self.logger.info(f" -> 변경될 항목 상세 내역을 '{os.path.basename(preview_file_path)}' 파일에서 확인하십시오.")

        if preview_only:
            # preview_only 모드는 파일 생성 후 즉시 반환하며, 파일은 삭제하지 않습니다.
            return report_bundle_preview, True

        if not suppress_output:
            _render_standard_report(report_bundle_preview)
        
        choice = 'y'
        if not skip_confirmation:
            prompt = f"\n>> 이 계획대로 '{os.path.basename(self.get_path())}' 파일을 업데이트하시겠습니까? (Enter/y, ESC/n, a: 모두 예): "
            choice = prompt_for_input(prompt, valid_choices=['y', 'n', 'a'], allow_empty=True, default_on_empty='y')

        if choice not in ('y', 'a', ''):
            self.logger.info(" -> 작업을 취소했습니다.")
            # [핵심 수정 2] 작업 취소 시 미리보기 파일 삭제
            if os.path.exists(preview_file_path) and not is_test_run:
                os.remove(preview_file_path)
                self.logger.info(f" -> 작업 취소로 인해 미리보기 파일 '{os.path.basename(preview_file_path)}'을(를) 삭제했습니다.")
            return False
        
        if choice == 'a' and shared_state is not None:
             shared_state['auto_sync_all'] = True

        # --- 3. 실행 (내부 엔진 호출) ---
        logger.info("\n -> [3단계] 사용자 승인에 따라 최종 데이터를 재구성하고 저장합니다...")
        final_data_list = self._execute_merge(report, target_data, is_test_run)
        
        # --- 4. 최종 리포트 및 클린업 ---
        report['final_master_item_count'] = len(final_data_list)
        report_bundle_final = _display_push_to_master_report(dict(report), self.base_path, operation_title)
        if not suppress_output:
            _render_standard_report(report_bundle_final)
        
        # [핵심 수정 3] 작업 완료 후 미리보기 파일 삭제
        if os.path.exists(preview_file_path) and not is_test_run:
            os.remove(preview_file_path)
            self.logger.info(f" -> 작업 완료로 인해 미리보기 파일 '{os.path.basename(preview_file_path)}'을(를) 삭제했습니다.")

        return True

class ActionFlagProcessorService:
    """
    [신규 서비스] 0번 기능: 'Translatable' 액션 플래그 처리를 전담하는 클래스.
    파일 분류, 미리보기, 실행, 리포팅까지 모든 책임을 캡슐화합니다.
    """
    def __init__(self, base_path, is_test_run, logger, master_service: MasterFileService, csv_service: CsvFileService):
        self.base_path = base_path
        self.is_test_run = is_test_run
        self.paths = PathManager(base_path)
        self.logger = logger
        self.master_service = master_service
        self.csv_service = csv_service

        self.current_source_file = None

        # 분류된 항목들을 저장할 내부 리스트들
        self._items_to_master_integrate = []
        self._items_to_master_review = []
        self._rows_to_trash = []
        self._rows_to_stage = []
        self._unhandled_items_for_review_file = [] # 원본 파일에 남겨질 항목
        
        # 작업 통계
        self._report_stats = defaultdict(int)

    def process_file(self, source_file_path):
        """
        주어진 검토 파일을 로드하고 'Translatable' 플래그에 따라 항목들을 분류합니다.
        """
        self.current_source_file = source_file_path

        self.logger.info(f"\n -> '{os.path.basename(source_file_path)}' 파일의 액션 플래그를 분석합니다...")
        source_data = self.csv_service.load_rows_from_csv(source_file_path)
        if not source_data:
            self.logger.warning(f" -> 처리할 데이터가 '{os.path.basename(source_file_path)}' 파일에 없습니다.")
            return False

        self._report_stats['initial_item_count'] = len(source_data)

        # 처리할 파일이 마스터 관련 리뷰 파일인지 감지
        master_review_filenames = {
            os.path.basename(self.paths.get_master_review_needed_file()),
            os.path.basename(self.paths.get_master_true_review_file()),
            os.path.basename(self.paths.get_master_purged_file()),
            os.path.basename(self.paths.get_master_empty_kr_file()), # 마스터 번역 없는 항목 파일 추가
            os.path.basename(self.paths.get_master_false_review_file()), # False 상태 검토 파일 추가
        }
        is_master_review_file = os.path.basename(source_file_path) in master_review_filenames

        is_filtered_export_file = os.path.basename(source_file_path) == os.path.basename(self.paths.get_filtered_items_file())

        for row in source_data:
            translatable_value = row.get('Translatable', '').strip().lower()
            
            if translatable_value == 's':
                # 스테이징으로 이동할 항목은 Translatable을 초기화합니다.
                row_copy = row.copy()
                row_copy['Translatable'] = '' 
                self._rows_to_stage.append(row_copy)
                self._report_stats['flag_s_count'] += 1
            elif translatable_value == 'x':
                # 트래시로 이동할 항목은 Translatable을 'x'로 명시합니다.
                row_copy = row.copy()
                row_copy['Translatable'] = 'x'
                self._rows_to_trash.append(row_copy)
                self._report_stats['flag_x_count'] += 1
            elif translatable_value in ('true', 't'):
                if is_master_review_file or is_filtered_export_file:
                    # 마스터 관련 파일 또는 필터링된 Export 파일에서 'true'는 마스터 통합 대상으로 간주
                    row_copy = row.copy()
                    row_copy['Translatable'] = 'True' # 마스터에 'True'로 통합
                    self._items_to_master_integrate.append(row_copy)
                    self._report_stats['flag_t_integrate_count'] += 1
                else:
                    # 그 외 파일에서 'true'는 마스터 검토 파일로 이동
                    row_copy = row.copy()
                    row_copy['Translatable'] = '' # 마스터 검토 파일에 ' '로 추가
                    self._items_to_master_review.append(row_copy)
                    self._report_stats['flag_t_review_count'] += 1
            else:
                # 처리되지 않은 항목은 원본 파일에 그대로 남깁니다.
                self._unhandled_items_for_review_file.append(row)
                self._report_stats['flag_unhandled_count'] += 1
        
        return True # 분류 성공

    def _display_preview_and_confirm(self):
        """
        분류된 항목들을 바탕으로 사용자에게 미리보기를 출력하고, 실행 여부를 묻습니다.
        """
        total_actions = sum([
            len(self._items_to_master_integrate),
            len(self._items_to_master_review),
            len(self._rows_to_trash),
            len(self._rows_to_stage)
        ])

        if total_actions == 0:
            self.logger.info("\n -> 처리할 유효한 'Translatable' 액션('true'/'t', 'x', 's')이 없습니다.")
            return False

        print("\n" + "="*60)
        self.logger.info(" [ 검토 파일 처리 미리보기 ]")
        self.logger.info(f"  - 원본 파일: '{os.path.basename(self.current_source_file)}'")
        print("-" * 60)
        
        if self._items_to_master_integrate:
            target_file = os.path.basename(self.paths.get_master_file())
            self.logger.info(f"  - [대상: {target_file}] 마스터 통합 (플래그: 't'/'true'): {len(self._items_to_master_integrate)}개 항목")
        if self._items_to_master_review:
            target_file = os.path.basename(self.paths.get_master_review_needed_file())
            self.logger.info(f"  - [대상: {target_file}] 마스터 검토로 이동 (플래그: 't'/'true'): {len(self._items_to_master_review)}개 항목")
        if self._rows_to_trash:
            target_file = os.path.basename(self.paths.get_purge_trash_file())
            self.logger.info(f"  - [대상: {target_file}] 트래시로 이동 (플래그: 'x'): {len(self._rows_to_trash)}개 항목")
        if self._rows_to_stage:
            target_file = os.path.basename(self.paths.get_staging_master_file())
            self.logger.info(f"  - [대상: {target_file}] 스테이징으로 이동 (플래그: 's'): {len(self._rows_to_stage)}개 항목")
        if self._unhandled_items_for_review_file:
            self.logger.info(f"  - [원본 파일에 유지] (플래그 없음/기타): {len(self._unhandled_items_for_review_file)}개 항목")
        print("="*60)
        prompt = "\n>> 위 내용으로 작업을 실행하시겠습니까? (Enter/y: 예, ESC/n: 아니오): "
        choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')
        
        return choice == 'y'

    def _execute_actions(self):
        """
        분류된 항목들을 실제 대상 파일에 저장/추가하는 파일 I/O 작업을 수행합니다.
        """
        # 1. 스테이징 파일에 추가
        if self._rows_to_stage:
            staging_file = self.paths.get_staging_master_file()
            added_count = self.csv_service.append_rows_to_csv_without_duplicates(
                staging_file, self._rows_to_stage, headers=STAGING_FILE_HEADERS,
                create_backup_on_write=True, is_test_run=self.is_test_run
            )
            self.logger.info(f" -> '{os.path.basename(staging_file)}' 파일에 {added_count}개의 새로운 항목을 추가했습니다.")
            self._report_stats['executed_s_count'] = added_count

        # 2. 마스터 검토 파일에 추가
        if self._items_to_master_review:
            master_review_file = self.paths.get_master_review_needed_file()
            added_count = self.csv_service.append_rows_to_csv_without_duplicates(
                master_review_file, self._items_to_master_review, headers=REVIEW_NEEDED_HEADERS,
                create_backup_on_write=True, is_test_run=self.is_test_run
            )
            self.logger.info(f" -> '{os.path.basename(master_review_file)}' 파일에 {added_count}개의 새로운 항목을 추가했습니다.")
            self._report_stats['executed_t_review_count'] = added_count

        # 3. 마스터 통합 및 트래시 이동 (MasterFileService 활용)
        if self._items_to_master_integrate or self._rows_to_trash:
            # _update_master_from_review_engine은 MasterFileService를 내부적으로 사용합니다.
            handled_items = self._items_to_master_integrate + self._rows_to_trash
            
            # _update_master_from_review_engine은 이제 내부적으로 MasterFileService를 사용합니다.
            # 이 함수는 처리된 항목에 대한 요약 정보를 반환하지 않으므로, count를 직접 집계해야 합니다.
            _update_master_from_review_engine(
                handled_items, self.current_source_file, self.is_test_run, self.base_path
            )
            
            self.master_service.load_data(force_reload=True) # 1. 먼저 데이터를 강제로 다시 로드
            final_master_data_count = len(self.master_service.get_data()) # 2. 인자 없이 get_data() 호출

            self._report_stats['executed_t_integrate_count'] = len(self._items_to_master_integrate)
            self._report_stats['executed_x_count_master'] = len([r for r in self._rows_to_trash if (r['source_file'], r['id'], r['type'], r['text_en']) in {k[0] for k in self.master_service.get_data()}] )
            self._report_stats['executed_x_count_trash'] = self._report_stats['flag_x_count'] # 트래시 파일에 추가된 항목 수

        # 4. 원본 검토 파일 다시 쓰기
        self.csv_service.write_rows_to_csv(
            self.current_source_file, self._unhandled_items_for_review_file,
            headers=REVIEW_NEEDED_HEADERS, create_backup_on_write=True, is_test_run=self.is_test_run
        )
        self.logger.info(f" -> '{os.path.basename(self.current_source_file)}' 파일에 처리되지 않은 {len(self._unhandled_items_for_review_file)}개 항목만 남겼습니다.")
        self._report_stats['executed_unhandled_count'] = len(self._unhandled_items_for_review_file)
        
        return True # 작업 실행 성공

    def _generate_report_bundle(self):
        """
        모든 작업 완료 후, 처리된 항목 수 등에 대한 종합적인 report_bundle을 생성합니다.
        """
        report = self._report_stats
        report_bundle = {
            "header": {
                "report_title": "액션 플래그 처리 리포트",
                "target_name": os.path.basename(self.base_path),
                "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                "summary_lines": [
                    {"label": "총 처리 대상 항목", "value": f"{report.get('initial_item_count', 0)}개"},
                    {"label": "실제 처리된 액션 수", "value": f"{report.get('flag_s_count',0) + report.get('flag_x_count',0) + report.get('flag_t_integrate_count',0) + report.get('flag_t_review_count',0)}개"}
                ]
            },
            "sections": [
                {
                    "section_title": "플래그별 처리 결과",
                    "section_type": "key_value_list",
                    "content": [
                        {"label": "스테이징으로 이동 ('s')", "label_prefix": "[+] ", "value": f"{report.get('executed_s_count',0)}개", "level": 1},
                        {"label": "트래시로 이동 ('x')", "label_prefix": "[-] ", "value": f"{report.get('executed_x_count_trash',0)}개", "level": 1},
                        {"label": "마스터 통합 ('t'/'true')", "label_prefix": "[+] ", "value": f"{report.get('executed_t_integrate_count',0)}개", "level": 1},
                        {"label": "마스터 검토로 이동 ('t'/'true')", "label_prefix": "[*] ", "value": f"{report.get('executed_t_review_count',0)}개", "level": 1},
                        {"label": "원본 파일에 유지 (플래그 없음/기타)", "label_prefix": "[ ] ", "value": f"{report.get('executed_unhandled_count',0)}개", "level": 1},
                    ]
                }
            ]
        }
        return report_bundle

class MasterXFlagService:
    """
    [신규 서비스] 마스터 파일 내 'Translatable: x' 항목의 처리(복사/이동)를 전담하는 서비스.
    트래시 파일로의 안전한 누적 기록과 마스터 파일 업데이트를 관리합니다.
    """
    def __init__(self, base_path, csv_service: CsvFileService, master_service: MasterFileService, path_manager: 'PathManager'):
        self.base_path = base_path
        self.csv_service = csv_service
        self.master_service = master_service
        self.paths = path_manager
        self.logger = LoggerService.get_logger()

    def process_x_flags(self, is_test_run=False):
        """
        마스터 파일에서 'Translatable: x' 항목을 찾아 트래시 파일로 복사/이동 처리합니다.
        하부 메뉴를 통해 사용자 선택을 받습니다.
        """
        master_data = self.master_service.get_data()
        x_flagged_items = [row for row in master_data if row.get('Translatable', '').strip().lower() == 'x']

        if not x_flagged_items:
            self.logger.info("\n -> 마스터 파일에 'Translatable: x'로 표시된 항목이 없습니다. 작업을 종료합니다.")
            pause_for_user()
            return False

        while True:
            display_header()
            print("\n [ 6-10. 'Translatable: x' 항목 처리 ]\n")
            print(f"  마스터 파일('{os.path.basename(self.master_service.get_path())}')에서")
            print(f"  총 {len(x_flagged_items)}개의 'Translatable: x' 항목이 발견되었습니다.\n")
            print("어떤 작업을 수행하시겠습니까?\n")
            print("  1. 마스터 파일에서 트래시로 'x' 처리된 항목 복사")
            print("     └─ 마스터 파일은 유지하고, 트래시 파일에만 항목을 추가합니다.")
            print("  2. 마스터 파일에서 트래시로 'x' 처리된 항목 이동")
            print("     └─ 마스터 파일에서 해당 항목을 제거하고, 트래시 파일에 추가합니다.")
            
            prompt = "\n>> 원하는 작업 번호를 선택하세요 (ESC: 뒤로): "
            choice = prompt_for_input(prompt, valid_choices=['1', '2'])

            if choice is UserInput.ESC or choice is UserInput.QUIT:
                self.logger.info(" -> 작업을 취소했습니다.")
                return False

            action_type = "복사" if choice == '1' else "이동"
            
            # --- 미리보기 및 확인 ---
            report_data = self._build_report_bundle(x_flagged_items, action_type)
            _render_standard_report(report_data)

            prompt_confirm = f"\n>> 위 내용으로 작업을 진행하시겠습니까? (Enter/y, ESC/n): "
            confirm_choice = prompt_for_input(prompt_confirm, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

            if confirm_choice != 'y':
                self.logger.info(" -> 작업을 취소했습니다.")
                continue # 하부 메뉴로 돌아감

            # --- 실제 작업 실행 ---
            added_to_trash_count = self._perform_actions(x_flagged_items, action_type, is_test_run)
            
            # --- 최종 리포트 출력 ---
            final_report_data = self._build_report_bundle(x_flagged_items, action_type, final_run=True, added_to_trash_count=added_to_trash_count)
            _render_standard_report(final_report_data)
            
            self.logger.info("\n -> 작업이 성공적으로 완료되었습니다.")
            pause_for_user()
            return True # 작업 완료 후 상위 메뉴로 돌아감

    def _perform_actions(self, items_to_process, action_type, is_test_run):
        """실제 복사/이동 작업을 수행하고 트래시 파일을 업데이트합니다."""
        trash_file_path = self.paths.get_purge_trash_file()
        
        # 트래시 파일에 추가 (기존 append_rows_to_csv_without_duplicates 사용)
        added_count = self.csv_service.append_rows_to_csv_without_duplicates(
            trash_file_path, items_to_process, headers=MASTER_FILE_HEADERS, create_backup_on_write=True, is_test_run=is_test_run
        )
        self.logger.info(f" -> 트래시 파일 '{os.path.basename(trash_file_path)}'에 {added_count}개의 새로운 항목을 추가했습니다.")

        if action_type == "이동":
            remaining_master_data = [row for row in self.master_service.get_data() if row not in items_to_process]
            self.master_service.save_data(remaining_master_data, is_test_run=is_test_run)
            self.logger.info(f" -> 마스터 파일에서 'Translatable: x' 항목들을 제거했습니다.")
        
        return added_count

    def _build_report_bundle(self, x_flagged_items, action_type, final_run=False, added_to_trash_count=0):
        """미리보기 및 최종 리포트용 데이터 번들을 생성합니다."""
        current_master_count = len(self.master_service.get_data())
        removed_from_master_count = len(x_flagged_items) if action_type == "이동" else 0
        final_master_count = current_master_count - removed_from_master_count

        if final_run:
            report_title = "작업 완료: 'Translatable: x' 항목 처리"
            item_count_label = "처리된 항목"
            added_to_trash_label = "트래시 파일에 새로 추가"
            master_items_label = "최종 마스터 항목 수"
        else:
            report_title = f"미리보기: 'Translatable: x' 항목 {action_type}"
            item_count_label = "처리 대상 항목"
            added_to_trash_label = "트래시 파일에 추가될 항목"
            master_items_label = "변경 후 예상 마스터 항목 수"

        report_bundle = {
            "header": {
                "report_title": report_title,
                "target_name": get_mod_display_name(self.base_path),
                "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                "summary_lines": [
                    {"label": item_count_label, "value": f"{len(x_flagged_items)}개"},
                    {"label": "작업 유형", "value": action_type}
                ]
            },
            "sections": [
                {
                    "section_title": "작업 상세",
                    "section_type": "key_value_list",
                    "content": [
                        {"label": added_to_trash_label, "label_prefix": "[+] ", "value": f"{added_to_trash_count if final_run else len(x_flagged_items)}개 (중복 제외)", "level": 1},
                        {"label": f"마스터 파일('{os.path.basename(self.master_service.get_path())}')", "value": "", "level": 1},
                        {"label": "현재 항목 수", "label_prefix": " └─ ", "value": f"{current_master_count}개", "level": 2},
                        {"label": "제거될 항목 수", "label_prefix": " └─ [-] ", "value": f"{removed_from_master_count}개", "level": 2} if action_type == "이동" else None,
                        {"label": master_items_label, "label_prefix": " └─ ", "value": f"{final_master_count}개", "level": 2} if action_type == "이동" else None,
                        {"label": "마스터 파일 변경 없음", "label_prefix": " └─ [ ] ", "value": "복사 작업 시", "level": 2} if action_type == "복사" else None,
                    ]
                }
            ]
        }
        # None인 항목 제거
        report_bundle["sections"][0]["content"] = [item for item in report_bundle["sections"][0]["content"] if item is not None]
        return report_bundle

# ==============================================================================
#
#                 [ 신규: 객체 지향 처리 엔진 기반 구조 ]
#
# ==============================================================================
# 이 섹션은 Export/Apply 로직을 더 안정적이고 확장 가능하게 만들기 위한
# 새로운 객체 지향 아키텍처의 핵심 구성 요소입니다.

class ExecutionContext:
    """
    단일 작업 실행에 필요한 모든 데이터와 서비스를 담는 '컨텍스트' 객체입니다.
    이 객체 하나만 처리기(Strategy)에 전달되어 인자 누락 문제를 원천적으로 방지합니다.
    """
    def __init__(self, base_path, is_test_run=False, shared_state=None):
        # --- 기본 실행 정보 ---
        self.base_path = base_path
        self.is_test_run = is_test_run
        self.shared_state = shared_state if shared_state is not None else {}
        
        # --- 공통 서비스 ---
        self.paths = PathManager(base_path)
        self.logger = LoggerService.get_logger()
        
        # --- 현재 처리 중인 파일 정보 (루프마다 외부에서 업데이트) ---
        self.current_source_path = None
        self.current_dest_path = None
        self.current_relative_path = None
        self.current_rules = None
        
        # --- [리팩토링] 지연 로딩(Lazy Loading) 데이터 (Apply 시에만 필요) ---
        self._translation_map = None
        self._translation_map_insensitive = None
        self._files_to_translate = None
        self._excluded_by_x_map = None
        self._excluded_keys_by_file = None
        self._full_translation_map = None
        self._latest_data_map = None

    @property
    def latest_data_map(self):
        """Apply 리포팅 시점에 필요한 최신 data_en 정보를 지연 로딩합니다."""
        if self._latest_data_map is None:
            self.logger.info(" -> (Context) 최신 원본(data_en) 데이터 지연 로딩을 시작합니다...")
            src_folder = os.path.join(self.base_path, SOURCE_DATA_FOLDER)
            # mod_root_path는 base_path와 동일한 목적으로 사용되므로 통일합니다.
            self._latest_data_map, _, _ = extract_all_text_to_map(self.base_path, src_folder, mod_root_path=self.base_path)
        return self._latest_data_map

    @property
    def translation_map(self):
        if self._translation_map is None:
            self._load_apply_data()
        return self._translation_map

    @property
    def translation_map_insensitive(self):
        if self._translation_map_insensitive is None:
            self._load_apply_data()
        return self._translation_map_insensitive
        
    @property
    def files_to_translate(self):
        if self._files_to_translate is None:
            self._load_apply_data()
        return self._files_to_translate

    @property
    def excluded_by_x_map(self):
        if self._excluded_by_x_map is None:
            self._load_apply_data()
        return self._excluded_by_x_map
        
    @property
    def excluded_keys_by_file(self):
        if self._excluded_keys_by_file is None:
            self._load_apply_data()
        return self._excluded_keys_by_file

    @property
    def full_translation_map(self):
        if self._full_translation_map is None:
            self._load_apply_data()
        return self._full_translation_map

# 경로: class ExecutionContext

    def _load_apply_data(self):
        """
        [로직 이전 완료] Apply에 필요한 모든 번역 데이터를 메모리로 로드합니다.
        [수정] 'orphan' 상태 필터링을 제거하여 full_translation_map이 마스터 파일 상태를
        최대한 반영하도록 복원합니다. 최종 필터링 책임은 분석 단계로 이관합니다.
        """
        self.logger.info(" -> (Context) Apply 데이터 지연 로딩을 시작합니다...")
        
        # 변수 초기화
        self._full_translation_map = {}
        self._translation_map, self._files_to_translate = {}, set()
        self._translation_map_insensitive = {}
        self._excluded_by_x_map = defaultdict(int)
        self._excluded_keys_by_file = defaultdict(set)
        
        analyzer = ApplyAnalyzer(self.base_path)
        translation_file_path = self.paths.get_apply_source_file()

        self.logger.info(f"'{os.path.basename(translation_file_path)}' 파일에서 번역 데이터를 불러옵니다...")
        if not os.path.exists(translation_file_path):
            self.logger.warning("  번역 파일을 찾을 수 없습니다.")
            return

        try:
            with open(translation_file_path, mode='r', encoding=INPUT_FILE_ENCODING, newline='') as infile:
                reader = csv.DictReader(infile)
                required_headers = ['source_file', 'id', 'type', 'text_en', 'text_kr']
                # [수정] 헤더 검증 로직 강화
                if not reader.fieldnames or not all(h in reader.fieldnames for h in required_headers):
                    self.logger.error("  번역 파일에 필수 열이 없습니다.")
                    return
                
                for row_num, row in enumerate(reader, 2):
                    translatable_status = row.get('Translatable', '').strip().lower() 
                    
                    cleaned_source_file = text_processor_service.process(row.get('source_file', ''))
                    row_id = row.get('id', '')
                    row_type = row.get('type', '')
                    cleaned_text_en = text_processor_service.process(row.get('text_en', ''), item_type=row_type)
                    text_kr_raw = row.get('text_kr', '') 
                    
                    composite_key = (cleaned_source_file, row_id, row_type, cleaned_text_en)

                    # --- [핵심 수정된 부분 시작] ---
                    # 'orphan' 필터링 로직을 제거하고 'x' 상태만 처리하도록 복원합니다.
                    if translatable_status == 'x':
                        self._excluded_by_x_map[cleaned_source_file] += 1
                        self._excluded_keys_by_file[cleaned_source_file].add(composite_key)
                        continue
                    # --- [핵심 수정된 부분 끝] ---

                    self._full_translation_map[composite_key] = {'text_kr': text_kr_raw, 'status': translatable_status}
                    
                    # [수정] orphan 항목은 번역 적용 대상에서는 제외되어야 합니다.
                    if translatable_status != 'orphan' and cleaned_source_file and row_id and row_type and text_kr_raw.strip():
                        processed_text_kr = text_kr_raw.replace('\\n', '\n') if APPLY_RESTORE_NEWLINES else text_kr_raw
                        if APPLY_NORMALIZE_QUOTES:
                            processed_text_kr = processed_text_kr.replace('“', '"').replace('”', '"')
                        
                        self._translation_map[composite_key] = processed_text_kr
                        composite_key_insensitive = (cleaned_source_file, row_id.lower(), row_type.lower(), cleaned_text_en)
                        self._translation_map_insensitive[composite_key_insensitive] = processed_text_kr
                        self._files_to_translate.add(cleaned_source_file)
            
            self.logger.info(f"  -> {len(self._translation_map)}개의 유효한 번역 데이터를 불러왔습니다.")
            if self._excluded_by_x_map:
                total_excluded = sum(self._excluded_by_x_map.values())
                self.logger.info(f"  -> {total_excluded}개 항목은 'Translatable: x'로 설정되어 의도적으로 제외되었습니다.")
            self.logger.info(f"  -> {len(self._files_to_translate)}개의 파일에 번역이 적용될 것입니다.")

        except Exception as e:
            self.logger.error(f"  번역 파일을 읽는 중 오류 발생: {e}", exc_info=True)


class IProcessingStrategy(ABC):
    """
    모든 파서(Parser)와 어플라이어(Applier)가 따라야 하는 인터페이스입니다.
    이는 전략 패턴(Strategy Pattern)의 기본 계약 역할을 합니다.
    """
    @abstractmethod
    def execute(self, context: ExecutionContext):
        """
        주어진 실행 컨텍스트(context)를 사용하여 특정 파일 처리 작업을 수행합니다.
        
        :param context: 작업에 필요한 모든 정보를 담고 있는 ExecutionContext 객체.
        :return: 작업 결과. Export의 경우 추출된 데이터, Apply의 경우 (적용 카운트, 성공 키 집합).
        """
        pass


############################################################################
#
#        [ ARCHITECTURAL DIRECTIVE - POLYMORPHIC_JSON_ARRAY_ENGINE_V3.0_FINALIZED ]
#
# TARGET: TipsPolymorphicParser(), TipsPolymorphicApplier(), _get_tips_json_key() 및 strings/tips.json, strings/ship_names.json 등 단순 문자열/객체 배열 JSON 파일 처리 전체
# STATUS: FINALIZED (Ship Names Support Added)
# ROLE: Polymorphic Engine for JSON files containing simple arrays of strings or objects, adapting to various array structures found across mods/files.
# BEHAVIOR:
#   이 함수 그룹은 `strings/tips.json`이나 `strings/ship_names.json`과 같이 **배열 형태의 값**을 가지는 JSON 파일의 다양한 구조적 변형에 유연하게 대응하는 '다형성 처리 엔진'이다.
#   1. [동적 규칙 선택 (`json_scan_process` 활용)] `json_scan_process()`를 호출하여 파일 내용과 `JSON_STRUCTURE_PATTERNS`를 대조, 현재 작업 중인 파일의 구조에 가장 적합한 규칙 세트(`structure_pattern`)를 동적으로 선택한다.
#   2. [패턴 기반 추출/적용] 선택된 규칙 세트(`structure_pattern`)에 정의된 `export_category_regex`, `export_kv_regex` 및 `apply_category_regex`, `apply_kv_regex` 패턴을 사용하여 텍스트 목록을 정확하게 추출 및 적용한다.
#   3. [고유 ID 생성] 추출된 각 항목에 대해 인덱스 기반의 고유 ID를 생성한다.
#   4. [배열 항목 서식 재구성] `tips_string_array` (PAGSM 팁) 또는 `ship_names_string_array` (ship_names)와 같이 문자열 배열인 경우, 최종 파일 쓰기 전에 항목별 한 줄 줄바꿈 서식 재구성을 적용한다.
# DESIGN_CHOICE:
#   'Configuration-Driven Parsing'(설정 주도 파싱) 원칙과 'Scanner-Executor Pattern'을 결합하여, 패턴 정의를 중앙 집중화하고 처리 로직의 유연성을 극대화한다.
# MODIFICATION_PROTOCOL:
#   새로운 배열 형태 JSON 형식을 지원하려면, 이 함수 그룹을 수정하는 대신 USER SETTINGS의 `{JSON_STRUCTURE_PATTERNS}` 섹션에 새 규칙 블록을 추가하고 `SPECIAL_FILE_HANDLING`에 해당 파일을 `process_tips_polymorphic` 및 `apply_tips_polymorphic`에 매핑하십시오.
#
############################################################################
class TipsPolymorphicParser(IProcessingStrategy):
    """
    [v3.4.2 - ID FIX] 상태 저장 순차 탐색 로직과 함께,
    IdPrefixResolver를 올바르게 사용하여 ID 접두사를 결정하고
    모든 형식의 tips.json/ship_names.json을 안정적으로 추출합니다.
    """
    def execute(self, context: ExecutionContext):
        logger = context.logger
        relative_path = context.current_relative_path
        base_path = context.base_path
        tips_scoped_logger.log(f"  [PARSER-V3.4.2-ID_FIX] TipsPolymorphicParser 실행 시작: '{relative_path}'", base_path=base_path)

        extracted = []
        try:
            source_path = context.current_source_path
            rules = context.current_rules

            content, _, _ = read_file_with_fallback(source_path)
            if not content:
                tips_scoped_logger.log(f"    [FAIL] 파일 내용이 비어있어 처리를 중단합니다.", base_path=base_path)
                return []

            forced_pattern_name = rules.get('json_pattern_name') if rules else None
            tips_scoped_logger.log(f"    [CONFIG] 강제 패턴 이름 (from rules): '{forced_pattern_name}'", base_path=base_path)
            
            structure_pattern = json_scan_process(content, forced_pattern_name=forced_pattern_name)

            if not structure_pattern:
                logger.error(f"  [ERROR] '{relative_path}' 파일의 JSON 구조를 분석할 수 없습니다. 추출을 건너뜁니다.")
                tips_scoped_logger.log(f"    [FAIL] JSON 구조 분석 실패.", base_path=base_path)
                return []
            
            tips_scoped_logger.log(f"    [SCAN] 감지된/지정된 JSON 패턴: '{structure_pattern.get('name')}'", base_path=base_path)

            category_regex = re.compile(structure_pattern['export_category_regex'], re.DOTALL)
            tips_array_match = category_regex.search(content)
            
            if not tips_array_match:
                logger.warning(f"  [WARN] '{relative_path}'에서 배열 블록(예: 'tips' 또는 'FUEL')을 찾을 수 없습니다.")
                tips_scoped_logger.log(f"    [FAIL] 배열 블록 경계 탐색 실패.", base_path=base_path)
                return []
            
            tips_inner_content = tips_array_match.group(1)
            tips_scoped_logger.log(f"    [SCAN] 배열 내용 추출 성공. (길이: {len(tips_inner_content)})", base_path=base_path)

            # --- 설정에 따른 주석 처리 분기 ---
            if TIPS_JSON_REMOVE_COMMENTS:
                tips_scoped_logger.log(f"    [CONFIG] 주석 제거 모드 활성화 (TIPS_JSON_REMOVE_COMMENTS=True).", base_path=base_path)
                original_len = len(tips_inner_content)
                tips_inner_logger_content = re.sub(r'^\s*#.*', '', tips_inner_content, flags=re.MULTILINE)
                tips_scoped_logger.log(f"      -> 주석 제거 후 내용 길이: {len(tips_inner_logger_content)} (변경: {original_len - len(tips_inner_logger_content)})", base_path=base_path)
                combined_pattern = re.compile(r'(\{[\s\S]*?\})|\"((?:\\.|[^\"\\])*)\"', re.DOTALL)
            else:
                tips_scoped_logger.log(f"    [CONFIG] 주석 보존 모드 활성화 (TIPS_JSON_REMOVE_COMMENTS=False).", base_path=base_path)
                tips_inner_logger_content = tips_inner_content # 주석 보존 모드에서는 원본 내용을 사용
                combined_pattern = re.compile(r'(\{[\s\S]*?\})|\"((?:\\.|[^\"\\])*)\"|(#[^\r\n]*)', re.DOTALL)

            # --- [핵심 수정] ID 생성 및 타입 결정을 현재 structure_pattern에 직접 위임 ---
            uaf_counter, pagsm_counter = 0, 0
            
            resolver = IdPrefixResolver(mod_root_path=base_path, file_path=source_path)
            
            # [핵심 수정 1] 현재 structure_pattern의 id_prefix를 직접 사용
            current_file_id_prefix = resolver.resolve(rules=context.current_rules, structure_pattern=structure_pattern)
            
            # [핵심 수정 2] 현재 structure_pattern의 item_type을 직접 사용 (rules override 고려)
            current_file_item_type = context.current_rules.get('item_type', structure_pattern.get('item_type', 'tip_json'))
            
            tips_scoped_logger.log(f"    [ID-INIT] 현재 파일 ID 접두사: '{current_file_id_prefix}', 항목 타입: '{current_file_item_type}'", base_path=base_path)

            for i, match in enumerate(combined_pattern.finditer(tips_inner_content)):
                object_content, string_content = match.group(1), match.group(2)
                
                if not TIPS_JSON_REMOVE_COMMENTS:
                    comment_content = match.group(3)
                    if comment_content is not None:
                        tips_scoped_logger.log(f"      [SKIP] 탐색 #{i}: 주석 발견, 건너뜠습니다. 내용: '{comment_content.strip()}'", base_path=base_path)
                        continue

                item_id, item_type, text_to_translate = None, None, None

                if object_content:
                    tip_match = re.search(r'"tip"\s*:\s*"((?:\\.|[^"\\])*)"', object_content, re.DOTALL)
                    if tip_match:
                        # [핵심 수정 3] current_file_id_prefix 사용 (UAF 형식은 object_array 패턴에 따라 따로 정의됨)
                        # 이 부분이 uaf_counter를 쓰는 UAF 형식으로 판별되므로, uaf_pattern_info에서 가져옵니다.
                        uaf_pattern_info = next((p for p in JSON_STRUCTURE_PATTERNS if p['name'] == 'tips_object_array'), {})
                        uaf_specific_id_prefix = resolver.resolve(rules=context.current_rules, structure_pattern=uaf_pattern_info)
                        uaf_specific_item_type = context.current_rules.get('item_type', uaf_pattern_info.get('item_type', 'tip_json'))

                        text_to_translate = tip_match.group(1)
                        item_id = f"{uaf_specific_id_prefix}[{uaf_counter}]"
                        item_type = uaf_specific_item_type
                        tips_scoped_logger.log(f"      [MATCH-UAF] 탐색 #{i}: 객체 발견. ID: {item_id}", base_path=base_path)
                        uaf_counter += 1

                elif string_content is not None and string_content.strip():
                    text_to_translate = string_content
                    # [핵심 수정 4] current_file_id_prefix 사용 (PAGSM/ship_names 형식은 string_array 패턴에 따라 정의됨)
                    # 이 부분이 pagsm_counter를 쓰는 PAGSM/ship_names 형식으로 판별되므로, current_file_id_prefix를 사용합니다.
                    item_id = f"{current_file_id_prefix}[{pagsm_counter}]"
                    item_type = current_file_item_type # 미리 결정된 current_file_item_type 사용
                    tips_scoped_logger.log(f"      [MATCH-PAGSM] 탐색 #{i}: 문자열 발견. ID: {item_id}", base_path=base_path)
                    pagsm_counter += 1
                
                if all([item_id, item_type, text_to_translate]):
                    extracted.append({
                        'source_file': relative_path, 'id': item_id, 'type': item_type,
                        'text_en': text_processor_service.process(text_to_translate)
                    })
            logger.info(f"     ... 'tips.json'에서 {len(extracted)}개의 항목(UAF: {uaf_counter}, PAGSM/Ship: {pagsm_counter})을 성공적으로 추출했습니다.")
            return extracted

        except Exception as e:
            logger.error(f"'TipsPolymorphicParser'로 '{relative_path}' 처리 중 오류: {e}", exc_info=True)
            return []


class TipsPolymorphicApplier(IProcessingStrategy):
    """
    [v3.4-REFORMAT] `re.sub` 콜백 패턴과 상세 디버그 로깅을 사용하고,
    PAGSM 형식의 문자열 배열에 대해 최종 서식 재구성(reformatting)을 수행합니다.
    """
    def execute(self, context: ExecutionContext):
        logger = context.logger
        source_path = context.current_source_path
        dest_path = context.current_dest_path
        relative_path = context.current_relative_path
        mod_root_path = context.base_path
        translation_map = context.translation_map
        rules = context.current_rules
        
        tips_scoped_logger.log(f"  [APPLIER-V3.4-REFORMAT] TipsPolymorphicApplier 실행 시작: '{relative_path}'", base_path=mod_root_path)

        try:
            content, _, _ = read_file_with_fallback(source_path)
            if content is None:
                tips_scoped_logger.log(f"    [FAIL] 파일 내용이 비어있어 원본을 복사합니다.", base_path=mod_root_path)
                if not context.is_test_run: shutil.copy2(source_path, dest_path)
                return 0, set()

            # --- 1. 전처리 및 경계 탐색 ---
            content_for_parsing = content
            if TIPS_JSON_REMOVE_COMMENTS:
                tips_scoped_logger.log(f"    [CONFIG] 주석 제거 모드 활성화 (TIPS_JSON_REMOVE_COMMENTS=True).", base_path=mod_root_path)
                content_for_parsing = re.sub(r'^\s*#.*', '', content, flags=re.MULTILINE)

            forced_pattern_name = rules.get('json_pattern_name') if rules else None
            structure_pattern = json_scan_process(content_for_parsing, forced_pattern_name=forced_pattern_name)
            if not structure_pattern:
                logger.error(f"  [ERROR] '{relative_path}' 파일의 JSON 구조를 분석할 수 없어 원본을 복사합니다.")
                tips_scoped_logger.log(f"    [FAIL] JSON 구조 분석 실패.", base_path=mod_root_path)
                if not context.is_test_run: shutil.copy2(source_path, dest_path)
                return 0, set()
            
            tips_scoped_logger.log(f"    [SCAN] 감지된/지정된 JSON 패턴: '{structure_pattern.get('name')}'", base_path=mod_root_path)
            
            category_regex = re.compile(structure_pattern['export_category_regex'], re.DOTALL)
            tips_array_match = category_regex.search(content_for_parsing)

            if not tips_array_match:
                logger.warning(f"  [WARN] '{relative_path}'에서 'tips' 배열을 찾을 수 없어 원본을 복사합니다.")
                tips_scoped_logger.log(f"    [FAIL] 'tips' 배열 경계 탐색 실패.", base_path=mod_root_path)
                if not context.is_test_run: shutil.copy2(source_path, dest_path)
                return 0, set()
            
            tips_inner_content = tips_array_match.group(1)
            tips_scoped_logger.log(f"    [SCAN] 'tips' 배열 내용 추출 성공 (길이: {len(tips_inner_content)}).", base_path=mod_root_path)

            # --- [핵심 수정] ID 생성 및 타입 결정을 현재 structure_pattern에 직접 위임 ---
            uaf_counter, pagsm_counter = 0, 0
            
            resolver = IdPrefixResolver(mod_root_path=mod_root_path, file_path=source_path)
            
            # [핵심 수정 1] 현재 structure_pattern의 id_prefix를 직접 사용
            current_file_id_prefix = resolver.resolve(rules=context.current_rules, structure_pattern=structure_pattern)
            
            # [핵심 수정 2] 현재 structure_pattern의 item_type을 직접 사용 (rules override 고려)
            current_file_item_type = context.current_rules.get('item_type', structure_pattern.get('item_type', 'tip_json'))
            
            successfully_applied_keys = set()
            
            # --- 3. re.sub 콜백 함수 정의 ---
            def replacer(match):
                nonlocal uaf_counter, pagsm_counter, successfully_applied_keys
                object_content, string_content, comment_content = match.groups()

                if comment_content is not None:
                    tips_scoped_logger.log(f"      [SKIP] 주석 발견, 건너뜁니다: '{comment_content.strip()}'", base_path=mod_root_path)
                    return match.group(0)

                apply_key = None
                
                if object_content:
                    tip_match = re.search(r'"tip"\s*:\s*"((?:\\.|[^"\\])*)"', object_content, re.DOTALL)
                    if tip_match:
                        # [핵심 수정 3] current_file_id_prefix 사용 (UAF 형식은 object_array 패턴에 따라 따로 정의됨)
                        uaf_pattern_info = next((p for p in JSON_STRUCTURE_PATTERNS if p['name'] == 'tips_object_array'), {})
                        uaf_specific_id_prefix = resolver.resolve(rules=context.current_rules, structure_pattern=uaf_pattern_info)
                        uaf_specific_item_type = context.current_rules.get('item_type', uaf_pattern_info.get('item_type', 'tip_json'))

                        text_to_translate = tip_match.group(1)
                        item_id = f"{uaf_specific_id_prefix}[{uaf_counter}]"
                        item_type = uaf_specific_item_type
                        apply_key = (relative_path, item_id, item_type, text_processor_service.process(text_to_translate))
                        tips_scoped_logger.log(f"      [MATCH-UAF] UAF 객체 발견. ID: {item_id}", base_path=mod_root_path)
                        uaf_counter += 1
                elif string_content is not None and string_content.strip():
                    text_to_translate = string_content
                    # [핵심 수정 4] current_file_id_prefix 사용 (PAGSM/ship_names 형식은 string_array 패턴에 따라 정의됨)
                    item_id = f"{current_file_id_prefix}[{pagsm_counter}]"
                    item_type = current_file_item_type # 미리 결정된 current_file_item_type 사용
                    apply_key = (relative_path, item_id, item_type, text_processor_service.process(text_to_translate))
                    tips_scoped_logger.log(f"      [MATCH-PAGSM] PAGSM 문자열 발견. ID: {item_id}", base_path=mod_root_path)
                    pagsm_counter += 1

                if apply_key:
                    tips_scoped_logger.log(f"        -> 생성된 조회 키(4-tuple): ('{apply_key[0]}', '{apply_key[1]}', '{apply_key[2]}', '{apply_key[3][:30]}...')", base_path=mod_root_path)
                    translated_text = translation_map.get(apply_key)
                    if translated_text:
                        tips_scoped_logger.log(f"        -> [HIT] 번역 발견. KR: '{translated_text[:30]}...'", base_path=mod_root_path)
                        successfully_applied_keys.add(apply_key)
                        
                        if object_content: # UAF 형식
                            replacement_literal = json.dumps(translated_text, ensure_ascii=APPLY_JSON_ENSURE_ASCII)[1:-1]
                            final_replacement = object_content[:tip_match.start(1)] + replacement_literal + object_content[tip_match.end(1):]
                            tips_scoped_logger.log(f"        -> UAF 치환 결과: '{final_replacement[:50]}...'", base_path=mod_root_path)
                            return final_replacement
                        else: # PAGSM 형식
                            final_replacement = json.dumps(translated_text, ensure_ascii=APPLY_JSON_ENSURE_ASCII)
                            tips_scoped_logger.log(f"        -> PAGSM 치환 결과: '{final_replacement[:50]}...'", base_path=mod_root_path)
                            return final_replacement
                    else:
                        tips_scoped_logger.log(f"        -> [MISS] 번역 없음.", base_path=mod_root_path)
                
                return match.group(0)

            # --- 4. 치환 실행 ---
            tips_scoped_logger.log(f"    [EXEC] `re.sub` 콜백을 사용하여 치환을 시작합니다...", base_path=mod_root_path)
            combined_pattern = re.compile(r'(\{[\s\S]*?\})|\"((?:\\.|[^\"\\])*)\"|(#[^\r\n]*)', re.DOTALL)
            modified_inner_content = combined_pattern.sub(replacer, tips_inner_content)
            tips_scoped_logger.log(f"    [EXEC] `re.sub` 치환 완료.", base_path=mod_root_path)

            # --- 5. 서식 재구성 후처리 ---
            final_content = content_for_parsing
            
            # 5a. PAGSM 문자열 배열 서식 재구성
            if structure_pattern.get('name') in ['tips_string_array', 'ship_names_string_array']:
                tips_scoped_logger.log(f"    [FORMAT] '{structure_pattern.get('name')}' 형식 감지. 서식을 재구성합니다.", base_path=mod_root_path)
                # 1. 번역이 적용된 모든 문자열 리터럴("..." 형태)을 추출
                all_tips_quoted = re.findall(r'\"(?:\\.|[^\"\\])*\"', modified_inner_content)
                
                # 2. 원하는 서식으로 다시 조합
                if all_tips_quoted:
                    # 각 줄 앞의 들여쓰기를 제거합니다.
                    joined_tips = ",\n".join(all_tips_quoted)
                    # 최종 배열 내용물 생성 시, 마지막 항목 뒤의 불필요한 줄바꿈과 탭을 제거합니다.
                    reformatted_inner_content = f"\n{joined_tips}"
                    
                    final_content = final_content[:tips_array_match.start(1)] + reformatted_inner_content + final_content[tips_array_match.end(1):]
                    tips_scoped_logger.log(f"    [FORMAT] 서식 재구성 완료. 총 {len(all_tips_quoted)}개 항목.", base_path=mod_root_path)
                else:
                    # 치환된 내용으로 원본을 업데이트 (후처리 없이)
                    final_content = final_content[:tips_array_match.start(1)] + modified_inner_content + final_content[tips_array_match.end(1):]
            else:
                # PAGSM/ship_names 형식이 아니면, 치환된 내용으로 원본을 업데이트
                final_content = final_content[:tips_array_match.start(1)] + modified_inner_content + final_content[tips_array_match.end(1):]
            
            # --- 6. 최종 파일 저장 ---
            if not context.is_test_run:
                tips_scoped_logger.log(f"    [WRITE] 최종 파일 저장을 시작합니다: '{dest_path}'", base_path=mod_root_path)
                with open(dest_path, 'w', encoding='utf-8') as f:
                    f.write(final_content)
            
            applied_count = len(successfully_applied_keys)
            if applied_count > 0:
                logger.info(f"     ... [re.sub 서식 보존/재구성 완료] 총 {applied_count}개의 팁에 번역을 적용했습니다.")
            else:
                logger.warning(f"     ... [경고] 'tips.json'에 적용된 번역이 없습니다.")
            
            return applied_count, successfully_applied_keys

        except Exception as e:
            logger.error(f"  [CRITICAL ERROR] 'TipsPolymorphicApplier' 처리 중 오류: {e}", exc_info=True)
            if not context.is_test_run: copy_with_recode(source_path, dest_path, context.is_test_run)
            return 0, set()
                    
    
class GeneralCsvParser(IProcessingStrategy):
    """
    [신규 Parser Strategy] 대부분의 표준 CSV 파일을 처리하는 기본 파서입니다.
    """
    def execute(self, context: ExecutionContext):
        """ExecutionContext를 사용하여 일반 CSV 파일에서 텍스트를 추출합니다."""
        logger = context.logger
        file_path = context.current_source_path
        relative_path = context.current_relative_path
        rules = context.current_rules
        input_folder_path = os.path.join(context.base_path, SOURCE_DATA_FOLDER)
        
        extracted = []
        
        delimiter = rules.get('delimiter', ',') if rules else ','
        
        try:
            content, _, _ = read_file_with_fallback(file_path)
            if content is None:
                return []

            reader = list(csv.reader(StringIO(content), delimiter=delimiter))
            if not reader:
                return []

            first_line_index = 0
            while first_line_index < len(reader) and reader[first_line_index] and reader[first_line_index][0].strip().startswith('#'):
                first_line_index += 1
            
            if first_line_index >= len(reader):
                return []

            header = reader[first_line_index]
            data_rows = reader[first_line_index + 1:]

            key_columns = rules.get('key_columns', ID_COLUMNS_TO_CHECK) if rules else ID_COLUMNS_TO_CHECK
            id_column_in_file = next((col for col in key_columns if col in header), None)

            if not id_column_in_file:
                logger.debug(f"'{relative_path}'에 ID 열을 찾을 수 없어 첫 열을 ID로 간주합니다.")
                header = ['id'] + [f'col{i+1}' for i in range(len(header)-1)]
                id_column_in_file = 'id'
            
            id_col_idx = header.index(id_column_in_file)
            
            translatable_cols_names = rules.get('translatable_columns') if rules and rules.get('translatable_columns') else set(NAME_COLUMNS_TO_CHECK) | set(TEXT_COLUMNS_TO_CHECK) | set(AUTHOR_COLUMNS_TO_CHECK)
            translatable_cols_indices = [i for i, h in enumerate(header) if h in translatable_cols_names]

            for row in data_rows:
                if not row or len(row) <= id_col_idx or not row[id_col_idx].strip() or row[id_col_idx].strip().startswith('#'):
                    continue
                
                row_id = row[id_col_idx].strip()
                for col_idx in translatable_cols_indices:
                    if len(row) > col_idx:
                        cell_content = row[col_idx]
                        col_name = header[col_idx]
                            
                        is_valid, reason = analyze_text_validity(cell_content)
                        if is_valid:
                            extracted.append({'source_file': relative_path, 'id': row_id, 'type': col_name, 'text_en': cell_content})
                        else:
                            FilterAuditService.record(relative_path, row_id, col_name, cell_content, reason)

        except Exception as e:
            logger.error(f"GeneralCsvParser로 '{relative_path}' 처리 중 오류: {e}")
        
        return extracted


class GeneralCsvApplier(IProcessingStrategy):
    """
    [v2.1] 대부분의 표준 CSV 파일에 번역을 적용하는 기본 어플라이어입니다.
    TextProcessorService의 restore_newlines를 사용하여 줄바꿈을 복원합니다.
    """
    def execute(self, context: ExecutionContext):
        """ExecutionContext를 사용하여 일반 CSV 파일에 번역을 적용합니다."""
        logger = context.logger
        relative_path = context.current_relative_path
        applied_count = 0
        successfully_applied_keys = set()

        if context.is_test_run:
            logger.debug(f"테스트 모드: CSV '{relative_path}' 파일 생성을 스킵합니다.")
            return 0, set()
        
        try:
            content, _, _ = read_file_with_fallback(context.current_source_path)
            if content is None:
                return 0, set()

            reader = csv.DictReader(StringIO(content))
            header = reader.fieldnames
            if not header:
                if not context.is_test_run: shutil.copy2(context.current_source_path, context.current_dest_path)
                return 0, set()
            
            id_col_in_file = next((col for col in ID_COLUMNS_TO_CHECK if col in header), header[0])

            processed_rows = []
            for row_dict in reader:
                if (row_dict.get(header[0], "") or "").strip().startswith('#'):
                    processed_rows.append(row_dict)
                    continue

                new_row_dict = dict(row_dict)
                row_id = new_row_dict.get(id_col_in_file, "").strip()

                if row_id:
                    for col_name, original_text_en in row_dict.items():
                        if col_name is None or original_text_en is None: continue

                        # text_processor_service.process 호출 시 item_type을 명확히 전달합니다.
                        cleaned_text_en_for_key = text_processor_service.process(original_text_en, item_type=col_name)
                        key = (relative_path, row_id, col_name, cleaned_text_en_for_key)
                        
                        translated_text = context.translation_map.get(key)
                        if translated_text is None and context.translation_map_insensitive:
                            fallback_key = (relative_path, row_id.lower(), col_name.lower(), cleaned_text_en_for_key)
                            translated_text = context.translation_map_insensitive.get(fallback_key)
                        
                        if translated_text is not None:
                            # --- [핵심 수정] ---
                            # text_processor_service.restore_newlines를 사용하여 줄바꿈을 복원합니다.
                            new_row_dict[col_name] = text_processor_service.restore_newlines(translated_text, item_type=col_name)
                            # --- [수정 끝] ---
                            applied_count += 1
                            successfully_applied_keys.add(key)
                
                if None in new_row_dict: del new_row_dict[None]
                processed_rows.append(new_row_dict)

            if not context.is_test_run:
                temp_dest_path = context.current_dest_path + '.tmp'
                with open(temp_dest_path, mode='w', encoding=OUTPUT_FILE_ENCODING, newline='') as outfile:
                    writer = csv.DictWriter(outfile, fieldnames=header)
                    writer.writeheader()
                    writer.writerows(processed_rows)
                os.replace(temp_dest_path, context.current_dest_path)
            
            return applied_count, successfully_applied_keys

        except Exception as e:
            logger.error(f"  GeneralCsvApplier로 '{relative_path}' 처리 중 오류: {e}", exc_info=True)
            if not context.is_test_run:
                copy_with_recode(context.current_source_path, context.current_dest_path, context.is_test_run)
            return 0, set()

class RulesCsvParser(IProcessingStrategy):
    """
    [신규 Parser Strategy] 'rules.csv'와 같이 복잡한 구조를 가진 CSV 파일을 처리합니다.
    내부에 script, options 컬럼 처리를 위한 헬퍼 메서드를 포함합니다.
    """
    def execute(self, context: ExecutionContext):
        logger = context.logger
        file_path = context.current_source_path
        relative_path = context.current_relative_path
        rules = context.current_rules
        
        extracted = []
        logger.debug(f"  -> RulesCsvParser로 '{relative_path}' 처리 시작.")

        try:
            content, _, _ = read_file_with_fallback(file_path)
            if content is None: return []
        
            lines = content.splitlines(keepends=True)
            if not lines: return []

            header = [h.strip() for h in lines[0].strip().lstrip('\ufeff').split(',')]
            num_columns = len(header)
            translatable_columns_config = {col.lower() for col in rules.get('translatable_columns', [])}

            current_base_id = ""
            # csv.reader는 여러 줄로 구성된 셀을 올바르게 처리하지 못할 수 있으므로,
            # 전체 내용을 읽고 수동으로 파싱하는 것이 더 안정적일 수 있습니다.
            # 여기서는 기존 로직을 유지합니다.
            reader = csv.reader(StringIO("".join(lines[1:])))

            for row in reader:
                if not row or not any(field.strip() for field in row) or row[0].strip().startswith('#'):
                    continue
                if len(row) > num_columns: row = row[:num_columns]
                if row[0].strip(): current_base_id = row[0].strip()
                if not current_base_id: continue

                for col_idx, column_text in enumerate(row):
                    if col_idx >= len(header): continue
                    
                    col_name = header[col_idx]
                    if col_name.lower() not in translatable_columns_config: continue

                    handler_results = None
                    if col_name.lower() == 'script':
                        handler_results = self._handle_script_column(column_text, relative_path, current_base_id, col_name)
                    elif col_name.lower() == 'options':
                        result = self._handle_options_column(column_text, relative_path, current_base_id, col_name)
                        if result: handler_results = [result]
                    elif col_name.lower() == 'text':
                        result = self._handle_text_column(column_text, relative_path, current_base_id, col_name)
                        if result: handler_results = [result]
                    
                    if handler_results:
                        extracted.extend(handler_results)
        
        except Exception as e:
            logger.error(f"RulesCsvParser로 '{relative_path}' 처리 중 오류 발생: {e}", exc_info=True)

        return extracted

    def _extract_script_snippets(self, line_text, source_file, item_id):
        """
        [내부 헬퍼] script 라인에서 번역 가능한 텍스트 조각을 추출하고 [ESC] 태그로 변환합니다.
        """
        command_list = '|'.join(COMMANDS_WITH_TRANSLATABLE_TEXT)
        command_syntax_pattern = re.compile(fr'^\s*({command_list})\b(\s+[^"]*)?\s*(.*)', re.IGNORECASE | re.DOTALL)
        match = command_syntax_pattern.match(line_text)
        if not match: return [], []
        
        text_argument_part = match.group(3)
        quote_pattern = re.compile(r'\"((?:\\.|[^\"\\])*?)\"|\\\"([\s\S]*?)\\\"')
        raw_snippets = [m[0] or m[1] for m in quote_pattern.findall(text_argument_part)]
        
        translatable, processed = [], []
        for snippet in raw_snippets:
            is_valid, reason = analyze_text_validity(snippet.replace('\\"', '"'))
            if is_valid:
                translatable.append(snippet)
                processed.append(snippet.replace('\\"', '[ESC]'))
            else:
                FilterAuditService.record(source_file, item_id, 'script', snippet, reason)
        return translatable, processed

    def _handle_script_column(self, column_text, relative_path, base_id, col_name):
        """
        [내부 헬퍼] 'script' 컬럼 전체를 처리하여 여러 개의 번역 항목을 생성합니다.
        """
        results = []
        for line_index, line in enumerate(column_text.splitlines(), 1):
            if not line.strip(): continue
            _, processed_snippets = self._extract_script_snippets(line, relative_path, base_id)
            if processed_snippets:
                results.append({
                    'source_file': relative_path, 'id': base_id,
                    'type': f"{col_name}:{line_index}",
                    'text_en': SCRIPT_TEXT_DELIMITER.join(processed_snippets)
                })
        return results

    def _handle_options_column(self, column_text, relative_path, base_id, col_name):
        """
        [내부 헬퍼] 'options' 컬럼을 처리하여 단일 번역 항목을 생성합니다.
        """
        # _extract_options_snippets는 독립적인 전역 함수이므로 그대로 호출
        cleaned_options = _extract_options_snippets(column_text, relative_path, base_id)
        if cleaned_options:
            return {'source_file': relative_path, 'id': base_id, 'type': f"{col_name}:{len(cleaned_options)}", 'text_en': SCRIPT_TEXT_DELIMITER.join(cleaned_options)}
        return None
    
    def _handle_text_column(self, column_text, relative_path, base_id, col_name):
        """
        [내부 헬퍼] 'text' 컬럼을 처리하여 단일 번역 항목을 생성합니다.
        """
        if is_translatable(column_text):
            return {'source_file': relative_path, 'id': base_id, 'type': col_name, 'text_en': text_processor_service.process(column_text, item_type='text')}
        return None

class RulesCsvApplier(IProcessingStrategy):
    """
    [v2.1] 'rules.csv'와 같은 복잡한 CSV 파일에 번역을 적용합니다.
    TextProcessorService의 restore_newlines를 사용하여 줄바꿈을 복원합니다.
    """
    def execute(self, context: ExecutionContext):
        logger = context.logger
        relative_path = context.current_relative_path
        successfully_applied_keys = set()

        try:
            content, _, _ = read_file_with_fallback(context.current_source_path)
            if content is None: return 0, set()

            lines = content.splitlines(keepends=True)
            if not lines: return 0, set()

            header = [h.strip() for h in lines[0].strip().lstrip('\ufeff').split(',')]
            output_rows = [header]
            
            reader = csv.reader(StringIO("".join(lines[1:])))

            for original_row in reader:
                row = original_row[:len(header)]
                if not row or not any(field.strip() for field in row) or row[0].strip().startswith('#'):
                    output_rows.append(original_row)
                    continue

                base_id = row[0].strip()
                modified_row = list(row)

                for col_idx, column_text in enumerate(row):
                    if col_idx >= len(header): continue
                    col_name = header[col_idx]
                    
                    if col_name not in context.current_rules.get('translatable_columns', []): continue

                    applied_keys_in_cell = set()
                    if col_name == 'script':
                        modified_row[col_idx], applied_keys_in_cell = self._handle_script_column(column_text, context, base_id)
                    elif col_name == 'options':
                        modified_row[col_idx], applied_keys_in_cell = self._handle_options_column(column_text, context, base_id)
                    else:
                        final_text_en_for_key = text_processor_service.process(column_text, item_type=col_name)
                        apply_key = (relative_path, base_id, col_name, final_text_en_for_key)
                        
                        translated_value = context.translation_map.get(apply_key) or context.translation_map_insensitive.get((relative_path, base_id.lower(), col_name.lower(), final_text_en_for_key))
                        if translated_value is not None:
                            # --- [핵심 수정] ---
                            # text_processor_service.restore_newlines를 사용하여 줄바꿈을 복원합니다.
                            modified_row[col_idx] = text_processor_service.restore_newlines(translated_value, item_type=col_name)
                            # --- [수정 끝] ---
                            applied_keys_in_cell = {apply_key}

                    if applied_keys_in_cell:
                        successfully_applied_keys.update(applied_keys_in_cell)

                output_rows.append(modified_row)

            if not context.is_test_run:
                temp_dest_path = context.current_dest_path + '.tmp'
                with open(temp_dest_path, 'w', encoding=OUTPUT_FILE_ENCODING, newline='') as f_out:
                    writer = csv.writer(f_out, quoting=csv.QUOTE_MINIMAL)
                    writer.writerows(output_rows)
                os.replace(temp_dest_path, context.current_dest_path)
            
            return len(successfully_applied_keys), successfully_applied_keys

        except Exception as e:
            logger.error(f"  RulesCsvApplier로 '{relative_path}' 처리 중 오류: {e}", exc_info=True)
            if not context.is_test_run:
                copy_with_recode(context.current_source_path, context.current_dest_path, context.is_test_run)
            return 0, set()

    def _handle_options_column(self, column_text, context, base_id):
        """
        [내부 엔진 v2 - 최종] 'options' 컬럼에 대한 번역을 서식을 보존하며 적용합니다.
        기존 handle_options_column_apply 함수의 완전한 로직을 통합했습니다.
        """
        logger = context.logger
        
        # 1. 조회 키 생성
        translatable_originals = _extract_options_snippets(
            column_text, 
            source_file=context.current_relative_path, 
            item_id=base_id
        )
        if not translatable_originals:
            return column_text, set()

        unified_en_text = SCRIPT_TEXT_DELIMITER.join(translatable_originals)
        type_info = f"options:{len(translatable_originals)}"
        apply_key = (context.current_relative_path, base_id, type_info, unified_en_text)
        
        translated_unified_text = context.translation_map.get(apply_key)
        if translated_unified_text is None and context.translation_map_insensitive:
            fallback_key = (context.current_relative_path, base_id.lower(), type_info.lower(), unified_en_text)
            translated_unified_text = context.translation_map_insensitive.get(fallback_key)

        if not translated_unified_text:
            return column_text, set()
        
        translated_snippets = translated_unified_text.split(SCRIPT_TEXT_DELIMITER)
        if len(translatable_originals) != len(translated_snippets):
            logger.warning(f"      [경고] ID '{base_id}'의 options 번역 조각 개수 불일치! 적용 건너뜁니다.")
            return column_text, set()

        key_value_pattern = re.compile(r'(?P<key>[a-zA-Z0-9_]+)\s*:\s*(?P<value>.+?)(?=\s*[a-zA-Z0-9_]+:\s*|$)', re.DOTALL)
        matches = list(re.finditer(key_value_pattern, column_text))
        
        targets_to_replace = []
        original_idx = 0
        for match in matches:
            raw_value = match.group('value')
            cleaned_value = _clean_and_strip_quotes(raw_value)
            
            if original_idx < len(translatable_originals) and cleaned_value == translatable_originals[original_idx]:
                targets_to_replace.append({
                    'match_obj': match,
                    'translated_text': translated_snippets[original_idx]
                })
                original_idx += 1

        modified_column_text = column_text
        for target in reversed(targets_to_replace):
            match = target['match_obj']
            translated_text = target['translated_text']
            start, end = match.span('value')
            original_value_str = match.group('value').strip()

            replacement = translated_text
            
            if original_value_str.startswith('"') and not replacement.startswith('"'):
                replacement = '"' + replacement
            if original_value_str.endswith('"') and not replacement.endswith('"'):
                replacement += '"'
                
            original_raw_value = match.group('value')
            leading_whitespace = original_raw_value[:len(original_raw_value) - len(original_raw_value.lstrip())]
            trailing_whitespace = original_raw_value[len(original_raw_value.rstrip()):]
            final_replacement = leading_whitespace + replacement + trailing_whitespace
                
            modified_column_text = modified_column_text[:start] + final_replacement + modified_column_text[end:]

        return modified_column_text, {apply_key}

    def _handle_script_column(self, column_text, context, base_id):
        # 기존 handle_script_column_apply 로직 (self, context 추가)
        modified_lines = []
        successfully_applied_keys = set()
        for line_index, line in enumerate(column_text.splitlines(), 1):
            if not line.strip():
                modified_lines.append(line)
                continue
            
            # _extract_script_snippets를 RulesCsvParser의 인스턴스 메서드로 호출
            temp_parser = RulesCsvParser()
            translatable_originals, processed_snippets = temp_parser._extract_script_snippets(line, context.current_relative_path, base_id)

            if not processed_snippets:
                modified_lines.append(line)
                continue

            type_info = f"script:{line_index}"
            unified_en_text = SCRIPT_TEXT_DELIMITER.join(processed_snippets)
            apply_key = (context.current_relative_path, base_id, type_info, unified_en_text)
            translated_unified_text = context.translation_map.get(apply_key) or context.translation_map_insensitive.get((context.current_relative_path, base_id.lower(), type_info.lower(), unified_en_text))

            if not translated_unified_text:
                modified_lines.append(line)
                continue

            translated_snippets = translated_unified_text.split(SCRIPT_TEXT_DELIMITER)
            if len(translatable_originals) != len(translated_snippets):
                modified_lines.append(line)
                continue
            
            translation_mapping = dict(zip(translatable_originals, translated_snippets))
            
            quote_pattern = re.compile(r'\"((?:\\.|[^\"\\])*?)\"|\\\"([\s\S]*?)\\\"')
            def replacer(match):
                raw_content = match.group(1) if match.group(1) is not None else match.group(2)
                if raw_content in translation_mapping:
                    restored_kr = translation_mapping[raw_content].replace('[ESC]', '\\"')
                    return f'"{restored_kr}"' if match.group(1) is not None else f'\\"{restored_kr}\\"'
                return match.group(0)

            modified_line = quote_pattern.sub(replacer, line)
            modified_lines.append(modified_line)
            successfully_applied_keys.add(apply_key)

        return "\n".join(modified_lines), successfully_applied_keys


# 구 class JsonPolymorphicApplier(IProcessingStrategy):
class GenericRegexJsonApplier(IProcessingStrategy):
    """
    [v2.8-REFACTOR] reformat_on_apply 로직을 re.sub 콜백 기반으로 재설계하여
    번역 누락 롤백 버그를 해결하고 유니코드/이스케이프 처리를 통합합니다.
    """
    def execute(self, context: ExecutionContext):
        logger = context.logger
        source_path = context.current_source_path
        dest_path = context.current_dest_path
        relative_path = context.current_relative_path
        
        if context.is_test_run:
            logger.debug(f"테스트 모드: JSON '{relative_path}' 파일 생성을 스킵합니다.")
            return 0, set()
        
        try:
            content, _, _ = read_file_with_fallback(source_path)
            if content is None: return 0, set()

            structure_pattern = json_scan_process(content)
            if not structure_pattern:
                copy_with_recode(source_path, dest_path, context.is_test_run)
                return 0, set()

            apply_category_template = structure_pattern.get('apply_category_regex')
            apply_kv_template = structure_pattern.get('apply_kv_regex')

            if not apply_category_template or not apply_kv_template:
                copy_with_recode(source_path, dest_path, context.is_test_run)
                return 0, set()

            # --- [핵심 수정] reformat_on_apply 플래그에 따라 로직 분기 ---
            if context.current_rules and context.current_rules.get('reformat_on_apply', False):
                # --- 새로운 통합 후처리 로직 ---
                logger.info(f"  -> [서식 재구성 모드] '{relative_path}' 파일의 서식을 재구성하며 번역을 적용합니다...")
                
                successfully_applied_keys = set()

                def reformat_and_apply_callback(category_match):
                    # 콜백 함수는 category_match 객체 하나만 인자로 받습니다.
                    # nonlocal을 사용하여 외부의 successfully_applied_keys를 수정할 수 있도록 합니다.
                    nonlocal successfully_applied_keys
                    
                    category_block_content = category_match.group(1)
                    # 카테고리 이름을 찾기 위한 더 안정적인 정규식
                    category_name_match = re.search(r'"([a-zA-Z0-9_]+)"\s*:\s*\{', category_match.group(0))
                    if not category_name_match: return category_match.group(0) # 카테고리 이름을 못 찾으면 원본 블록 반환
                    category_name = category_name_match.group(1)
                    
                    # 모든 키-값 쌍을 찾는 정규식
                    kv_pattern = re.compile(r'"([a-zA-Z0-9_]+)"\s*:\s*"((?:\\.|[^"\\])*)"')
                    
                    formatted_lines = []
                    
                    for kv_match in kv_pattern.finditer(category_block_content):
                        key = kv_match.group(1)
                        value_en_raw = kv_match.group(2)
                        
                        # Apply 키 생성
                        value_en_processed = text_processor_service.process(value_en_raw, item_type='json')
                        apply_key = (relative_path, f"{category_name}.{key}", 'json', value_en_processed)
                        
                        # 번역 조회
                        translated_text = context.translation_map.get(apply_key)
                        
                        final_value_text = value_en_raw # 기본값은 원본 text_en
                        if translated_text is not None:
                            successfully_applied_keys.add(apply_key)
                            # 번역문을 JSON 값으로 안전하게 변환 (따옴표 제거)
                            temp_val = json.dumps(translated_text, ensure_ascii=APPLY_JSON_ENSURE_ASCII)[1:-1]
                            final_value_text = temp_val
                        
                        # [핵심] 최종 값에 대해 유니코드 이스케이프 적용 (Python 3.8+ f-string 디버그 문법 사용 자제)
                        # f-string 내부에서 백슬래시가 해석될 수 있으므로, replace를 사용
                        if not APPLY_JSON_ENSURE_ASCII:
                            for char, escaped_char in CHARS_TO_ESCAPE_IN_JSON.items():
                                final_value_text = final_value_text.replace(char, escaped_char)
                        
                        formatted_lines.append(f'\t\t"{key}":"{final_value_text}"')

                    joined_kv = ",\n".join(formatted_lines)
                    reformatted_inner_content = f"\n{joined_kv}\n\t"
                    
                    # 원래 카테고리 블록의 시작 부분 + 재구성된 내용 + 닫는 괄호
                    return category_match.group(0)[:category_match.start(1)-category_match.start(0)] + reformatted_inner_content + "}"

                category_pattern_str = apply_category_template.format(category="[a-zA-Z0-9_]+")
                content = re.sub(category_pattern_str, reformat_and_apply_callback, content)
                
                applied_count = len(successfully_applied_keys)
                
            else:
                # --- 기존의 서식 보존 로직 ---
                relevant_translations = {k: v for k, v in context.translation_map.items() if k[0] == relative_path}
                replacements = []
                successfully_applied_keys = set()

                for key_4_tuple, text_kr in relevant_translations.items():
                    _, item_id, item_type, text_en_master = key_4_tuple
                    path_parts = item_id.split('.')
                    if structure_pattern.get('name') == 'json_selective_key_value':
                        continue
                    if len(path_parts) < 2: continue
                    
                    category, final_key = path_parts[0], path_parts[-1]

                    category_pattern_str = apply_category_template.format(category=re.escape(category))
                    category_match = re.search(category_pattern_str, content)
                    
                    if not category_match: continue
                    
                    category_block_content = category_match.group(1)
                    category_block_start_index = category_match.start(1)

                    text_en_as_json_value = json.dumps(text_en_master, ensure_ascii=APPLY_JSON_ENSURE_ASCII)[1:-1]
                    final_pattern_str = apply_kv_template.format(
                        key=re.escape(final_key),
                        text_en_escaped=re.escape(text_en_as_json_value)
                    )
                    
                    for final_match in re.finditer(final_pattern_str, category_block_content):
                        raw_value_from_file = final_match.group(1) 
                        processed_value_for_check = text_processor_service.process(raw_value_from_file, item_type='json')
                        
                        if processed_value_for_check == text_en_master:
                            replacement_value = json.dumps(text_kr, ensure_ascii=APPLY_JSON_ENSURE_ASCII)[1:-1]
                            if not APPLY_JSON_ENSURE_ASCII:
                                for char, escaped_char in CHARS_TO_ESCAPE_IN_JSON.items():
                                    replacement_value = replacement_value.replace(char, escaped_char)
                            
                            start_pos_abs = category_block_start_index + final_match.start(1)
                            end_pos_abs = category_block_start_index + final_match.end(1)
                            
                            replacements.append((start_pos_abs, end_pos_abs, replacement_value))
                            successfully_applied_keys.add(key_4_tuple)
                            break
                
                sorted_replacements = sorted(replacements, key=lambda x: x[0], reverse=True)
                for start, end, replacement in sorted_replacements:
                    content = content[:start] + replacement + content[end:]
                
                applied_count = len(successfully_applied_keys)
            
            # --- 공통 파일 저장 및 로깅 ---
            with open(dest_path, 'w', encoding=OUTPUT_FILE_ENCODING) as f:
                f.write(content)
                
            if applied_count > 0:
                logger.info(f"  -> [동적 JSON 처리 성공] '{relative_path}' 파일에 {applied_count}개의 번역을 적용했습니다.")
                
            return applied_count, successfully_applied_keys

        except Exception as e:
            logger.error(f"  동적 JSON '{relative_path}' 처리 중 오류: {e}. 원본 복사 시도.", exc_info=True)
            copy_with_recode(source_path, dest_path, context.is_test_run)
            return 0, set()

# def _recursive_escape_chars(obj):
#     """
#     Python 객체(dict, list)를 재귀적으로 순회하며, 모든 문자열 값에 대해
#     CHARS_TO_ESCAPE_IN_JSON 규칙에 따라 유니코드 이스케이프를 적용합니다.
#     """
#     if isinstance(obj, dict):
#         return {k: _recursive_escape_chars(v) for k, v in obj.items()}
#     elif isinstance(obj, list):
#         return [_recursive_escape_chars(elem) for elem in obj]
#     elif isinstance(obj, str):
#         if not APPLY_JSON_ENSURE_ASCII:
#             escaped_str = obj
#             for char, escaped_char in CHARS_TO_ESCAPE_IN_JSON.items():
#                 escaped_str = escaped_str.replace(char, escaped_char)
#             return escaped_str
#     return obj

############################################################################
#
#        [ ARCHITECTURAL DIRECTIVE - NESTED_JSON_APPLIER_V4_HYBRID_COMPACT ]
#
# TARGET: GeneralJsonApplier, config/chatter/characters/*.json 및 GeneralJsonParser에 의해 처리되는 유사한 JSON 파일
# STATUS: FINALIZED (Two-step Post-processing Applied)
# ROLE: Handles recursive application of translations for deeply nested JSON structures, prioritizing functional correctness. Offers configurable output formatting (indented with minimal spacing, including optional one-line compact objects and simple arrays).
# BEHAVIOR:
#   이 Applier는 `json.dumps()`로 표준화된 JSON 문자열을 생성한 후, 두 단계의 정규식 후처리를 적용한다:
#   1. (배열 내 객체 압축) `JSON_COMPACT_OBJECTS_IN_ARRAYS`가 `True`일 경우, 배열 내의 다중 줄 객체를 한 줄로 압축한다.
#   2. (단순 배열 압축) `JSON_COMPACT_SIMPLE_ARRAYS`가 `True`일 경우, `{}` 객체를 포함하지 않는 단순 배열을 한 줄로 압축한다.
# CRITICAL_CONTEXT:
#   이 지침은 `JSON_STRINGS_PROCESSOR_V2.1_STABLE`이 `strings/strings.json`과 같은 파일에 대해 요구하는 엄격한 서식 보존 원칙의 예외를 명시한다.
#   `config/chatter/characters/*.json`과 같은 파일의 경우, 주석, 키 순서, 미묘한 공백 변경과 같은 비의미론적 서식 손실보다 깊이 중첩된 텍스트 필드의 기능적 번역 적용이 더 중요하다고 판단된다.
#   다만, `json.dumps`의 옵션 조정을 통해 출력의 들여쓰기 정도 및 공백 최소화는 물론, 배열 내 객체의 선택적 한 줄 압축 및 단순 배열의 한 줄 압축까지 사용자가 선택할 수 있도록 유연성을 제공한다.
#   이 조합을 통해, 이 프로젝트에서는 "Chatter JSON 형식"이라 명명하는 고유한 출력 스타일을 생성한다.
# DESIGN_CHOICE:
#   Recursive Object-Modification Pattern coupled with a two-step Regex Post-processing for sophisticated inline compaction. `apply_translation_recursive`의 기존 재귀 로직을 활용하여 복잡한 중첩 구조에 효율적으로 대응하며,
#   `json.dumps` 결과물에 대한 정규식 후처리를 통해 미세한 서식 조정을 추가한다.
# MODIFICATION_PROTOCOL:
#   새로운 종류의 깊이 중첩된 JSON 파일을 `GeneralJsonParser`로 처리하고 `GeneralJsonApplier`로 번역을 적용해야 할 경우,
#   `SPECIAL_FILE_HANDLING`에서 해당 파일을 `GeneralJsonParser`와 `GeneralJsonApplier`에 매핑하십시오.
#   이 Applier의 `json.dumps` 동작 또는 후처리 로직을 변경하려면 이 지침을 수정해야 한다.
#
############################################################################
# 깊이 중첩된 JSON 파일에 번역을 적용하기 위한 새로운 Applier
class GeneralJsonApplier(IProcessingStrategy):
    """
    [신규 Applier Strategy] 일반 JSON 파일 (특히 깊이 중첩된 구조)에 번역을 적용합니다.
    파일을 Python 객체로 로드하고, 재귀적으로 번역을 적용한 후, 다시 JSON 파일로 씁니다.
    [v3.2-FINAL] json.dumps 이후에 유니코드 이스케이프 후처리를 적용하여 번역 누락을 해결합니다.
    """
    def execute(self, context: ExecutionContext):
        logger = context.logger
        source_path = context.current_source_path
        dest_path = context.current_dest_path
        relative_path = context.current_relative_path
        
        applied_count = 0
        successfully_applied_keys = set()

        if context.is_test_run:
            logger.debug(f"테스트 모드: GeneralJsonApplier '{relative_path}' 파일 생성을 스킵합니다.")
            return 0, set()

        try:
            content, _, _ = read_file_with_fallback(source_path)
            if content is None:
                if not context.is_test_run: shutil.copy2(source_path, dest_path)
                return 0, set()

            # 1. JSON 파일 내용을 Python 객체로 파싱 (중앙 로더 사용)
            data_obj = _load_and_sanitize_json(content, relative_path)
            if data_obj is None:
                logger.error(f"  [ERROR] '{relative_path}' 파일을 JSON 객체로 파싱할 수 없어 원본을 복사합니다.")
                if not context.is_test_run: shutil.copy2(source_path, dest_path)
                return 0, set()

            # 2. 재귀적으로 번역 적용
            # apply_translation_recursive는 이제 successfully_applied_keys도 반환합니다.
            modified_obj, applied_count, applied_keys = apply_translation_recursive(
                data_obj, "", context.translation_map, relative_path, context.translation_map_insensitive
            )
            successfully_applied_keys.update(applied_keys)

            # json.dumps 호출 전, 유니코드 이스케이프를 재귀적으로 적용
            # final_obj_to_dump = _recursive_escape_chars(modified_obj)

            # 3. 변경된 객체를 다시 JSON 파일로 씁니다 (표준화된 포맷)
            if not context.is_test_run:
                json_string = json.dumps(
                    modified_obj, 
                    indent=JSON_OUTPUT_INDENT,
                    ensure_ascii=APPLY_JSON_ENSURE_ASCII, 
                    sort_keys=JSON_OUTPUT_SORT_KEYS,
                    separators=JSON_OUTPUT_SEPARATORS
                )

                # 2. json.dumps 이후, 유니코드 이스케이프 후처리 적용
                if not APPLY_JSON_ENSURE_ASCII:
                    for char, escaped_char in CHARS_TO_ESCAPE_IN_JSON.items():
                        json_string = json_string.replace(char, escaped_char)

                # 3b. [핵심 수정] 선택적 압축 후처리 로직
                if JSON_COMPACT_OBJECTS_IN_ARRAYS and JSON_OUTPUT_INDENT is not None:
                    # 정규식 패턴: 배열 내의 다중 줄 객체를 찾음
                    # 이 패턴은 `id`, `text`, 그리고 선택적으로 `replyToId` 필드를 가진 객체를 대상으로 합니다.
                    # json.dumps(indent=2, separators=(',',':'))에 의해 생성된 정확한 들여쓰기 수준과 줄바꿈 패턴을 활용합니다.
                    pattern = re.compile(
                        r"(\s*){\n"                        # 1: obj_indent (객체 시작 들여쓰기)
                        r"\s*\"id\":\"[^\"]*\",\n"         # id 필드
                        r"\s*\"text\":\"[^\"]*\""         # text 필드
                        r"(,\n\s*\"replyToId\":\"[^\"]*\")?" # 2: reply_to_id (선택적 replyToId 필드)
                        r"\n\s*}(,)?",                      # 3: trailing_comma (객체 뒤의 쉼표)
                        re.MULTILINE
                    )
                    
                    def compact_object_replacer(match):
                        obj_indent = match.group(1)
                        # 매칭된 전체 문자열에서 줄바꿈과 들여쓰기를 제거하여 한 줄로 압축
                        # [핵심 버그 수정] 압축 시 원본에 포함된 쉼표를 제거(rstrip)하여 이중 쉼표 방지
                        compacted_str = re.sub(r'\s*\n\s*', '', match.group(0).strip()).rstrip(',')
                        # 객체 뒤의 쉼표가 있었다면 다시 붙여줌
                        trailing_comma = match.group(3) or ''
                        # 최종적으로 들여쓰기 + {압축된 내용} + 쉼표 형태로 반환
                        return f"{obj_indent}{compacted_str}{trailing_comma}"

                    json_string = pattern.sub(compact_object_replacer, json_string)

                # 3c. [2단계 후처리] 단순 배열 선택적 압축
                if JSON_COMPACT_SIMPLE_ARRAYS and JSON_OUTPUT_INDENT is not None:
                    # 정규식 패턴: 키와 함께 다중 줄로 확장된 배열을 찾음
                    pattern = re.compile(
                        r'(\s*)("[^"]+":\s*)\[(\s*?\n[\s\S]*?\n\s*)\]',
                        re.MULTILINE
                    )
                    
                    def compact_simple_array_replacer(match):
                        indent, key, content = match.groups()
                        if '{' in content:
                            return match.group(0)
                        compacted_content = re.sub(r'\s*\n\s*', '', content.strip())
                        return f"{indent}{key}[{compacted_content}]"
                    
                    json_string = pattern.sub(compact_simple_array_replacer, json_string)

                with open(dest_path, 'w', encoding=OUTPUT_FILE_ENCODING) as f:
                    f.write(json_string)
            
            if applied_count > 0:
                logger.info(f"  -> [객체 기반 적용 성공] '{relative_path}' 파일에 {applied_count}개의 번역을 적용했습니다. (서식 표준화)")
            else:
                logger.warning(f"  -> [경고] GeneralJsonApplier로 '{relative_path}'에 적용된 번역이 없습니다. (원본 복사)")
                # 번역이 적용되지 않았지만 파일이 성공적으로 파싱되었다면 원본 그대로 복사하는 것이 아니라 빈번역 파일을 생성.
                # 그러나 이 Applier는 재덤프를 하기 때문에 서식이 달라진다.
                # 번역이 없었다면 굳이 파일을 새로 만들 필요가 없다.
                # (수정) 번역이 없으면 원본 그대로 복사. (기존 Apply의 폴백 동작과 유사)
                if not context.is_test_run: shutil.copy2(source_path, dest_path)

            return applied_count, successfully_applied_keys

        except Exception as e:
            logger.error(f"  GeneralJsonApplier로 '{relative_path}' 처리 중 오류: {e}. 원본 복사 시도.", exc_info=True)
            if not context.is_test_run:
                copy_with_recode(source_path, dest_path, context.is_test_run)
            return 0, set()

class JsonPolymorphicParser(IProcessingStrategy):
    """
    [v2.0] 모든 정규화 책임을 text_processor_service에 위임하여
    중앙 집중식 데이터 처리를 보장합니다.
    """
    def execute(self, context: ExecutionContext):
        """ExecutionContext를 사용하여 JSON 파일에서 텍스트를 추출합니다."""
        logger = context.logger
        file_path = context.current_source_path
        input_folder_path = os.path.join(context.base_path, SOURCE_DATA_FOLDER)
        relative_path = os.path.relpath(file_path, input_folder_path).replace('\\', '/')
        logger.info(f" -> 동적 JSON 파서로 '{relative_path}' 파일을 처리합니다...")

        extracted = []
        try:
            content, _, _ = read_file_with_fallback(file_path)
            if not content:
                return []

            structure_pattern = json_scan_process(content)
            if not structure_pattern:
                logger.error(f"  -> '{relative_path}' 파일의 JSON 구조를 분석할 수 없어 처리를 중단합니다.")
                return []

            top_level_pattern = re.compile(structure_pattern['export_category_regex'], re.DOTALL)
            kv_pattern = re.compile(structure_pattern['export_kv_regex'])

            for top_match in top_level_pattern.finditer(content):
                category_name = top_match.group(1)
                category_block = top_match.group(2)
                
                if category_name == "starSystems":
                    continue

                for kv_match in kv_pattern.finditer(category_block):
                    key = kv_match.group(1)
                    raw_value = kv_match.group(2)

                    # --- [핵심 수정] ---
                    # 모든 텍스트 정규화(이스케이프, 유니코드, 공백 처리 등)의 책임을
                    # text_processor_service에 완전히 위임합니다.
                    processed_value = text_processor_service.process(raw_value, item_type='json')
                    # --- [수정 끝] ---

                    is_valid, reason = analyze_text_validity(processed_value)
                    if is_valid:
                        hybrid_id = f"{category_name}.{key}"
                        extracted.append({
                            'source_file': relative_path, 'id': hybrid_id,
                            'type': 'json', 'text_en': processed_value
                        })
                    else:
                        FilterAuditService.record(
                            source_file=relative_path,
                            item_id=f"{category_name}.{key}",
                            item_type='json',
                            text_en=processed_value,
                            reason=reason
                        )
            
            logger.info(f" -> 동적 JSON 파서가 {len(extracted)}개의 항목을 성공적으로 추출했습니다.")
            return extracted
            
        except Exception as e:
            logger.error(f"동적 JSON 파서 처리 중 오류 발생: {e}", exc_info=True)
            return []

class GeneralJsonParser(IProcessingStrategy):
    """
    [신규 Parser Strategy] 일반 JSON 파일의 모든 번역 가능 텍스트를 재귀적으로 추출합니다.
    기존 process_json_file 함수의 로직을 이식합니다.
    (수정) `target_keys`를 받아 특정 키만 선택적으로 추출할 수 있도록 기능을 확장합니다.
    """
    def execute(self, context: ExecutionContext):
        logger = context.logger
        file_path = context.current_source_path
        input_folder_path = os.path.join(context.base_path, SOURCE_DATA_FOLDER)
        rules = context.current_rules
        mod_root_path = context.base_path

        extracted = []
        relative_path = os.path.relpath(file_path, input_folder_path).replace('\\', '/')
        anomalies, suspicious_scripts = [], []
        
        use_key_as_type = rules.get('json_type_from_key', False) if rules else False
        
        # [핵심 변경 1] target_keys를 규칙에서 가져와 traverse_json에 전달합니다.
        target_keys_for_extraction = rules.get('target_keys', []) if rules else []
        
        logger.debug(f"  -> 재귀 JSON 파서 'GeneralJsonParser'로 '{relative_path}' 처리 시작. (use_key_as_type: {use_key_as_type}, target_keys: {target_keys_for_extraction})")

        try:
            file_content_tuple = read_file_with_fallback(file_path)
            if file_content_tuple and file_content_tuple[0]:
                content, _, _ = file_content_tuple
                
                data = _load_and_sanitize_json(content, relative_path)
                
                if data:
                    # [핵심 변경 2] target_keys_for_extraction을 traverse_json에 전달
                    traverse_json(data, "", extracted, relative_path, 
                                  use_key_as_type=use_key_as_type, 
                                  target_keys=target_keys_for_extraction) # <--- [추가]
            
            logger.debug(f"     ... 'GeneralJsonParser'가 {len(extracted)}개의 항목을 성공적으로 추출했습니다.")

        except Exception as e:
            logger.error(f"'{relative_path}' 처리 중 예상치 못한 오류 발생: {e}", exc_info=True)

        return extracted

class SkillFileParser(IProcessingStrategy):
    """
    [신규 Parser Strategy] .skill 파일처럼 {FILENAME_PLACEHOLDER} 규칙을 사용하는 파일을 위한
    전용 정규식 파서입니다.
    기존 process_skill_file 함수의 로직을 이식합니다.
    """
    def execute(self, context: ExecutionContext):
        """ExecutionContext를 사용하여 .skill 파일에서 텍스트를 추출합니다."""
        logger = context.logger
        file_path = context.current_source_path
        input_folder_path = os.path.join(context.base_path, SOURCE_DATA_FOLDER)
        rules = context.current_rules
        mod_root_path = context.base_path
        
        extracted = []
        relative_path = os.path.relpath(file_path, input_folder_path).replace('\\', '/')
        
        logger.debug(f"  -> .skill 파일 전용 파서 'SkillFileParser'로 처리 시작.")
        
        pattern = rules.get('regex_pattern')
        if not pattern:
            logger.error(f"'{relative_path}'에 'regex_pattern' 규칙이 없어 처리를 중단합니다.")
            return []

        try:
            file_content_tuple = read_file_with_fallback(file_path)
            if file_content_tuple is None or file_content_tuple[0] is None:
                return []

            content, _, _ = file_content_tuple
            
            matches = re.findall(pattern, content, re.DOTALL)

            resolver = IdPrefixResolver(mod_root_path=mod_root_path, file_path=file_path)
            final_id_prefix = resolver.resolve(rules=rules, structure_pattern=None) # .skill 파일은 structure_pattern 없음

            item_type = rules.get('type', 'skill_item')

            for i, match_text in enumerate(matches):
                text_to_translate = match_text if isinstance(match_text, str) else match_text[0]
                item_id = f"{final_id_prefix}[{i}]"

                is_valid, reason = analyze_text_validity(text_to_translate)
                if is_valid:
                    cleaned_text_en = text_processor_service.process(text_to_translate)
                    extracted.append({
                        'source_file': relative_path,
                        'id': item_id,
                        'type': item_type,
                        'text_en': cleaned_text_en
                    })
                else:
                    FilterAuditService.record(
                        source_file=relative_path,
                        item_id=item_id,
                        item_type=item_type,
                        text_en=text_to_translate,
                        reason=reason
                    )
            
            logger.debug(f"     ... 'SkillFileParser'가 {len(extracted)}개의 항목을 성공적으로 추출했습니다.")

        except Exception as e:
            logger.error(f"'SkillFileParser'로 '{relative_path}' 처리 중 오류: {e}", exc_info=True)
            
        return extracted


class StrategyFactory:
    """
    USER SETTINGS에 정의된 문자열(parser/applier 이름)을 기반으로,
    실제 처리기(Strategy) 객체를 생성하는 '공장' 클래스입니다.
    """
    def __init__(self):
        self._strategies = {
            # ... 기타 모든 파서와 어플라이어를 여기에 등록 ...

            # --- 다형성 처리기 ---
            'process_tips_polymorphic': TipsPolymorphicParser(),
            'apply_tips_polymorphic': TipsPolymorphicApplier(),

            # strings.json 등 서식 보존이 중요한 JSON 파일용 Applier
            'json_apply_strings': GenericRegexJsonApplier(),
            'json_export_string': JsonPolymorphicParser(),

            # 일반 JSON 파일용 Parser (재귀적 탐색)
            'process_json_file': GeneralJsonParser(),
            'apply_general_json': GeneralJsonApplier(),
            'process_skill_file': SkillFileParser(),

            # --- 일반 CSV 처리기 ---
            'process_general_csv': GeneralCsvParser(),
            'apply_translation_to_csv_file': GeneralCsvApplier(),

            # --- Rules.csv 처리기 ---
            'process_regex_csv': RulesCsvParser(),
            'apply_regex_csv': RulesCsvApplier(),
        }

    def get_strategy(self, name: str) -> IProcessingStrategy:
        """
        주어진 이름에 해당하는 처리기(Strategy) 객체를 반환합니다.
        등록되지 않은 경우, 경고 메시지를 출력하고 None을 반환합니다.
        """
        strategy_instance = self._strategies.get(name)
        if strategy_instance is None:
            # [핵심 수정] 등록되지 않은 전략 이름에 대한 경고 메시지 추가
            logger = LoggerService.get_logger() # 로거 인스턴스 가져오기
            logger.warning(f" [!] 경고: 알 수 없거나 등록되지 않은 처리기(Strategy) 이름이 요청되었습니다: '{name}'.")
            logger.warning(f"     -> USER SETTINGS의 'parser' 또는 'applier' 설정이 올바른지 확인하십시오.")
            # 추가적으로, 클래스로 전환되지 않은 기존 함수들을 임시로 지원하는 로직을 고려할 수 있지만,
            # 현재는 모든 핵심 처리기가 Strategy 클래스로 전환되었으므로 None을 반환하는 것이 맞습니다.
            pass
        return strategy_instance

# 전역 팩토리 인스턴스 생성
strategy_factory = StrategyFactory()



# ┏───────────────────────────────────────────────────┐
# ┃
# ┃           [ ScopedLogger 디버그 인스턴스 ]
# ┃

tips_scoped_logger = ScopedLogger(
    name='tips', 
    debug_flag=TIPS_JSON_DEBUG_MODE, 
    log_to_file_flag=TIPS_JSON_DEBUG_LOG_TO_FILE, 
    filename=TIPS_JSON_DEBUG_FILENAME
)

orphan_scoped_logger = ScopedLogger(
    name='orphan_recovery', 
    debug_flag=ORPHAN_RECOVERY_DEBUG_MODE, 
    log_to_file_flag=ORPHAN_RECOVERY_DEBUG_LOG_TO_FILE, 
    filename=ORPHAN_RECOVERY_DEBUG_FILENAME
)

# ┃
# ┗───────────────────────────────────────────────────┘


# ┏───────────────────────────────────────────────────┐
# ┃
# ┃            [ 공통 헬퍼 함수 ]
# ┃

# [global csv_file_service 객체 선언]
# CsvFileService 인스턴스는 main 함수에서 초기화됩니다.
csv_file_service: CsvFileService = None


# 사용자 입력을 위한 상수 클래스
class UserInput:
    """사용자의 특수 입력을 나타내는 상수. '매직 스트링' 대신 사용합니다."""
    ESC = object()
    QUIT = object()

def _escape_regex_literal_chars(text):
    """
    정규식에서 특별한 의미를 가지는 문자만을 이스케이프합니다.
    re.escape()와 달리 일반 문자(예: %, /)는 이스케이프하지 않습니다.
    """
    special_chars = r".^$*+?{}[]\|()"
    escaped_text = "".join(['\\' + char if char in special_chars else char for char in text])
    return escaped_text

def prompt_for_input(prompt, valid_choices=None, allow_empty=False, default_on_empty='', help_dict=None, help_context=None, help_key_prefix=''):
    """
    [범용 입력기 v3 - 주제어 도움말 추가] 사용자 입력을 처리하며, [번호]? 및 help [주제] 형식의 도움말을 모두 지원합니다.
    """
    logger = LoggerService.get_logger()
    
    while True:
        raw_input = get_user_input_with_special_keys(prompt)

        if raw_input == '__ESC__':
            return UserInput.ESC

        cleaned_input = raw_input.strip().lower()

        if cleaned_input == GLOBAL_EXIT_COMMAND:
            return UserInput.QUIT

        # --- [핵심 수정: 도움말 처리 로직 확장] ---
        if help_dict:
            # 1. "help [주제]" 또는 "? [주제]" 형식 확인
            if cleaned_input.startswith(('help ', '? ')):
                help_key = cleaned_input.split(maxsplit=1)[1]
                if _display_help_for_key(help_key, help_dict, help_context):
                    continue
                else:
                    # 유효하지 않은 도움말 키에 대한 경고는 _display_help_for_key가 처리
                    continue
            
            # 2. 기존의 "[번호]?" 형식 확인
            elif cleaned_input.endswith('?'):
                help_key_base = cleaned_input[:-1]
                full_help_key = f"{help_key_prefix}{help_key_base}"
                if _display_help_for_key(full_help_key, help_dict, help_context):
                    continue
                else:
                    continue
        # --- [수정 끝] ---
        
        if not cleaned_input:
            if allow_empty:
                return default_on_empty
            else:
                logger.warning(" [!] 아무것도 입력되지 않았습니다. 다시 시도하세요.")
                continue
        
        if valid_choices:
            if cleaned_input in valid_choices:
                return cleaned_input
            else:
                if cleaned_input.isdigit() and cleaned_input in valid_choices:
                     return cleaned_input
                logger.warning(f" [!] 잘못된 입력입니다. 허용되는 값: {', '.join(valid_choices)}")
                continue
        
        return cleaned_input


# 경로 축약 헬퍼 함수
def _get_short_path(full_path, num_parts=2):
    """
    전체 파일 경로를 받아 마지막 N개의 부분만 반환하여 가독성을 높입니다.
    예: 'C:/A/B/C' -> '.../B/C'
    """
    try:
        parts = str(full_path).replace('\\', '/').split('/')
        if len(parts) <= num_parts:
            return full_path
        return '.../' + '/'.join(parts[-num_parts:])
    except:
        return full_path # 오류 발생 시 원본 경로 반환


def pause_for_user(clear_screen=False):
    """
    [v3] 사용자가 '아무 키나' 누르면 다음으로 진행합니다.
    clear_screen의 기본값을 False로 변경하여 로그를 보존합니다.
    """
    print("\n" + "-"*50)
    print("아무키나 눌러 돌아갑니다...\n")
    
    if os.name == 'nt':  # Windows
        import msvcrt
        while msvcrt.kbhit():
            msvcrt.getch()
        msvcrt.getch()
    else:  # Unix/Linux/macOS
        import sys, tty, termios
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            termios.tcflush(sys.stdin, termios.TCIFLUSH)
            tty.setcbreak(sys.stdin.fileno())
            sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

def standardize_newlines(text, tag=None):
    """[수정] 줄바꿈 문자를 지정된 태그 또는 '\\n'으로 표준화합니다."""
    if not isinstance(text, str): return ""
    
    # 1. 모든 종류의 줄바꿈(CRLF, CR)을 단일 형식(LF, \n)으로 통일합니다.
    normalized_text = text.replace('\r\n', '\n').replace('\r', '\n')

    # 2. tag 유무에 따라 처리 방식을 분기합니다.
    if tag is not None:
        # tag가 지정된 경우 (예: '|n|'), 모든 \n을 해당 태그로 치환합니다.
        # "a\n\nb" -> "a|n||n|b"
        return normalized_text.replace('\n', tag)
    else:
        # tag가 없는 경우 (기본), 기존 방식대로 \n을 '\\n' 문자열로 이스케이프 처리합니다.
        # "a\n\nb" -> "a\\n\\nb"
        return normalized_text.replace('\n', '\\n')


def _run_normalize_json_kr_engine(staging_file_path, is_test_run=False):
    """
    [엔진 강화] 'type: json' 항목에 대해, text_kr의 이스케이프 시퀀스 변환과
    text_en 기준의 외곽 따옴표 동기화를 모두 수행합니다.
    """
    logger = LoggerService.get_logger()
    staging_data = csv_file_service.load_rows_from_csv(staging_file_path)
    
    report = {'updated_count': 0, 'processed_count': 0, 'examples': []}
    if not staging_data:
        logger.warning(f" -> 스테이징 파일 '{os.path.basename(staging_file_path)}'에 데이터가 없습니다.")
        return report, staging_data

    normalized_data = []
    processed_count = 0
    updated_count = 0
    
    for row in staging_data:
        row_copy = row.copy()
        row_type = row_copy.get('type', '').strip().lower()
        
        if row_type == 'json':
            processed_count += 1
            original_kr = row_copy.get('text_kr', '')
            text_en_raw = row_copy.get('text_en', '')
            
            if not original_kr.strip():
                normalized_data.append(row_copy)
                continue

            # --- [★★★★★ 핵심 수정: 2단계 정규화 로직 ★★★★★] ---
            
            # 1단계: 이스케이프 시퀀스 변환
            normalized_kr_step1 = original_kr.replace('\\n', '\n').replace('\\"', '"').replace('\\\\', '\\')
            
            # 2단계: 외곽 따옴표 동기화
            normalized_kr_step2 = normalized_kr_step1
            en_has_quotes = text_en_raw.startswith('"') and text_en_raw.endswith('"')
            
            kr_stripped = normalized_kr_step1.strip()
            kr_has_quotes = kr_stripped.startswith('"') and kr_stripped.endswith('"')

            if en_has_quotes and not kr_has_quotes:
                # text_kr의 기존 앞뒤 공백을 보존하면서 따옴표 추가
                match = re.match(r'^(\s*)([\s\S]*?)(\s*)$', normalized_kr_step1, re.DOTALL)
                if match:
                    leading_ws, content, trailing_ws = match.groups()
                    normalized_kr_step2 = f'{leading_ws}"{content}"{trailing_ws}'

            # 최종적으로 변경이 있었는지 확인
            if original_kr != normalized_kr_step2:
                updated_count += 1
                if len(report['examples']) < 3:
                    report['examples'].append({
                        'id': row_copy.get('id'),
                        'before': original_kr[:50] + ('...' if len(original_kr) > 50 else ''),
                        'after': normalized_kr_step2[:50] + ('...' if len(normalized_kr_step2) > 50 else '')
                    })
                row_copy['text_kr'] = normalized_kr_step2
        
        normalized_data.append(row_copy)
        
    report['updated_count'] = updated_count
    report['processed_count'] = processed_count
    
    return report, normalized_data


def _run_legacy_newline_migration_engine(data_list, is_preview=True):
    """
    [v2 - 데이터 흐름 개선] 파일 경로 대신 데이터 리스트를 직접 받아 처리하여
    효율성과 안정성을 높입니다.
    """
    logger = LoggerService.get_logger()
    
    report = {'updated_count': 0, 'examples': []}
    if not data_list:
        return report, data_list

    new_data_list = []
    updated_count = 0
    
    for row in data_list:
        row_copy = row.copy()
        original_kr = row_copy.get('text_kr', '')
        
        if '|n|' in original_kr:
            normalized_kr = original_kr.replace('|n|', '\\n')
            
            # is_preview 모드에서는 변경 사항만 집계
            if original_kr != normalized_kr:
                updated_count += 1
                if len(report['examples']) < 3:
                    report['examples'].append({
                        'id': row_copy.get('id'),
                        'before': original_kr.replace('\n', '\\n')[:50],
                        'after': normalized_kr.replace('\n', '\\n')[:50]
                    })
                # 실행 모드에서는 실제 데이터도 변경
                if not is_preview:
                    row_copy['text_kr'] = normalized_kr
        
        if not is_preview:
            new_data_list.append(row_copy)
        
    report['updated_count'] = updated_count
    
    # is_preview=False일 때는 수정된 데이터 리스트를 반환
    if not is_preview:
        return report, new_data_list
    
    # is_preview=True일 때는 원본 데이터 리스트를 그대로 반환
    return report, data_list


def _run_remove_master_duplicates_from_staging_engine(base_path, is_test_run=False):
    """
    [신규 엔진 7-6-9] 스테이징 파일에서, 마스터 파일과 완전히 동일한
    (source_file, id, type, text_en, text_kr) 항목을 찾아 제거합니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    staging_path = paths.get_staging_master_file()
    master_path = paths.get_master_file()

    if not os.path.exists(staging_path) or not os.path.exists(master_path):
        logger.error(" [!] 작업을 위해 스테이징 파일과 마스터 파일이 모두 필요합니다.")
        pause_for_user()
        return

    logger.info("\n" + "="*60)
    logger.info("7-6-9. 스테이징에서 마스터와 중복된 항목 정리를 시작합니다...")
    
    staging_data = csv_file_service.load_rows_from_csv(staging_path)
    master_data = csv_file_service.load_rows_from_csv(master_path)

    if not staging_data:
        logger.warning(" -> 정리할 항목이 스테이징 파일에 없습니다.")
        pause_for_user()
        return

    # 마스터 데이터의 해시 셋 생성 (빠른 조회를 위해)
    # 5-tuple (source_file, id, type, text_en, text_kr)을 키로 사용
    master_keys_set = set()
    for row in master_data:
        row_type = row.get('type', '')
        key = (
            row.get('source_file', ''),
            row.get('id', ''),
            row_type,
            text_processor_service.process(row.get('text_en', ''), item_type=row_type),
            text_processor_service.process(row.get('text_kr', ''), item_type=row_type)
        )
        master_keys_set.add(key)

    # 스테이징 데이터에서 중복되지 않는 항목만 필터링
    kept_rows = []
    removed_count = 0
    for row in staging_data:
        row_type = row.get('type', '')
        key = (
            row.get('source_file', ''),
            row.get('id', ''),
            row_type,
            text_processor_service.process(row.get('text_en', ''), item_type=row_type),
            text_processor_service.process(row.get('text_kr', ''), item_type=row_type)
        )
        if key in master_keys_set:
            removed_count += 1
        else:
            kept_rows.append(row)
            
    if removed_count == 0:
        logger.info("\n -> 마스터 파일과 완전히 중복되는 항목을 찾지 못했습니다. 파일이 변경되지 않았습니다.")
        pause_for_user()
        return

    # 미리보기 및 실행 확인
    print("\n" + "="*70)
    print(" [ 작업 미리보기: 스테이징 중복 정리 ]")
    print("-" * 70)
    print(f"  - 대상 파일: '{os.path.basename(staging_path)}' (현재 {len(staging_data)}개 항목)")
    print(f"  - 마스터 파일과 완전히 일치하여 제거될 항목: {removed_count}개")
    print(f"  - 작업 후 스테이징 파일에 남을 항목: {len(kept_rows)}개")
    print("="*70)

    prompt_confirm = "\n>> 위 내용으로 스테이징 파일을 정리하시겠습니까? (Enter/y, ESC/n): "
    choice_confirm = prompt_for_input(prompt_confirm, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

    if choice_confirm != 'y':
        logger.info(" -> 작업을 취소했습니다.")
        pause_for_user()
        return

    # 실제 파일 쓰기
    csv_file_service.write_rows_to_csv(
        staging_path,
        kept_rows,
        headers=STAGING_FILE_HEADERS,
        create_backup_on_write=True,
        is_test_run=is_test_run
    )
    logger.info(f"\n -> 작업 완료! {removed_count}개의 중복 항목을 스테이징 파일에서 제거했습니다.")
    pause_for_user()

############################################################################
#
#        [ ARCHITECTURAL DIRECTIVE - JSON_LOADER_FALLBACK_V2 ]
#
# TARGET: _load_and_sanitize_json()
# STATUS: NEW & STABLE
# ROLE: Centralized JSON Loader, Sanitizer, and Recovery Engine
#
# BEHAVIOR:
#   이 함수는 스크립트의 모든 JSON 파싱을 책임지는 '단일 진실 공급원'이다.
#   다음과 같은 3단계 폴백(Fallback) 메커니즘을 엄격히 준수한다.
#
#   1. [시도 1: 정규식 K-V 추출] json.loads() 없이, 정규식만으로 "k":"v" 패턴을
#      신속하게 추출한다. 파일에 문법 오류가 있어도 정상적인 부분은 최대한
#      추출하며, 성공 시 결과를 즉시 반환하고 모든 처리를 종료한다.
#
#   2. [시도 2: 표준 파싱] 1단계 실패 시, 가벼운 정규식(주석/후행 쉼표 제거)으로
#      텍스트를 교정한 후, 표준 json.loads()를 시도한다. 성공 시 즉시 반환한다.
#
#   3. [시도 3: 완전 복구] 2단계마저 실패 시, '수동 파싱'으로 문자열 내 모든
#      제어 문자(줄바꿈, 탭 등)를 교정한 후, 다시 정규식으로 후처리하여
#      최종 파싱을 시도한다.
#
# DESIGN_CHOICE:
#   '점진적 강화' 원칙에 따라, 가장 빠르고 가벼운 방법부터 시도하여 대부분의
#   케이스에서 최적의 성능을 보장한다. 동시에, 가장 복잡한 오류에 대해서도
#   단계적인 복구 메커니즘을 통해 최고의 강건성을 확보한다.
#
# MODIFICATION_PROTOCOL:
#   - 새로운 종류의 JSON 문법 오류(사례)가 발견될 경우, 이 함수의 3단계
#     (완전 복구) 로직에 해당 사례를 처리하는 코드를 '누적'하여 추가한다.
#   - 이 함수 외의 다른 곳에서 json.loads()를 직접 호출하는 것은 금지된다.
#     모든 JSON 파싱은 반드시 이 중앙 로더를 통해 이루어져야 한다.
#
############################################################################
def _load_and_sanitize_json(json_string, file_path_for_log=""):
    """
    [v3.3 - 인코딩 보존] JSON 파싱 복구 로직을 수정하여, 문자열 내용의
    유니코드 이스케이프 시퀀스를 포함한 모든 원본 형식을 보존합니다.
    """
    logger = LoggerService.get_logger()
    
    # --- 시도 1: 표준 파서 (가장 흔한 오류만 빠르게 교정) ---
    try:
        quick_fix = re.sub(r'(?<![:/])(//.*|#.*|/\*[\s\S]*?\*/)', '', json_string)
        quick_fix = re.sub(r',\s*([}\]])', r'\1', quick_fix)
        quick_fix = re.sub(r'(\}\s*|\].*?)\s*(?=\S)', r'\1', quick_fix, flags=re.DOTALL)
        return json.loads(quick_fix)
    except json.JSONDecodeError as e:
        logger.warning(f"  -> '{file_path_for_log}' 파일에서 표준 파싱 실패({e}). 완전 복구 모드를 실행합니다...")
        pass

    # --- 시도 2: 최종 수단 - 수동 파싱 완전 복구 ---
    try:
        # 1단계: 정규식으로 먼저 최대한 정리
        sanitized_str = json_string
        sanitized_str = re.sub(r'(?<![:/])(//.*|#.*|/\*[\s\S]*?\*/)', '', sanitized_str)
        sanitized_str = re.sub(r',\s*([}\]])', r'\1', sanitized_str)
        sanitized_str = re.sub(r'([{,]\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*:', r'\1"\2":', sanitized_str)

        # 2단계: 수동으로 누락된 쉼표 등을 보정 (문자열 내용은 건드리지 않음)
        sanitized_chars = []
        in_string = False
        previous_char = ''
        expecting_comma = False

        for char in sanitized_str:
            if char == '"' and previous_char != '\\':
                in_string = not in_string
                if not in_string: expecting_comma = True
            elif not in_string and char in ('{', '['):
                expecting_comma = False
            elif not in_string and char == ',':
                expecting_comma = False
            elif not in_string and expecting_comma and char.strip() and char not in ('}', ']'):
                sanitized_chars.append(',')
                expecting_comma = False
            
            sanitized_chars.append(char)
            previous_char = char if char != '\\' else '' # 이중 백슬래시 처리

        final_result = "".join(sanitized_chars).strip()
        
        logger.info(f"  -> [성공] '{file_path_for_log}' 파일의 비표준 JSON 복구 및 파싱 성공!")
        return json.loads(final_result)
        
    except json.JSONDecodeError as e:
        logger.error(f"  -> [최종 실패] 모든 복구 시도 후에도 '{file_path_for_log}' 파싱 실패: {e}")
        return None

def _clean_and_strip_quotes(text):
    """
    [v2 - 최종 수정] options 타입의 text_en/text_kr 문자열을 위한 전용 클리너.
    ' ||| ' 구분자로 분해하여 각 조각의 외부 따옴표를 개별적으로 제거한 후 다시 합칩니다.
    """
    if not isinstance(text, str):
        return ""

    # [★★★★★ 최종 수정: 분해 -> 처리 -> 재조립 로직 ★★★★★]
    
    # 1. '|||' 구분자로 문자열을 개별 조각(snippet)으로 분해합니다.
    snippets = text.split(SCRIPT_TEXT_DELIMITER)
    
    cleaned_snippets = []
    # 2. 각 조각을 순회하며 따옴표 제거 로직을 적용합니다.
    for snippet in snippets:
        # 시작(^)과 끝($)에 있는 하나 이상의 연속된 따옴표(`"`)와 공백을 제거합니다.
        cleaned_snippet = re.sub(r'^\s*"+|"+$', '', snippet.strip())
        cleaned_snippets.append(cleaned_snippet)
        
    # 3. 정제된 조각들을 다시 '|||' 구분자로 재조립합니다.
    return SCRIPT_TEXT_DELIMITER.join(cleaned_snippets)


def get_mod_display_name(base_path):
    """
    [v3 - 중앙 로더 사용] 주어진 모드 폴더 경로에서 표시할 이름을 결정합니다.
    """
    logger = LoggerService.get_logger()
    try:
        mod_info_path = os.path.join(base_path, 'mod_info.json')
        if os.path.exists(mod_info_path):
            file_content_tuple = read_file_with_fallback(mod_info_path)
            if file_content_tuple and file_content_tuple[0]:
                content, _, _ = file_content_tuple
                
                # [★★★★★ 핵심 변경 ★★★★★]
                # 모든 복잡한 로직을 중앙 로더에 위임합니다.
                data = _load_and_sanitize_json(content, os.path.basename(mod_info_path))

                if data and data.get('name'):
                    return f"{data.get('name')} ({os.path.basename(base_path)})"
                
    except Exception as e:
        logger.debug(f"'{os.path.basename(base_path)}'의 mod_info.json 처리 중 예외 발생: {e}")
        
    return os.path.basename(base_path)

def copy_directory_contents(src_dir, dst_dir, is_test_run=False):
    """
    (신규) src_dir의 모든 내용을 dst_dir로 재귀적으로 복사하며 상세 로그를 남깁니다.
    dst_dir이 없으면 생성하고, 파일이 이미 있으면 덮어씁니다.
    """
    logger = LoggerService.get_logger()
    copied_files = 0
    
    if not os.path.isdir(src_dir):
        logger.error(f"원본 폴더를 찾을 수 없습니다: {src_dir}")
        return 0

    if not os.path.exists(dst_dir):
        if not is_test_run:
            os.makedirs(dst_dir)
        logger.debug(f"  -> 대상 폴더 생성: {os.path.basename(dst_dir)}")

    for item in os.listdir(src_dir):
        src_path = os.path.join(src_dir, item)
        dst_path = os.path.join(dst_dir, item)

        if os.path.isdir(src_path):
            # 재귀적으로 하위 폴더 복사
            copied_files += copy_directory_contents(src_path, dst_path, is_test_run)
        else:
            # 파일 복사
            if is_test_run:
                logger.debug(f"  [테스트] 복사 건너뜀: {os.path.basename(src_path)}")
            else:
                shutil.copy2(src_path, dst_path)
            logger.debug(f"  - [복사] {os.path.basename(src_path)}")
            copied_files += 1
            
    return copied_files


def copy_and_log_actions(src, dst, is_test_run):
    """
    src 폴더의 내용을 dst로 복사하면서 모든 파일/폴더 생성/덮어쓰기 작업을 로그에 기록합니다.
    is_test_run=True이면 실제 파일 작업을 건너뜁니다.
    """
    logger = LoggerService.get_logger()
    if is_test_run:
        logger.debug(f"    테스트 모드: 폴더 '{dst}' (src: '{src}') 복사 스킵.")
        return

    if not os.path.exists(dst):
        os.makedirs(dst)
        logger.info(f"    - [생성] 폴더: {dst}")

    for item in os.listdir(src):
        src_path = os.path.join(src, item)
        dst_path = os.path.join(dst, item)
        
        if os.path.isdir(src_path):
            copy_and_log_actions(src_path, dst_path, is_test_run)
        else:
            shutil.copy2(src_path, dst_path)
            logger.info(f"    - [복사] 파일: {dst_path}")

def copy_with_recode(source_path, dest_path, is_test_run=False):
    """
    오류 발생 시의 안전 장치. 원본 파일을 읽어(INPUT_FILE_ENCODING)
    사용자가 설정한 OUTPUT_FILE_ENCODING으로 다시 저장하여 인코딩 일관성을 보장합니다.
    """
    logger = LoggerService.get_logger()
    if is_test_run:
        logger.debug(f"테스트 모드: 오류 발생. '{os.path.basename(source_path)}'의 인코딩 변환 복사를 스킵합니다.")
        return
    try:
        with open(source_path, 'r', encoding=INPUT_FILE_ENCODING) as f_in:
            content = f_in.read()
        with open(dest_path, 'w', encoding=OUTPUT_FILE_ENCODING) as f_out:
            f_out.write(content)
        logger.debug(f"  -> 오류 복구: 원본 내용을 '{OUTPUT_FILE_ENCODING}' 인코딩으로 변환하여 복사했습니다.")
    except Exception as e:
        logger.error(f"  -> 오류 복구 실패! '{os.path.basename(source_path)}' 파일 복사 중 심각한 오류 발생: {e}")
        # 최후의 수단으로 그냥 복사
        shutil.copy2(source_path, dest_path)

def get_user_input_with_special_keys(prompt):
    """
    [리팩토링됨] AppState를 사용하여 커맨드 히스토리를 관리합니다.
    사용자 입력을 받되, 특수 키(ESC, 화살표)를 즉시 감지합니다.
    """
    if os.name == 'nt':
        import msvcrt
        
        while msvcrt.kbhit():
            msvcrt.getch()

        print(prompt, end='', flush=True)
        buffer = list()

        while True:
            char_code = msvcrt.getwch()

            if char_code == '\r' or char_code == '\n':
                print()
                command = "".join(buffer)
                if command and (not app_state.command_history or app_state.command_history[-1] != command):
                    app_state.command_history.append(command)
                app_state.history_index = len(app_state.command_history)
                return command.strip()
            elif char_code == '\x1b':
                print("[ESC]")
                return '__ESC__'
            elif char_code == '\x08':
                if buffer:
                    buffer.pop()
                    print('\b \b', end='', flush=True)
            elif char_code == '\xe0' or char_code == '\x00':
                arrow_key = msvcrt.getwch()
                if arrow_key == 'H': # Up arrow
                    if app_state.command_history:
                        app_state.history_index = max(0, app_state.history_index - 1)
                        new_command = app_state.command_history[app_state.history_index]
                        print('\r' + ' ' * (len(prompt) + len(buffer)), end='')
                        print(f'\r{prompt}{new_command}', end='', flush=True)
                        buffer = list(new_command)
                elif arrow_key == 'P': # Down arrow
                    if app_state.history_index < len(app_state.command_history) - 1:
                        app_state.history_index += 1
                        new_command = app_state.command_history[app_state.history_index]
                    else:
                        app_state.history_index = len(app_state.command_history)
                        new_command = ""
                    print('\r' + ' ' * (len(prompt) + len(buffer)), end='')
                    print(f'\r{prompt}{new_command}', end='', flush=True)
                    buffer = list(new_command)
            else:
                buffer.append(char_code)
                print(char_code, end='', flush=True)
    else: # non-Windows fallback
        user_input = input(prompt)
        return user_input.strip()

    
def is_file_excluded(relative_path, for_export=True):
    """
    (신규) 파일이 사용자 설정에 따라 처리 대상에서 제외되어야 하는지 중앙에서 확인합니다.
    :param relative_path: 파일의 상대 경로 (예: 'campaign/rules.csv')
    :param for_export: True일 경우 Export 전용 규칙(확장자 등)까지 함께 검사합니다.
    :return: 제외 대상이면 True, 아니면 False

    (개선) 파일이 사용자 설정에 따라 제외되어야 하는지 확인합니다.
    'EXCLUDE_FILES' 목록의 와일드카드(*) 패턴을 지원합니다.
    """
    # 규칙 1: EXCLUDE_FILES 목록 확인
    for pattern in PROCESSING_RULES.get('EXCLUDE_FILES', set()):
        # 와일드카드 패턴 매칭
        if '*' in pattern:
            # fnmatch와 유사하게 동작하도록 정규식으로 변환
            # 예: "*.csv" -> ".*\\.csv$"
            regex_pattern = pattern.replace('.', '\\.').replace('*', '.*') + '$'
            if re.search(regex_pattern, relative_path):
                return True
        # 정확한 경로 일치
        elif pattern == relative_path:
            return True

    # 규칙 2: Export 전용 확장자 제외 규칙
    if for_export:
        file_extension = os.path.splitext(relative_path)[1].lower()
        if file_extension in EXCLUDE_EXTENSIONS_FROM_EXPORT:
            return True
            
    return False

def _is_file_in_whitelist(file_path, whitelist_patterns):
    """
    파일 경로가 주어진 화이트리스트 패턴 중 하나와 일치하는지 확인합니다.
    와일드카드(*) 패턴을 지원합니다.
    :param file_path: 검사할 파일의 상대 경로 (예: 'campaign/rules.csv')
    :param whitelist_patterns: 와일드카드를 포함할 수 있는 패턴 문자열 목록/집합
    :return: 파일이 화이트리스트 패턴 중 하나와 일치하면 True, 아니면 False
    """
    for pattern in whitelist_patterns:
        # 와일드카드 패턴 매칭
        if '*' in pattern:
            # fnmatch와 유사하게 동작하도록 정규식으로 변환하고, 전체 경로 일치를 위해 ^와 $ 추가
            # 예: "strings/*.json" -> "^strings/.*\\.json$"
            # re.escape를 사용하여 '.'과 같은 특수 문자를 리터럴로 처리하고, '*'만 '.*'로 변환
            # (re.escape는 '*'도 이스케이프하므로, 다시 '.*'로 복원해야 함)
            escaped_pattern = re.escape(pattern).replace('\\*', '.*')
            regex_pattern = r'^' + escaped_pattern + r'$'
            
            if re.match(regex_pattern, file_path): # re.match는 문자열 시작부터 일치하는지 확인
                return True
        # 정확한 경로 일치
        elif pattern == file_path:
            return True
            
    return False

# _conditions의 'mod_folder_name'이 단일 문자열 또는 문자열 리스트를 지원하도록 수정
def get_rules_for_file(relative_path, base_path):
    """
    주어진 파일 경로에 적용할 규칙을 찾습니다.
    1. GENERIC_PARSER_RULES (규칙 중심)을 먼저 검색합니다.
    2. 일치하는 규칙이 없으면 SPECIAL_FILE_HANDLING (파일 중심)에서 찾습니다.
    """
    logger = LoggerService.get_logger()

    # --- 1. GENERIC_PARSER_RULES (규칙 중심) 검색 ---
    for generic_rule in GENERIC_PARSER_RULES:
        for target_pattern in generic_rule.get('target_files', []):
            # 와일드카드 지원
            if '*' in target_pattern:
                regex_pattern = target_pattern.replace('.', '\\.').replace('*', '.*') + '$'
                if re.match(regex_pattern, relative_path):
                    logger.debug(f"  [DEBUG-RULES] 범용 규칙 일치 (와일드카드): '{target_pattern}' -> '{relative_path}'")
                    return generic_rule
            # 정확한 경로 일치
            elif target_pattern == relative_path:
                logger.debug(f"  [DEBUG-RULES] 범용 규칙 일치 (정확): '{relative_path}'")
                return generic_rule

    # --- 2. SPECIAL_FILE_HANDLING (파일 중심) 검색 (하위 호환성) ---
    # (이 부분의 로직은 이전과 동일하게 유지됩니다)
    exact_match_rules = SPECIAL_FILE_HANDLING.get(relative_path)
    if exact_match_rules:
        rules_config = exact_match_rules
    else:
        # 와일드카드 검색
        found_wildcard_rule = None
        for pattern, rules in SPECIAL_FILE_HANDLING.items():
            if '*' in pattern:
                regex_pattern = pattern.replace('.', '\\.').replace('*', '.*') + '$'
                if re.match(regex_pattern, relative_path):
                    found_wildcard_rule = rules
                    break
        if not found_wildcard_rule:
            return None # 어떤 규칙도 찾지 못함
        rules_config = found_wildcard_rule

    # 조건부 규칙 처리 (tips.json 등)
    if isinstance(rules_config, list):
        current_mod_name = os.path.basename(base_path)
        for rule_set in rules_config:
            conditions = rule_set.get('_conditions')
            if not conditions: continue
            
            mod_name_condition = conditions.get('mod_folder_name')
            if mod_name_condition:
                if isinstance(mod_name_condition, list) and current_mod_name in mod_name_condition:
                    return rule_set
                elif isinstance(mod_name_condition, str) and mod_name_condition == current_mod_name:
                    return rule_set

        # 일치하는 조건이 없을 경우 기본값(fallback) 규칙 반환
        for rule_set in rules_config:
            if not rule_set.get('_conditions'):
                return rule_set
        return None
    
    elif isinstance(rules_config, dict):
        return rules_config
    
    return None

def _analyze_merge_for_report(completed_rows, master_data, shared_state):
    """
    [UI 엔진] 실제 병합 없이, 스테이징 항목과 마스터 파일을 비교하여 보고서 카운터를 생성합니다.
    [리팩토링됨] text_processor_service를 사용하여 텍스트를 일관되게 정규화합니다.
    """
    
    # 4-tuple (src, id, type, cleaned_en)을 키로 사용하는 마스터 맵
    master_map = {
        (row['source_file'], row['id'], row['type'], text_processor_service.process(row.get('text_en', ''), item_type=row.get('type', ''))): row.copy() 
        for row in master_data
    }

    # 3-tuple 위치 키를 사용하여 해당 위치에 마스터 항목이 존재하는지 확인 (새 항목 감지용)
    master_location_map = {
        (row['source_file'], row['id'], row['type']): row 
        for row in master_data
    }
    
    report_analysis = {
        'added': 0,
        'en_updated': 0,
        'kr_updated': 0,
        'no_change': 0,
        'status_preserved': 0,
        'status_set_to_empty': 0,
        'total_processed': len(completed_rows)
    }

    for staging_row in completed_rows:
        key_3_tuple = (staging_row['source_file'], staging_row['id'], staging_row['type'])
        row_type = staging_row.get('type', '')
        
        # [수정] text_processor_service 사용
        new_en_cleaned = text_processor_service.process(staging_row.get('text_en', ''), item_type=row_type)
        new_kr_cleaned = text_processor_service.process(staging_row.get('text_kr', ''), item_type=row_type)

        # 4-tuple (staging_row의 현재 상태)
        new_key_4_tuple = (key_3_tuple[0], key_3_tuple[1], key_3_tuple[2], new_en_cleaned)

        if key_3_tuple in master_location_map:
            # 1. 위치 키는 일치 (기존 항목)
            
            # 마스터의 기존 대표 항목을 가져옴
            existing_master_row = master_location_map[key_3_tuple]
            # [수정] text_processor_service 사용
            old_en_cleaned = text_processor_service.process(existing_master_row.get('text_en', ''), item_type=row_type)
            old_kr_cleaned = text_processor_service.process(existing_master_row.get('text_kr', ''), item_type=row_type)
            preserved_status = (existing_master_row.get('Translatable') or '').strip().lower()
            
            # 2. EN/Type 변경 감지 (마이그레이션)
            if old_en_cleaned != new_en_cleaned:
                report_analysis['en_updated'] += 1
                if preserved_status in ('true', 'x'):
                     report_analysis['status_preserved'] += 1
                     
            # 3. KR만 변경 감지
            elif old_kr_cleaned != new_kr_cleaned:
                report_analysis['kr_updated'] += 1
                if preserved_status in ('true', 'x'):
                     report_analysis['status_preserved'] += 1

            # 4. 내용 완벽히 동일 (EN, KR 모두 동일하고, 4-tuple 기준으로 마스터에 존재하는 키)
            elif new_key_4_tuple in master_map:
                # 4-tuple 키가 일치하는 마스터 항목을 찾았으므로, 내용이 동일하다고 판단
                report_analysis['no_change'] += 1
            
        else:
            # 위치 키 불일치 -> 신규 항목
            report_analysis['added'] += 1
            report_analysis['status_set_to_empty'] += 1

    return report_analysis

def _analyze_merge_details(source_rows, target_data):
    """[엔진] 소스 데이터가 타겟 데이터에 병합될 때 발생할 변경사항
    (신규, 원문변경, 번역변경, 중복)을 정밀 분석하여 딕셔너리로 반환합니다."""
    
    # 타겟 데이터를 3-tuple key 기반의 분석용 맵으로 변환
    target_map_3key = defaultdict(set)
    for row in target_data:
        key = (row.get('source_file'), row.get('id'), row.get('type'))
        value_tuple = (row.get('text_en', ''), row.get('text_kr', ''))
        target_map_3key[key].add(value_tuple)

    # 카운터 초기화
    analysis = {
        'new': {'total': 0, 'with_kr': 0},
        'en_update': {'total': 0, 'with_kr': 0},
        'kr_update': 0,
        'duplicate': 0
    }
    
    # 소스 데이터를 순회하며 분석
    for s_row in source_rows:
        s_key = (s_row.get('source_file'), s_row.get('id'), s_row.get('type'))
        s_en = s_row.get('text_en', '')
        s_kr = s_row.get('text_kr', '')
        has_kr = bool(s_kr.strip())

        if s_key not in target_map_3key:
            analysis['new']['total'] += 1
            if has_kr:
                analysis['new']['with_kr'] += 1
        else:
            target_en_set = {en for en, kr in target_map_3key[s_key]}
            
            if s_en in target_en_set:
                if (s_en, s_kr) in target_map_3key[s_key]:
                    analysis['duplicate'] += 1
                else:
                    analysis['kr_update'] += 1
            else:
                analysis['en_update']['total'] += 1
                if has_kr:
                    analysis['en_update']['with_kr'] += 1
                
    return analysis

def _update_master_from_review_engine(handled_items, review_file_path, is_test_run, base_path):
    """
    [리팩토링] MasterFileService를 사용하여 마스터 파일 쓰기 작업을 중앙화합니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    
    # [수정 1] MasterFileService 인스턴스 생성 및 데이터 로드
    master_service = MasterFileService(base_path, csv_file_service)
    current_master_data = master_service.get_data()
    
    trash_file = paths.get_purge_trash_file()

    # 1. 기존 마스터 파일 로드
    master_map_for_update = {}
    if current_master_data:
        master_map_for_update = {
            (row['source_file'], row['id'], row['type'], row.get('text_en', '')): row
            for row in current_master_data
        }
    
    updated_in_master_count = 0
    added_to_master_count = 0
    removed_from_master_count = 0
    added_to_trash_count = 0

    items_to_trash_list = []

    # 2. handled_items를 처리하여 마스터 및 트래시 데이터 준비
    for row in handled_items:
        translatable_flag = row.get('Translatable', '').strip().lower()
        key_for_master = (row['source_file'], row['id'], row['type'], row.get('text_en', ''))

        # 'x'인 경우: 트래시로 이동하고 마스터에서 제거
        if translatable_flag == 'x':
            row_for_trash = row.copy()
            row_for_trash['Translatable'] = 'x'
            items_to_trash_list.append(row_for_trash)
            
            if key_for_master in master_map_for_update:
                del master_map_for_update[key_for_master]
                removed_from_master_count += 1
            else:
                logger.debug(f"  -> [경고] ID '{row['id']}' 항목이 마스터에 없지만 'x'로 지정되어 트래시로 이동됩니다.")

        # 'true' 또는 't'인 경우: 마스터 파일 업데이트
        elif translatable_flag in ('true', 't'):
            # [수정] Translatable 값을 명확하게 'True'로 설정합니다.
            row['Translatable'] = 'True'
            
            if key_for_master in master_map_for_update:
                master_map_for_update[key_for_master] = row
                updated_in_master_count += 1
            else:
                master_map_for_update[key_for_master] = row
                added_to_master_count += 1
    
    # 3. 마스터 파일과 트래시 파일에 쓰기
    final_master_rows = list(master_map_for_update.values())

    # [★★★★★ 핵심 수정 2: 서비스 메서드 호출로 교체 ★★★★★]
    master_service.save_data(final_master_rows, is_test_run=is_test_run)
    logger.info(f" -> 마스터 파일 ('{os.path.basename(master_service.get_path())}') 업데이트 완료.")
    
    if items_to_trash_list:
        added_to_trash_count = csv_file_service.append_rows_to_csv_without_duplicates(
            trash_file, items_to_trash_list, headers=REVIEW_NEEDED_HEADERS, create_backup_on_write=True, is_test_run=is_test_run
        )
    logger.info(f" -> 트래시 파일 ('{os.path.basename(trash_file)}') 업데이트 완료.")

    # 4. 결과 요약
    print("\n" + "="*60)
    print(" [ 마스터 파일 처리 결과 요약 ]")
    print("-" * 60)
    print(f"  - 마스터 파일에 신규 추가: {added_to_master_count}개 항목")
    print(f"  - 마스터 파일 항목 업데이트: {updated_in_master_count}개 항목")
    print(f"  - 마스터 파일에서 제거: {removed_from_master_count}개 항목 ('Translatable: x' 지시)")
    print(f"  - 트래시 파일에 추가: {added_to_trash_count}개 항목 ('Translatable: x' 지시)")
    print(f"  - 최종 마스터 파일 항목 수: {len(final_master_rows)}개")
    print("="*60)


# ############################################################################
#
#               [ ARCHITECTURAL DIRECTIVE - PATH_MANAGER_V1 ]
#
# TARGET: PathManager Class
# STATUS: FINALIZED & FROZEN
#
# REASON: 
#   이 PathManager 클래스는 스크립트 전체의 파일 경로 생성을 중앙에서
#   관리하는 '단일 진실 공급원(Single Source of Truth)'입니다.
#   USE_DYNAMIC_FILE_PATHS 설정에 따른 모든 분기 로직이 이 클래스 내부에
#   캡슐화되어 있습니다. 이 클래스의 일관성을 유지하는 것은 스크립트 전체의
#   안정성과 직결되므로, 내부 로직의 임의 변경을 엄격히 금지합니다.
#
# MODIFICATION_PROTOCOL: 
#   1. [신규 파일 추가]: 새로운 관리 대상 파일이 생겼을 경우,
#      USER SETTINGS에 'NEW_FILE_SUFFIX'를 추가하고, 이 클래스 내부에
#      get_new_file() 메서드를 추가하는 방식으로만 확장해야 합니다.
#
#   2. [핵심 로직 변경]: 동적/정적 경로를 생성하는 _get_path() 메서드의
#      로직을 변경해야 할 경우, 반드시 "DIRECTIVE-ID: PATH_MANAGER_V1에
#      대한 수정 요청"이라는 명시적인 요청과 함께 변경 사유를 상세히
#      기술해야 합니다.
#
# ############################################################################
def apply_mod_validation_check(mod_path):
    paths = PathManager(mod_path)
    translation_file = paths.get_apply_source_file()
    return os.path.isfile(translation_file)

class PathManager:
    """
    모든 파일 경로 생성을 중앙에서 관리하는 클래스.
    폴더 이름을 있는 그대로 사용하여 경로 생성의 일관성을 보장합니다.
    """
    def __init__(self, base_path):
        self.base_path = base_path
        self.is_dynamic = USE_DYNAMIC_FILE_PATHS
        
        # [핵심] 폴더 이름을 변환 없이 그대로 사용합니다.
        self.folder_name = os.path.basename(base_path)
        self.static_base_name = "mod" 

    def _get_path(self, suffix, static_filename_override=None):
        """내부 헬퍼: 동적/정적 경로를 계산하여 반환합니다."""
        if self.is_dynamic:
            # 원본 폴더 이름을 그대로 사용하여 동적 경로를 생성합니다.
            return os.path.join(self.base_path, f"{self.folder_name}{suffix}")
        else:
            # 정적 경로는 static_filename_override가 있으면 그것을 사용하고, 없으면 기존 방식을 따릅니다.
            if static_filename_override:
                return os.path.join(self.base_path, static_filename_override)
            return os.path.join(self.base_path, f"{self.static_base_name}{suffix}")
    
    # --- 각 파일 유형별 경로 제공 메서드 (내용 변경 없음) ---
    # 이제 모든 메서드는 위에서 재설계된 _get_path를 통해 올바른 경로를 반환합니다.

    def get_master_file(self):
        return self._get_path(MASTER_FILENAME_SUFFIX, MASTER_FILENAME_SUFFIX_STATIC)

    def get_old_master_file(self):
        return self._get_path(OLD_MASTER_FILENAME_SUFFIX)

    def get_merged_file(self):
        # MERGED_FILENAME_SUFFIX에 대한 정적 파일 이름 설정이 없으므로,
        # 이 부분은 동적 경로만 지원하는 것으로 가정합니다.
        # 만약 정적 경로일 때 'mod_merged_kr.csv'를 사용하려면 USER SETTINGS에
        # MERGED_FILENAME_STATIC = 'mod_merged_kr.csv'를 추가하고 아래를 수정해야 합니다.
        return self._get_path(MERGED_FILENAME_SUFFIX) # 정적일 때를 위한 static_filename_override 없음

    def get_missing_file(self):
        return self._get_path(MISSING_TRANSLATION_FILENAME, MISSING_TRANSLATION_FILENAME_STATIC)

    def get_empty_kr_file(self):
        return self._get_path(EMPTY_KR_FILENAME_SUFFIX)

    def get_changes_file(self):
        return self._get_path(CHANGES_FILENAME_SUFFIX)

    def get_apply_source_file(self):
        return self._get_path(APPLY_TRANSLATION_FILENAME_SUFFIX, APPLY_TRANSLATION_FILENAME_STATIC)

    def get_staging_master_file(self):
         return self._get_path(STAGING_MASTER_FILENAME_SUFFIX)

    def get_orphan_file(self):
        return self._get_path(ORPHAN_FILENAME_SUFFIX)
        
    def get_reverse_extract_success_file(self):
        return self._get_path(REVERSE_EXTRACT_SUCCESS_SUFFIX)
    
    def get_reverse_extract_mismatch_file(self):
        return self._get_path(REVERSE_EXTRACT_MISMATCH_SUFFIX)

    def get_reverse_extract_orphan_file(self):
        return self._get_path(REVERSE_EXTRACT_ORPHAN_SUFFIX)
        
    def get_reverse_extract_recovered_file(self):
        return self._get_path(REVERSE_EXTRACT_RECOVERED_SUFFIX)

    def get_reverse_extract_unrecovered_file(self):
        return self._get_path(REVERSE_EXTRACT_UNRECOVERED_SUFFIX)
    
    def get_purge_trash_file(self):
        return self._get_path(PURGE_TRASH_FILENAME_SUFFIX)
    
    def get_filtered_items_file(self):
        return self._get_path(FILTERED_ITEMS_FILENAME_SUFFIX)

    def get_string_integrity_report_file(self):
        return self._get_path(STRING_INTEGRITY_REPORT_SUFFIX)

    def get_apply_skipped_report_file(self):
        return self._get_path(APPLY_SKIPPED_REPORT_SUFFIX)

    def get_review_needed_file(self):
        return self._get_path(REVIEW_NEEDED_FILENAME_SUFFIX)

    def get_master_review_needed_file(self):
        return self._get_path(MASTER_REVIEW_NEEDED_FILENAME_SUFFIX)

    def get_master_purged_file(self):
        return self._get_path(MASTER_PURGED_FILENAME_SUFFIX)

    def get_master_true_review_file(self):
        return self._get_path(MASTER_TRUE_REVIEW_FILENAME_SUFFIX)

    def get_master_empty_kr_file(self):
        return self._get_path(MASTER_EMPTY_KR_FILENAME_SUFFIX)

    def get_master_false_review_file(self):
        return self._get_path(MASTER_FALSE_REVIEW_FILENAME_SUFFIX)
    
    def get_master_merge_preview_file(self):
        return self._get_path(MASTER_MERGE_PREVIEW_FILENAME_SUFFIX)



class ValidationService:
    """모든 기능별 유효성 검사 책임을 중앙에서 관리하는 클래스."""
    def __init__(self, mod_path):
        self.mod_path = mod_path
        self.paths = PathManager(mod_path)
        self.mod_name = os.path.basename(mod_path)
        self.logger = LoggerService.get_logger()

    def for_export(self):
        """Export, Check, Forward Sync를 위한 검사: 'data_en' 폴더 존재 여부."""
        return os.path.isdir(os.path.join(self.mod_path, SOURCE_DATA_FOLDER))

    def for_apply(self):
        """Apply를 위한 검사: 적용할 번역 파일 존재 여부."""
        return os.path.isfile(self.paths.get_apply_source_file())

    def for_deploy(self):
        """Deploy를 위한 검사: 'data' 폴더 존재 및 이름 규칙 준수 여부."""
        if MOD_USE_PREFIX_FILTER and not self.mod_name.startswith(MOD_FOLDER_PREFIX):
            return False
        return os.path.isdir(os.path.join(self.mod_path, "data"))

    def for_consolidate(self):
        """Update/Consolidate를 위한 검사: 'data_en' 폴더와 '_merged_kr.csv' 파일 동시 존재 여부."""
        self.logger.debug(f"--- [DEBUG-VALIDATION] 8번 기능 유효성 검사 시작: '{self.mod_name}' ---")
        has_data_en = self.for_export()
        has_merged_file = os.path.isfile(self.paths.get_merged_file())
        self.logger.debug(f"  - 'data_en' 존재: {has_data_en}, '_merged_kr.csv' 존재: {has_merged_file}")
        return has_data_en and has_merged_file

    def for_sync(self):
        """Sync, DeduplicateMaster를 위한 검사: '_merged_kr.csv'와 마스터 파일 동시 존재 여부."""
        return os.path.isfile(self.paths.get_merged_file()) and os.path.isfile(self.paths.get_master_file())

    def for_mod_info_sync(self):
        """Mod Info Sync를 위한 검사: 로컬 폴더 규칙 및 게임 폴더 내 존재 여부."""
        if self.mod_name in MOD_FOLDERS_TO_EXCLUDE: return False
        if MOD_USE_PREFIX_FILTER and not self.mod_name.startswith(MOD_FOLDER_PREFIX): return False
        
        mod_id = self.mod_name[len(MOD_FOLDER_PREFIX):] if MOD_USE_PREFIX_FILTER and self.mod_name.startswith(MOD_FOLDER_PREFIX) else self.mod_name
        game_mod_path = os.path.join(DESTINATION_BASE_PATH, mod_id)
        return os.path.isdir(game_mod_path)

    def for_reverse_sync(self):
        """Reverse Sync를 위한 검사: 이름 규칙 준수 및 폴더 존재 여부."""
        if MOD_USE_PREFIX_FILTER and not self.mod_name.startswith(MOD_FOLDER_PREFIX):
            return False
        return os.path.isdir(self.mod_path)

    def for_forward_sync(self):
        """Forward Sync를 위한 검사: 이름 규칙 준수 및 'data_en' 폴더 존재 여부."""
        if MOD_USE_PREFIX_FILTER and not self.mod_name.startswith(MOD_FOLDER_PREFIX):
            return False
        return self.for_export() # 'data_en' 폴더 존재 여부 검사를 재사용

    def for_reverse_extract(self):
        """Reverse Extract를 위한 검사: 'data_en' 및 'data' 또는 대체 폴더 존재 여부."""
        if not self.for_export(): return False
        has_data = os.path.isdir(os.path.join(self.mod_path, TRANSLATED_DATA_FOLDER.lstrip('./\\')))
        has_alt_data = bool(REVERSE_EXTRACT_ALT_SOURCE_FOLDER) and os.path.isdir(os.path.join(self.mod_path, REVERSE_EXTRACT_ALT_SOURCE_FOLDER.lstrip('./\\')))
        return has_data or has_alt_data

    def for_push_missing_to_merged(self):
        """Push TODO to Merged를 위한 검사: missing 파일과 merged 파일 동시 존재 여부."""
        return os.path.isfile(self.paths.get_missing_file()) and os.path.isfile(self.paths.get_merged_file())

    def for_rename_master_file(self):
        """마스터 파일 이름 변경을 위한 검사: 이전 이름의 파일 존재 여부."""
        return os.path.isfile(self.paths.get_old_master_file())



# ┏────────────────────────────────────────────────────────────────┐
#
#       [ 파일 읽기 인코딩 '시도-실패-대안(Try-Fail-Fallback)'  ]
#
# ┗────────────────────────────────────────────────────────────────┘
def read_file_with_fallback(file_path):
    """
    (v4.27.5 수정됨) orphan_scoped_logger가 apply 시점에 호출되지 않도록 수정합니다.
    """
    logger = LoggerService.get_logger()
    
    # [★★★★★ 핵심 수정: 조건부 로깅 ★★★★★]
    # 이 로거는 orphan 복구 시에만 사용되어야 하므로, apply 중에는 메시지를 남기지 않습니다.
    # ScopedLogger의 인스턴스를 직접 확인하는 대신, 현재 컨텍스트를 기반으로 로깅 여부를 결정하는 것이 더 안전합니다.
    # 하지만 현재 구조에서는 ScopedLogger 호출 자체를 막는 것이 가장 간단합니다.
    # apply_all_translations 함수에서는 orphan_scoped_logger를 직접 사용하지 않으므로,
    # 이 함수가 호출되는 컨텍스트를 추적하여 로깅을 분기하는 것이 좋습니다.
    # 임시로 orphan_scoped_logger의 로그 호출을 주석 처리하여 빠른 해결을 도모할 수 있습니다.
    
    # orphan_scoped_logger.log(f"    [READER] 파일 열기 시도. 경로: {os.path.abspath(file_path)}")
    # 위 라인을 주석 처리하거나, 더 나은 방법은 이 함수에 컨텍스트를 전달하는 것입니다.
    # 여기서는 간단하게 주석 처리하여 문제를 해결합니다.

    try:
        with open(file_path, 'rb') as f:
            raw_bytes = f.read()
    except (IOError, OSError) as e:
        logger.error(f"'{os.path.basename(file_path)}' 파일 접근 중 I/O 오류 발생: {e}")
        return None, None, False

    encodings_to_try = ['utf-8-sig', 'utf-8', 'cp949']
    
    logger.debug(f"파일 읽기 시도: {os.path.basename(file_path)}, 인코딩 목록: {encodings_to_try}")

    for encoding in encodings_to_try:
        try:
            content = raw_bytes.decode(encoding)
            fallback_used = (encoding != INPUT_FILE_ENCODING)
            
            if fallback_used:
                logger.info(f"  - 정보: '{os.path.basename(file_path)}' 파일을 '{encoding}' 인코딩으로 읽었습니다. (폴백 발생)")
            
            return content, encoding, fallback_used
        except UnicodeDecodeError:
            logger.debug(f"    - '{encoding}' 디코딩 실패, 다음 인코딩 시도...")
            continue
            
    try:
        content = raw_bytes.decode(sys.getdefaultencoding(), errors='replace')
        logger.warning(f"  [경고] '{os.path.basename(file_path)}'을(를) 표준 인코딩으로 읽기 실패. 시스템 기본 인코딩으로 강제 변환했습니다.")
        return content, f"{sys.getdefaultencoding()} (replaced)", True
    except Exception as e:
        logger.error(f" [!!!] 치명적 오류: '{os.path.basename(file_path)}' 파일을 어떤 방식으로도 디코딩할 수 없습니다: {e}")
        return None, None, False


# ┏────────────────────────────────────────────────────────────────┐
#
#                    [ Export 기능 블록 ]
#
# ┗────────────────────────────────────────────────────────────────┘

def analyze_text_validity(text):
    """
    (신규 모듈) 문자열의 번역 가능 여부와 '제외 사유'를 함께 반환하는 진단 함수입니다.
    기존 is_translatable()의 모든 로직을 이관받았습니다.
    반환 값: (is_valid: bool, reason: str or None)
    """
    logger = LoggerService.get_logger()
    
    if not isinstance(text, str):
        return False, "Not a String"
        
    cleaned = text.lstrip('\ufeff').strip()
    
    if not cleaned or cleaned.startswith('#'):
        return False, "Empty or Comment"
    
    if cleaned.lower() in DEFAULT_VALUE_EXCLUSIONS:
        return False, "Default Value Exclusion"
    
    if EXCLUDE_PERCENTAGE_ONLY_STRINGS and re.fullmatch(r"[-+]?[\d,]+(\.\d+)?%", cleaned):
        return False, "Percentage-only String"
    
    if re.fullmatch(r"[-+]?[\d,]+(\.\d+)?", cleaned):
        return False, "Numeric-only String"

    if re.fullmatch(r'\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}(?:\s*,\s*\d{1,3})?', cleaned):
        return False, "RGB Color Code"

    cleaned_lower = cleaned.lower()
    if cleaned_lower.startswith(('music_', 'sound_', 'sfx_')):
        return False, "Resource ID"

    if ' ' not in cleaned and cleaned.isalpha() and len(re.findall(r'[A-Z]', cleaned)) >= 2 and len(cleaned) >= 10:
        return False, "Camel/Pascal Case Variable"

    if ' ' not in cleaned and cleaned.startswith('$'):
        return False, "Single Dollar Variable"

    if '.' in cleaned and ' ' not in cleaned and not cleaned.endswith('.'):
        return False, "Object Property Access"

    if len(cleaned.strip()) <= 2 and re.fullmatch(r'\\?.\s*', cleaned):
        return False, "Single Special Character"
    
    script_code_patterns = [
        (r'^\s*\$[a-zA-Z0-9_.]+\s*=\s*.+$', "Variable Assignment"),
        (r'^\s*(Call|FireAll|FireBest|AdjustRep|RemoveOption|AddRemoveAnyItem|BeginMission|EndConversation|ShowPersonVisual|SetPersonHidden|AddCredits|RemoveCommodity|DoCanAffordCheck)\s+.*', "Script Command"),
        (r'^\s*\$global\..*$', "Global Variable Usage"),
        (r'^\s*\$player\..*$', "Player Variable Usage"),
        (r'^\s*BeginConversation\s', "Script Command"),
        (r'^\s*SetOptionColor\s', "Script Command"),
        (r'^\s*ShowImageVisual\s', "Script Command"),
    ]
    for pattern, reason in script_code_patterns:
        if re.search(pattern, cleaned):
            return False, reason

    if EXCLUDE_FILE_PATH_LIKE_STRINGS and ('/' in cleaned or '\\' in cleaned):
        path_like_rules = PROCESSING_RULES.get('EXCLUDE_PATH_LIKE_STRINGS', set())
        cleaned_path = cleaned.lower().replace('\\', '/')
        for rule in path_like_rules:
            if (rule.startswith('.') and cleaned_path.endswith(rule.lower())) or \
               (rule.endswith('/') and cleaned_path.startswith(rule.lower())) or \
               (cleaned_path == rule.lower()):
                return False, "File Path String"

    if '$' in cleaned and ' ' not in cleaned:
        return False, "Single Script Variable"
        
    if cleaned.lower() in NON_TRANSLATABLE_STRINGS:
        return False, "Non-translatable Word"

    return True, None

def _audit_string_integrity(all_merged_data, path_manager, is_test_run):
    """
    [문자열 무결성 감사 엔진 v2] 병합된 데이터 전체를 검사하여 text_en과 text_kr 간의
    [ESC] 태그 및 큰따옴표(") 개수 불일치를 찾아 별도의 보고서 파일로 생성합니다.
    """
    logger = LoggerService.get_logger()
    mismatched_items = []

    for row in all_merged_data:
        text_en = row.get('text_en', '') or ""
        text_kr = row.get('text_kr', '') or ""

        en_esc_count = text_en.count('[ESC]')
        kr_esc_count = text_kr.count('[ESC]')
        en_quote_count = text_en.count('"')
        kr_quote_count = text_kr.count('"')

        esc_mismatch = en_esc_count != kr_esc_count
        quote_mismatch = en_quote_count != kr_quote_count

        if esc_mismatch or quote_mismatch:
            reason = ""
            if esc_mismatch and quote_mismatch:
                reason = "Both Mismatched"
            elif esc_mismatch:
                reason = "ESC Mismatch"
            else:
                reason = "Quote Mismatch"
            
            mismatched_items.append({
                'source_file': row.get('source_file'),
                'id': row.get('id'),
                'type': row.get('type'),
                'mismatch_reason': reason,
                'en_esc_count': en_esc_count,
                'kr_esc_count': kr_esc_count,
                'en_quote_count': en_quote_count,
                'kr_quote_count': kr_quote_count,
                'text_en': text_en,
                'text_kr': text_kr
            })
    
    report_path = path_manager.get_string_integrity_report_file()
    
    if not mismatched_items:
        logger.info(" -> [문자열 무결성 감사] 모든 항목의 [ESC] 태그 및 따옴표 개수가 일치합니다.")
        if os.path.exists(report_path):
            if not is_test_run:
                os.remove(report_path)
            logger.info(f" -> 문제가 해결되어 이전의 '{os.path.basename(report_path)}' 파일을 삭제했습니다.")
        return 0

    headers = ['source_file', 'id', 'type', 'mismatch_reason', 
               'en_esc_count', 'kr_esc_count', 'en_quote_count', 'kr_quote_count', 
               'text_en', 'text_kr']
    
    csv_file_service.write_rows_to_csv(
        report_path,
        mismatched_items,
        headers=headers,
        is_test_run=is_test_run,
        sort_data=True
    )
    
    if not is_test_run:
        logger.warning(f" [!] [문자열 무결성 감사] {len(mismatched_items)}개의 불일치 항목을 발견했습니다.")
        logger.warning(f"     -> 상세 내용은 '{os.path.basename(report_path)}' 파일을 확인하세요.")
    
    return len(mismatched_items)

def is_translatable(text):
    """
    (래퍼 함수) 문자열이 번역할 가치가 있는지 여부만 반환합니다. (기존 코드 호환성 유지)
    실제 로직은 analyze_text_validity()에 위임합니다.
    """
    is_valid, _ = analyze_text_validity(text)
    return is_valid


# ############################################################################
#
#                    [ ARCHITECTURAL DIRECTIVE - DO NOT MODIFY ]
#
# DIRECTIVE-ID: OPTIONS_HANDLER_STABLE_V1
# TARGET: _extract_options_snippets(), handle_options_column_export(),
#         handle_options_column_apply()
# STATUS: FINALIZED & VALIDATED
#
# REASON: 
#   이 함수 그룹은 'rules.csv' 파일의 'options' 열을 처리하는 핵심 로직을
#   캡슐화합니다. 'script' 열 처리 로직과 마찬가지로 안정화 및 검증이
#   완료되었으므로, 의도치 않은 변경을 방지하기 위해 동결 상태로 유지됩니다.
#
# MODIFICATION_PROTOCOL: 
#   이 함수의 로직을 수정해야 할 경우, 반드시 다음과 같이 명시적으로
#   요청하십시오: "DIRECTIVE-ID: OPTIONS_HANDLER_STABLE_V1에 대한 수정 요청:
#   [변경 내용 요약]". 이 프로토콜 없이는 AI가 임의로 수정하지 않습니다.
#
# ############################################################################
# ┏─────────────────────────────────────────────────────
# ┃ 
# ┃ [ Options Column 처리 로직 ]
# ┃ process_regex_csv (Export) 함수와 apply_regex_csv (Apply) 함수에서 사용
# ┃ 
def _extract_options_snippets(column_text, source_file, item_id):
    """
    options 열의 텍스트를 파싱하여, 번역 가능한 텍스트 조각들의 리스트를 반환합니다.
    [v4.27.19 최종 수정] 추출된 Value를 _clean_and_strip_quotes으로 즉시 정제합니다.
    """
    translatable_options = []
    stripped_text = column_text.strip()
    
    if not stripped_text:
        return translatable_options

    key_value_pairs = re.findall(
        r'([a-zA-Z0-9_]+)\s*:\s*(.+?)(?=\s*[a-zA-Z0-9_]+:\s*|$)',
        stripped_text,
        re.DOTALL
    )
    
    if not key_value_pairs:
        return translatable_options

    for key, value_raw in key_value_pairs:
        # [★★★★★ 최종 수정 ★★★★★]
        # 추출된 value_raw에 대해 즉시 전용 클리너를 호출하여 정제합니다.
        cleaned_value = _clean_and_strip_quotes(value_raw)
        
        is_valid, reason = analyze_text_validity(cleaned_value)
        
        if is_valid:
            translatable_options.append(cleaned_value) # 정제된 값을 추가
        else:
            FilterAuditService.record(source_file, item_id, 'options', cleaned_value, reason)     
                           
    return translatable_options


def process_special_csv(file_path, input_folder_path, rules):
    logger = LoggerService.get_logger()
    extracted, relative_path = [], os.path.relpath(file_path, input_folder_path).replace('\\', '/')
    key_columns, translatable_columns = rules['key_columns'], rules['translatable_columns']
    try:
        with open(file_path, mode='r', encoding='utf-8-sig', newline='') as infile:
            reader = csv.DictReader(infile)
            if not reader.fieldnames or not all(k in reader.fieldnames for k in key_columns):
                logger.warning(f"특별 파일 '{relative_path}'에 필수 키 열({key_columns})이 없어 건너뜁니다.")
                return []
            for row in reader:
                if next(iter(row.values()), "").strip().startswith('#'): continue
                id_parts = [row.get(k, '').strip() for k in key_columns]
                if not all(id_parts) or any(p.startswith('#') for p in id_parts): continue
                composite_id = '|'.join(id_parts)
                for col_name in translatable_columns:
                    content = row.get(col_name, '')
                    content_precise_stripped = content.strip(' \t')
                    
                    is_valid, reason = analyze_text_validity(content_precise_stripped)
                    if is_valid:
                        extracted.append({'source_file': relative_path, 'id': composite_id, 'type': col_name, 'text_en': standardize_newlines(content_precise_stripped)})
                    else:
                        # [감사] 필터링된 항목을 기록합니다.
                        FilterAuditService.record(
                            source_file=relative_path,
                            item_id=composite_id,
                            item_type=col_name,
                            text_en=content_precise_stripped,
                            reason=reason
                        )
    except Exception as e:
        logger.error(f"특별 파일 '{relative_path}' 처리 중 오류: {e}")
    return extracted

def traverse_json(obj, path, extracted_list, relative_path, use_key_as_type=False, target_keys=None):
    """
    [v2 - 공백 보존 수정] 모든 텍스트 처리를 text_processor_service에 위임하여,
    JSON 타입의 앞/뒤 공백이 보존되도록 수정합니다.
    """
    is_selective_extraction = target_keys is not None and len(target_keys) > 0
    
    if isinstance(obj, dict):
        for key, value in obj.items():
            current_path_segment = f"{path}.{key}" if path else key
            
            if is_selective_extraction and isinstance(value, str):
                if key not in target_keys:
                    continue
            
            traverse_json(value, current_path_segment, extracted_list, relative_path, use_key_as_type, target_keys)

    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            current_path_segment = f"{path}[{i}]"
            traverse_json(item, current_path_segment, extracted_list, relative_path, use_key_as_type, target_keys)

    elif isinstance(obj, str):
        # [핵심 수정] item_type 결정
        item_type = path.split('.')[-1] if use_key_as_type else 'json'

        # [핵심 수정] 모든 텍스트 처리를 text_processor_service에 위임
        # obj (원본 문자열)을 직접 전달하여 서비스가 공백 보존 여부를 결정하도록 함
        processed_value = text_processor_service.process(obj, item_type=item_type)
        
        last_key_match = re.search(r'\.?(\w+)(?:\[\d+\])?$', path)
        current_key_name = last_key_match.group(1) if last_key_match else None

        if is_selective_extraction and (current_key_name is None or current_key_name not in target_keys):
            return

        # [핵심 수정] is_valid 검사에도 처리된 값을 사용
        is_valid, reason = analyze_text_validity(processed_value)
        
        if is_valid:
            extracted_list.append({
                'source_file': relative_path, 
                'id': path, 
                'type': item_type,
                'text_en': processed_value # <-- 이미 모든 처리가 완료된 값 사용
            })
        else:
            FilterAuditService.record(
                source_file=relative_path,
                item_id=path,
                item_type=item_type,
                text_en=processed_value, # <-- 처리된 값을 기준으로 기록
                reason=reason
            )


def process_strings_json(file_path, input_folder_path, rules=None, mod_root_path=None):
    """
    (신규 전용 파서) "key": "value" 쌍으로 구성된, 주석 포함 JSON 형식의 파일에서
    is_translatable()을 통과하는 값만 안전하게 추출합니다. (주로 strings.json 용)
    """
    logger = LoggerService.get_logger()
    extracted, anomalies, suspicious_scripts = [], [], []
    relative_path = os.path.relpath(file_path, input_folder_path).replace('\\', '/')
    logger.debug(f"  -> 전용 K-V 파서 'process_strings_json'으로 '{relative_path}' 처리 시작.")

    try:
        file_content_tuple = read_file_with_fallback(file_path)
        # [★★★★★ 핵심 수정 ★★★★★]
        # file_content_tuple이 (content, encoding, fallback_used) 3개 값을 반환하므로,
        # 3개의 변수로 받거나, 필요 없는 값은 _ 로 무시합니다.
        if file_content_tuple is None:
            return [], [], []

        content, _, _ = file_content_tuple # 3개 값으로 받도록 수정

        # 1. 먼저 주석을 제거하여 정규식의 정확도를 높입니다.
        content = re.sub(r'#.*', '', content)
        
        # 2. "key": "value" 패턴을 찾는 정규식
        # 그룹 1: 키 (따옴표 안의 내용)
        # 그룹 2: 값 (따옴표 안의 내용, 이스케이프된 따옴표 포함)
        kv_pattern = re.compile(r'"([a-zA-Z0-9_\(\)]+)"\s*:\s*"((?:[^"\\]|\\.)*)"')
        
        # 3. 모든 키-값 쌍을 찾습니다.
        matches = kv_pattern.finditer(content)

        # 4. 각 쌍을 순회하며 번역 대상인지 확인합니다.
        for match in matches:
            key = match.group(1)
            value = match.group(2)

            # [핵심] 값이 is_translatable()을 통과하는 경우에만 추출 대상으로 삼습니다.
            is_valid, reason = analyze_text_validity(value)
            if is_valid:
                extracted.append({
                    'source_file': relative_path,
                    'id': key,
                    'type': 'json', # 명확한 타입 지정
                    'text_en': standardize_newlines(value)
                })
            else:
                FilterAuditService.record(
                    source_file=relative_path,
                    item_id=key,
                    item_type='json',
                    text_en=value,
                    reason=reason
                )

        logger.debug(f"     ... 'process_strings_json'이 {len(extracted)}개의 항목을 성공적으로 추출했습니다.")

    except Exception as e:
        logger.error(f"'process_strings_json'으로 '{relative_path}' 처리 중 오류: {e}", exc_info=True)
        
    return extracted, anomalies, suspicious_scripts


def _analyze_and_route_json(file_path):
    """
    [지능형 JSON 디스패처 v3.0 - 책임 강화]
    중앙 로더를 사용하여 안전하게 객체를 얻은 후, 그 구조를 분석하여 최적의 파서를 결정합니다.
    """
    logger = LoggerService.get_logger()
    logger.debug(f"  [AutoDetect] '{os.path.basename(file_path)}' 파일의 최적 파서 분석 시작...")

    content_tuple = read_file_with_fallback(file_path)
    if not content_tuple or not content_tuple[0]:
        logger.debug("  [AutoDetect] -> 파일이 비어있어 기본 재귀 파서 'process_json_file' 선택.")
        return 'process_json_file'

    content = content_tuple[0]
    # [★★★★★ 핵심 변경 ★★★★★]
    # 모든 파싱/복구 작업을 중앙 로더에 위임하여 'data' 객체를 얻습니다.
    data = _load_and_sanitize_json(content, os.path.basename(file_path))

    if data is None:
        logger.error(f"  [AutoDetect] -> '{os.path.basename(file_path)}' 파일을 파싱할 수 없어 처리를 중단합니다.")
        return None # 파싱 실패 시 None을 반환하여 처리를 중단시킴
        
    if not isinstance(data, dict) or not data:
        logger.debug("  [AutoDetect] -> 표준 딕셔너리 구조가 아니므로 재귀 파서 'process_json_file' 선택.")
        return 'process_json_file'

    # [판단 로직]
    if any(isinstance(value, (dict, list)) for value in data.values()):
        logger.debug("  [AutoDetect] -> 중첩 구조(dict/list)가 발견되어 재귀 파서 'process_json_file' 선택.")
        return 'process_json_file'
    else:
        logger.debug("  [AutoDetect] -> 모든 값이 단순 타입이므로 평면 파서 'process_strings_json' 선택.")
        return 'process_strings_json'


def json_scan_process(file_content, forced_pattern_name=None):
    """
    [신규 지능형 스캐너] JSON 파일 내용을 분석하여, USER SETTINGS의
    JSON_STRUCTURE_PATTERNS와 일치하는 첫 번째 구조 패턴을 찾아 반환합니다.
    (수정) `forced_pattern_name` 인자를 추가하여 특정 패턴을 강제할 수 있도록 함.
    """
    logger = LoggerService.get_logger()
    
    # 강제된 패턴 이름이 있다면 해당 패턴만 검색
    if forced_pattern_name:
        for pattern_rule in JSON_STRUCTURE_PATTERNS:
            if pattern_rule.get('name') == forced_pattern_name:
                logger.debug(f"  -> JSON 구조 감지 성공 (강제): '{pattern_rule.get('name')}' 패턴과 일치합니다.")
                return pattern_rule
        logger.warning(f"  -> [경고] 강제된 패턴 '{forced_pattern_name}'을(를) 찾을 수 없습니다. 처리를 계속할 수 없습니다.")
        return None

    # 강제된 패턴이 없다면 일반적인 순차 검색
    for pattern_rule in JSON_STRUCTURE_PATTERNS:
        detector_regex = pattern_rule.get('detector_regex')
        if detector_regex and re.search(detector_regex, file_content):
            logger.debug(f"  -> JSON 구조 감지 성공: '{pattern_rule.get('name')}' 패턴과 일치합니다.")
            return pattern_rule
    
    logger.warning("  -> [경고] 어떤 JSON 구조 패턴과도 일치하지 않습니다. 처리를 계속할 수 없습니다.")
    return None


# ┏────────────────────────────────────────────────────────────────┐
#
#                    [ 통합 데이터 로딩 함수 ]
#
# ┗────────────────────────────────────────────────────────────────┘
def _load_csv_to_map(file_path, row_processor):
    """(신규 헬퍼) CSV 파일을 열어 각 행을 row_processor로 처리하고, 그 결과를 딕셔너리로 반환합니다."""
    logger = LoggerService.get_logger()
    data_map = {}
    
    if not os.path.exists(file_path):
        logger.debug(f"  -> 데이터 로딩 건너뜀: '{os.path.basename(file_path)}' 파일 없음.")
        return data_map
        
    try:
        with open(file_path, mode='r', encoding='utf-8-sig', newline='') as infile:
            reader = csv.DictReader(infile)
            for row in reader:
                key, value = row_processor(row)
                if key:
                    data_map[key] = value

        logger.debug(f"  -> '{os.path.basename(file_path)}'에서 총 {len(data_map)}개 항목 로드 완료.")
    except Exception as e:
        logger.error(f"  -> '{os.path.basename(file_path)}' 파일 읽기 중 오류 발생: {e}")
        
    return data_map



# 로드된 text_en과 text_kr에 text_processor_service.process을 적용하여 일관성을 확보합니다 (4.22.0 버전).
def load_existing_translations(file_paths, existing_kr_file_path=None):
    """
    (v4.27.19 최종 수정) options 타입의 text_kr도 text_en과 동일하게 정제하여
    완벽한 데이터 대칭성을 보장합니다.
    [마에스트로 수정] type:text인 text_kr의 '\\n'을 '|n|' 태그로 변환합니다.
    """
    logger = LoggerService.get_logger()
    primary_translation_dict = {}
    fallback_translation_dict = {}
    
    logger.info("기존 번역 데이터 로드를 시작합니다...")

    for file_path in file_paths:
        if not os.path.exists(file_path):
            logger.debug(f"  - 번역 소스 '{os.path.basename(file_path)}' 파일이 없어 건너뜁니다.")
            continue
        
        logger.info(f"  -> '{os.path.basename(file_path)}'에서 데이터를 불러옵니다...")
        loaded_count_for_this_file = 0
        
        all_rows = csv_file_service.load_rows_from_csv(file_path)
        if not all_rows:
            logger.warning(f"    '{os.path.basename(file_path)}' 파일에 데이터가 없어 번역을 로드할 수 없습니다.")
            continue

        required_headers = ['source_file', 'id', 'type', 'text_en', 'text_kr']
        if not all_rows or not all(h in all_rows[0].keys() for h in required_headers):
            logger.warning(f"    '{os.path.basename(file_path)}'에 필수 열({', '.join(required_headers)}) 중 하나 이상이 없어 번역을 로드할 수 없습니다.")
            continue
        
        for row in all_rows:
            source = row.get('source_file', '')
            row_id = row.get('id', '')
            row_type = row.get('type', '')
            text_en = row.get('text_en', '')
            text_kr = row.get('text_kr', '')

            if row_type.startswith('options:'):
                text_en = _clean_and_strip_quotes(text_en)
                text_kr = _clean_and_strip_quotes(text_kr)
            
            # [핵심 수정] 중앙 처리 엔진을 사용하여 EN과 KR을 동일한 규칙으로 처리
            processed_text_en = text_processor_service.process(text_en, item_type=row_type)
            processed_text_kr = text_processor_service.process(text_kr, item_type=row_type)

            if row_id == 'GAPZDiktatHub6':
                logger.info("="*20 + " [ DEBUG: MASTER FILE LOAD ] " + "="*20)
                logger.info(f"  - ID: {row_id}")
                logger.info(f"  - Original text_en from Master: '{row.get('text_en', '')}'")
                logger.info(f"  - >> Processed text_en for Key: '{processed_text_en}'")
                logger.info(f"  - Original text_kr from Master: '{row.get('text_kr', '')}'")
                logger.info(f"  - >> Processed text_kr for Value: '{processed_text_kr}'")
                logger.info("="*69)
            
            if not (source and row_id and row_type and processed_text_en):
                logger.debug(f"     [경고] 불완전한 필수 키로 인해 항목 건너뜀: source='{source}', id='{row_id}', type='{row_type}'")
                continue
            
            translatable_status = row.get('Translatable', '').strip().lower()

            key = (source, row_id, row.get('type'), processed_text_en)
            primary_translation_dict[key] = (processed_text_kr, translatable_status)
            
            if processed_text_kr.strip() and processed_text_en not in fallback_translation_dict:
                fallback_translation_dict[processed_text_en] = processed_text_kr

            loaded_count_for_this_file += 1

        logger.debug(f"     ... {loaded_count_for_this_file}개의 번역문을 로드했습니다.")
            
    total_primary = len(primary_translation_dict)
    total_fallback = len(fallback_translation_dict)

    if total_primary > 0:
        logger.info(f"총 {total_primary}개의 정밀 번역 키와 {total_fallback}개의 대체 번역 키를 성공적으로 불러왔습니다.")
    else:
        logger.info(" -> 불러올 기존 번역 데이터가 없습니다. 'data_en'에서 새로 추출한 내용을 기반으로 작업을 계속합니다.")
        
    return primary_translation_dict, fallback_translation_dict


# ┏────────────────────────────────────────────────────────────────┐
# ┃
# ┃                  [ 분석 및 UI 렌더링 엔진 ]
# ┃

def _analyze_and_display_sync_status(differences, merged_file_path, master_file_path, base_path):
    """[UI 엔진 v3] 트래시 파일과 교차 분석하여, 고아 항목의 원인까지 추적/보고합니다."""
    logger = LoggerService.get_logger()
    
    def group_by_source_file(keys):
        """주어진 키 목록을 source_file 별로 그룹화하고 개수를 셉니다."""
        grouped = defaultdict(int)
        for key in keys:
            grouped[key[0]] += 1
        return sorted(grouped.items(), key=lambda item: item[1], reverse=True)

    # [핵심 추가] 고아 항목의 원인 분석 로직
    orphans_in_trash_count = 0
    true_orphans_count = 0
    removed_keys = differences.get('removed', set())

    if removed_keys and 'EXCLUDE_TRASH_FILE_FROM_PROCESSING' in globals() and EXCLUDE_TRASH_FILE_FROM_PROCESSING:
        paths = PathManager(base_path)
        trash_file_path = paths.get_purge_trash_file()
        if os.path.exists(trash_file_path):
            # 트래시 파일을 4-tuple 키의 set으로 로드
            trash_data_map = load_data_for_check(trash_file_path)
            trash_keys_set = set(trash_data_map.keys())
            
            # 고아 키와 트래시 키의 교집합 계산
            intersection = removed_keys.intersection(trash_keys_set)
            orphans_in_trash_count = len(intersection)

    true_orphans_count = len(removed_keys) - orphans_in_trash_count

    # --- UI 렌더링 시작 ---
    print("\n" + "!"*70)
    logger.warning(f" [알림] 마스터 파일('{os.path.basename(master_file_path)}') 동기화 필요 사항 분석:")
    print("-" * 70)
    
    print("  [ Export 컨텍스트 요약 ]")
    if 'EXCLUDE_TRASH_FILE_FROM_PROCESSING' in globals() and EXCLUDE_TRASH_FILE_FROM_PROCESSING:
        print(f"    - 트래시 파일(접미사: '{PURGE_TRASH_FILENAME_SUFFIX}')의 내용은 이번 Export에서 제외되었습니다.")
    print(f"    - 비교 대상인 '{os.path.basename(merged_file_path)}'는 위 규칙에 따라 생성되었습니다.")
    print("-" * 70)
    
    print("  [ 동기화 상세 정보 ]")
    print(f"    [기준]: '{os.path.basename(master_file_path)}' (현재 마스터 라이브러리)")
    print(f"    [비교]: '{os.path.basename(merged_file_path)}' (최신 Export 결과)")
    print("-" * 70)
    
    grouped_added = group_by_source_file(differences.get('added', []))
    grouped_modified = group_by_source_file(differences.get('modified', []))
    grouped_removed = group_by_source_file(differences.get('removed', []))

    if differences.get('added'):
        print(f"  - {len(differences['added']):>5} 개 : [신규] Master에 없으나, 최신 Export 결과에 있음")
        for i, (file, count) in enumerate(grouped_added):
            if i < 3: print(f"      └─ {file}: {count}개")
        if len(grouped_added) > 3: print("      └─ ... 등")

    if differences.get('modified'):
        print(f"  - {len(differences['modified']):>5} 개 : [번역 변경] 양쪽에 모두 존재하나, 'text_kr' 내용이 다름")
        for i, (file, count) in enumerate(grouped_modified):
            if i < 3: print(f"      └─ {file}: {count}개")
        if len(grouped_modified) > 3: print("      └─ ... 등")
            
    if removed_keys:
        print(f"  - {len(removed_keys):>5} 개 : [고아] Master에는 있으나, 최신 Export 결과에 없음")
        if orphans_in_trash_count > 0:
            print(f"      └─ 이 중 {orphans_in_trash_count}개는 트래시 파일에서 발견되었습니다.")
        if true_orphans_count > 0:
            print(f"      └─ 이 중 {true_orphans_count}개는 'data_en'에서 삭제된 것으로 추정됩니다.")
        
        # 파일별 상세 내역은 전체 고아 항목 기준으로 표시 (가독성을 위해 약간 들여쓰기)
        if grouped_removed:
             print("         (주요 발생 파일):")
        for i, (file, count) in enumerate(grouped_removed):
            if i < 3: print(f"         - {file}: {count}개")
        if len(grouped_removed) > 3: print("         - ... 등")
            
    print("!"*70)
    
# ┃
# ┃
# ┗────────────────────────────────────────────────────────────────┘

def run_post_export_sync_check(base_path, is_test_run, shared_state):
    logger = LoggerService.get_logger()
    logger.info("\n" + "-"*50)
    logger.info("후속 작업: 스테이징 파일과의 동기화 상태를 확인합니다...")

    paths = PathManager(base_path)
    merged_file_path = paths.get_merged_file()
    staging_file_path = paths.get_staging_master_file()
    # missing_file_path는 이제 _sync_engine_overwrite 호출 후 처리되므로 여기서 제거. # 이 주석은 이전 단계에서 제거되었어야 합니다.

    # [핵심 수정 1] _compare_files_engine 호출 및 결과 사용
    differences, merged_data_map, staging_data_map = _compare_files_engine(merged_file_path, staging_file_path)
    
    if not differences or not any(differences.values()):
        logger.info(" -> 스테이징 파일이 이미 최신 상태입니다. 추가 작업이 필요 없습니다.")
        # 변경사항이 없으면 빈 리포트 번들을 반환
        return {
            "header": {"report_title": "스테이징 동기화", "summary_lines": []},
            "sections": [
                {"section_title": "스테이징 동기화 상태", "section_type": "key_value_list", "content": [
                    {"label": "현재 상태", "label_prefix": "[✔] ", "value": "이미 최신 상태입니다.", "level": 1}
                ]}
            ]
        }, False # 리포트 번들, 동기화 필요 여부

    # [핵심 수정 2] `text_en` 변경으로 인한 항목 재추출 (Removed + Added) 감지 로직
    text_en_changed_count = 0
    
    if differences.get('added') and differences.get('removed'):
        added_loc_keys = {k[:3] for k in differences['added']}
        removed_loc_keys = {k[:3] for k in differences['removed']}
        common_loc_keys = added_loc_keys.intersection(removed_loc_keys)

        for loc_key in common_loc_keys:
            new_ens_at_loc = {k[3] for k in differences['added'] if k[:3] == loc_key}
            old_ens_at_loc = {k[3] for k in differences['removed'] if k[:3] == loc_key}

            if new_ens_at_loc and old_ens_at_loc and new_ens_at_loc != old_ens_at_loc:
                text_en_changed_count += 1
        
        # 리포트용 differences 딕셔너리를 복사하여 수정
        report_differences = {k: set(v) for k, v in differences.items()}
        
        keys_related_to_en_change = set()
        for loc_key in common_loc_keys:
            keys_related_to_en_change.update({k for k in differences['added'] if k[:3] == loc_key})
            keys_related_to_en_change.update({k for k in differences['removed'] if k[:3] == loc_key})

        report_differences['added'] -= keys_related_to_en_change
        report_differences['removed'] -= keys_related_to_en_change
    else:
        report_differences = {k: set(v) for k, v in differences.items()}

    # --- Report Bundle 데이터 구조 생성 (출력용) ---
    report_bundle = {
        "header": {
            "report_title": "스테이징 파일 동기화 필요", # 제목 변경
            "target_name": os.path.basename(base_path),
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%MM:%S'),
            "summary_lines": [] # 요약 라인은 동적으로 추가
        },
        "sections": []
    }
    
    # 요약 라인 생성 (이전과 동일)
    total_non_en_changes = (len(report_differences['added']) + len(report_differences['modified']) + 
                     len(report_differences['removed']))
    total_changes = total_non_en_changes + text_en_changed_count

    if total_changes > 0:
        report_bundle["header"]["summary_lines"].append({"label": "총 감지된 변경 항목", "value": f"{total_changes}개"})
        if text_en_changed_count > 0:
            report_bundle["header"]["summary_lines"].append({"label": "원문(EN) 변경된 항목", "value": f"{text_en_changed_count}개"})
        if total_non_en_changes > 0:
             report_bundle["header"]["summary_lines"].append({"label": "KR 변경/신규/제거 항목", "value": f"{total_non_en_changes}개"})


    # 섹션 1: 동기화 대상 파일 (이전과 동일)
    overview_content = [
        {"label": f"원본 (최신 Export 결과)", "value": os.path.basename(merged_file_path), "level": 1},
        {"label": f"대상 (현재 스테이징 파일)", "value": os.path.basename(staging_file_path), "level": 1},
    ]
    report_bundle["sections"].append({
        "section_title": "동기화 대상 파일",
        "section_type": "key_value_list",
        "content": overview_content
    })

    # 섹션 2: 예상되는 스테이징 파일 변경 내역 (이전과 동일)
    changes_section_content = []

    if report_differences.get('added'):
        changes_section_content.append({"label": "새로 추가될 항목", "label_prefix": "[+] ", "value": f"{len(report_differences['added'])}개", "level": 2})
        changes_section_content.extend(_prepare_grouped_file_details(report_differences['added']))
    
    if report_differences.get('modified'):
        changes_section_content.append({"label": "번역(KR)이 변경될 항목", "label_prefix": "[*] ", "value": f"{len(report_differences['modified'])}개", "level": 2})
        changes_section_content.extend(_prepare_grouped_file_details(report_differences['modified']))
    
    if report_differences.get('removed'):
        changes_section_content.append({"label": "제거될 항목 (merged에 없음)", "label_prefix": "[-] ", "value": f"{len(report_differences['removed'])}개", "level": 2})
        changes_section_content.extend(_prepare_grouped_file_details(report_differences['removed']))

    if text_en_changed_count > 0:
        changes_section_content.append({"label": "원문(EN)이 변경된 항목", "label_prefix": "[!] ", "value": f"{text_en_changed_count}개", "level": 2})
        changes_section_content.append({"label": "   └─ 원문이 변경되어 새로 추가/제거될 항목들입니다. 주의!", "level": 3})

    if not changes_section_content:
        changes_section_content.append({"label": "감지된 변경 사항 없음", "label_prefix": "[ ] ", "value": "모든 항목이 일치합니다.", "level": 2})

    report_bundle["sections"].append({
        "section_title": "예상되는 스테이징 파일 변경 내역",
        "section_type": "key_value_list",
        "content": changes_section_content
    })
    
    # [핵심 수정 3] 리포트 번들 및 동기화 필요 여부를 반환합니다. (이전과 동일)
    return report_bundle, True # 리포트 번들, 동기화 필요 여부


def _process_pending_translations(base_path, is_test_run):
    logger = LoggerService.get_logger()
    
    if USE_DYNAMIC_FILE_PATHS:
        folder_name = os.path.basename(base_path)
        missing_file_path = os.path.join(base_path, f"{folder_name}{MISSING_TRANSLATION_FILENAME}")
        pending_file_path = os.path.join(base_path, f"{folder_name}{PENDING_MERGE_FILENAME_SUFFIX}")
    else:
        missing_file_path = os.path.join(base_path, MISSING_TRANSLATION_FILENAME_STATIC)
        pending_file_path = os.path.join(base_path, PENDING_MERGE_FILENAME_STATIC)

    if not os.path.exists(missing_file_path):
        return

    translated_items = []
    untranslated_items = []
    
    # CsvFileService를 사용하여 파일 로드
    all_missing_data = csv_file_service.load_rows_from_csv(missing_file_path) # <--- CsvFileService 사용
    if not all_missing_data:
        return

    for row in all_missing_data:
        if row.get('text_kr', '').strip():
            translated_items.append(row)
        else:
            untranslated_items.append(row)

    if translated_items:
        logger.info(f" -> '{os.path.basename(missing_file_path)}'에서 번역된 {len(translated_items)}개 항목을 발견했습니다.")
        
        # 병합 대기 파일에 추가(append)
        csv_file_service.append_rows_to_csv_without_duplicates( # <--- CsvFileService 사용
            pending_file_path, translated_items, headers=OUTPUT_HEADERS, create_backup_on_write=False, is_test_run=is_test_run
        )

        # _TODO_ 파일은 번역되지 않은 항목만 남기고 덮어쓰기
        csv_file_service.write_rows_to_csv(missing_file_path, untranslated_items, OUTPUT_HEADERS, is_test_run) # <--- CsvFileService 사용


def _render_key_value_section(content, translations=None):
    """
    [리포트 렌더러 v3] key_value_list 타입의 섹션 내용을 출력합니다.
    [최종 수정] 번역 사전을 인자로 받아 번역을 수행합니다.
    """
    logger = LoggerService.get_logger()
    if not content:
        return
        
    translations = translations or {} # None일 경우 빈 딕셔너리로 초기화
    
    processed_content = []
    for item in content:
        item_copy = item.copy()
        final_label = ""
        if item_copy.get("translate_label"):
            label_key = item_copy.get("label_key", "")
            final_label = translations.get(label_key, label_key)
        else:
            final_label = item_copy.get("label", "")
        
        final_label = item_copy.get("label_prefix", "") + final_label
        item_copy["final_label"] = final_label
        processed_content.append(item_copy)

    max_label_len = 0
    if processed_content:
        max_label_len = max(len(item.get("final_label", "")) for item in processed_content)

    for item in processed_content:
        label = item.get("final_label", "")
        value = item.get("value", "")
        indent = "  " * (item.get("level", 1) - 1)
        
        if value:
            logger.info(f"{indent}{label:<{max_label_len - len(indent)}} : {value}")
        else:
            logger.info(f"{indent}{label}")

def _render_standard_report(report_bundle, translations=None):
    """
    [범용 리포트 렌더러 v4] report_bundle과 번역 사전을 입력받아 표준 UI로 출력합니다.
    """
    logger = LoggerService.get_logger()
    header = report_bundle.get("header", {})

    # --- 헤더 출력 ---
    logger.info("\n" + "="*70)
    title_text = header.get("report_title", '종합 리포트')
    try:
        # 한글/영문 길이를 고려하여 중앙 정렬 (EUC-KR 기준 근사치)
        title_len_for_calc = len(title_text.encode('euc-kr')) 
    except:
        title_len_for_calc = len(title_text)
    title_padding_total = 70 - title_len_for_calc - 4
    title_padding = title_padding_total // 2 if title_padding_total > 0 else 0
    logger.info(f"{' '*title_padding}[ {title_text} ]")
    
    logger.info("-" * 70)
    logger.info(f" 작업 대상: {header.get('target_name', 'N/A')}")
    logger.info(f" 작업 시간: {header.get('timestamp', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))}")
    if header.get("summary_lines"):
        logger.info("-" * 70)
        for line in header["summary_lines"]:
            logger.info(f"  ▶ {line.get('label', '')}: {line.get('value', '')}")
    logger.info("="*70)

    # --- 섹션 출력 ---
    for section in report_bundle.get("sections", []):
        section_title = section.get("section_title", "상세 내역")
        try:
            title_len_for_calc = len(section_title.encode('euc-kr'))
        except:
            title_len_for_calc = len(section_title)
        right_padding = 34 - title_len_for_calc
        if right_padding < 0: right_padding = 0
        logger.info(f"\n{'='*30} [ {section_title} ] {'='*right_padding}")
        
        section_type = section.get("section_type")
        content = section.get("content")

        if section_type == "key_value_list":
            if not content:
                logger.info("  (해당 없음)")
            else:
                _render_key_value_section(content, translations=translations)
            
    # --- 푸터 출력 ---
    logger.info("\n" + "="*70)

def _display_export_report(report_data, base_path, sync_report_bundle=None):
    """
    [리팩토링 v3 - UI 개선 및 스테이징 동기화 리포트 통합] Export 작업 리포트용 '데이터 빌더'.
    모든 출력 파일 목록을 동적으로 표시하고, 스테이징 동기화 리포트도 통합하여 표시합니다.
    """
    if not ENABLE_EXPORT_REPORT_OUTPUT:
        return None # 리포트 출력이 비활성화된 경우 None 반환

    # --- 1. Report Bundle 데이터 구조 생성 ---
    report_bundle = {
        "header": {
            "report_title": "Export 종합 빌드 리포트",
            "target_name": os.path.basename(base_path),
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "summary_lines": [] # 요약은 동적으로 추가
        },
        "sections": []
    }

    # --- 섹션 1: 원본 분석 (`data_en`) ---
    final_analysis_count = report_data.get('latest_item_count', 0) - report_data.get('trash_filtered_count', 0)
    analysis_section_content = [
        {"label": "추출된 총 텍스트 수", "label_prefix": "[+] ", "value": f"{report_data.get('latest_item_count', 0)}개"},
        {"label": "트래시/블랙리스트 제외", "label_prefix": "   └─ [-] ", "value": f"{report_data.get('trash_filtered_count', 0)}개"} if report_data.get('trash_filtered_count', 0) > 0 else None,
        {"label": "최종 분석 대상 텍스트", "label_prefix": "[=] ", "value": f"{final_analysis_count}개"}
    ]
    report_bundle["sections"].append({
        "section_title": "단계 1: 원본 분석 (`data_en`)",
        "section_type": "key_value_list",
        "content": [item for item in analysis_section_content if item]
    })

    # --- 섹션 2: 데이터 병합 및 조립 결과 ---
    merge_stats = report_data.get('merge_stats', {})
    merge_section_content = [
        {"label": "조립된 최종 데이터 총계", "label_prefix": "[+] ", "value": f"{report_data.get('total_merged_items', 0)}개 항목"},
        {"label": f"최신 원본 기반 항목 ({final_analysis_count}개)", "label_prefix": " └─ ", "level": 2},
        {"label": "사용자 작업 파일에서 가져옴", "label_prefix": "    └─ [*] ", "value": f"{merge_stats.get('from_user_files', 0)}개", "level": 3} if merge_stats.get('from_user_files', 0) > 0 else None,
        {"label": "이전 Merged 파일에서 가져옴", "label_prefix": "    └─ [*] ", "value": f"{merge_stats.get('from_merged', 0)}개", "level": 3} if merge_stats.get('from_merged', 0) > 0 else None,
        {"label": "마스터 라이브러리에서 가져옴", "label_prefix": "    └─ [*] ", "value": f"{merge_stats.get('from_master', 0)}개", "level": 3} if merge_stats.get('from_master', 0) > 0 else None,
        {"label": "신규 발견 (번역 없음)", "label_prefix": "    └─ [ ] ", "value": f"{merge_stats.get('untranslated', 0)}개", "level": 3} if merge_stats.get('untranslated', 0) > 0 else None,
    ]
    report_bundle["sections"].append({
        "section_title": "단계 2: 데이터 병합 및 조립 결과",
        "section_type": "key_value_list",
        "content": [item for item in merge_section_content if item]
    })

    # --- 섹션 3: 후처리 필터링 결과 ---
    filter_stats = report_data.get('post_filter_stats', {})
    report_bundle["sections"].append({
        "section_title": "단계 3: 후처리 필터링 결과",
        "section_type": "key_value_list",
        "content": [
            {"label": "통과 (번역 대상 확정)", "label_prefix": "[+] ", "value": f"{filter_stats.get('ok', 0)}개"},
            {"label": "검토 필요 (코드로 의심)", "label_prefix": "[*] ", "value": f"{filter_stats.get('review_needed', 0)}개"},
        ]
    })

    # --- 섹션 4: 최종 출력 파일 요약 ---
    def bp(file_suffix): return os.path.basename(f"...{file_suffix}")
    output_stats = report_data.get('output_file_stats', {})
    output_section_content = []
    
    if output_stats.get('merged', -1) >= 0:
        output_section_content.append({"label": bp(MERGED_FILENAME_SUFFIX), "label_prefix": "[✔] ", "value": f"{output_stats['merged']}개 행"})
    if output_stats.get('missing', -1) > 0:
        output_section_content.append({"label": bp(MISSING_TRANSLATION_FILENAME), "label_prefix": "[+] ", "value": f"{output_stats['missing']}개 행"})
    if output_stats.get('review_needed', 0) > 0:
        output_section_content.append({"label": bp(REVIEW_NEEDED_FILENAME_SUFFIX), "label_prefix": "[*] ", "value": f"{output_stats['review_needed']}개 행"})
    if output_stats.get('integrity_mismatch', 0) > 0:
        output_section_content.append({"label": bp(STRING_INTEGRITY_REPORT_SUFFIX), "label_prefix": "[-] ", "value": f"{output_stats['integrity_mismatch']}개 행 (!!불일치 발견!!)"})

    report_bundle["sections"].append({
        "section_title": "단계 4: 최종 출력 파일 요약",
        "section_type": "key_value_list",
        "content": output_section_content
    })

    # --- [핵심 통합 로직] sync_report_bundle의 섹션과 헤더를 Export 리포트에 통합 ---
    if sync_report_bundle and sync_report_bundle.get("sections"):
        # 동기화 리포트의 헤더를 보고서 제목으로 추가
        sync_title = sync_report_bundle.get("header", {}).get("report_title", "스테이징 동기화 상태")
        report_bundle["sections"].append({"section_title": sync_title, "section_type": "key_value_list", "content": []})
        
        # 각 섹션의 content를 가져와서 합침
        for section in sync_report_bundle["sections"]:
            report_bundle["sections"][-1]["content"].extend(section.get("content", []))

    return report_bundle


def _handle_review_needed_output(review_needed_rows, review_file_path, is_test_run=False):
    """
    (CsvFileService 적용) '검토 필요' 항목들을 받아 지정된 파일에 저장합니다.
    """
    logger = LoggerService.get_logger()
    
    if not review_needed_rows:
        if os.path.exists(review_file_path):
            if not is_test_run:
                os.remove(review_file_path)
            logger.info(f" -> 검토 필요 항목이 없어 기존 '{os.path.basename(review_file_path)}' 파일을 삭제했습니다.")
        return

    for row in review_needed_rows:
        row['Translatable'] = ''

    # [수정] write_csv -> csv_file_service.write_rows_to_csv
    csv_file_service.write_rows_to_csv(
        review_file_path,
        review_needed_rows,
        headers=REVIEW_NEEDED_HEADERS,
        is_test_run=is_test_run
    )

def _classify_merged_data(all_merged_data, master_map):
    """
    [신규 내부 엔진] 병합된 데이터를 받아 후처리 필터를 적용하고,
    'ok', 'review_needed', 'missing' 그룹으로 분류하여 반환합니다.
    파일 I/O를 수행하지 않는 순수 데이터 처리 함수입니다.
    """
    logger = LoggerService.get_logger()
    logger.info("\n" + "="*30 + " [ 단계 3: 데이터 분류 및 후처리 ] " + "="*25)
    logger.info(f" ✔ 조립된 {len(all_merged_data)}개 항목에 대해 후처리 필터를 적용합니다.")

    # 1. 'ok'와 'review_needed'로 1차 분류
    ok_rows, review_needed_rows, _ = _classify_rows_by_filter(all_merged_data, master_map=master_map)
    
    # 2. 'ok' 그룹 내에서 'missing' 항목을 2차 분류
    missing_rows = [row for row in ok_rows if not row.get('text_kr', '').strip()]

    # 3. 통계 집계
    stats = {
        'ok': len(ok_rows),
        'review_needed': len(review_needed_rows)
    }
    logger.info(f"    - {stats['ok']:>5}개: [통과] 번역 대상으로 확정")
    if stats['review_needed'] > 0:
        logger.info(f"    - {stats['review_needed']:>5}개: [검토 필요] 코드로 의심되어 분리")

    return {
        "ok_rows": ok_rows,
        "review_needed_rows": review_needed_rows,
        "missing_rows": missing_rows,
        "stats": stats
    }

def _save_export_artifacts(classified_data, paths, report, is_test_run, report_only):
    """
    [신규 내부 엔진] 분류된 Export 결과물(Artifacts)을 각 목적에 맞는
    CSV 파일로 디스크에 저장하는 책임을 가집니다.
    """
    logger = LoggerService.get_logger()
    logger.info("\n" + "="*30 + " [ 단계 4: 최종 결과 파일 생성 ] " + "="*26)

    # 1. 분류된 데이터 가져오기
    ok_to_translate_rows = classified_data["ok_rows"]
    review_needed_rows = classified_data["review_needed_rows"]
    missing_data = classified_data["missing_rows"]

    # 2. 파일 경로 가져오기
    merged_file = paths.get_merged_file()
    missing_file = paths.get_missing_file()
    review_file = paths.get_review_needed_file()

    # 3. _merged_kr.csv 생성
    if not report_only:
        csv_file_service.write_rows_to_csv(merged_file, ok_to_translate_rows, headers=MASTER_FILE_HEADERS, is_test_run=is_test_run)
    report['output_file_stats']['merged'] = len(ok_to_translate_rows)

    # 4. _!!!_NEW_EMPTY_KR...csv 생성
    if missing_data:
        for row in missing_data: row['Translatable'] = ''
        csv_file_service.write_rows_to_csv(missing_file, missing_data, headers=REVIEW_NEEDED_HEADERS, is_test_run=is_test_run)
    elif os.path.exists(missing_file) and not is_test_run:
        os.remove(missing_file)
    report['output_file_stats']['missing'] = len(missing_data)
    
    # 5. _!!_TODO_review...csv 생성
    _handle_review_needed_output(review_needed_rows, review_file, is_test_run=is_test_run)
    report['output_file_stats']['review_needed'] = len(review_needed_rows)
    
    # 6. 기타 리포트 파일 생성
    FilterAuditService.save_report(paths, is_test_run)

def _load_all_export_sources(base_path):
    """
    [신규 내부 엔진] Export에 필요한 모든 데이터 소스를 로드하고 준비하는 책임을 가집니다.
    """
    paths = PathManager(base_path)
    src_folder = os.path.join(base_path, SOURCE_DATA_FOLDER)

    latest_data_map, _, _ = extract_all_text_to_map(base_path, src_folder, mod_root_path=base_path)
    
    master_map, _ = load_existing_translations([paths.get_master_file()])
    user_files_map, _ = load_existing_translations([paths.get_missing_file(), paths.get_empty_kr_file()])
    merged_ref_map, _ = load_existing_translations([paths.get_merged_file()]) if EXPORT_REFERENCE_EXISTING_MERGED_FILE else ({}, {})
    
    blacklist_keys = {key for key, (_, status) in master_map.items() if status.lower() == 'x'}
    
    return {
        "latest_data_map": latest_data_map,
        "master_map": master_map,
        "user_files_map": user_files_map,
        "merged_ref_map": merged_ref_map,
        "blacklist_keys": blacklist_keys
    }

def extract_and_merge(is_test_run=False, base_path=None, shared_state=None, report_only=False):
    """
    [v-최종 리팩토링] Export 워크플로우의 컨트롤러 역할을 수행합니다.
    모든 핵심 로직은 내부 헬퍼 엔진에 위임됩니다.
    """
    if base_path is None: 
        base_path = os.getcwd()
    logger = LoggerService.get_logger()

    if report_only:
        logger.info(f"리포트 갱신 작업을 시작합니다. (테스트 모드: {is_test_run}, 분석 전용)")
    else:
        logger.info(f"Export 작업을 시작합니다. (테스트 모드: {is_test_run})")

    FilterAuditService.clear()
    report = defaultdict(lambda: 0, { 'merge_stats': defaultdict(int), 'post_filter_stats': defaultdict(int), 'output_file_stats': defaultdict(int) })
    paths = PathManager(base_path)
    
    sources = _load_all_export_sources(base_path)
    
    merger_service = DataMergerService(sources["latest_data_map"], sources["master_map"], sources["user_files_map"], sources["merged_ref_map"], sources["blacklist_keys"])
    all_merged_data, merge_stats = merger_service.execute()
    
    report['latest_item_count'] = len(sources["latest_data_map"])
    report['total_merged_items'] = len(all_merged_data)
    report['merge_stats'] = merge_stats
    report['trash_filtered_count'] = merge_stats.get('trash_filtered_count', 0)
    
    integrity_mismatch_count = _audit_string_integrity(all_merged_data, paths, is_test_run)
    report['output_file_stats']['integrity_mismatch'] = integrity_mismatch_count

    classified_data = _classify_merged_data(all_merged_data, sources["master_map"])
    report['post_filter_stats'] = classified_data['stats']

    _save_export_artifacts(classified_data, paths, report, is_test_run, report_only)
    
    if not report_only:
        staging_service = MasterFileService(base_path, csv_file_service, target_file_path=paths.get_staging_master_file())
        merged_data = csv_file_service.load_rows_from_csv(paths.get_merged_file())

        preview_report_bundle, has_changes = staging_service.intelligent_merge(
            source_data=merged_data, is_test_run=is_test_run, target_is_staging=True, 
            preview_only=True, suppress_output=True
        )

        if has_changes:
            _render_standard_report(preview_report_bundle)
            
            auto_sync_all = shared_state is not None and shared_state.get('auto_sync_all', False)
            
            choice = 'y'
            if not auto_sync_all:
                prompt = ">> 위 계획대로 스테이징 파일을 동기화하시겠습니까? (Enter/y: 예, n: 건너뛰기, a: 이후 모두 예): "
                choice = prompt_for_input(prompt, valid_choices=['y', 'n', 'a'], allow_empty=True, default_on_empty='y')

            sync_successful = False
            if choice is UserInput.QUIT:
                print("\n프로그램을 종료합니다.")
                sys.exit()
            elif choice is UserInput.ESC or choice == 'n':
                logger.info(" -> 동기화를 건너뛰었습니다. 원하실 때 5번 메뉴를 통해 수동으로 동기화할 수 있습니다.")
            else:
                if choice == 'a' and shared_state is not None:
                    logger.info(" -> [일괄 처리 설정] 이후 모든 모드에 대해 자동으로 병합을 실행합니다.")
                    shared_state['auto_sync_all'] = True
                
                # --- [핵심 수정] ---
                # 두 번째 실행 호출 시, skip_confirmation=True를 전달하여 사용자 확인을 건너뜁니다.
                sync_successful = staging_service.intelligent_merge(
                    source_data=merged_data, is_test_run=is_test_run, 
                    target_is_staging=True, preview_only=False, suppress_output=False,
                    shared_state=shared_state, skip_confirmation=True # <--- 이 인자를 추가합니다.
                )
            
            if sync_successful:
                missing_file_path = paths.get_missing_file()
                if os.path.exists(missing_file_path):
                    if not is_test_run: os.remove(missing_file_path)
                    logger.info(f" -> 스테이징 파일 동기화가 완료되어 '{os.path.basename(missing_file_path)}' 파일을 삭제했습니다.")
                pause_for_user()
        else:
             logger.info("\n -> 스테이징 파일이 이미 최신 상태입니다. 추가 동기화가 필요 없습니다.")

    final_report_bundle = _display_export_report(report, base_path, None)
    if final_report_bundle:
        _render_standard_report(final_report_bundle)
        
    
############################################################################
#
#            [ ARCHITECTURAL DIRECTIVE - POST_FILTER_ENGINE_V1 ]
#
# TARGET: _classify_rows_by_filter()
# STATUS: STABLE
# ROLE: Post-Filter Engine
#
# BEHAVIOR:
#   이 함수는 Export 과정에서 병합된 모든 데이터를 받아, 최종적으로 '번역 대상'과
#   '검토 필요' 그룹으로 분류하는 '후처리 필터 엔진'입니다.
#
#   1. [1차 필터링] USER SETTINGS의 `{POST_FILTER_EXCLUSION_RULES}`에 정의된
#      정규식 규칙을 사용하여, 코드나 개발자 메시지로 의심되는 항목을
#      '검토 필요' 대상으로 1차 분류합니다.
#
#   2. [2차 검증 - 마스터 승인 우선] 1차에서 '검토 필요'로 분류된 항목에 대해,
#      함께 전달받은 `master_map`을 조회합니다. 만약 해당 항목이 마스터 파일에
#      이미 'Translatable: True' 상태로 존재한다면, 1차 판단을 무시하고
#      '번역 대상'으로 최종 분류합니다.
#     [단순화] 이 함수는 더 이상 줄바꿈 태그 변환을 책임지지 않습니다.
#     모든 텍스트(text_en)는 이 함수에 전달되기 전에 
#     text_processor_service.process 엔진을 통해 이미 마스터 맵의 키와
#     동일한 형식으로 정규화됩니다. 따라서 별도의 변환 없이 키를 생성하여 master_map을 조회합니다.
#
# DESIGN_CHOICE:
#   '사용자 결정 우선 원칙(User-Decision Precedence)'을 따릅니다. 시스템의
#   자동 필터링(1차)보다 사용자의 명시적인 승인(2차)을 더 높은 우선순위로
#   두어, 불필요한 반복 검토 작업을 방지하고 사용자 경험을 향상시킵니다.
#
# MODIFICATION_PROTOCOL:
#   - 필터링 규칙 자체를 수정하려면 USER SETTINGS의
#     `{POST_FILTER_EXCLUSION_RULES}`를 수정해야 합니다.
#   - 마스터 파일 외에 다른 소스(예: 스테이징 파일)의 승인 상태도 반영하려면,
#     이 함수의 시그니처를 변경하여 해당 데이터를 추가로 전달받아야 합니다.
#
############################################################################
def _classify_rows_by_filter(all_merged_rows, master_map=None):
    """
    [v2.2 - 마스터 승인 우선] 병합된 데이터를 '유지', '검토 필요' 그룹으로 분류합니다.
    [마에스트로 수정] 마스터 조회 키 생성 시 줄바꿈 형식 불일치 문제를 해결합니다.
    """
    logger = LoggerService.get_logger()
    logger.info(" -> 병합된 데이터에 대해 후처리 필터링 및 클리닝을 시작합니다...")

    kept_rows, review_needed_rows, removed_rows = [], [], []

    compiled_rules = {}
    for rule_type, patterns in POST_FILTER_EXCLUSION_RULES.items():
        compiled_rules[rule_type] = [re.compile(p, re.IGNORECASE | re.DOTALL) for p in patterns]

    for row in all_merged_rows:
        # [핵심 수정] row의 text_en은 이미 중앙 엔진을 통해 정규화된 상태입니다.
        text_en_processed = row.get('text_en', '') # .strip() 제거, 이미 처리됨
        item_type = row.get('type', '').lower().split(':')[0]
        
        is_review_needed = False
        rules_for_type = compiled_rules.get(item_type)

        if rules_for_type:
            # [핵심 수정] processed_text를 기준으로 검사
            for segment in text_en_processed.split(SCRIPT_TEXT_DELIMITER):
                segment_to_check = segment.strip()
                if not segment_to_check: continue
                
                for pattern in rules_for_type:
                    if pattern.search(segment_to_check):
                        is_review_needed = True
                        break
                if is_review_needed: break
        
        if is_review_needed and master_map:
            # [★★★★★ 핵심 수정 ★★★★★]
            # 더 이상 '|n|' 변환이 필요 없습니다. text_en_processed가 이미 마스터 맵의 키 형식과 일치합니다.
            key = (
                row.get('source_file', ''),
                row.get('id', ''),
                row.get('type', ''),
                text_en_processed # 이미 정규화된 키를 그대로 사용
            )
            master_status_tuple = master_map.get(key)
            if master_status_tuple:
                translatable_status = master_status_tuple[1]
                if translatable_status.lower() == 'true':
                    is_review_needed = False
                    logger.debug(f"  - [필터 무시] 마스터 승인 항목: '{text_en_processed[:50]}...'")

        if is_review_needed:
            review_needed_rows.append(row)
        else:
            kept_rows.append(row)

    final_kept, final_review_needed = [], []
    for r_list, f_list in [(kept_rows, final_kept), (review_needed_rows, final_review_needed)]:
        for r in r_list:
            r_copy = r.copy()
            if 'original_translatable_status' in r_copy:
                del r_copy['original_translatable_status']
            f_list.append(r_copy)

    if final_review_needed:
        logger.info(f" -> 총 {len(final_review_needed)}개의 항목이 '검토 필요'로 분류되었습니다.")
        
    return final_kept, final_review_needed, []


    
class DataMergerService:
    """
    [신규 서비스] Export의 핵심 병합 로직을 전담하는 서비스 클래스.
    순수 스냅샷 원칙에 따라, 오직 현재 data_en에 존재하는 항목만 처리합니다.
    """
    def __init__(self, latest_data_map, master_map, user_files_map, merged_ref_map, blacklist_keys):
        self.latest_data = latest_data_map
        self.master_map = master_map
        self.user_files_map = user_files_map
        self.merged_ref_map = merged_ref_map
        self.blacklist = blacklist_keys
        self.logger = LoggerService.get_logger()

    def execute(self):
        """
        주어진 데이터 소스들을 병합하여 최종 데이터 리스트와 통계를 반환합니다.
        (기존 _merge_and_collect_stats 함수의 로직을 그대로 수행)
        """
        self.logger.info("\n" + "="*30 + " [ 단계 2: 데이터 병합 및 조립 ] " + "="*33)
        self.logger.info(" -> 최신 원본(data_en)과 기존 번역 자산을 병합합니다...")

        all_merged_data = []
        stats = defaultdict(int)

        total_latest = len(self.latest_data)
        self.logger.info(f" ✔ 총 {total_latest}개의 최신 원본 항목을 처리합니다.")

        for (src, item_id, item_type), text_en_raw in self.latest_data.items():
            key_4_tuple = (src, item_id, item_type, text_processor_service.process(text_en_raw, item_type=item_type))
            
            if key_4_tuple in self.blacklist:
                stats['trash_filtered_count'] += 1
                continue

            text_kr, status, source_found = self._find_translation(key_4_tuple)
            stats[source_found] += 1

            self.logger.debug(f"  - 병합: {item_id[:30]:<30} (번역 소스: {source_found})")

            all_merged_data.append({
                'source_file': src, 'id': item_id, 'type': item_type,
                'text_en': text_en_raw,
                'text_kr': text_kr,
                'Translatable': status
            })

        if stats['trash_filtered_count'] > 0:
            self.logger.info(f"   └─ 이 중 {stats['trash_filtered_count']}개는 트래시/블랙리스트 규칙에 따라 제외되었습니다.")
        
        final_analysis_count = total_latest - stats['trash_filtered_count']
        self.logger.info(f" → 최종 분석 대상 텍스트: {final_analysis_count}개")

        stats['orphan_count'] = 0
        self.logger.info(" -> (설계 변경) 고아 데이터는 더 이상 _merged_kr.csv에 포함되지 않습니다. 마스터 파일에서 관리됩니다.")
                
        return all_merged_data, stats

    def _find_translation(self, key_4_tuple):
        """병합 우선순위에 따라 번역을 찾고, 출처를 반환하는 내부 헬퍼."""
        if key_4_tuple in self.user_files_map and self.user_files_map[key_4_tuple][0].strip():
            text_kr, status = self.user_files_map[key_4_tuple]
            return text_kr, status, "from_user_files"
        elif key_4_tuple in self.merged_ref_map and self.merged_ref_map[key_4_tuple][0].strip():
            text_kr, status = self.merged_ref_map[key_4_tuple]
            return text_kr, status, "from_merged"
        elif key_4_tuple in self.master_map and self.master_map[key_4_tuple][0].strip():
            text_kr, status = self.master_map[key_4_tuple]
            return text_kr, status, "from_master"
        else:
            # 번역이 없더라도 마스터에 키가 존재하면 status는 가져올 수 있음
            _, status = self.master_map.get(key_4_tuple, ('', ''))
            return '', status, "untranslated"


def extract_all_text_to_map(base_path, src_folder, target_files=None, mod_root_path=None, force_process_files=None):
    """
    [v7.0 - 객체 지향 리팩토링] ExtractorService를 인스턴스화하고 실행하는 래퍼 함수.
    """
    # mod_root_path는 base_path와 동일한 목적으로 사용되므로 base_path로 통일
    service = ExtractorService(base_path, src_folder, target_files, force_process_files)
    return service.execute()

class ExtractorService:
    """
    [신규 서비스] Export의 모든 로직을 관장하는 중앙 서비스.
    ExecutionContext를 사용하여 각 파일에 대한 처리 전략(Parser)을 결정하고 실행합니다.
    """
    def __init__(self, base_path, src_folder, target_files=None, force_process_files=None):
        self.base_path = base_path
        self.src_folder = src_folder
        self.target_files = target_files
        self.force_process_files = force_process_files or set()
        self.logger = LoggerService.get_logger()
        self.json_whitelist = PROCESSING_RULES.get('INCLUDE_ONLY_JSON_FILES', set())

    def execute(self):
        """전체 텍스트 추출 워크플로우를 실행하고 결과를 반환합니다."""
        self.logger.info(f"'{os.path.basename(self.src_folder)}'에서 최신 텍스트를 추출합니다...")
        
        extracted_data = {}
        context = ExecutionContext(self.base_path)

        for dirpath, _, filenames in os.walk(self.src_folder):
            for filename in filenames:
                full_path = os.path.join(dirpath, filename)
                relative_path = os.path.relpath(full_path, self.src_folder).replace('\\', '/')

                if self.target_files and relative_path not in self.target_files:
                    continue
                if relative_path not in self.force_process_files and is_file_excluded(relative_path, for_export=True):
                    continue
                if filename.lower().endswith(JSON_FILE_EXTENSIONS) and not _is_file_in_whitelist(relative_path, self.json_whitelist):
                    self.logger.debug(f"  [DEBUG-FILTER] '{relative_path}'는 JSON 화이트리스트에 없어 파싱 건너뜀.")
                    continue

                # 각 파일에 대한 컨텍스트 업데이트
                context.current_source_path = full_path
                context.current_relative_path = relative_path
                context.current_rules = get_rules_for_file(relative_path, self.base_path)

                # 전략 라우팅 및 실행
                strategy = self._route_file_to_strategy(context)
                if strategy:
                    self.logger.debug(f"  -> 라우팅 (Strategy): '{type(strategy).__name__}' 사용 ({relative_path})")
                    extracted_items = strategy.execute(context)
                    if extracted_items:
                        for item in extracted_items:
                            if item.get('text_en'):
                                key = (item['source_file'], item['id'], item['type'])
                                extracted_data[key] = item['text_en']
                else:
                    self.logger.warning(f"  [WARN] '{relative_path}'에 대한 유효한 파서 전략을 찾을 수 없어 추출을 건너뜀.")

        self.logger.info(f" -> 총 {len(extracted_data)}개의 유효한 최신 텍스트 항목을 추출했습니다.")
        return extracted_data, [], []

    def _route_file_to_strategy(self, context: ExecutionContext) -> IProcessingStrategy:
        """주어진 컨텍스트를 기반으로 적절한 파서 전략 객체를 반환합니다."""
        rules = context.current_rules
        filename = os.path.basename(context.current_relative_path)
        
        parser_name = rules.get('parser') if rules else None
        
        if parser_name:
            return strategy_factory.get_strategy(parser_name)

        # 규칙이 없을 경우, 확장자를 기준으로 기본 파서 결정
        if filename.lower().endswith(CSV_FILE_EXTENSIONS):
            return strategy_factory.get_strategy('process_general_csv')
        elif filename.lower().endswith(JSON_FILE_EXTENSIONS):
            return strategy_factory.get_strategy('process_json_file') # 기본은 재귀 파서
        elif filename.lower().endswith(SKILL_FILE_EXTENSIONS):
            # .skill 파일은 규칙이 필수적이므로, 규칙이 없다면 처리할 수 없음
            return None
        
        return None

def _post_filter_extracted_data(extracted_data):
    """[엔진] 추출된 데이터에 대해 후처리 필터 규칙을 적용하여,
    각 항목에 'status' 플래그를 추가한 리스트를 반환합니다."""
    logger = LoggerService.get_logger()
    logger.info(" -> 추출된 데이터에 대해 후처리 필터링을 시작합니다...")
    
    flagged_data_list = []
    review_count = 0

    # 입력이 딕셔너리이므로, 먼저 리스트 형태로 변환
    # Key: (src, id, type), Value: text_en
    for (src, item_id, item_type), text_en in extracted_data.items():
        row = {'source_file': src, 'id': item_id, 'type': item_type, 'text_en': text_en}
        status = 'ok' # 기본 상태는 'ok'

        # type에 맞는 필터 규칙 가져오기
        rules_for_type = POST_FILTER_EXCLUSION_RULES.get(item_type.lower().split(':')[0])

        if rules_for_type:
            # text_en이 여러 줄(delimiter |||)로 구성된 경우, 각 줄을 검사
            for segment in text_en.split(SCRIPT_TEXT_DELIMITER):
                segment_to_check = segment.strip()
                if not segment_to_check:
                    continue
                
                for pattern in rules_for_type:
                    # [핵심] 정규식 매치 확인 (대소문자 무시)
                    if re.search(pattern, segment_to_check, re.IGNORECASE):
                        status = 'review_needed'
                        review_count += 1
                        logger.debug(f"  - [검토 필요] '{text_en[:50]}...' (패턴: '{pattern}')")
                        break # 이 segment에 대한 패턴 검사 중단
                if status == 'review_needed':
                    break # 이 text_en에 대한 segment 검사 중단
        
        row['status'] = status
        flagged_data_list.append(row)

    if review_count > 0:
        logger.info(f" -> 총 {review_count}개의 항목이 '검토 필요'로 분류되었습니다.")
        
    return flagged_data_list



# 로드된 text_en과 text_kr에 text_processor_service.process을 적용하여 일관성을 확보합니다 (4.22.0 버전).
def load_merged_data(merged_file_path):
    """
    (v4.26.32 수정됨) CSV 파일을 읽어 4요소 키와 (cleaned_text_en, cleaned_text_kr) 튜플을 반환합니다.
    Translatable 컬럼의 존재 여부를 유연하게 처리합니다.
    """
    logger = LoggerService.get_logger()
    logger.info(f"'{os.path.basename(merged_file_path)}'에서 데이터 로드를 시작합니다...")
    
    all_rows = csv_file_service.load_rows_from_csv(merged_file_path)
    data_map = {}

    if not all_rows:
        logger.info(f" -> 총 0개의 항목을 로드했습니다. (파일 비어있음 또는 없음)")
        return data_map
    
    required_headers = ['source_file', 'id', 'type', 'text_en', 'text_kr']
    if not all(h in all_rows[0].keys() for h in required_headers):
        logger.warning(f"    '{os.path.basename(merged_file_path)}'에 필수 열({', '.join(required_headers)}) 중 하나 이상이 없어 데이터 로드를 건너뜀.")
        return data_map

    for row in all_rows:
        source = row.get('source_file', '')
        row_id = row.get('id', '')
        row_type = row.get('type', '')
        text_en_cleaned = text_processor_service.process(row.get('text_en', ''))
        
        if not (source and row_id and row_type and text_en_cleaned):
            logger.debug(f"     [경고] 불완전한 필수 키로 인해 항목 건너뜀: source='{source}', id='{row_id}', type='{row_type}'")
            continue

        key = (source, row_id, row_type, text_en_cleaned)
        value = (text_en_cleaned, text_processor_service.process(row.get('text_kr', '')))
        
        data_map[key] = value

    logger.info(f" -> 총 {len(data_map)}개의 항목을 성공적으로 로드했습니다.")
    return data_map


# [ Sync 전용 데이터 로딩 함수 - load_merged_data_for_sync]
def load_merged_data_for_sync(merged_file_path):
    """
    (v4.26.32 수정됨) CSV 파일을 읽어 4요소 키와 text_kr 값 문자열을 반환합니다.
    Translatable 컬럼의 존재 여부를 유연하게 처리합니다.
    """
    logger = LoggerService.get_logger()
    logger.info(f"'{os.path.basename(merged_file_path)}'에서 Sync용 데이터 로드를 시작합니다...")

    all_rows = csv_file_service.load_rows_from_csv(merged_file_path)
    data_map = {}

    if not all_rows:
        logger.info(f" -> 총 0개의 Sync용 항목을 로드했습니다. (파일 비어있음 또는 없음)")
        return data_map

    required_headers = ['source_file', 'id', 'type', 'text_en', 'text_kr']
    if not all(h in all_rows[0].keys() for h in required_headers):
        logger.warning(f"    '{os.path.basename(merged_file_path)}'에 필수 열({', '.join(required_headers)}) 중 하나 이상이 없어 데이터 로드를 건너뜀.")
        return data_map

    for row in all_rows:
        source = row.get('source_file', '')
        row_id = row.get('id', '')
        row_type = row.get('type', '')
        text_en_cleaned = text_processor_service.process(row.get('text_en', ''))
        
        if not (source and row_id and row_type and text_en_cleaned):
            logger.debug(f"     [경고] 불완전한 필수 키로 인해 항목 건너뜀: source='{source}', id='{row_id}', type='{row_type}'")
            continue

        key = (source, row_id, row_type, text_en_cleaned)
        value = text_processor_service.process(row.get('text_kr', ''))

        data_map[key] = value
            
    logger.info(f" -> 총 {len(data_map)}개의 Sync용 항목을 성공적으로 로드했습니다.")
    return data_map


# 로드된 text_en과 text_kr에 text_processor_service.process을 적용하여 일관성을 확보합니다 (4.22.0 버전).
def load_data_for_check(file_path):
    """
    (v4.26.32 수정됨) CSV 파일을 읽어 4요소 키와 text_kr 값 문자열을 반환합니다.
    Translatable 컬럼의 존재 여부를 유연하게 처리합니다.
    """
    logger = LoggerService.get_logger()
    logger.info(f"'{os.path.basename(file_path)}'에서 검사용 데이터 로드를 시작합니다...")

    all_rows = csv_file_service.load_rows_from_csv(file_path)
    data_map = {}

    if not all_rows:
        logger.info(f" -> 총 0개의 검사용 항목을 로드했습니다. (파일 비어있음 또는 없음)")
        return data_map

    required_headers = ['source_file', 'id', 'type', 'text_en', 'text_kr']
    if not all(h in all_rows[0].keys() for h in required_headers):
        logger.warning(f"    '{os.path.basename(file_path)}'에 필수 열({', '.join(required_headers)}) 중 하나 이상이 없어 데이터 로드를 건너뜀.")
        return data_map

    for row in all_rows:
        source = row.get('source_file', '')
        row_id = row.get('id', '')
        row_type = row.get('type', '')
        text_en_for_key = text_processor_service.process(row.get('text_en', ''), item_type=row_type)
        
        if not (source and row_id and row_type and text_en_for_key):
            logger.debug(f"     [경고] 불완전한 필수 키로 인해 항목 건너뜀: source='{source}', id='{row_id}', type='{row_type}'")
            continue

        key = (source, row_id, row_type, text_en_for_key)
        value = text_processor_service.process(row.get('text_kr', ''))

        data_map[key] = value

    logger.info(f" -> 총 {len(data_map)}개의 검사용 항목을 성공적으로 로드했습니다.")
    return data_map



def process_generic_file(file_path, input_folder_path, rules):
    """(업그레이드) 설정의 'mode'에 따라 단순 Key-Value 또는 정규식 패턴으로 텍스트를 추출하는 범용 파서."""
    logger = LoggerService.get_logger()
    extracted = []
    relative_path = os.path.relpath(file_path, input_folder_path).replace('\\', '/')
    
    mode = rules.get('mode')
    
    # 공통 설정 읽기
    id_source = rules.get('id_source', 'auto_index')
    id_prefix = rules.get('id_prefix', os.path.splitext(os.path.basename(relative_path))[0])
    item_type = rules.get('type', 'generic')

    try:
        with open(file_path, 'r', encoding=INPUT_FILE_ENCODING) as f:
            content, _ = read_file_with_fallback(file_path)

        matches = []
        # [핵심] mode에 따라 패턴 생성 또는 직접 사용
        if mode == 'simple_kv':
            key_name = rules.get('key_name')
            if not key_name:
                logger.error(f"'{relative_path}'의 'simple_kv' 모드에 'key_name'이 정의되지 않았습니다.")
                return []
            # 단순 모드를 위한 정규식을 동적으로 생성
            pattern = f'"{key_name}"\\s*:\\s*"((?:\\"|[^"])*)"'
            matches = re.findall(pattern, content, re.DOTALL)
        
        elif mode == 'generic_regex':
            pattern = rules.get('regex_pattern')
            if not pattern:
                logger.error(f"'{relative_path}'의 'generic_regex' 모드에 'regex_pattern'이 정의되지 않았습니다.")
                return []
            matches = re.findall(pattern, content, re.DOTALL)
        
        else:
            logger.error(f"'{relative_path}'에 알 수 없는 mode '{mode}'가 지정되었습니다.")
            return []

        for i, match_text in enumerate(matches):
            text_to_translate = match_text if isinstance(match_text, str) else match_text[0]
            
            item_id = ""
            if id_source == 'auto_index':
                item_id = f"{id_prefix}[{i}]"

            is_valid, reason = analyze_text_validity(text_to_translate)
            if is_valid:
                if item_id:
                    extracted.append({
                        'source_file': relative_path,
                        'id': item_id,
                        'type': item_type,
                        'text_en': standardize_newlines(text_to_translate.strip())
                    })
            else:
                # [감사] 필터링된 항목을 기록합니다.
                if item_id: # ID가 있어야 기록 가능
                    FilterAuditService.record(
                        source_file=relative_path,
                        item_id=item_id,
                        item_type=item_type,
                        text_en=text_to_translate,
                        reason=reason
                    )
        
        logger.debug(f"     ... 범용 파서({mode})가 {len(extracted)}개의 항목을 성공적으로 추출했습니다.")

    except Exception as e:
        logger.error(f"범용 파서 '{relative_path}' 처리 중 오류: {e}")
        
    return extracted


# ┏────────────────────────────────────────────────────────────────┐
#
#                    [ Apply 기능 블록 ]
#
# ┗────────────────────────────────────────────────────────────────┘
def _handle_options_column(self, column_text, context, base_id):
        """
        [내부 엔진] 'options' 컬럼에 대한 번역을 서식을 보존하며 적용합니다.
        기존 handle_options_column_apply 함수의 로직을 통합했습니다.
        """
        logger = context.logger
        
        # 1. '조회 키' 생성을 위한 로직
        translatable_originals = _extract_options_snippets(
            column_text, 
            source_file=context.current_relative_path, 
            item_id=base_id
        )

        if not translatable_originals:
            return column_text, set()

        unified_en_text = SCRIPT_TEXT_DELIMITER.join(translatable_originals)
        type_info = f"options:{len(translatable_originals)}"
        apply_key = (context.current_relative_path, base_id, type_info, unified_en_text)
        
        translated_unified_text = context.translation_map.get(apply_key)
        if translated_unified_text is None and context.translation_map_insensitive:
            fallback_key = (context.current_relative_path, base_id.lower(), type_info.lower(), unified_en_text)
            translated_unified_text = context.translation_map_insensitive.get(fallback_key)

        if not translated_unified_text:
            logger.debug(f"      => No translation found for key: {apply_key}")
            return column_text, set()

        logger.debug(f"      => Found KR: '{translated_unified_text[:60].replace(chr(10), ' ')}...'")
        
        translated_snippets = translated_unified_text.split(SCRIPT_TEXT_DELIMITER)
        if len(translatable_originals) != len(translated_snippets):
            logger.warning(f"      [경고] ID '{base_id}'의 options 번역 조각 개수 불일치! 원본: {len(translatable_originals)}, 번역: {len(translated_snippets)}. 적용을 건너뜁니다.")
            return column_text, set()

        # 2. '위치 정보' 획득을 위한 파싱
        key_value_pattern = re.compile(
            r'(?P<key>[a-zA-Z0-9_]+)\s*:\s*(?P<value>.+?)(?=\s*[a-zA-Z0-9_]+:\s*|$)',
            re.DOTALL
        )
        matches = list(re.finditer(key_value_pattern, column_text))
        
        targets_to_replace = []
        original_idx = 0
        for match in matches:
            raw_value = match.group('value')
            # _extract_options_snippets는 이제 전역 함수가 아니므로 직접 호출
            cleaned_value = _clean_and_strip_quotes(raw_value)
            
            if original_idx < len(translatable_originals) and cleaned_value == translatable_originals[original_idx]:
                targets_to_replace.append({
                    'match_obj': match,
                    'translated_text': translated_snippets[original_idx]
                })
                original_idx += 1

        # 3. 형태 모방 및 역순 치환 로직
        modified_column_text = column_text
        for target in reversed(targets_to_replace):
            match = target['match_obj']
            translated_text = target['translated_text']
            
            start, end = match.span('value')
            original_value_str = match.group('value').strip()

            replacement = translated_text
            
            if original_value_str.startswith('"') and not replacement.startswith('"'):
                replacement = '"' + replacement
            
            if original_value_str.endswith('"') and not replacement.endswith('"'):
                replacement = replacement + '"'
                
            original_raw_value = match.group('value')
            leading_whitespace = original_raw_value[:len(original_raw_value) - len(original_raw_value.lstrip())]
            trailing_whitespace = original_raw_value[len(original_raw_value.rstrip()):]
            final_replacement = leading_whitespace + replacement + trailing_whitespace
                
            modified_column_text = modified_column_text[:start] + final_replacement + modified_column_text[end:]
        
        return modified_column_text, {apply_key}

# ############################################################################
#
#        [ ARCHITECTURAL DIRECTIVE - TEXT_REPLACEMENT_ENGINE_V1 ]
#
# TARGET: _apply_text_replacement_engine()
# STATUS: FINALIZED & FROZEN
#
# REASON: 
#   이 헬퍼 함수는 원본 텍스트 파일의 스타일(들여쓰기, 공백 등)을 100%
#   보존하면서 번역을 적용하는 안정화된 핵심 로직을 캡슐화합니다.
#   로직의 핵심은 다음과 같습니다:
#   1. re.finditer()를 사용해 교체할 텍스트의 정확한 위치를 찾습니다.
#   2. '역순 치환(reverse replacement)'을 통해 문자열 길이 변경으로 인한
#      후속 매치의 인덱스 오류를 원천적으로 방지합니다.
#   3. json.dumps(text, ensure_ascii=False)를 사용하여 한글을 유지하면서
#      안전하게 이스케이프된 치환 문자열을 생성합니다.
#
# MODIFICATION_PROTOCOL: 
#   이 함수의 로직은 매우 안정적이고 다양한 케이스에 대해 검증되었습니다.
#   향후 이 함수의 수정이 필요할 경우, 반드시 "DIRECTIVE-ID:
#   TEXT_REPLACEMENT_ENGINE_V1에 대한 수정 요청"이라는 명시적인 요청과
#   함께 변경 사유를 상세히 기술해야 합니다. 이 프로토콜 없이는 AI가
#   임의로 수정하지 않습니다.
#
# ############################################################################
def _apply_text_replacement_engine(source_path, dest_path, rules, id_prefix, tips_map_by_id, is_test_run, mod_root_path, relative_path):
    """[동결] 원본 텍스트를 직접 수정하여 번역을 적용하는 핵심 엔진."""
    logger = LoggerService.get_logger()
    try:
        file_content_tuple = read_file_with_fallback(source_path)
        if file_content_tuple is None or file_content_tuple[0] is None:
            return 0
        
        content, _, _ = file_content_tuple

        pattern = rules.get('regex_pattern')
        if not pattern:
            logger.error(f"'{relative_path}'에 'regex_pattern' 규칙이 없어 적용을 건너뜁니다.")
            if not is_test_run: shutil.copy2(source_path, dest_path)
            return 0

        matches = list(re.finditer(pattern, content))
        applied_count = 0
        
        for i in range(len(matches) - 1, -1, -1):
            match = matches[i]
            original_text = match.group(1)
            item_id = f"{id_prefix}[{i}]"

            if item_id in tips_map_by_id:
                stored_en, translated_text = tips_map_by_id[item_id]
                if stored_en == text_processor_service.process(original_text):
                    escaped_kr_with_quotes = json.dumps(translated_text, ensure_ascii=False)
                    escaped_kr_content = escaped_kr_with_quotes[1:-1]
                    content = content[:match.start(1)] + escaped_kr_content + content[match.end(1):]
                    applied_count += 1
                    tips_scoped_logger.log(f"  [APPLY-ENGINE] ID '{item_id}' 성공적으로 치환.", base_path=mod_root_path)
                else:
                    tips_scoped_logger.log(f"  [APPLY-ENGINE] 경고: ID '{item_id}'는 일치하지만 text_en 불일치. 건너뜀.", base_path=mod_root_path)
            else:
                tips_scoped_logger.log(f"  [APPLY-ENGINE] ID '{item_id}'에 대한 번역 없음. 건너뜀.", base_path=mod_root_path)
        
        if applied_count > 0:
            with open(dest_path, 'w', encoding=OUTPUT_FILE_ENCODING) as f:
                f.write(content)
        
        return applied_count

    except Exception as e:
        logger.error(f"  '_apply_text_replacement_engine' 처리 중 오류: {e}. 원본 복사를 시도합니다.", exc_info=True)
        copy_with_recode(source_path, dest_path, is_test_run)
        return -1 # 오류 발생을 알림

# ############################################################################
#
#        [ ARCHITECTURAL DIRECTIVE - ID_PREFIX_RESOLVER_V1 ]
#
# TARGET: _resolve_dynamic_id_prefix()
# STATUS: FINALIZED & FROZEN
#
# REASON: 
#   이 헬퍼 함수는 Export(process_tips_json)와 Apply(apply_tips_json) 양쪽에서
#   공통으로 사용되는, id_prefix의 '{MOD_NAME_PLACEHOLDER}'를 실제 모드 이름으로
#   치환하는 안정화된 로직을 캡슐화합니다.
#   이 로직의 중앙 관리는 ID 불일치 버그를 방지하는 데 매우 중요합니다.
#
# MODIFICATION_PROTOCOL: 
#   이 함수의 수정은 Export와 Apply 양쪽에 영향을 미치므로 신중해야 합니다.
#   수정이 필요할 경우, 반드시 "DIRECTIVE-ID: ID_PREFIX_RESOLVER_V1에 대한
#   수정 요청"이라는 명시적인 요청과 함께 변경 사유를 상세히 기술해야 합니다.
#
# ############################################################################
class IdPrefixResolver:
    """
    [신규 클래스] ID 접두사 결정을 중앙에서 책임지는 클래스.
    규칙의 우선순위를 내부적으로 관리하여 호출부의 복잡성을 줄입니다.
    """
    def __init__(self, mod_root_path, file_path=None):
        self.mod_root_path = mod_root_path
        self.file_path = file_path
        self.logger = LoggerService.get_logger()

    def resolve(self, rules, structure_pattern=None):
        """
        주어진 규칙 소스를 기반으로 최종 id_prefix를 계산하여 반환합니다.
        우선순위: structure_pattern -> rules -> 기본값
        """
        id_prefix = 'item' # 기본값
        if structure_pattern and 'id_prefix' in structure_pattern:
            id_prefix = structure_pattern['id_prefix']
        elif rules and 'id_prefix' in rules:
            id_prefix = rules['id_prefix']

        # {MOD_NAME_PLACEHOLDER} 치환
        if '{MOD_NAME_PLACEHOLDER}' in id_prefix and self.mod_root_path:
            actual_mod_folder_name = os.path.basename(self.mod_root_path)
            mod_id_part = actual_mod_folder_name
            if MOD_USE_PREFIX_FILTER and actual_mod_folder_name.startswith(MOD_FOLDER_PREFIX):
                mod_id_part = actual_mod_folder_name[len(MOD_FOLDER_PREFIX):]
            id_prefix = id_prefix.replace('{MOD_NAME_PLACEHOLDER}', mod_id_part)
            self.logger.debug(f"  -> 동적 id_prefix (모드): '{id_prefix}'")

        # {FILENAME_PLACEHOLDER} 치환
        if '{FILENAME_PLACEHOLDER}' in id_prefix and self.file_path:
            filename_no_ext = os.path.splitext(os.path.basename(self.file_path))[0]
            id_prefix = id_prefix.replace('{FILENAME_PLACEHOLDER}', filename_no_ext)
            self.logger.debug(f"  -> 동적 id_prefix (파일): '{id_prefix}'")
        
        return id_prefix


def apply_translation_recursive(obj, path, translation_map, relative_path, translation_map_insensitive=None):
    """
    (v-latest + Key Parity Analyzer v1.1) 로거 객체를 명시적으로 가져와 사용하여
    모든 디버그 로그가 log_apply.txt 파일에 기록되도록 보장합니다.
    """
    # [★★★★★ 핵심 수정 ★★★★★]
    # LoggerService를 통해 현재 활성화된 로거를 명시적으로 가져옵니다.
    logger = LoggerService.get_logger()

    if isinstance(obj, str):
        # 1. Apply 시점에서 조회할 키(apply_key)를 생성합니다.
        cleaned_en_text_apply = text_processor_service.process(obj, item_type='json')
        apply_key = (relative_path, path, 'json', cleaned_en_text_apply)
        
        translated_value = translation_map.get(apply_key)
        
        if translated_value is None and translation_map_insensitive:
            fallback_key = (relative_path, path.lower(), 'json', cleaned_en_text_apply)
            translated_value = translation_map_insensitive.get(fallback_key)
            if translated_value:
                logger.debug(f"    -> [폴백 성공] ID 대소문자 불일치: '{path}'")
        
        if translated_value is not None:
            logger.debug(f"    - [Path: {path}] 번역 발견.")
            match = re.match(r'^(\s*)(.*?)(\s*)$', obj, re.DOTALL)
            if match:
                leading_ws, _, trailing_ws = match.groups()
                final_value = f"{leading_ws}{translated_value}{trailing_ws}"
            else:
                final_value = translated_value
            return final_value, 1, {apply_key}
        else:
            # [키 정밀 분석기 실행]
            if "strings.json" in relative_path:
                found_master_key = None
                for master_key in translation_map.keys():
                    if master_key[0] == relative_path and master_key[1] == path and master_key[2] == 'json':
                        found_master_key = master_key
                        break
                
                if found_master_key:
                    cleaned_en_text_master = found_master_key[3]
                    if cleaned_en_text_apply != cleaned_en_text_master:
                        logger.debug("="*20 + f" [ DEBUG: Key Parity Mismatch - ID: {path} ] " + "="*20)
                        logger.debug(f"  - Apply가 생성한 text_en: '{cleaned_en_text_apply}' (길이: {len(cleaned_en_text_apply)})")
                        logger.debug(f"  - Master에 저장된 text_en: '{cleaned_en_text_master}' (길이: {len(cleaned_en_text_master)})")
                        
                        max_len = max(len(cleaned_en_text_apply), len(cleaned_en_text_master))
                        for i in range(max_len):
                            char_apply = cleaned_en_text_apply[i] if i < len(cleaned_en_text_apply) else '""'
                            char_master = cleaned_en_text_master[i] if i < len(cleaned_en_text_master) else '""'
                            if char_apply != char_master:
                                # [수정] ord() 호출 시 문자가 비어있을 경우에 대한 예외 처리 추가
                                ord_apply = ord(char_apply) if char_apply != '""' else 'N/A'
                                ord_master = ord(char_master) if char_master != '""' else 'N/A'
                                logger.debug(f"  -> [불일치!] 위치 {i}: (Apply: {repr(char_apply)}, ASCII: {ord_apply}) vs (Master: {repr(char_master)}, ASCII: {ord_master})")
                                break
                        logger.debug("="*80)

            return obj, 0, set()
        
    # 재귀 케이스 1: 객체가 딕셔너리일 경우
    if isinstance(obj, dict):
        total_applied_in_children = 0
        total_applied_keys = set()
        new_dict = {}
        for key, value in obj.items():
            new_path = f"{path}.{key}" if path else key
            # [핵심 수정 2] 재귀 호출 시 보조 맵을 그대로 전달
            modified_value, applied_count, applied_keys = apply_translation_recursive(value, new_path, translation_map, relative_path, translation_map_insensitive)
            new_dict[key] = modified_value
            total_applied_in_children += applied_count
            total_applied_keys.update(applied_keys)
        return new_dict, total_applied_in_children, total_applied_keys
        
    # 재귀 케이스 2: 객체가 리스트일 경우
    if isinstance(obj, list):
        total_applied_in_children = 0
        total_applied_keys = set()
        new_list = []
        for i, item in enumerate(obj):
            new_path = f"{path}[{i}]"
            # [핵심 수정 2] 재귀 호출 시 보조 맵을 그대로 전달
            modified_item, applied_count, applied_keys = apply_translation_recursive(item, new_path, translation_map, relative_path, translation_map_insensitive)
            new_list.append(modified_item)
            total_applied_in_children += applied_count
            total_applied_keys.update(applied_keys)
        return new_list, total_applied_in_children, total_applied_keys
        
    return obj, 0, set()


def _render_key_value_section(content, translations=None):
    """
    [리포트 렌더러 v3] key_value_list 타입의 섹션 내용을 출력합니다.
    [최종 수정] 번역 사전을 인자로 받아 번역을 수행합니다.
    """
    logger = LoggerService.get_logger()
    if not content:
        return
        
    translations = translations or {} # None일 경우 빈 딕셔너리로 초기화
    
    processed_content = []
    for item in content:
        item_copy = item.copy()
        final_label = ""
        if item_copy.get("translate_label"):
            label_key = item_copy.get("label_key", "")
            final_label = translations.get(label_key, label_key)
        else:
            final_label = item_copy.get("label", "")
        
        final_label = item_copy.get("label_prefix", "") + final_label
        item_copy["final_label"] = final_label
        processed_content.append(item_copy)

    max_label_len = 0
    if processed_content:
        max_label_len = max(len(item.get("final_label", "")) for item in processed_content)

    for item in processed_content:
        label = item.get("final_label", "")
        value = item.get("value", "")
        indent = "  " * (item.get("level", 1) - 1)
        
        if value:
            logger.info(f"{indent}{label:<{max_label_len - len(indent)}} : {value}")
        else:
            logger.info(f"{indent}{label}")

def _render_standard_report(report_bundle, translations=None):
    """
    [범용 리포트 렌더러 v4] report_bundle과 번역 사전을 입력받아 표준 UI로 출력합니다.
    """
    logger = LoggerService.get_logger()
    header = report_bundle.get("header", {})

    # --- 헤더 출력 ---
    logger.info("\n" + "="*70)
    title_text = header.get("report_title", '종합 리포트')
    try:
        # 한글/영문 길이를 고려하여 중앙 정렬 (EUC-KR 기준 근사치)
        title_len_for_calc = len(title_text.encode('euc-kr')) 
    except:
        title_len_for_calc = len(title_text)
    title_padding_total = 70 - title_len_for_calc - 4
    title_padding = title_padding_total // 2 if title_padding_total > 0 else 0
    logger.info(f"{' '*title_padding}[ {title_text} ]")
    
    logger.info("-" * 70)
    logger.info(f" 작업 대상: {header.get('target_name', 'N/A')}")
    logger.info(f" 작업 시간: {header.get('timestamp', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))}")
    if header.get("summary_lines"):
        logger.info("-" * 70)
        for line in header["summary_lines"]:
            logger.info(f"  ▶ {line.get('label', '')}: {line.get('value', '')}")
    logger.info("="*70)

    # --- 섹션 출력 ---
    for section in report_bundle.get("sections", []):
        section_title = section.get("section_title", "상세 내역")
        try:
            title_len_for_calc = len(section_title.encode('euc-kr'))
        except:
            title_len_for_calc = len(section_title)
        right_padding = 34 - title_len_for_calc
        if right_padding < 0: right_padding = 0
        logger.info(f"\n{'='*30} [ {section_title} ] {'='*right_padding}")
        
        section_type = section.get("section_type")
        content = section.get("content")

        if section_type == "key_value_list":
            if not content:
                logger.info("  (해당 없음)")
            else:
                _render_key_value_section(content, translations=translations)
            
    # --- 푸터 출력 ---
    logger.info("\n" + "="*70)

def _display_push_to_master_report(report_data, base_path, operation_title="마스터 파일 자동 병합 리포트"):
    """
    [v2] 범용 병합 리포트용 '데이터 빌더'.
    [수정] report_data에서 'final_master_item_count'를 사용하여 summary_lines를 구성합니다.
    """
    total_changes = (
        report_data.get('added_count', 0) +
        report_data.get('updated_kr_count', 0) +
        report_data.get('orphaned_by_en_change_count', 0) +
        report_data.get('orphaned_by_loc_change_count', 0)
    )
    
    summary_lines = [
        {"label": "총 처리 대상 항목 (소스)", "value": f"{report_data.get('total_processed_source', 0)}개"},
        {"label": "실제 변경이 발생한 항목", "value": f"{total_changes}개"}
    ]

    if 'final_master_item_count' in report_data:
        summary_lines.append({"label": "최종 마스터 항목 수", "value": f"{report_data['final_master_item_count']}개"})

    report_bundle = {
        "header": {
            "report_title": operation_title,
            "target_name": os.path.basename(base_path),
            "summary_lines": summary_lines
        },
        "sections": []
    }

    # --- 섹션 1: 병합 상세 내역 ---
    merge_section_content = []
    if report_data.get('added_count', 0) > 0:
        merge_section_content.append({"label": "신규 추가", "label_prefix": "[+] ", "value": f"{report_data['added_count']}개", "level": 1})
    if report_data.get('updated_kr_count', 0) > 0:
        merge_section_content.append({"label": "번역(KR) 업데이트", "label_prefix": "[*] ", "value": f"{report_data['updated_kr_count']}개", "level": 1})
    if report_data.get('orphaned_by_en_change_count', 0) > 0:
        merge_section_content.append({"label": "'Orphan' 처리 (원문 변경)", "label_prefix": "[-] ", "value": f"{report_data['orphaned_by_en_change_count']}개", "level": 1})
    if report_data.get('orphaned_by_loc_change_count', 0) > 0:
        merge_section_content.append({"label": "'Orphan' 처리 (ID/Type 변경)", "label_prefix": "[-] ", "value": f"{report_data['orphaned_by_loc_change_count']}개", "level": 1})
    if report_data.get('restored_orphan_count', 0) > 0:
        merge_section_content.append({"label": "'Orphan' 상태에서 복원", "label_prefix": "[+] ", "value": f"{report_data['restored_orphan_count']}개", "level": 1})

    report_bundle["sections"].append({
        "section_title": "병합 상세 내역",
        "section_type": "key_value_list",
        "content": merge_section_content
    })
    
    # # --- 섹션 2: 최종 결과 (작업 완료 후 표시) ---
    # if report_data.get('final_master_item_count', 0) > 0:
    #     final_section_content = [
    #         {"label": "최종 마스터 파일 항목 수", "label_prefix": "[i] ", "value": f"{report_data['final_master_item_count']}개", "level": 1}
    #     ]
    #     report_bundle["sections"].append({
    #         "section_title": "최종 결과",
    #         "section_type": "key_value_list",
    #         "content": final_section_content
    #     })

    # --- 2. [핵심] 생성된 Report Bundle을 반환합니다 ---
    return report_bundle

def _display_apply_report(report_data, base_path):
    """
    [v5.2 - 데이터 빌더로 리팩토링] Apply 종합 빌드 리포트의 데이터 빌더.
    사전 분석된 report_data를 받아 표준 Report Bundle을 생성하여 반환합니다.
    """
    # --- 1. Report Bundle 데이터 구조 생성 ---
    report_bundle = {
        "header": {
            "report_title": "Apply 종합 빌드 리포트",
            "target_name": os.path.basename(base_path),
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "summary_lines": [
                {"label": "총 적용된 번역문 수", "value": f"{report_data.get('total_applied_count', 0)}개"},
                {"label": "처리된 파일 수", "value": f"{report_data.get('processed_file_count', 0)}개"}
            ]
        },
        "sections": []
    }

    # --- 섹션 1, 2, 3 (기존과 동일한 로직) ---
    sections_content = [
        ("단계 1: 번역 데이터 분석", [
            {"label": f"'{report_data['translation_source_name']}'에서 로드", "label_prefix": "[i] ", "value": f"{report_data.get('loaded_translation_count', 0)}개"},
            {"label": "'Translatable: x'로 제외됨", "label_prefix": "   └─ [-] ", "value": f"{sum(report_data.get('excluded_by_x_map', {}).values())}개"} if sum(report_data.get('excluded_by_x_map', {}).values()) > 0 else None,
            {"label": "적용 대상 파일 수", "label_prefix": "[=] ", "value": f"{report_data.get('initial_file_count', 0)}개"}
        ]),
        ("단계 2: 원본 파일 검증 (`data_en`)", [
            {"label": "누락된 원본 파일 (건너뜀)", "label_prefix": "[-] ", "value": f"{report_data['unfound_source_file_count']}개"} if report_data['unfound_source_file_count'] > 0 else None,
            {"label": "유효한 대상 파일", "label_prefix": "[+] ", "value": f"{report_data.get('valid_file_count', 0)}개"}
        ]),
        ("단계 3: 최종 출력 요약", [
            {"label": "'{output_folder_name}' 폴더에 파일 생성/업데이트".format(output_folder_name=os.path.basename(report_data['output_folder_path'])), "label_prefix": "[✔] ", "value": f"{report_data.get('processed_file_count', 0)}개"},
            {"label": "모든 파일에 걸쳐 총 적용된 번역문", "label_prefix": "[+] ", "value": f"{report_data.get('total_applied_count', 0)}개"},
        ])
    ]
    for title, content in sections_content:
        report_bundle["sections"].append({
            "section_title": title,
            "section_type": "key_value_list",
            "content": [item for item in content if item]
        })

    # --- 섹션 4: 파일별 적용 상세 내역 ---
    details_section_content = []
    sorted_details = sorted(report_data.get('file_details', []), key=lambda x: x.get('path'))
    
    for detail in sorted_details:
        applied_count = detail['applied_count']
        skipped_reasons = detail.get('skipped_reasons', {})
        
        orphan_count = skipped_reasons.get('Orphan 항목 (구버전 데이터)', 0)
        en_changed_count = skipped_reasons.get('원문(text_en) 변경', 0)
        
        total_skipped = sum(skipped_reasons.values())
        
        actionable_targets = applied_count + (total_skipped - orphan_count - en_changed_count)
        
        percentage = (applied_count / actionable_targets * 100.0) if actionable_targets > 0 else 0.0
        
        total_applied_for_display = f"{applied_count} / {actionable_targets}개 적용 ({percentage:.1f}%)"
        prefix = "[✔] " if applied_count > 0 and total_skipped == 0 else ("[*] " if applied_count > 0 else "[-] ")
        
        details_section_content.append({"label": detail['path'], "label_prefix": prefix, "value": total_applied_for_display, "level": 1})

        if total_skipped > 0:
            for reason, count in sorted(skipped_reasons.items(), key=lambda item: item[1], reverse=True):
                details_section_content.append({"label": reason, "value": f"{count}개", "level": 2, "label_prefix": "   └─ "})

    report_bundle["sections"].append({"section_title": "파일별 적용 상세 내역", "section_type": "key_value_list", "content": details_section_content})

    return report_bundle

def apply_all_translations(is_test_run=False, base_path=None, shared_state=None, target_files=None, mod_root_path=None, translation_map_override=None, output_folder_override=None):
    """
    [v-최종 객체지향 리팩토링] ExecutionContext와 Strategy 패턴을 사용하여 Apply 작업을
    조율하는 순수 컨트롤러 역할을 수행합니다.
    """
    if base_path is None: 
        base_path = os.getcwd()
    logger = LoggerService.get_logger()
    logger.info(f"Apply 작업을 시작합니다... (테스트 모드: {is_test_run})")

    # --- 1. 초기화 및 컨텍스트 생성 ---
    encoding_fallback_files = []
    ApplyAuditService.clear()
    report = defaultdict(int)
    report['file_details'] = []
    
    context = ExecutionContext(base_path, is_test_run, shared_state)
    output_folder_path = output_folder_override or os.path.join(base_path, TRANSLATED_DATA_FOLDER)
    report['output_folder_path'] = output_folder_path
    
    # --- [핵심 변경] 데이터 로딩은 context property에 접근하는 순간 자동으로 발생 ---
    if translation_map_override is not None:
        logger.info("  -> 외부에서 제공된 번역 데이터를 사용합니다.")
        # 외부 데이터가 있으면 context의 로딩 메커니즘을 우회하고 직접 설정
        context._translation_map = translation_map_override
        context._translation_map_insensitive = {} # 외부 데이터는 대소문자 구분 폴백 미지원
        context._files_to_translate = {key[0] for key in translation_map_override.keys()}
        context._full_translation_map = {k: {'text_kr': v, 'status': ''} for k, v in translation_map_override.items()}
        context._excluded_by_x_map = defaultdict(int)
        context._excluded_keys_by_file = defaultdict(set)
        report['translation_source_name'] = "외부 제공 데이터"
    else:
        report['translation_source_name'] = os.path.basename(context.paths.get_apply_source_file())
    
    # --- 2. 처리 대상 파일 목록 결정 ---
    # context.files_to_translate에 처음 접근 -> _load_apply_data() 자동 호출
    # load_translation_data 호출 부분 완전 제거
    files_to_process = context.files_to_translate
    report['loaded_translation_count'] = len(context.translation_map)
    report['initial_file_count'] = len(files_to_process)
    report['excluded_by_x_map'] = context.excluded_by_x_map

    if not files_to_process:
        logger.warning("번역된 내용이 있는 파일이 하나도 없습니다. 작업을 종료합니다.")
        return

    if target_files:
        files_to_process = {f for f in files_to_process if f in target_files}

    # --- 3. 사전 검증 및 폴더 정리 ---
    source_folder_path = os.path.join(base_path, SOURCE_DATA_FOLDER)
    logger.info(" -> 원본 파일 존재 여부를 사전 검증합니다...")
    valid_relative_paths = []
    for relative_path in sorted(list(files_to_process)):
        if os.path.exists(os.path.join(source_folder_path, relative_path.replace('/', os.sep))):
            valid_relative_paths.append(relative_path)
        else:
            logger.warning(f"  - [누락] 원본 파일을 찾을 수 없어 건너뜁니다: {relative_path}")
            report['unfound_source_file_count'] += 1
    report['valid_file_count'] = len(valid_relative_paths)

    if os.path.exists(output_folder_path) and not is_test_run:
        logger.info(f"기존 출력 폴더 '{os.path.basename(output_folder_path)}'를 삭제합니다.")
        shutil.rmtree(output_folder_path)

    # --- 4. 파일별 번역 적용 루프 ---
    logger.info("\n" + "-" * 50 + "\n번역 적용 실행을 시작합니다...")
    total_applied_count = 0
    for relative_path in valid_relative_paths:
        # 4a. 현재 파일에 대한 컨텍스트 업데이트
        context.current_relative_path = relative_path
        context.current_source_path = os.path.join(source_folder_path, relative_path.replace('/', os.sep))
        context.current_dest_path = os.path.join(output_folder_path, relative_path.replace('/', os.sep))
        context.current_rules = get_rules_for_file(relative_path, base_path)
        
        if not is_test_run: os.makedirs(os.path.dirname(context.current_dest_path), exist_ok=True)

        # 4b. 전략 선택 및 실행
        applier_name = context.current_rules.get('applier') if context.current_rules else None
        strategy = strategy_factory.get_strategy(applier_name)
        if not strategy and relative_path.lower().endswith('.csv'):
            strategy = strategy_factory.get_strategy('apply_translation_to_csv_file') # CSV 폴백
        
        applied_in_file, successfully_applied_keys = 0, set()
        if strategy:
            try:
                logger.info(f"-> 번역 적용 중: {relative_path} (Using Strategy: {type(strategy).__name__})")
                applied_in_file, successfully_applied_keys = strategy.execute(context)
            except Exception as e:
                logger.error(f"[오류] Strategy '{type(strategy).__name__}' 실행 중 오류: {e}", exc_info=True)
                if not is_test_run: copy_with_recode(context.current_source_path, context.current_dest_path, is_test_run)
        else:
            logger.warning(f"  [경고] '{relative_path}'에 대한 Applier 규칙이 없습니다. 원본을 복사합니다.")
            if not is_test_run: copy_with_recode(context.current_source_path, context.current_dest_path, is_test_run)

        total_applied_count += applied_in_file

        # 4c. 리포트 데이터 집계 (스킵 사유 분석 로직 추가)
        # [핵심 수정] context.full_translation_map에서 'Orphan' 상태의 항목을 제외하여 candidates_in_file 계산
        candidates_in_file_raw = {
            k: v for k, v in context.full_translation_map.items() 
            if k[0] == relative_path and (v.get('status', '') or '').strip().lower() != 'orphan'
        }
        
        # 유효한 apply_key (4-튜플)만 candidates_in_file로 만듭니다.
        # text_kr이 비어있는 항목은 번역 대상이 아니므로 제외합니다.
        candidates_in_file = {
            k for k, v in candidates_in_file_raw.items() if (v.get('text_kr') or '').strip()
        }

        # 'Translatable: x'로 제외된 키는 적용 대상이 아니므로, 스킵 사유 분석에서 제외
        excluded_keys_for_file = context.excluded_keys_by_file.get(relative_path, set())
        
        # 성공적으로 적용된 키, 'x'로 제외된 키, 그리고 Apply 대상이 될 수 없었던 키(text_kr 없음)를 뺀
        # 순수한 '번역 실패' 키 목록을 만듭니다.
        skipped_for_analysis = candidates_in_file - successfully_applied_keys - excluded_keys_for_file
        
        # 스킵 사유 분석
        skipped_reasons = defaultdict(int)
        for skipped_key in skipped_for_analysis:
            latest_map = context.latest_data_map
            loc_key = skipped_key[:3]
            
            # (이 로직은 text_kr이 비어있지 않은 상태에서 실패한 경우에만 진입합니다.)
            # Orphan 항목 (data_en에 해당 위치 자체가 없는 경우)
            if loc_key not in latest_map:
                skipped_reasons['Orphan 항목 (구버전 데이터)'] += 1
                continue

            # [핵심] 공백 불일치와 실제 내용 변경을 구분하는 로직
            latest_en_raw = latest_map.get(loc_key)
            latest_en_cleaned = text_processor_service.process(latest_en_raw, item_type=skipped_key[2])
            master_en_key = skipped_key[3]
            
            if latest_en_cleaned != master_en_key:
                if latest_en_cleaned.strip() == master_en_key.strip():
                    skipped_reasons['원문(text_en) 공백 불일치'] += 1
                else:
                    skipped_reasons['원문(text_en) 변경'] += 1
            else:
                # text_en은 일치하지만, Apply에 실패한 경우 (Applier 내부 로직 문제 의심)
                skipped_reasons['키 일치 오류 (Applier 문제 의심)'] += 1
        
        report['file_details'].append({
            'path': relative_path,
            'applied_count': applied_in_file,
            'total_targets': len(candidates_in_file) - len(excluded_keys_for_file), # <-- 최종 적용 대상 수 계산
            'skipped_reasons': dict(skipped_reasons),
            'excluded_by_x_count': len(excluded_keys_for_file)
        })

    # --- 5. 최종 리포트 및 정리 ---
    report['processed_file_count'] = len(valid_relative_paths)
    report['total_applied_count'] = total_applied_count

    final_report_bundle = _display_apply_report(report, base_path)
    if final_report_bundle:
        _render_standard_report(final_report_bundle)

    if encoding_fallback_files:
        print("\n" + "="*70)
        logger.warning(" [!! 경고 !!] 일부 파일에서 인코딩 문제가 감지되었습니다.")
        print("-" * 70)
        print(f"'apply' 작업 중 다음 파일들은 기본 인코딩('{INPUT_FILE_ENCODING}')으로 읽지 못하여")
        print("대체 인코딩으로 처리되었습니다. 이로 인해 일부 문자가 깨질 수 있습니다.\n")
        print("[ 감지된 파일 목록 ]")
        for item in encoding_fallback_files:
            print(f" - {item['path']} (읽기 성공: {item['used_encoding']})")
        print("\n[ 권장 조치 ]")
        print("위 파일들을 'UTF-8 with BOM' 인코딩으로 변환하여 저장하는 것을 강력히 권장합니다.")
        print("="*70)

    flush_and_sync_all_loggers()
    LoggerService.close_aux_loggers()


def _run_sync_overwrite_auditor(source_path, target_path, is_test_run, is_skipped):
    """
    7-6 메뉴의 2번 '전체 복사 (덮어쓰기)' 작업 완료 후,
    복사 전후 파일의 차이점을 분석하여 상세 보고서를 출력합니다.
    """
    logger = LoggerService.get_logger()
    
    # 1. 건너뛰기 보고서 (실제 복사가 발생하지 않은 경우)
    if is_skipped:
        target_data_list_skipped = csv_file_service.load_rows_from_csv(target_path)
        
        logger.info("\n" + "="*70)
        logger.info(f"{'[':^28} 마스터 전체 복사 (덮어쓰기) 리포트 {']':^28}")
        logger.info("-" * 70)
        logger.info(f" 작업 대상 파일: {os.path.basename(target_path)}")
        logger.info(f" [상태] 원본과 대상 파일의 내용이 이미 동일하여 복사 작업이 생략되었습니다.")
        logger.info("-" * 70)
        logger.info(f" 최종 항목 수: {len(target_data_list_skipped)}개")
        logger.info("="*70)
        return
        
    # --- (is_skipped가 False인 경우, 즉 실제 복사가 발생했거나 파일이 없어서 생성된 경우) ---

    # 1. 파일 재로드 (현재 target_path의 내용)
    target_data_list = csv_file_service.load_rows_from_csv(target_path)
    
    # 2. 백업 파일 찾기 (가장 최근의 백업을 찾아서 이전 상태로 간주)
    target_dir = os.path.dirname(target_path)
    target_filename = os.path.basename(target_path)
    
    backup_dir = os.path.join(target_dir, 'backups')
    latest_backup_path = None
    latest_timestamp = None

    if os.path.exists(backup_dir):
        # target_filename이 'mod_PAGSM_MASTER_LIB_kr.csv'일 경우, 'mod_PAGSM_MASTER_LIB_kr'로 분리
        base_name_without_ext = os.path.splitext(target_filename)[0]
        
        backup_files = [f for f in os.listdir(backup_dir) if f.startswith(base_name_without_ext)]
        
        # 타임스탬프 형식 (YYYYMMDD_HHMMSS)을 기준으로 최신 백업 파일 찾기
        for f in backup_files:
            match = re.search(r'(\d{8}_\d{6})', f)
            if match:
                timestamp_str = match.group(1)
                try:
                    timestamp = datetime.strptime(timestamp_str, '%Y%m%d_%H%M%S')
                    if latest_timestamp is None or timestamp > latest_timestamp:
                        latest_timestamp = timestamp
                        latest_backup_path = os.path.join(backup_dir, f)
                except ValueError:
                    # 타임스탬프 형식 불일치 무시
                    continue

    old_data_list = []
    if latest_backup_path:
        # 백업 파일을 찾았으면, 이를 이전 데이터로 로드
        old_data_list = csv_file_service.load_rows_from_csv(latest_backup_path)
        logger.info(f" -> 이전 상태 비교를 위해 백업 파일 '{os.path.basename(latest_backup_path)}'을 사용했습니다.")
    else:
        logger.warning(" -> 비교할 이전 백업 파일을 찾지 못해 변경 상세 분석을 건너뜁니다.")


    # 3. 데이터 비교 분석 (현재 상태 vs 이전 백업 상태)
    added_count, removed_count, modified_kr_count = 0, 0, 0
    
    if latest_backup_path:
        # 현재 데이터 (덮어쓴 후)
        current_map = { 
            (row['source_file'], row['id'], row['type'], text_processor_service.process(row.get('text_en', ''))): 
            text_processor_service.process(row.get('text_kr', ''))
            for row in target_data_list 
        }
        # 이전 데이터 (덮어쓰기 전, 백업 파일)
        old_map = { 
            (row['source_file'], row['id'], row['type'], text_processor_service.process(row.get('text_en', ''))): 
            text_processor_service.process(row.get('text_kr', ''))
            for row in old_data_list 
        }

        keys_current = set(current_map.keys())
        keys_old = set(old_map.keys())
        
        added_count = len(keys_current - keys_old)
        removed_count = len(keys_old - keys_current)
        common_keys = keys_current.intersection(keys_old)
        modified_kr_count = len({k for k in common_keys if current_map[k] != old_map[k]})
    

    # 4. 보고서 출력
    
    logger.info("\n" + "="*70)
    logger.info(f"{'[':^28} 마스터 전체 복사 (덮어쓰기) 리포트 {']':^28}")
    logger.info("-" * 70)
    logger.info(f" 작업 대상 파일: {os.path.basename(target_path)}")
    logger.info(f" [상태] 파일 덮어쓰기 성공.")
    logger.info(f" 최종 항목 수: {len(target_data_list)}개")
    
    if latest_backup_path:
        logger.info("\n--- [ 이전 상태 대비 변경 상세 ] " + "-"*40)
        logger.info(f" (비교 기준: {os.path.basename(latest_backup_path)})")
        
        if added_count > 0:
            logger.info(f"    - {added_count:>5}개: [신규 추가] 이전 파일에 없던 항목")
        if removed_count > 0:
            logger.warning(f"    - {removed_count:>5}개: [제거] 이전 파일에 있었으나, 이번 복사로 삭제된 항목")
        if modified_kr_count > 0:
            logger.info(f"    - {modified_kr_count:>5}개: [수정] 동일 항목의 KR 내용이 변경됨")
        
        if added_count == 0 and removed_count == 0 and modified_kr_count == 0:
            logger.info("    - 변경된 내용이 감지되지 않았습니다. (EN/Type/KR 모두 동일)")
    else:
        logger.warning("\n--- [ 이전 상태 대비 변경 상세 ] " + "-"*40)
        logger.warning("    - 이전 파일과의 비교가 불가능하여 상세 분석을 생략합니다.")


    logger.info("="*70)


# ┏────────────────────────────────────────────────────────────────┐
#
#                    [ 데이터 배포 (Copy/Deploy) 기능 블록 ]
#
# ┗────────────────────────────────────────────────────────────────┘

def deploy_mod_data(is_test_run=False, base_path=None, shared_state=None):
    """(4.2.7) base_path를 인자로 받아 경로 의존성을 제거한 Deploy 함수.
    현재 모드 폴더의 'data' 디렉토리를 DESTINATION_BASE_PATH로 배포합니다.
    """
    if base_path is None:
        base_path = os.getcwd()

    logger = LoggerService.get_logger()
    logger.info(f"모드 'data' 폴더 배포 스크립트를 시작합니다. (테스트 모드: {is_test_run})")

    # [수정] os.getcwd() 대신 base_path를 사용합니다.
    current_mod_path = base_path
    current_mod_name = os.path.basename(current_mod_path)
    
    logger.info(f"  - 배포 대상 모드: '{current_mod_name}'")

    logger.debug(f"소스 모드 경로: {current_mod_path}")
    logger.debug(f"목표 경로: {DESTINATION_BASE_PATH}")
    logger.debug(f"배포 방식: {DEPLOY_METHOD}")
    
    if not os.path.isdir(DESTINATION_BASE_PATH):
        logger.error(f"[오류] 목표 경로 '{DESTINATION_BASE_PATH}'를 찾을 수 없습니다.")
        return
    if DEPLOY_METHOD not in ['OVERWRITE', 'DELETE']:
        logger.error(f"[오류] DEPLOY_METHOD 설정 오류: '{DEPLOY_METHOD}'. 'OVERWRITE' 또는 'DELETE'여야 합니다.")
        return

    # [수정] 유효성 검사는 이미 컨트롤러 레벨에서 수행되었지만, 함수 단독 실행을 위해 유지합니다.
    if current_mod_name in MOD_FOLDERS_TO_EXCLUDE:
        logger.warning(f"-> 건너뛰기: '{current_mod_name}'은(는) 제외 목록에 있습니다.")
        return
    if MOD_USE_PREFIX_FILTER and not current_mod_name.startswith(MOD_FOLDER_PREFIX):
        logger.warning(f"-> 건너뛰기: '{current_mod_name}'은(는) 접두사 '{MOD_FOLDER_PREFIX}'와 일치하지 않습니다.")
        return

    mod_id = current_mod_name
    if MOD_USE_PREFIX_FILTER:
        mod_id = current_mod_name[len(MOD_FOLDER_PREFIX):]
    
    if not mod_id:
        logger.error(f"[오류] '{current_mod_name}' 폴더에서 유효한 모드 ID를 추출할 수 없습니다.")
        return

    logger.info(f"-> 모드 '{current_mod_name}' (목표 ID: {mod_id}). 배포 시작...")

    # [수정] 소스 경로는 current_mod_path(base_path)를 기준으로 계산됩니다.
    source_data_path = os.path.join(current_mod_path, "data")
    dest_mod_path = os.path.join(DESTINATION_BASE_PATH, mod_id)
    dest_data_path = os.path.join(dest_mod_path, "data")

    if not os.path.isdir(source_data_path):
        logger.warning(f"  [경고] '{current_mod_name}' 내에 'data' 폴더가 없어 배포를 건너뜁니다.")
        return
    
    if not os.path.isdir(dest_mod_path):
        logger.warning(f"  [정보] 목표 경로에 '{mod_id}' 모드 폴더가 없어 배포를 건너뜁니다.")
        return

    try:
        if DEPLOY_METHOD == 'DELETE':
            logger.debug(f"  - [삭제 후 복사] 모드로 배포합니다.")
            if os.path.exists(dest_data_path):
                if is_test_run:
                    logger.debug(f"    테스트 모드: 기존 '{mod_id}/data' 폴더 삭제를 스킵합니다.")
                else:
                    logger.debug(f"    - [삭제] 기존 '{mod_id}/data' 폴더.")
                    shutil.rmtree(dest_data_path)
            copy_and_log_actions(source_data_path, dest_data_path, is_test_run)

        elif DEPLOY_METHOD == 'OVERWRITE':
            logger.debug(f"  - [덮어쓰기] 모드로 배포합니다.")
            copy_and_log_actions(source_data_path, dest_data_path, is_test_run)
        
        logger.info(f"  [성공] '{mod_id}/data' 폴더 배포를 완료했습니다.")
    
    except Exception as e:
        logger.error(f"  [오류] '{mod_id}/data' 폴더 배포 중 문제가 발생했습니다: {e}")


# ┏────────────────────────────────────────────────────────────────┐
#
#        [ 'data'에서 번역 역추적/역추출 로직 함수 (Reverse-Extract) ]
#
# ┗────────────────────────────────────────────────────────────────┘

def start_reverse_extraction(is_test_run=False, base_path=None, shared_state=None):
    """[컨트롤러] 6번. 'data'에서 번역 역추출 기능의 진입점. 사용자 확인 후 execute_task를 호출."""
    logger = LoggerService.get_logger()
    
    display_name = get_mod_display_name(base_path)
    src_en_folder = os.path.join(base_path, SOURCE_DATA_FOLDER)
    
    source_kr_folder_name = TRANSLATED_DATA_FOLDER.lstrip('./\\')
    source_kr_folder = os.path.join(base_path, source_kr_folder_name)

    logger.info(f"\n[{display_name}] '{os.path.basename(source_kr_folder)}' 폴더에서 번역 역추출을 시작합니다...")
    
    # --- 사용자 최종 확인 절차 ---
    # 테스트 모드에서는 이 확인 절차를 건너뜁니다.
    if not is_test_run:
        print("\n" + "!"*60)
        logger.warning(" [주의] 6. 'data'에서 번역 역추출을 시작합니다.")
        logger.warning("        이 작업은 'data_en'과 'data' 폴더 전체를 분석하여")
        logger.warning("        새로운 검토용 파일(_rev_... .csv)들을 생성/덮어씁니다.")
        print("!"*60)
        
        confirm_prompt = "\n>> 계속 진행하시겠습니까? (Enter/y: 예, ESC/n: 아니오): "
        choice = prompt_for_input(confirm_prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')
        if choice != 'y':
            logger.info(" -> 작업을 취소했습니다.")
            return False
    
    # --- 확인 후 실제 작업 실행 위임 ---
    # execute_task를 다시 호출하여, 이번에는 실제 '엔진' 함수를 실행시킴
    execute_task(run_reverse_extraction, lambda p: ValidationService(p).for_reverse_extract(), None, "ReverseExtract", is_test_run=is_test_run)
    return True


def _run_merge_reverse_results_engine(base_path, is_test_run=False):
    """[엔진 - CsvFileService 적용] 6-4. 모든 역추출 결과를 병합합니다."""
    logger = LoggerService.get_logger()
    logger.info("\n" + "="*60)
    logger.info("6-4. 역추출 결과 최종 병합을 시작합니다...")

    paths = PathManager(base_path)
    success_file = paths.get_reverse_extract_success_file()
    recovered_file = paths.get_reverse_extract_recovered_file()

    if not os.path.exists(success_file) or not os.path.exists(recovered_file):
        logger.error(" [!] 오류: 병합에 필요한 파일이 모두 준비되지 않았습니다.")
        return

    # [수정] _load_csv_to_list_of_dicts -> csv_file_service.load_rows_from_csv
    success_data = csv_file_service.load_rows_from_csv(success_file)
    final_data_map = {
        (row['source_file'], row['id'], row['type'], row['text_en']): row
        for row in success_data
    }
    initial_count = len(final_data_map)
    logger.info(f" -> 기준 데이터 ('{os.path.basename(success_file)}')에서 {initial_count}개 항목 로드.")

    # [수정] _load_csv_to_list_of_dicts -> csv_file_service.load_rows_from_csv
    recovered_data = csv_file_service.load_rows_from_csv(recovered_file)
    added_from_recovered_count = 0
    for row in recovered_data:
        key = (row['source_file'], row['id'], row['type'], row['text_en'])
        if key not in final_data_map:
            final_data_map[key] = row
            added_from_recovered_count += 1
    
    logger.info(f" -> 복원 데이터 ('{os.path.basename(recovered_file)}')에서 {added_from_recovered_count}개의 신규 항목 추가.")
    
    final_data_list = list(final_data_map.values())
    total_count = len(final_data_list)
    
    # ... (미리보기 UI는 변경 없음) ...
    print("\n" + "-"*60)
    logger.info(" [ 병합 결과 미리보기 ]")
    logger.info(f"  - 최종 항목 수: {total_count}개")
    print("-" * 60)

    if added_from_recovered_count == 0:
        logger.info(" -> 추가할 새로운 항목이 없습니다. 작업을 종료합니다.")
        return

    prompt = f"\n>> 위 내용으로 '{os.path.basename(success_file)}' 파일을 덮어쓰시겠습니까? (Enter/y, ESC/n): "
    choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')
    
    if choice == 'y':
        logger.info(f" -> '{os.path.basename(success_file)}' 파일을 업데이트합니다...")
        # [수정] _create_timestamped_backup 및 write_csv -> csv_file_service.write_rows_to_csv
        csv_file_service.write_rows_to_csv(
            success_file,
            final_data_list,
            headers=OUTPUT_HEADERS,
            create_backup_on_write=True,
            is_test_run=is_test_run
        )
        logger.info(" -> 병합 작업이 성공적으로 완료되었습니다.")
    else:
        logger.info(" -> 작업을 취소했습니다.")

# ┏────────────────────────────────────────────────────────────────┐
#
#               [ 6번 메뉴 기능 : 역추적/추출 기능 ]
#
# ┗────────────────────────────────────────────────────────────────┘
def run_reverse_extraction(is_test_run=False, base_path=None, shared_state=None, source_kr_folder=None):
    """
    [컨트롤러로 리팩토링됨] 역추출 워크플로우를 조율합니다.
    데이터 로딩, 분석 서비스 호출, 결과 저장, 리포팅의 명확한 단계를 따릅니다.
    """
    if base_path is None: base_path = os.getcwd()
    logger = LoggerService.get_logger()
    
    display_name = get_mod_display_name(base_path)
    
    # --- 1. 경로 설정 및 전제 조건 검사 ---
    src_en_folder = os.path.join(base_path, SOURCE_DATA_FOLDER)
    if source_kr_folder is None:
        logger.error(" [오류] 내부 로직 오류: 역추출할 소스 폴더가 지정되지 않았습니다.")
        return

    logger.info(f"\n[{display_name}] '{os.path.basename(source_kr_folder)}' 폴더에서 역추출 엔진을 실행합니다...")
    if not (os.path.isdir(src_en_folder) and os.path.isdir(source_kr_folder)):
        logger.error(f" [!] 오류: '{os.path.basename(src_en_folder)}' 또는 '{os.path.basename(source_kr_folder)}' 폴더를 찾을 수 없습니다.")
        return

    paths = PathManager(base_path)

    # --- 2. 데이터 로딩 ---
    logger.info(" -> 원본(data_en) 폴더 구조를 분석 중입니다...")
    map_en, _, _ = extract_all_text_to_map(base_path, src_en_folder, mod_root_path=base_path)
    
    logger.info(f" -> 번역본('{os.path.basename(source_kr_folder)}') 폴더 구조를 분석 중입니다...")
    map_kr, _, _ = extract_all_text_to_map(base_path, source_kr_folder, mod_root_path=base_path)

    # --- 3. 핵심 분석 로직 실행 (서비스 위임) ---
    service = ReverseExtractorService(map_en, map_kr)
    classified_results = service.execute()

    # --- 4. 결과 파일 저장 (I/O 위임) ---
    _save_reverse_extract_artifacts(classified_results, paths, is_test_run)

    # --- 5. 최종 리포트 출력 ---
    success_count = len(classified_results['success'])
    mismatch_count = len(classified_results['mismatch'])
    orphan_count = len(classified_results['orphan'])

    logger.info("\n" + "-" * 50)
    logger.info("역추출 작업 요약:")
    logger.info(f"  - {success_count}개의 성공 항목을 '{os.path.basename(paths.get_reverse_extract_success_file())}'에 저장했습니다.")
    if REVERSE_EXTRACT_GENERATE_MISMATCH_FILE:
        logger.info(f"  - {mismatch_count}개의 불일치 항목을 '{os.path.basename(paths.get_path(REVERSE_EXTRACT_MISMATCH_SUFFIX))}'에 저장했습니다.")
    else:
        logger.info("  - (설정 비활성화됨) 불일치 항목 검사를 건너뛰었습니다.")
    logger.info(f"  - {orphan_count}개의 고아 항목을 '{os.path.basename(paths.get_reverse_extract_orphan_file())}'에 저장했습니다.")
    print("")
    logger.info("  - 생성된 파일들을 검토하고, 필요한 내용을 마스터 번역 파일에 수동으로 병합하십시오.")
    logger.info("-" * 50)

def _run_push_missing_to_merged_engine(is_test_run=False, base_path=None, shared_state=None):
    """[래퍼] 11. _TODO_missing_translations.csv의 내용을 _STAGING_kr.csv로 병합합니다."""
    # [핵심 수정] _run_merge_engine 호출 시, 스테이징 파일에 맞는 STAGING_FILE_HEADERS를 명시적으로 전달합니다.
    _run_merge_engine(
        base_path=base_path,
        source_file_provider=lambda p: p.get_missing_file(),
        target_file_provider=lambda p: p.get_staging_master_file(),
        operation_title="11. '번역 작업' -> '스테이징' 파일로 전송",
        target_headers=STAGING_FILE_HEADERS, # <--- [핵심 추가]
        is_test_run=is_test_run
    )

# 범용 병합 엔진
def _run_merge_engine(base_path, source_file_provider, target_file_provider, operation_title, target_headers, is_test_run=False):
    """
    [v2 - 헤더 및 키 정규화 수정] 지정된 두 파일을 안전하게 병합하는 범용 엔진입니다.
    이제 대상 파일에 사용할 헤더를 인자로 받아, 헤더 불일치 문제를 해결합니다.
    또한, 키 생성 시 text_en을 정규화하여 데이터 처리의 대칭성을 보장합니다.
    """
    logger = LoggerService.get_logger()
    logger.info(f"\n{'='*60}")
    logger.info(f"{operation_title} 시작...")

    paths = PathManager(base_path)
    source_file = source_file_provider(paths)
    target_file = target_file_provider(paths)

    source_data = csv_file_service.load_rows_from_csv(source_file)
    if not source_data:
        logger.warning(f" -> 원본 파일 '{os.path.basename(source_file)}'에 전송할 데이터가 없습니다.")
        return

    # [핵심 수정 1] 키 생성 시 text_en을 정규화하여 데이터 대칭성 확보
    target_data_map = { 
        (row['source_file'], row['id'], row['type'], text_processor_service.process(row.get('text_en', ''), item_type=row.get('type', ''))): row 
        for row in csv_file_service.load_rows_from_csv(target_file) 
    }

    new_count = 0
    overwrite_count = 0
    no_change_count = 0
    source_empty_count = 0

    for row in source_data:
        if not row.get('text_kr', '').strip():
            source_empty_count += 1
            continue
        
        # [핵심 수정 2] 키 조회 시에도 동일한 정규화 규칙 적용
        key = (row['source_file'], row['id'], row['type'], text_processor_service.process(row.get('text_en', ''), item_type=row.get('type', '')))
        
        if key not in target_data_map:
            new_count += 1
        elif target_data_map[key].get('text_kr') != row.get('text_kr'):
            overwrite_count += 1
        else:
            no_change_count += 1

    print("\n" + "!"*60)
    logger.info(f" [알림] '{os.path.basename(target_file)}' 파일 업데이트 미리보기:")
    print(f"  - 원본: '{os.path.basename(source_file)}' ({len(source_data)}개 항목)")
    print(f"  - 대상: '{os.path.basename(target_file)}' ({len(target_data_map)}개 항목)")
    print("-" * 60)
    print("  [ 분석된 변경 내역 ]")
    print(f"   - 신규 추가될 항목: {new_count}개")
    print(f"   - 덮어쓰여질 항목: {overwrite_count}개")
    print(f"   - 내용이 동일한 항목: {no_change_count}개")
    if source_empty_count > 0:
        print(f"   - (무시) 원본 번역이 비어있는 항목: {source_empty_count}개")
    print("!"*60)
    
    if new_count == 0 and overwrite_count == 0:
        logger.info("\n -> 대상 파일에 적용할 새로운 변경 사항이 없습니다. 작업을 종료합니다.")
        return

    confirm = get_user_input_with_special_keys("\n>> 위 내용으로 업데이트를 계속 진행하시겠습니까? (Enter/y: 예, ESC/n: 아니오): ").lower()
    if confirm not in ('', 'y'):
        logger.info(" -> 작업을 취소했습니다.")
        return
  
    for row in source_data:
        if not row.get('text_kr', '').strip():
            continue
        # [핵심 수정 3] 최종 맵에 저장 시에도 정규화된 키 사용
        key = (row['source_file'], row['id'], row['type'], text_processor_service.process(row.get('text_en', ''), item_type=row.get('type', '')))
        target_data_map[key] = row

    final_data_list = list(target_data_map.values())
    
    # [핵심 수정 4] 하드코딩된 헤더 대신, 인자로 받은 target_headers 사용
    csv_file_service.write_rows_to_csv(target_file, final_data_list, headers=target_headers, create_backup_on_write=True, is_test_run=is_test_run)

    logger.info(" -> 작업 완료!")
    logger.info(f"    (신규: {new_count}개, 덮어쓰기: {overwrite_count}개, 최종: {len(final_data_list)}개)")

def _run_push_success_to_missing_engine(base_path, is_test_run=False):
    """[래퍼] 6-3. _rev_extracted_kr.csv의 내용을 _TODO_missing_translations.csv로 병합합니다."""
    _run_merge_engine(
        base_path=base_path,
        source_file_provider=lambda p: p.get_reverse_extract_success_file(),
        target_file_provider=lambda p: p.get_missing_file(),
        operation_title="6-3. 성공 결과를 '번역 작업' 파일로 전송",
        target_headers=OUTPUT_HEADERS,
        is_test_run=is_test_run
    )

def _run_merge_reverse_success_to_staging_wrapper(is_test_run=False, base_path=None, shared_state=None):
    """
    [신규 래퍼 7-4] _rev_SUCCESS_kr.csv의 내용을 _STAGING_kr.csv로 지능형 병합합니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    source_path = paths.get_reverse_extract_success_file()
    target_path = paths.get_staging_master_file()

    source_data = csv_file_service.load_rows_from_csv(source_path)
    if not source_data:
        logger.warning(f" -> 병합할 원본 데이터가 '{os.path.basename(source_path)}' 파일에 없습니다.")
        return False # 작업 미수행

    # MasterFileService를 스테이징 파일을 대상으로 인스턴스화
    staging_service = MasterFileService(base_path, csv_file_service, target_file_path=target_path)
    
    logger.info(f" -> '{os.path.basename(source_path)}' -> '{os.path.basename(target_path)}' 지능형 병합을 시작합니다...")
    
    # intelligent_merge를 실행 모드로 호출 (preview_only=False)
    # shared_state와 is_test_run을 그대로 전달
    sync_successful = staging_service.intelligent_merge(
        source_data=source_data, 
        is_test_run=is_test_run, 
        target_is_staging=True,
        preview_only=False,
        shared_state=shared_state
    )

    if not sync_successful:
        logger.warning(" -> 스테이징 파일 병합 작업이 취소되었거나 변경사항이 없었습니다.")
        return False
    
    return True # 작업 성공

def _run_orphan_recovery_engine(base_path, is_test_run=False):
    """
    [컨트롤러로 리팩토링됨] 고아 데이터 복구 워크플로우를 조율합니다.
    OrphanRecoveryService를 사용하여 핵심 로직을 위임합니다.
    """
    logger = LoggerService.get_logger()
    orphan_scoped_logger.log("역추적 엔진 컨트롤러 시작.", base_path=base_path)
    logger.info("\n" + "="*60)
    logger.info("고아 데이터 text_en 역추적을 시작합니다...")

    paths = PathManager(base_path)
    orphan_file_path = paths.get_reverse_extract_orphan_file()

    # --- 1. 데이터 로딩 ---
    orphan_rows = csv_file_service.load_rows_from_csv(orphan_file_path)
    if not orphan_rows:
        logger.warning(f" -> '{os.path.basename(orphan_file_path)}' 파일에 처리할 데이터가 없습니다.")
        return

    # --- 2. 핵심 로직 실행 (서비스 위임) ---
    service = OrphanRecoveryService(orphan_rows)
    classified_results = service.execute(base_path)
    
    recovered_items = classified_results['recovered']
    unrecovered_items = classified_results['unrecovered']

    # --- 3. 결과 파일 저장 ---
    recovered_output_path = paths.get_reverse_extract_recovered_file()
    unrecovered_output_path = paths.get_reverse_extract_unrecovered_file()

    # ==========================================================
    # [요청하신 디버깅 코드 추가 및 개선]
    # ==========================================================
    print("\n" + "!"*20 + " [ 컨트롤러 디버깅 정보 ] " + "!"*18)
    print(f" -> REVERSE_EXTRACT_RECOVERED_SUFFIX: '{REVERSE_EXTRACT_RECOVERED_SUFFIX}'")
    print(f" -> 최종 'recovered_output_path' 경로: '{os.path.abspath(recovered_output_path)}'")
    print("!"*60 + "\n")
    # ==========================================================

    csv_file_service.write_rows_to_csv(recovered_output_path, recovered_items, headers=OUTPUT_HEADERS, is_test_run=is_test_run)
    csv_file_service.write_rows_to_csv(unrecovered_output_path, unrecovered_items, headers=OUTPUT_HEADERS, is_test_run=is_test_run)
    
    # --- 4. 최종 리포트 출력 ---
    logger.info("\n" + "-" * 50)
    logger.info("역추적 작업 요약:")
    if recovered_items:
        logger.info(f"  - [성공] {len(recovered_items)}개 항목의 text_en 복원 완료 -> '{os.path.basename(recovered_output_path)}'")
    if unrecovered_items:
        logger.info(f"  - [실패] {len(unrecovered_items)}개 항목 복원 실패 -> '{os.path.basename(unrecovered_output_path)}'")
    if not recovered_items and not unrecovered_items:
         logger.info("  - 처리할 항목이 없거나, 모든 항목의 복원에 실패했습니다.")
    logger.info("-" * 50)


# ┏────────────────────────────────────────────────────────────────┐
#              [ 데이터 유지보수 (8, 9) 기능 블록 ]
# ┗────────────────────────────────────────────────────────────────┘
def _load_check_cache(base_path):
    """
    [리팩토링됨] AppState를 사용하여 캐시를 관리합니다.
    설정에 따라 파일 또는 메모리에서 Check 결과를 로드하고 검증합니다.
    """
    logger = LoggerService.get_logger()
    current_mod_name = os.path.basename(base_path)
    
    cache_data = None

    if USE_FILE_BASED_CACHE:
        paths = PathManager(base_path)
        cache_file_path = paths._get_path(CHECK_CACHE_FILENAME_SUFFIX)
        if not os.path.exists(cache_file_path):
            logger.error(" [!] 오류: 캐시 파일(_check_cache.json)이 없습니다. 먼저 5. Check 기능을 실행하세요.")
            return None
        try:
            # [수정] with open(...) 대신 read_file_with_fallback 사용
            content, encoding, _ = read_file_with_fallback(cache_file_path)
            if content is None:
                # read_file_with_fallback 내부에서 이미 오류 로그를 남겼으므로 여기서는 종료만 함
                return None

            # .json 파일은 보통 utf-8 계열을 가정하므로, cp949로 읽혔다면 경고
            if encoding == 'cp949':
                logger.warning(f" [경고] 캐시 파일 '{os.path.basename(cache_file_path)}'이(가) 비표준 인코딩({encoding})으로 감지되었습니다.")
            
            cache_data = json.loads(content)
        except json.JSONDecodeError as e:
            logger.error(f" [!] 캐시 파일('{os.path.basename(cache_file_path)}') 파싱 중 오류 발생: {e}")
            return None
        except Exception as e:
            logger.error(f" [!] 캐시 파일 로딩 중 예상치 못한 오류 발생: {e}")
            return None

    else: # 메모리 기반
        if not app_state.get_cache():
            logger.error(" [!] 오류: 메모리에 캐시된 데이터가 없습니다. 먼저 5. Check 기능을 실행하세요.")
            return None
        cache_data = app_state.get_cache()

    # 캐시가 현재 모드에 대한 것인지 확인
    if cache_data.get('generated_for_mod') != current_mod_name:
        logger.error(f" [!] 데이터 불일치 오류: 현재 캐시는 '{cache_data.get('generated_for_mod')}' 모드에 대한 것입니다.")
        logger.error(f"     -> '{current_mod_name}' 모드에 대한 작업을 계속할 수 없습니다. 먼저 5. Check를 실행하세요.")
        return None
        
    return cache_data


def run_consistency_check(is_test_run=False, base_path=None, shared_state=None):
    """
    [리팩토링됨] AppState를 사용하여 캐시를 관리합니다.
    (v4.25.21 - CsvFileService 적용) 파일/메모리 하이브리드 캐시를 사용하여 중복 항목을 통합합니다.
    """
    if base_path is None: base_path = os.getcwd()
    logger = LoggerService.get_logger()
    logger.info("="*60)
    logger.info("5. 번역 일관성 검사를 시작합니다...")

    paths = PathManager(base_path)
    merged_file_path = paths.get_merged_file()
    orphan_file_path = paths.get_orphan_file()

    src_folder = os.path.join(base_path, SOURCE_DATA_FOLDER)
    if not os.path.exists(merged_file_path) or not os.path.isdir(src_folder):
        logger.error(" [!] 검사에 필요한 파일(_merged_kr.csv) 또는 폴더(data_en)가 없습니다.")
        return

    logger.info(f"'{os.path.basename(src_folder)}'에서 최신 텍스트를 추출하고 그룹화합니다...")
    latest_grouped_data = defaultdict(set)
    temp_latest_data, _, _ = extract_all_text_to_map(base_path, src_folder) # {3-tuple: en_str}
    for (src, i, t), en_raw in temp_latest_data.items():
        latest_grouped_data[(src, i, t)].add(standardize_newlines(en_raw))
    
    logger.info(f"'{os.path.basename(merged_file_path)}'에서 기존 데이터를 로드하고 그룹화합니다...")
    existing_grouped_data = defaultdict(list)
    temp_existing_data = load_merged_data(merged_file_path) # {4-tuple: (en, kr)}
    for (src, i, t, en_std), (en, kr) in temp_existing_data.items():
        existing_grouped_data[(src, i, t)].append({'en': en_std, 'kr': kr})

    mismatches, orphans = [], []
    
    for key_3_tuple, existing_items in existing_grouped_data.items():
        if key_3_tuple not in latest_grouped_data:
            for item in existing_items:
                full_key = (*key_3_tuple, item['en'])
                orphans.append({'key': full_key, 'old_en': item['en'], 'kr': item['kr']})
            continue

        latest_en_set = latest_grouped_data[key_3_tuple]
        for item in existing_items:
            old_en_std = item['en']
            
            if old_en_std not in latest_en_set:
                new_en_representative = next(iter(latest_en_set), old_en_std) # Fallback
                mismatches.append({'key': key_3_tuple, 'old_en': old_en_std, 'new_en': new_en_representative, 'kr': item['kr']})

    paths = PathManager(base_path)
    cache_data = {
        'generated_for_mod': os.path.basename(base_path),
        'latest_data_map': temp_latest_data,
        'existing_data_map': temp_existing_data,
        'mismatches': mismatches,
        'orphans': orphans
    }

    if USE_FILE_BASED_CACHE:
        cache_file_path = paths._get_path(CHECK_CACHE_FILENAME_SUFFIX)
        try:
            with open(cache_file_path, 'w', encoding='utf-8') as f:
                json.dump(cache_data, f, indent=2)
            logger.info(f" -> 분석 결과를 '{os.path.basename(cache_file_path)}' 파일에 저장했습니다.")
        except Exception as e:
            logger.error(f" [!] 캐시 파일 저장 중 오류 발생: {e}")
    else:
        app_state.set_cache(cache_data)
        logger.info(" -> 분석 결과를 메모리에 캐시했습니다.")

    if not is_test_run:
        log_path = os.path.join(base_path, CONSISTENCY_CHECK_LOG_FILENAME)
        with open(log_path, 'w', encoding='utf-8-sig') as f:
            f.write(f"번역 일관성 검사 보고서 ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')})\n")
            f.write("="*80 + "\n\n")
            
            if mismatches:
                f.write(f"--- 텍스트 불일치 발견 ({len(mismatches)}개) ---\n")
                f.write("(9번 메뉴의 '업데이트' 대상입니다.)\n\n")
                for item in mismatches:
                    f.write(f"[위치]: {item['key'][0]} -> {item['key'][1]} (type: {item['key'][2]})\n")
                    f.write(f"  - 기존 text_en: {item['old_en']}\n")
                    f.write(f"  - 최신 text_en: {item['new_en']}\n")
                    f.write(f"  - 기존 text_kr: {item['kr']}\n\n")
            
            if orphans:
                f.write(f"--- 고아 번역 데이터 발견 ({len(orphans)}개) ---\n")
                f.write("(9번 메뉴의 '정리' 대상입니다.)\n\n")
                for item in orphans:
                    f.write(f"[위치]: {item['key'][0]} -> {item['key'][1]} (type: {item['key'][2]})\n")
                    f.write(f"  - text_en: {item['old_en']}\n")
                    f.write(f"  - text_kr: {item['kr']}\n\n")

    if not is_test_run and orphans:
        orphan_rows = [{'source_file': item['key'][0], 'id': item['key'][1], 'type': item['key'][2], 
                        'text_en': item['old_en'], 'text_kr': item['kr']} for item in orphans]
        csv_file_service.write_rows_to_csv(orphan_file_path, orphan_rows, OUTPUT_HEADERS, is_test_run)

    logger.info("="*60)
    logger.info("검사 완료.")
    if mismatches or orphans:
        logger.info(f" -> 총 {len(mismatches)}개의 텍스트 불일치와 {len(orphans)}개의 고아 번역을 발견했습니다.")
        if not is_test_run:
            logger.info(f" -> 불일치 상세 내용은 '{CONSISTENCY_CHECK_LOG_FILENAME}' 파일을 확인하십시오.")
            if orphans:
                if os.path.exists(orphan_file_path):
                     logger.info(f" -> 발견된 고아 데이터는 '{os.path.basename(orphan_file_path)}' 파일로 백업되었습니다.")
        logger.info(" -> 8번 메뉴를 통해 발견된 항목들을 자동으로 업데이트/정리할 수 있습니다.")
    else:
        logger.info(" -> 모든 번역 데이터가 최신 버전과 일치합니다.")

    if mismatches or orphans:
        prompt = "\n>> 분석이 완료되었습니다. 지금 바로 8. Update 기능을 실행하시겠습니까? (Enter/y, ESC/n): "
        choice = get_user_input_with_special_keys(prompt).lower()
        if choice in ('', 'y'):
            logger.info("\n" + "="*60)
            logger.info(" -> 8. Update 기능을 즉시 실행합니다...")
            run_consolidate_duplicates(is_test_run, base_path, shared_state)


def _compare_files_engine(file_a_path, file_b_path):
    """
    [엔진] 두 CSV 파일의 내용을 비교하여 차이점과 원본 데이터 맵을 분석하여 반환합니다.
    [리팩토링됨] text_processor_service를 사용하여 텍스트를 일관되게 정규화합니다.
    """
    logger = LoggerService.get_logger()
    logger.info(f"'{os.path.basename(file_a_path)}'와 '{os.path.basename(file_b_path)}'의 내용을 비교합니다.")
    
    data_a_list = csv_file_service.load_rows_from_csv(file_a_path)
    data_b_list = csv_file_service.load_rows_from_csv(file_b_path)

    # --- [핵심 수정된 부분 시작] ---
    # 리스트를 맵으로 변환하여 비교 효율을 높입니다.
    # text_processor_service.process를 사용하여 키와 값을 정규화합니다.
    data_a = { 
        (row['source_file'], row['id'], row['type'], text_processor_service.process(row.get('text_en', ''))): 
        (text_processor_service.process(row.get('text_en', '')), text_processor_service.process(row.get('text_kr', ''))) 
        for row in data_a_list 
    }
    data_b = { 
        (row['source_file'], row['id'], row['type'], text_processor_service.process(row.get('text_en', ''))): 
        (text_processor_service.process(row.get('text_en', '')), text_processor_service.process(row.get('text_kr', ''))) 
        for row in data_b_list 
    }
    # --- [핵심 수정된 부분 끝] ---

    if data_a == data_b:
        return None, data_a, data_b

    keys_a = set(data_a.keys())
    keys_b = set(data_b.keys())
    
    added_keys = keys_a - keys_b
    removed_keys = keys_b - keys_a
    common_keys = keys_a.intersection(keys_b)
    modified_keys = {k for k in common_keys if data_a[k] != data_b[k]}
    
    differences = {
        'added': added_keys,
        'removed': removed_keys,
        'modified': modified_keys
    }
    
    return differences, data_a, data_b

def _prepare_grouped_file_details(keys_set, title_prefix=""):
    """
    주어진 4-tuple 키 셋을 source_file별로 그룹화하고,
    리포트 렌더링에 적합한 List[Dict] 형태로 반환합니다.
    """
    if not keys_set:
        return []

    grouped_by_file = defaultdict(int)
    for key in keys_set:
        source_file_rel_path = key[0] # 4-tuple의 첫 번째 요소가 source_file
        grouped_by_file[source_file_rel_path] += 1

    report_items = []
    # 파일별 개수를 내림차순으로 정렬
    sorted_files = sorted(grouped_by_file.items(), key=lambda item: item[1], reverse=True)

    for i, (file_path, count) in enumerate(sorted_files):
        # 상위 5개 파일만 자세히 보여주고, 나머지는 '기타 X개 파일'로 요약
        if i < 5:
            report_items.append({
                "label": os.path.basename(file_path),
                "value": f"{count}개 항목",
                "level": 3,
                "label_prefix": "   └─ " # 3단계 들여쓰기
            })
        elif i == 5 and len(sorted_files) > 5:
            remaining_count = sum(c for fp, c in sorted_files[5:])
            report_items.append({
                "label": f"기타 {len(sorted_files) - 5}개 파일",
                "value": f"{remaining_count}개 항목",
                "level": 3,
                "label_prefix": "   └─ "
            })
            break # 더 이상 출력할 필요 없음

    return report_items


def _extract_and_save_changes_engine(output_path, differences, merged_data, master_data, is_test_run):
    """[엔진] 두 데이터셋 간의 차이점을 추출하여 상세 내용이 담긴 CSV 파일로 저장합니다."""
    logger = LoggerService.get_logger()
    changes_to_write = []
    
    # 헤더 정의
    headers = ['status', 'source_file', 'id', 'type', 'text_en', 'old_text_kr', 'new_text_kr']

    # 1. 추가된 항목 (ADDED)
    for key in sorted(list(differences['added'])):
        en_text, kr_text = merged_data[key]
        changes_to_write.append({
            'status': 'ADDED',
            'source_file': key[0], 'id': key[1], 'type': key[2],
            'text_en': en_text,
            'old_text_kr': '',
            'new_text_kr': kr_text
        })

    # 2. 수정된 항목 (MODIFIED)
    for key in sorted(list(differences['modified'])):
        new_en, new_kr = merged_data[key]
        old_en, old_kr = master_data[key]
        changes_to_write.append({
            'status': 'MODIFIED',
            'source_file': key[0], 'id': key[1], 'type': key[2],
            'text_en': new_en, # text_en이 변경되었을 수도 있으므로 최신 버전 표시
            'old_text_kr': old_kr,
            'new_text_kr': new_kr
        })

    # 3. 삭제된 항목 (REMOVED)
    for key in sorted(list(differences['removed'])):
        en_text, kr_text = master_data[key]
        changes_to_write.append({
            'status': 'REMOVED',
            'source_file': key[0], 'id': key[1], 'type': key[2],
            'text_en': en_text,
            'old_text_kr': kr_text,
            'new_text_kr': ''
        })

    csv_file_service.write_rows_to_csv(output_path, changes_to_write, headers=headers, is_test_run=is_test_run)
    print("\n" + "="*60 + "\n")
    logger.info(f" -> 총 {len(changes_to_write)}개의 변경 사항을 '{os.path.basename(output_path)}' 파일에 추출했습니다.")


def _sync_engine_overwrite(source_path, target_path, is_test_run):
    """
    [v-최종 리팩토링] 소스 파일로 타겟 파일을 안전하게 덮어씁니다.
    타겟이 마스터 파일인 경우 MasterFileService를, 그 외에는 CsvFileService를 사용합니다.
    """
    logger = LoggerService.get_logger()
    base_path = os.path.dirname(source_path)
    paths = PathManager(base_path)

    if not os.path.exists(source_path):
        logger.error(f" [!] 동기화 원본 파일 '{os.path.basename(source_path)}'이(가) 없습니다.")
        return False, True # 작업 실패, 건너뜀

    # filecmp를 사용하여 실제 변경이 있는지 확인 (불필요한 쓰기 및 백업 방지)
    if os.path.exists(target_path) and filecmp.cmp(source_path, target_path, shallow=False):
        logger.info(f" -> 두 파일('{os.path.basename(source_path)}', '{os.path.basename(target_path)}')의 내용이 이미 동일하여 동기화를 건너뜁니다.")
        return True, True # 작업 성공, 건너뜀

    source_data = csv_file_service.load_rows_from_csv(source_path)

    # 타겟 파일의 경로가 현재 모드의 마스터 파일 경로와 일치하는지 확인
    if target_path == paths.get_master_file():
        logger.info(f" -> 마스터 파일 동기화 감지. MasterFileService를 사용하여 안전하게 덮어쓰기를 진행합니다.")
        master_service = MasterFileService(base_path, csv_file_service)
        master_service.save_data(source_data, is_test_run=is_test_run)
        return True, False
    else:
        # --- 타겟이 마스터 파일이 아닌 경우 (예: _STAGING_kr.csv) ---
        logger.info(f" -> 일반 파일 동기화. '{os.path.basename(source_path)}' -> '{os.path.basename(target_path)}'")
        
        # [핵심 수정] CsvFileService를 사용하여 백업과 쓰기를 한번에 처리
        # 대상 파일의 기존 헤더를 유지하기 위해 헤더를 미리 읽어옴
        target_headers = None
        if os.path.exists(target_path):
            try:
                with open(target_path, 'r', encoding=INPUT_FILE_ENCODING, newline='') as f:
                    reader = csv.reader(f)
                    target_headers = next(reader)
            except Exception:
                logger.warning(f" -> 대상 파일 '{os.path.basename(target_path)}'의 헤더를 읽을 수 없어 자동 감지 모드로 전환합니다.")

        # 헤더가 없거나 읽지 못한 경우, 소스 데이터 기준으로 자동 감지
        if not target_headers and source_data:
            target_headers = list(source_data[0].keys())
        
        csv_file_service.write_rows_to_csv(
            target_path,
            source_data,
            headers=target_headers,
            create_backup_on_write=True,
            is_test_run=is_test_run
        )
        return True, False


def _manual_sync_ui_engine(source_data, target_data, logger):
    """
    [UI 엔진] 두 데이터셋을 비교하여 사용자에게 충돌 해결 UI를 제공하고,
    최종 병합된 데이터셋을 반환합니다. 취소 시 None을 반환합니다.
    """
    # 3-tuple (source, id, type)을 기준으로 그룹화
    grouped_source = defaultdict(set)
    for k, v in source_data.items(): grouped_source[k[:3]].add(v)

    grouped_target = defaultdict(set)
    for k, v in target_data.items(): grouped_target[k[:3]].add(v)
    
    all_loc_keys = sorted(list(set(grouped_source.keys()) | set(grouped_target.keys())))
    
    conflicts = []
    for loc_key in all_loc_keys:
        source_versions = grouped_source.get(loc_key, set())
        target_versions = grouped_target.get(loc_key, set())
        if source_versions and target_versions and source_versions != target_versions:
            conflicts.append({'loc_key': loc_key, 'source_versions': source_versions, 'target_versions': target_versions})
            
    if not conflicts:
        logger.info(" -> 수동으로 해결해야 할 충돌 항목이 없습니다.")
        return None

    logger.info(f" -> {len(conflicts)}개의 충돌 그룹을 발견했습니다. 수동 병합을 시작합니다.")
    
    # 최종 결과물은 원본 target_data의 복사본에서 시작
    final_data_map = dict(target_data)
    # ... (기존 run_sync_master_file의 while 루프 및 UI 로직을 여기에 통합) ...
    # ... (이 로직은 매우 길고 복잡하므로, 핵심 아이디어는 기존 코드를 여기로 옮기는 것입니다) ...
    
    # 이 부분은 매우 복잡하므로, 지금은 더 간단한 접근법으로 대체하겠습니다.
    # 복잡한 수동 병합 대신, 우선 9번 메뉴가 자동 동기화와 동일하게 동작하도록 수정하는 것이
    # 전체 리팩토링 흐름에 더 적합해 보입니다.

    # 임시 제안: 복잡한 수동 병합 UI 엔진은 다음 단계로 미루고,
    # 우선 9번 메뉴 전체를 단순화하는 것이 어떨까요?
    # 예를 들어 9번 메뉴가 "merged -> master" 또는 "master -> merged" 중
    # 덮어쓰기 방향을 선택하는 기능으로 바꾼다면 코드가 훨씬 간결해집니다.
    
    # 사용자의 의도를 다시 확인하는 것이 좋겠습니다.
    # 지금 단계에서는 복잡한 UI 엔진을 새로 만드는 것보다,
    # 기존 `run_sync_master_file`을 정리하는 데 집중하겠습니다.
    pass # 이 함수는 다음 단계에서 구현하겠습니다.



# ┏────────────────────────────────────────────────────────────────┐
#
#          [ 신규 기능: 원본 파일 역방향 동기화 (Reverse Sync) ]
#
# ┗────────────────────────────────────────────────────────────────┘

def run_reverse_sync(is_test_run=False, base_path=None, shared_state=None):
    """(신규) 게임 설치 폴더의 원본(data)을 로컬 작업 폴더(data_en)로 가져옵니다."""
    if base_path is None: base_path = os.getcwd()
    logger = LoggerService.get_logger()
    
    display_name = get_mod_display_name(base_path)
    logger.info(f"\n[{display_name}] 원본 파일 역방향 동기화를 시작합니다...")

    # 1. 로컬 경로 및 원본 모드 ID 결정
    local_mod_name = os.path.basename(base_path)
    local_data_en_path = os.path.join(base_path, SOURCE_DATA_FOLDER.lstrip('./\\'))
    if MOD_USE_PREFIX_FILTER and local_mod_name.startswith(MOD_FOLDER_PREFIX):
        source_mod_id = local_mod_name[len(MOD_FOLDER_PREFIX):]
    else: source_mod_id = local_mod_name
    source_mod_path = os.path.join(DESTINATION_BASE_PATH, source_mod_id)
    source_data_path = os.path.join(source_mod_path, 'data')
    if not os.path.isdir(DESTINATION_BASE_PATH) or not os.path.isdir(source_mod_path) or not os.path.isdir(source_data_path):
        logger.warning(f" -> [건너뛰기] 원본 또는 대상 경로가 유효하지 않습니다.")
        return

    # [핵심 개선] 사용자 확인 로직
    confirm = False
    if shared_state and shared_state.get('auto_confirm_all'):
        logger.info(" -> [자동 실행] '모두 예' 옵션에 따라 자동으로 덮어쓰기를 실행합니다.")
        confirm = True
    elif not is_test_run:
        while True:
            print("\n" + "!"*60)
            logger.warning(" [경고!] 이 작업은 로컬 원본 파일을 덮어씁니다.")
            print(f"  - [원본]: {source_data_path}")
            print(f"  - [대상]: {local_data_en_path}")
            print("!"*60)
            
            user_input = input("\n>> 정말로 덮어쓰시겠습니까? (y:예 / n:아니오 / a:모두 예 / q:중단): ").strip().lower()

            if user_input == 'y':
                confirm = True
                break
            elif user_input == 'n':
                logger.info(" -> 이번 모드의 작업을 건너뜁니다.")
                return
            elif user_input == 'q':
                if shared_state: shared_state['quit_all'] = True
                logger.info(" -> 작업을 중단합니다...")
                return
            elif user_input == 'a':
                if shared_state:
                    print("\n" + "-"*20 + " [최종 확인] " + "-"*20)
                    logger.warning("'모두 예'를 선택했습니다. 이후 모든 모드에 대해 자동으로 덮어쓰기를 진행합니다.")
                    final_confirm = input(">> 정말로 계속하시겠습니까? (y/n): ").strip().lower()
                    if final_confirm == 'y':
                        shared_state['auto_confirm_all'] = True
                        confirm = True
                        break
                    else:
                        print(" -> '모두 예'를 취소했습니다. 다시 선택해주세요.")
                else: # 단일 모드에서는 'a'가 'y'와 동일하게 동작
                    confirm = True
                    break
            else:
                print(" [!] 잘못된 입력입니다. y, n, a, q 중 하나를 입력하세요.")

    if not confirm and not is_test_run:
        return

    # 5. 실행
    logger.info(" -> 파일 복사를 시작합니다...")
    if is_test_run:
        logger.info("  (테스트 모드이므로 실제 파일 작업은 수행되지 않습니다.)")

    # 기존 data_en이 있으면 삭제 후 복사하는 것이 더 안전하고 깨끗합니다.
    if os.path.exists(local_data_en_path) and not is_test_run:
        logger.info(f"  -> 기존 '{os.path.basename(local_data_en_path)}' 폴더를 삭제합니다.")
        shutil.rmtree(local_data_en_path)

    copied_count = copy_directory_contents(source_data_path, local_data_en_path, is_test_run)

    if copied_count > 0:
        logger.info(f" -> [성공] 총 {copied_count}개의 파일을 '{os.path.basename(local_data_en_path)}' 폴더에 복사했습니다.")
    else:
        logger.warning(" -> [알림] 복사할 파일이 원본 'data' 폴더에 없습니다.")


# ┏────────────────────────────────────────────────────────────────┐
#
#          [ 모드 정보(mod_info.json) 동기화 (Sync Mod Info) ]
#
# ┗────────────────────────────────────────────────────────────────┘

def _mod_info_sync_engine(base_path, is_test_run, shared_state):
    """[엔진] 단일 모드에 대한 mod_info.json 동기화를 수행합니다."""
    logger = LoggerService.get_logger()
    
    local_mod_name = os.path.basename(base_path)
    
    # 1. 소스 및 타겟 경로 계산
    mod_id = local_mod_name
    if MOD_USE_PREFIX_FILTER and local_mod_name.startswith(MOD_FOLDER_PREFIX):
        mod_id = local_mod_name[len(MOD_FOLDER_PREFIX):]
    
    source_mod_path = os.path.join(DESTINATION_BASE_PATH, mod_id)
    source_info_file = os.path.join(source_mod_path, 'mod_info.json')
    target_info_file = os.path.join(base_path, 'mod_info.json')

    # 2. 유효성 검사
    if not os.path.exists(source_info_file):
        logger.warning(f" -> [건너뛰기] 게임 폴더에서 원본 'mod_info.json'을 찾을 수 없습니다: {source_mod_path}")
        return

    # 3. 파일 비교 및 사용자 확인
    perform_copy = False
    if not os.path.exists(target_info_file):
        logger.info(f" -> 로컬 'mod_info.json'이 없어 새로 복사합니다.")
        perform_copy = True
    elif not filecmp.cmp(source_info_file, target_info_file, shallow=False):
        logger.warning(f" -> 로컬 'mod_info.json'이 게임 폴더 버전과 다릅니다. 업데이트가 필요합니다.")
        perform_copy = True
    else:
        logger.info(f" -> 로컬 'mod_info.json'은 이미 최신 버전입니다.")
        return

    if perform_copy:
        # 4. 안전 장치: 사용자 확인
        confirm = False
        if shared_state and shared_state.get('auto_confirm_all'):
            confirm = True
            logger.info(" -> [자동 실행] '모두 예' 옵션에 따라 자동으로 덮어쓰기를 실행합니다.")
        elif not is_test_run:
            print("\n" + "!"*60)
            logger.warning(f" [주의] '{local_mod_name}'의 'mod_info.json' 파일을 덮어씁니다.")
            print(f"  - 원본: {source_info_file}")
            print(f"  - 대상: {target_info_file}")
            print("!"*60)
            prompt = ">> 계속하시겠습니까? (Enter/y: 예, ESC/n: 아니오, a: 모두 예, q: 중단): "
            user_input = get_user_input_with_special_keys(prompt).lower()

            if user_input in ('y', ''):
                confirm = True
            elif user_input == '__esc__' or user_input == 'n':
                logger.info(" -> 이번 모드의 작업을 건너뜁니다."); return
            elif user_input == '__quit__' or user_input == 'q':
                if shared_state: shared_state['quit_all'] = True
                logger.info(" -> 작업을 중단합니다..."); return
            elif user_input == 'a':
                if shared_state: shared_state['auto_confirm_all'] = True
                confirm = True

        if confirm or is_test_run:
            # 5. 파일 복사 실행
            logger.info(" -> 파일 복사를 시작합니다...")
            if is_test_run:
                logger.info("  (테스트 모드이므로 실제 파일 작업은 수행되지 않습니다.)")
            else:
                try:
                    shutil.copy2(source_info_file, target_info_file)
                    logger.info(f" -> [성공] 'mod_info.json' 동기화를 완료했습니다.")
                except Exception as e:
                    logger.error(f"  [오류] 파일 복사 중 문제가 발생했습니다: {e}")



def run_mod_info_sync(is_test_run=False, base_path=None, shared_state=None):
    """[컨트롤러] 모드 정보 동기화 작업을 시작합니다."""
    if base_path is None: base_path = os.getcwd()
    display_name = get_mod_display_name(base_path)
    logger = LoggerService.get_logger()
    logger.info(f"\n[{display_name}] 'mod_info.json' 동기화를 시작합니다...")
    
    # 실제 작업은 엔진 함수에 위임
    _mod_info_sync_engine(base_path, is_test_run, shared_state)



# ┏────────────────────────────────────────────────────────────────┐
#
#          [ 신규 기능: 원본 파일 정방향 동기화 (Forward Sync) ]
#
# ┗────────────────────────────────────────────────────────────────┘

def run_forward_sync(is_test_run=False, base_path=None, shared_state=None):
    """(개선) 로컬(data_en)을 게임 폴더(data)에 덮어씁니다. (일괄 처리/중단 기능 추가)"""
    if base_path is None: base_path = os.getcwd()
    logger = LoggerService.get_logger()
    
    display_name = get_mod_display_name(base_path)
    logger.info(f"\n[{display_name}] 원본 파일 정방향 동기화(Forward Sync)를 시작합니다...")

    # 1. 로컬 소스 경로 및 대상 모드 ID 결정
    local_mod_name = os.path.basename(base_path)
    local_data_en_path = os.path.join(base_path, SOURCE_DATA_FOLDER.lstrip('./\\'))
    
    if MOD_USE_PREFIX_FILTER and local_mod_name.startswith(MOD_FOLDER_PREFIX):
        dest_mod_id = local_mod_name[len(MOD_FOLDER_PREFIX):]
    else:
        dest_mod_id = local_mod_name

    # 2. 게임 폴더의 대상 경로 조합
    dest_mod_path = os.path.join(DESTINATION_BASE_PATH, dest_mod_id)
    dest_data_path = os.path.join(dest_mod_path, 'data')

    # 3. 유효성 검사
    if not os.path.isdir(local_data_en_path):
        # 이 검사는 forward_sync_mod_validation_check에서도 수행하지만, 단일 모드 실행을 위해 중복 검사합니다.
        logger.warning(f" -> [건너뛰기] 소스 폴더 '{os.path.basename(local_data_en_path)}'를 찾을 수 없습니다.")
        return
    
    confirm = False
    if shared_state and shared_state.get('auto_confirm_all'):
        logger.info(" -> [자동 실행] '모두 예' 옵션에 따라 자동으로 덮어쓰기를 실행합니다.")
        confirm = True
    elif not is_test_run:
        while True:
            print("\n" + "!"*70)
            logger.critical(" [!! 매우 위험 !!] 이 작업은 실제 게임 모드 파일을 영구적으로 덮어씁니다.")
            print(f"\n  - [로컬 소스]: {local_data_en_path}")
            print(f"  - [게임 폴더 대상]: {dest_data_path}")
            print("!"*70)

            user_input = input(f"\n>> 정말로 덮어쓰시겠습니까? (y:예 / n:아니오 / a:모두 예 / q:중단): ").strip().lower()

            if user_input == 'y':
                confirm = True
                break
            elif user_input == 'n':
                logger.info(" -> 이번 모드의 작업을 건너뜁니다.")
                return
            elif user_input == 'q':
                if shared_state: shared_state['quit_all'] = True
                logger.info(" -> 작업을 중단합니다...")
                return
            elif user_input == 'a':
                if shared_state:
                    print("\n" + "-"*20 + " [최종 확인] " + "-"*20)
                    logger.critical("'모두 예'를 선택했습니다. 이후 모든 모드의 게임 파일이 자동으로 덮어쓰여집니다.")
                    final_confirm = input(">> 정말로 계속하시겠습니까? (y/n): ").strip().lower()
                    if final_confirm == 'y':
                        shared_state['auto_confirm_all'] = True
                        confirm = True
                        break
                    else:
                        print(" -> '모두 예'를 취소했습니다. 다시 선택해주세요.")
                else: # 단일 모드에서는 'a'가 'y'와 동일하게 동작
                    confirm = True
                    break
            else:
                print(" [!] 잘못된 입력입니다. y, n, a, q 중 하나를 입력하세요.")

    if not confirm and not is_test_run:
        return

    # 5. 실행
    logger.info(" -> 게임 폴더의 파일 덮어쓰기를 시작합니다...")
    if is_test_run:
        logger.info("  (테스트 모드이므로 실제 파일 작업은 수행되지 않습니다.)")
        # 테스트 모드에서도 복사될 파일 수를 시뮬레이션 할 수 있습니다.
        copied_count = sum([len(files) for r, d, files in os.walk(local_data_en_path)])
    else:
        # 실제 실행: 대상 폴더 삭제 후 복사
        if os.path.exists(dest_data_path):
            logger.info(f"  -> 기존 게임 모드의 '{os.path.basename(dest_data_path)}' 폴더를 삭제합니다.")
            shutil.rmtree(dest_data_path)
        
        copied_count = copy_directory_contents(local_data_en_path, dest_data_path, is_test_run)

    if copied_count > 0:
        logger.info(f" -> [성공] 총 {copied_count}개의 파일을 게임 폴더의 '{os.path.basename(dest_data_path)}' 폴더에 복사했습니다.")
    else:
        logger.warning(" -> [알림] 로컬 소스 폴더가 비어있어 복사할 파일이 없습니다.")


# ┏────────────────────────────────────────────────────────────────┐

#              [ run_consolidate_duplicates 함수 ]

# ┗────────────────────────────────────────────────────────────────┘

def run_consolidate_duplicates(is_test_run=False, base_path=None, shared_state=None):
    """
    (v4.25.21 - CsvFileService 적용) 파일/메모리 하이브리드 캐시를 사용하여 중복 항목을 통합합니다.
    """
    if base_path is None: base_path = os.getcwd()
    logger = LoggerService.get_logger()

    logger.info("="*60)
    logger.info("8. 중복 항목 통합을 시작합니다...")

    # --- 1. 캐시 데이터 로드 및 검증 ---
    cache = _load_check_cache(base_path)
    if not cache:
        pause_for_user()
        return

    # 필요한 데이터를 캐시에서 추출
    existing_data = cache['existing_data_map']
    latest_data_map = cache['latest_data_map']

    # --- 1. 경로 설정 및 데이터 로딩 ---
    if USE_DYNAMIC_FILE_PATHS:
        folder_name = os.path.basename(base_path)
        merged_file_path = os.path.join(base_path, f"{folder_name}{MERGED_FILENAME_SUFFIX}")
        missing_file_path = os.path.join(base_path, f"{folder_name}{MISSING_TRANSLATION_FILENAME}")
    else:
        bname = os.path.splitext(EXPORT_OUTPUT_FILENAME_STATIC)[0].replace('_translation_source', '')
        merged_file_path = os.path.join(base_path, f"{bname}{MERGED_FILENAME_SUFFIX}")
        missing_file_path = os.path.join(base_path, MISSING_TRANSLATION_FILENAME_STATIC)

    src_folder = os.path.join(base_path, SOURCE_DATA_FOLDER)
    if not os.path.exists(merged_file_path):
        logger.error(f" [!] 작업 대상 파일 '{os.path.basename(merged_file_path)}'이 없습니다."); return

    logger.info(" -> 최신 원본(data_en) 및 기존 작업 파일(_merged_kr.csv)을 분석합니다...")
    latest_data_map, _, _ = extract_all_text_to_map(base_path, src_folder) # {3-tuple: en}
    existing_data = load_merged_data(merged_file_path) # {4-tuple: (en, kr)}

    # --- 2. 중복 그룹 식별 ---
    grouped_data = {}
    for (s, i, t, en), (en_val, kr_val) in existing_data.items():
        key_3_tuple = (s, i, t)
        if key_3_tuple not in grouped_data:
            grouped_data[key_3_tuple] = []
        grouped_data[key_3_tuple].append({'en': en, 'kr': kr_val})
    
    groups_to_consolidate = {k: v for k, v in grouped_data.items() if len(v) > 1}
    # final_data_map = {k: v[0] for k, v in grouped_data.items() if len(v) == 1} # 비중복 항목은 미리 최종본에 추가
    logger.debug(f"--- [DEBUG] 데이터 분석 결과 ---")
    logger.debug(f"[DEBUG] 총 {len(grouped_data)}개의 고유 위치 (3-tuple keys) 발견됨.")
    logger.debug(f"[DEBUG] 이 중 {len(groups_to_consolidate)}개의 위치에서 중복 항목 발견됨.")


    # --- 3. 사용자 모드 선택 ---
    print("\n" + "-"*20 + " [중복 항목 통합 모드 선택] " + "-"*20)
    display_name = get_mod_display_name(base_path)
    print(f"  [대상 폴더]: {os.path.basename(base_path)}")
    print(f"\n총 {len(groups_to_consolidate)}개의 위치에서 중복된 버전의 텍스트가 발견되었습니다.\n")
    print("1. 자동 모드 (권장)")
    print("   - 최신 원본(data_en)을 기준으로 text_en을 확정합니다.")
    print("   - 확정된 text_en과 짝이 맞는 번역이 있으면 계승하고, 없으면 비웁니다.")
    print("\n2. 수동 모드 (상세 확인)")
    print("   - 각 중복 그룹마다 남길 text_en과 text_kr을 직접 선택합니다.")
    print("\n3. 취소 (메인 메뉴로)")
    
    if not groups_to_consolidate:
        logger.info(" -> 중복으로 통합해야 할 항목을 찾지 못했습니다. 모든 데이터가 고유합니다.")

    choice = input("\n>> 원하는 작업 번호를 선택하세요 (1, 2, 3): ").strip()

    if not groups_to_consolidate and choice in ['1', '2']:
        logger.warning(" -> 처리할 중복 항목이 없으므로 작업을 진행할 수 없습니다.")
        return

    # --- 4. 모드별 처리 로직 ---
    quit_flag = False
    final_data_map = {}
    logger.debug(f"--- [DEBUG] 처리 로직 시작 (선택: {choice}) ---")
    logger.debug(f"[DEBUG] final_data_map 초기화됨 (현재 크기: {len(final_data_map)})")

    if choice == '1': # 자동 모드
        logger.debug(f"[DEBUG] 자동 모드 선택됨.")
        final_data_map.update({k: v[0] for k, v in grouped_data.items() if len(v) == 1})
        logger.debug(f"[DEBUG] 비중복 항목 {len(final_data_map)}개 final_data_map에 추가됨.")

        confirm = input("\n>> 자동 모드로 중복 항목 통합을 진행하시겠습니까? (y/n): ").strip().lower()
        if confirm == 'y':
            logger.debug(f"[DEBUG] 자동 모드 처리 시작: {len(groups_to_consolidate)}개 그룹 대상.")

            for key_3_tuple, items in groups_to_consolidate.items():
                logger.debug(f"  [DEBUG] >> 그룹 처리 중: {key_3_tuple[1]}")
                rep_en = latest_data_map.get(key_3_tuple)
                logger.debug(f"    [DEBUG] 최신 text_en (from latest_data_map): {'존재함' if rep_en else '없음 (고아 그룹)'}")
                if not rep_en: rep_en = max([item['en'] for item in items], key=len)
                rep_kr = ''
                for item in items:
                    if item['en'] == rep_en and item['kr'].strip():
                        rep_kr = item['kr']; break
                logger.debug(f"    [DEBUG] 최종 확정된 en: \"{rep_en[:30]}...\"")
                logger.debug(f"    [DEBUG] 최종 확정된 kr: \"{rep_kr[:30]}...\"")
                final_data_map[key_3_tuple] = {'en': rep_en, 'kr': rep_kr}
        else:
            quit_flag = True

    elif choice == '2': # 수동 모드
        logger.debug(f"[DEBUG] 수동 모드 선택됨.")
        for key, value_list in grouped_data.items():
            final_data_map[key] = max(value_list, key=lambda x: len(x['en']))
        logger.debug(f"[DEBUG] 전체 데이터 복사본으로 final_data_map 초기화됨 (크기: {len(final_data_map)})")

        for idx, (key_3_tuple, items) in enumerate(groups_to_consolidate.items()):
            logger.debug(f"  [DEBUG] >> 수동 처리 그룹 {idx+1}: {key_3_tuple[1]}")
            print("="*60)
            print(f"[ 중복 항목 통합 (수동 모드) - {idx+1} / {len(groups_to_consolidate)} ]")
            print(f"- 위치: {key_3_tuple[0]} | ID: {key_3_tuple[1]} | Type: {key_3_tuple[2]}")
            print("="*60)

            latest_en = latest_data_map.get(key_3_tuple)
            if latest_en: print(f"[A] 최신 원본 (data_en 기준):\n    \"{latest_en}\"\n")

            print("---- [B] 선택 옵션 ----")
            en_options = {i+1: item['en'] for i, item in enumerate(items)}
            kr_options = {i+1+len(items): item['kr'] for i, item in enumerate(items) if item['kr'].strip()}
            
            print("[ text_en 선택 ]")
            if latest_en: print("(a) 최신 원본 사용")
            for i, en in en_options.items(): print(f"({i}) \"{en}\"")

            print("\n[ text_kr 선택 ]")
            for i, kr in kr_options.items(): print(f"({i}) \"{kr}\"")
            last_kr_idx = max(kr_options.keys()) if kr_options else len(items)
            print(f"({last_kr_idx+1}) [ 직접 새로운 번역 입력 ]")
            print(f"({last_kr_idx+2}) [ 번역 없음 (비우기) ]")
            
            # 1. text_en 선택
            final_en = ''
            while True:
                en_choice = input("\n>> 최종적으로 남길 text_en의 번호를 선택하세요 (q: 중단): ").strip().lower()
                if en_choice == 'q': quit_flag = True; break
                if en_choice == 'a' and latest_en: final_en = latest_en; break
                if en_choice.isdigit() and int(en_choice) in en_options: final_en = en_options[int(en_choice)]; break
                print(" [!] 잘못된 입력입니다.")
            if quit_flag: break

            # 2. text_kr 선택
            final_kr = ''
            while True:
                kr_choice = input(">> 선택한 text_en에 연결할 text_kr의 번호를 선택하세요 (q: 중단): ").strip().lower()
                if kr_choice == 'q': quit_flag = True; break
                if kr_choice.isdigit():
                    choice_num = int(kr_choice)
                    if choice_num in kr_options: final_kr = kr_options[choice_num]; break
                    elif choice_num == last_kr_idx + 1: final_kr = input(">> 새로운 번역문을 입력하세요: ").strip(); break
                    elif choice_num == last_kr_idx + 2: final_kr = ''; break
                print(" [!] 잘못된 입력입니다.")
            if quit_flag: break

            final_data_map[key_3_tuple] = {'en': final_en, 'kr': final_kr}
    else:
        quit_flag = True

    if quit_flag:
        logger.info(" -> 작업을 취소했습니다."); return

    # --- 5. 최종 파일 쓰기 ---
    logger.info(" -> 모든 중복 항목 처리가 완료되었습니다. 최종 파일을 생성합니다...")
    logger.debug(f"--- [DEBUG] 최종 파일 쓰기 시작 ---")
    logger.debug(f"[DEBUG] final_data_map의 최종 크기: {len(final_data_map)}")
    
    # 최종 데이터 포맷 변환
    final_data_list = [{'source_file': k[0], 'id': k[1], 'type': k[2], 'text_en': v['en'], 'text_kr': v['kr']} for k,v in final_data_map.items()]
    missing_data_list = [row for row in final_data_list if not row['text_kr'].strip()]

    logger.debug(f"[DEBUG] 최종 저장될 항목 수: {len(final_data_list)}")
    logger.debug(f"[DEBUG] missing으로 분류될 항목 수: {len(missing_data_list)}")

    # 파일 쓰기
    if not is_test_run:
        if USE_FILE_BASED_CACHE:
            paths = PathManager(base_path)
            cache_file_path = paths._get_path(CHECK_CACHE_FILENAME_SUFFIX)
            if os.path.exists(cache_file_path):
                os.remove(cache_file_path)
                logger.info(" -> 사용된 캐시 파일을 정리했습니다.")
        else:
            app_state.clear_cache()
            logger.info(" -> 메모리 캐시를 정리했습니다.")
        
        csv_file_service.write_rows_to_csv(merged_file_path, final_data_list, headers=OUTPUT_HEADERS)
        csv_file_service.write_rows_to_csv(missing_file_path, missing_data_list, headers=OUTPUT_HEADERS)
    
    logger.info(f" -> '{os.path.basename(merged_file_path)}' 파일에 총 {len(final_data_list)}개의 통합된 항목을 저장했습니다.")
    if missing_data_list:
        logger.warning(f" -> '{os.path.basename(missing_file_path)}'에 {len(missing_data_list)}개의 번역 필요한 항목이 업데이트되었습니다.")


# ┏────────────────────────────────────────────────────────────────┐
#
#              [ 7번 기능: 스테이징 마스터 파일 관리 ]
#
# ┗────────────────────────────────────────────────────────────────┘

def _select_columns_ui(prompt, available_columns, allow_multiple=True):
    """(스테이징 헬퍼) 사용자에게 컬럼 목록을 보여주고 선택받는 공통 UI 함수."""
    logger = LoggerService.get_logger()
    
    while True:
        print("\n" + prompt)
        for i, col in enumerate(available_columns, 1):
            print(f"  [{i}] {col}")

        if "추천 조합" in prompt:
            print("\n[ 추천 조합 ]")
            print(" - ID는 같지만 원문(text_en)이 다른 항목 찾기 (가장 일반적): 2 4")
            print(" - Base ID가 같지만 원문(text_en)이 다른 항목 찾기 (tips.json 등): 3 5")

        if allow_multiple:
            print("\n>> 번호를 공백으로 구분하여 입력하세요 (예: 1 3).")
        else:
            print("\n>> 번호 하나만 입력하세요.")

        user_input = get_user_input_with_special_keys("선택: ")
        if user_input in ('__QUIT__', '__ESC__'):
            return None

        if not user_input:
            logger.warning(" [!] 아무것도 입력되지 않았습니다. 다시 시도하세요.")
            continue

        try:
            selected_indices = [int(i) - 1 for i in user_input.split()]
            
            if not allow_multiple and len(selected_indices) > 1:
                logger.warning(" [!] 하나의 번호만 입력해야 합니다.")
                continue

            chosen_columns = [available_columns[i] for i in selected_indices if 0 <= i < len(available_columns)]
            
            if len(chosen_columns) == len(selected_indices):
                return chosen_columns if allow_multiple else chosen_columns[0]
            else:
                logger.warning(" [!] 목록에 없는 번호가 포함되어 있습니다.")
        except ValueError:
            logger.warning(" [!] 유효한 숫자를 입력하세요.")


def _run_conditional_copy_engine(source_path, target_path, match_columns, update_columns, is_test_run=False, headers=None):
    """
    [v3 - 리포트 기능 추가] 조건부 복사/업데이트의 핵심 로직을 수행하고, 작업 결과를 딕셔너리로 반환합니다.
    """
    logger = LoggerService.get_logger()
    
    source_data = csv_file_service.load_rows_from_csv(source_path)
    target_data = csv_file_service.load_rows_from_csv(target_path)

    report_data = {
        'source_path': source_path,
        'target_path': target_path,
        'updated_count': 0,
        'source_total': len(source_data),
        'target_initial_total': len(target_data),
        'operation_skipped': False
    }

    if not target_data:
        logger.info(f" -> 대상 파일 '{os.path.basename(target_path)}'이(가) 비어있거나 존재하지 않아, 전체 복사를 수행합니다.")
        csv_file_service.write_rows_to_csv(target_path, source_data, headers=headers, create_backup_on_write=True, is_test_run=is_test_run)
        report_data['updated_count'] = len(source_data)
        return report_data

    if not source_data:
        logger.warning(f" -> 소스 파일 '{os.path.basename(source_path)}'에 데이터가 없어 작업을 중단합니다.")
        report_data['operation_skipped'] = True
        return report_data

    source_index = {tuple(row.get(mc, '') for mc in match_columns): row for row in source_data}

    updated_rows_count = 0
    new_target_data = []
    
    for target_row in target_data:
        key = tuple(target_row.get(mc, '') for mc in match_columns)
        source_row = source_index.get(key)
        
        if source_row:
            is_updated = False
            for col in update_columns:
                source_value = source_row.get(col)
                target_value = target_row.get(col)
                if target_value != source_value:
                    target_row[col] = source_value
                    is_updated = True
            if is_updated:
                updated_rows_count += 1
        new_target_data.append(target_row)

    report_data['updated_count'] = updated_rows_count
    
    if updated_rows_count > 0:
        csv_file_service.write_rows_to_csv(target_path, new_target_data, headers=headers, create_backup_on_write=True, is_test_run=is_test_run)
        logger.info(f" -> 성공적으로 '{os.path.basename(target_path)}' 파일의 {updated_rows_count}개 행을 업데이트했습니다.")
    else:
        logger.info(" -> 업데이트할 변경 사항이 없습니다.")
        report_data['operation_skipped'] = True
        
    return report_data


def run_pull_to_staging_menu(base_path, is_test_run):
    """
    (v4.26.28 수정됨) 7-1. Merged 파일에서 스테이징으로 데이터를 가져오는 기능.
    [마에스트로 수정] 조건부 업데이트 시 필요한 헤더 목록을 추출합니다.
    """
    logger = LoggerService.get_logger()
    
    if USE_DYNAMIC_FILE_PATHS:
        folder_name = os.path.basename(base_path)
        source_path = os.path.join(base_path, f"{folder_name}{MERGED_FILENAME_SUFFIX}")
        target_path = os.path.join(base_path, f"{folder_name}{STAGING_MASTER_FILENAME_SUFFIX}")
    else:
        bname = os.path.splitext(EXPORT_OUTPUT_FILENAME_STATIC)[0].replace('_translation_source', '')
        source_path = os.path.join(base_path, f"{bname}{MERGED_FILENAME_SUFFIX}")
        target_path = os.path.join(base_path, f"mod{STAGING_MASTER_FILENAME_SUFFIX}")

    if not os.path.exists(source_path):
        logger.error(f" [!] 원본 파일 '{os.path.basename(source_path)}'를 찾을 수 없습니다.")
        return

    # [핵심 수정 1] _merged_kr.csv 파일의 데이터 및 헤더 로드
    source_data = csv_file_service.load_rows_from_csv(source_path)
    
    if not source_data:
        logger.warning(f" -> 원본 파일 '{os.path.basename(source_path)}'에 데이터가 없어 조건부 업데이트를 진행할 수 없습니다.")
        # 데이터가 없더라도, 헤더는 최소한 MASTER_FILE_HEADERS를 기준으로 설정
        available_columns = MASTER_FILE_HEADERS 
    else:
        # 첫 행의 키를 사용 가능한 컬럼으로 지정
        available_columns = list(source_data[0].keys())


    print("\n1. 전체 복사 (스테이징 파일을 Merged 파일 내용으로 덮어쓰기)")
    print("2. 조건부 업데이트 (지정한 조건이 맞으면 특정 컬럼만 업데이트)")
    choice = get_user_input_with_special_keys("\n>> 원하는 작업 번호를 선택하세요 (ESC/q: 뒤로): ")

    if choice in ('__QUIT__', '__ESC__'):
        logger.info(" -> 작업을 취소했습니다.")
        return

    if choice == '1':
        print("\n" + "!"*60)
        logger.warning(f" [경고] 이 작업은 '{os.path.basename(target_path)}'의 모든 내용을 덮어씁니다.")
        print("!"*60)
        prompt = ">> 정말로 진행하시겠습니까? (Enter/y: 예, ESC/n: 아니오): "
        confirm_choice = get_user_input_with_special_keys(prompt)
        if confirm_choice in ('', 'y'):
            # source_data가 비어있지 않다고 가정하고, 로드된 데이터를 사용
            data_to_write = source_data or []
            for row in data_to_write:
                row['Translatable'] = ''
            csv_file_service.write_rows_to_csv(
                target_path, 
                data_to_write, 
                headers=STAGING_FILE_HEADERS,
                create_backup_on_write=True, 
                is_test_run=is_test_run
            )
            logger.info(f" -> 성공적으로 '{os.path.basename(target_path)}' 파일을 생성/덮어썼습니다.")
        else:
            logger.info(" -> 작업을 취소했습니다.")

    elif choice == '2':
        # [핵심 수정 2] 추출된 available_columns를 전달
        match_cols = _select_columns_ui("어떤 컬럼을 기준으로 일치하는 행을 찾을까요?", available_columns=available_columns)
        if match_cols is None:
            logger.info(" -> 컬럼 선택이 취소되었습니다.")
            return

        # [핵심 수정 3] 추출된 available_columns를 전달
        update_cols = _select_columns_ui("일치하는 행의 어떤 컬럼을 업데이트할까요?", available_columns=available_columns)
        if update_cols is None:
            logger.info(" -> 컬럼 선택이 취소되었습니다.")
            return
        
        logger.info(f"\n[설정된 규칙] '{', '.join(match_cols)}'이(가) 일치하는 행의 '{', '.join(update_cols)}' 값을 업데이트합니다.")
        
        # 조건부 업데이트 엔진은 source_data가 필요하므로, 데이터가 없으면 중단
        if not source_data:
            logger.error(" [!] 로드된 데이터가 없어 조건부 업데이트를 실행할 수 없습니다.")
            return
            
        _run_conditional_copy_engine(source_path, target_path, match_cols, update_cols, is_test_run)

    else:
        logger.warning(" [!] 잘못된 선택입니다.")


def _run_merge_completed_to_master_engine(staging_path, master_path, is_test_run=False, shared_state=None):
    """
    [컨트롤러로 리팩토링됨] 스테이징에서 완료된 항목을 마스터 파일로 병합하는
    작업의 UI 흐름을 제어합니다. 모든 핵심 로직은 MasterFileService에 위임됩니다.
    """
    logger = LoggerService.get_logger()
    base_path = os.path.dirname(master_path)
    
    # 1. 서비스 및 데이터 로드
    master_service = MasterFileService(base_path, csv_file_service, target_file_path=master_path)
    staging_data = csv_file_service.load_rows_from_csv(staging_path)
    
    # 2. 핵심 로직 실행 (MasterFileService에 위임)
    # target_is_staging=False (기본값) 이므로, text_kr이 있는 항목만 처리됨
    success = master_service.intelligent_merge(staging_data, is_test_run)
    
    if not success:
        pause_for_user()
        return False
    else:
        return True

def _run_manual_sync_merged_to_staging_engine(is_test_run=False, base_path=None, shared_state=None):
    """
    [신규 래퍼] Export 후 자동 동기화와 동일한 로직으로, merged -> 스테이징을 수동으로 실행합니다.
    """
    logger = LoggerService.get_logger()
    if base_path is None: base_path = os.getcwd()
    
    paths = PathManager(base_path)
    merged_file_path = paths.get_merged_file()
    staging_file_path = paths.get_staging_master_file()

    if not os.path.exists(merged_file_path):
        logger.error(f" [!] 원본 파일 '{os.path.basename(merged_file_path)}'을(를) 찾을 수 없어 작업을 중단합니다.")
        pause_for_user()
        return False
    
    logger.info(f"\n -> '{os.path.basename(merged_file_path)}' 파일에서 최신 데이터를 로드합니다...")
    merged_data = csv_file_service.load_rows_from_csv(merged_file_path)

    # MasterFileService를 스테이징 파일을 대상으로 인스턴스화
    staging_service = MasterFileService(base_path, csv_file_service, target_file_path=staging_file_path)
    
    logger.info(" -> 스테이징 파일과 지능형 동기화를 시작합니다...")
    
    # intelligent_merge를 실행 모드로 호출 (preview_only=False)
    sync_successful, _ = staging_service.intelligent_merge(
        source_data=merged_data, 
        is_test_run=is_test_run, 
        target_is_staging=True,
        preview_only=False # 실제 실행 모드
    )

    if not sync_successful:
        logger.warning(" -> 스테이징 파일 동기화 작업이 취소되었거나 변경사항이 없었습니다.")
        pause_for_user()
        return False
    
    logger.info("\n -> 스테이징 파일 동기화 완료.")
    pause_for_user()
    return True

def _run_t_flag_to_master_engine(staging_path, master_path, is_test_run):
    """[신규 엔진] 스테이징에서 't' 플래그가 지정된 항목만 마스터 파일로 이동합니다."""
    logger = LoggerService.get_logger()
    
    staging_data = csv_file_service.load_rows_from_csv(staging_path)
    if not staging_data:
        logger.warning(f" -> 스테이징 파일 '{os.path.basename(staging_path)}'에 처리할 데이터가 없습니다.")
        pause_for_user()
        return

    items_to_master = [row for row in staging_data if row.get('Translatable', '').strip().lower() in ('t', 'true')]
    remaining_items = [row for row in staging_data if row.get('Translatable', '').strip().lower() not in ('t', 'true')]

    if not items_to_master:
        logger.info("\n -> 마스터로 이동할 't' 또는 'true'로 표시된 항목이 없습니다.")
        pause_for_user()
        return

    print("\n" + "="*70)
    print(" [ 작업 미리보기: 't' 플래그 처리 ]")
    print(f"  - 총 {len(items_to_master)}개의 항목을 마스터 파일로 이동(병합)합니다.")
    print("="*70)
    
    choice = prompt_for_input("\n>> 작업을 계속 진행하시겠습니까? (Enter/y, ESC/n): ", valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')
    if choice != 'y':
        logger.info(" -> 작업을 취소했습니다.")
        pause_for_user()
        return

    master_data = csv_file_service.load_rows_from_csv(master_path)
    master_map = {(row['source_file'], row['id'], row['type'], row['text_en']): row for row in master_data}
    
    for row in items_to_master:
        key = (row['source_file'], row['id'], row['type'], row['text_en'])
        row_for_master = row.copy()
        row_for_master['Translatable'] = 'True'
        master_map[key] = row_for_master
    
    final_master_list = list(master_map.values())
    csv_file_service.write_rows_to_csv(master_path, final_master_list, MASTER_FILE_HEADERS, create_backup_on_write=True, is_test_run=is_test_run)
    logger.info(f" -> 마스터 파일 업데이트 완료. {len(items_to_master)}개 항목이 병합되었습니다.")

    print("\n" + "="*60)
    print(" [ 스테이징 파일 정리 ]")
    print(f"마스터 파일로 이동된 {len(items_to_master)}개의 항목을 스테이징 파일에서 삭제하시겠습니까?")
    cleanup_prompt = "\n>> 정말로 삭제하려면 'y'를 입력하세요 (y/n, ESC는 'n'으로 간주): "
    cleanup_choice = prompt_for_input(cleanup_prompt, valid_choices=['y', 'n'])

    if cleanup_choice == 'y':
        final_staging_data = remaining_items
        action_log = f"정리: 처리된 {len(items_to_master)}개 항목을 제거했습니다."
    else:
        final_staging_data = staging_data
        action_log = "보존: 모든 항목을 그대로 유지했습니다."
        if cleanup_choice is UserInput.ESC:
            logger.info(" -> [ESC] 입력으로 스테이징 파일 정리를 건너뛰고 항목을 보존합니다.")
    
    csv_file_service.write_rows_to_csv(staging_path, final_staging_data, headers=STAGING_FILE_HEADERS, create_backup_on_write=True, is_test_run=is_test_run)
    logger.info(f"\n -> 작업 완료! 스테이징 파일 {action_log}")
    logger.info(f"    '{os.path.basename(staging_path)}'의 최종 항목 수: {len(final_staging_data)}개")
    pause_for_user()


def _run_x_flag_to_trash_engine(staging_path, trash_path, is_test_run):
    """[신규 엔진] 스테이징에서 'x' 플래그가 지정된 항목만 트래시 파일로 이동합니다."""
    logger = LoggerService.get_logger()
    
    staging_data = csv_file_service.load_rows_from_csv(staging_path)
    if not staging_data:
        logger.warning(f" -> 스테이징 파일 '{os.path.basename(staging_path)}'에 처리할 데이터가 없습니다.")
        pause_for_user()
        return

    items_to_trash = [row for row in staging_data if row.get('Translatable', '').strip().lower() == 'x']
    remaining_items = [row for row in staging_data if row.get('Translatable', '').strip().lower() != 'x']

    if not items_to_trash:
        logger.info("\n -> 트래시로 이동할 'x'로 표시된 항목이 없습니다.")
        pause_for_user()
        return

    print("\n" + "="*70)
    print(" [ 작업 미리보기: 'x' 플래그 처리 ]")
    print(f"  - 총 {len(items_to_trash)}개의 항목을 트래시 파일로 이동합니다.")
    print("="*70)
    
    choice = prompt_for_input("\n>> 작업을 계속 진행하시겠습니까? (Enter/y, ESC/n): ", valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')
    if choice != 'y':
        logger.info(" -> 작업을 취소했습니다.")
        pause_for_user()
        return

    added_count = csv_file_service.append_rows_to_csv_without_duplicates(trash_path, items_to_trash, headers=STAGING_FILE_HEADERS, create_backup_on_write=True, is_test_run=is_test_run)
    logger.info(f" -> 트래시 파일 업데이트 완료. {added_count}개의 새로운 항목이 추가되었습니다.")

    print("\n" + "="*60)
    print(" [ 스테이징 파일 정리 ]")
    print(f"트래시 파일로 이동된 {len(items_to_trash)}개의 항목을 스테이징 파일에서 삭제하시겠습니까?")
    cleanup_prompt = "\n>> 정말로 삭제하려면 'y'를 입력하세요 (y/n, ESC는 'n'으로 간주): "
    cleanup_choice = prompt_for_input(cleanup_prompt, valid_choices=['y', 'n'])

    if cleanup_choice == 'y':
        final_staging_data = remaining_items
        action_log = f"정리: 처리된 {len(items_to_trash)}개 항목을 제거했습니다."
    else:
        final_staging_data = staging_data
        action_log = "보존: 모든 항목을 그대로 유지했습니다."
        if cleanup_choice is UserInput.ESC:
            logger.info(" -> [ESC] 입력으로 스테이징 파일 정리를 건너뛰고 항목을 보존합니다.")

    csv_file_service.write_rows_to_csv(staging_path, final_staging_data, headers=STAGING_FILE_HEADERS, create_backup_on_write=True, is_test_run=is_test_run)
    logger.info(f"\n -> 작업 완료! 스테이징 파일 {action_log}")
    logger.info(f"    '{os.path.basename(staging_path)}'의 최종 항목 수: {len(final_staging_data)}개")
    pause_for_user()


def _display_conditional_update_report(report_data_list, update_column_name, is_test_run):
    """[신규 리포트] 조건부 업데이트 작업의 종합 리포트를 출력합니다."""
    logger = LoggerService.get_logger()
    
    total_modes_processed = len(report_data_list)
    total_updated_items = sum(r['updated_count'] for r in report_data_list)

    logger.info("\n" + "="*70)
    logger.info(f"{'[':^24} 조건부 '{update_column_name}' 업데이트 리포트 {' ':^23}{']'}")
    logger.info("-" * 70)
    logger.info(f" 작업 시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f" 총 처리 모드: {total_modes_processed}개")
    logger.info(f" 총 업데이트된 항목 수: {total_updated_items}개")
    if is_test_run:
        logger.info(" [!!] 테스트 모드로 실행되어 실제 파일은 변경되지 않았습니다.")
    logger.info("="*70)

    if not report_data_list:
        logger.info("\n처리된 모드가 없습니다.")
        return

    logger.info("\n" + "="*30 + " [ 모드별 상세 내역 ] " + "="*38)
    
    # 가장 긴 모드 이름 길이를 계산하여 정렬
    max_len = 0
    if report_data_list:
        max_len = max(len(os.path.basename(os.path.dirname(r['target_path']))) for r in report_data_list)

    for report in sorted(report_data_list, key=lambda r: os.path.basename(os.path.dirname(r['target_path']))):
        mod_name = os.path.basename(os.path.dirname(report['target_path']))
        if report['operation_skipped']:
            status = "(변경 없음)"
        else:
            status = f"{report['updated_count']}개 업데이트됨"
        
        logger.info(f"  - {mod_name:<{max_len}} : {status}")

    logger.info("="*70)

def _run_conditional_push_wrapper(is_test_run, base_path, shared_state):
    """
    [신규 래퍼] execute_task가 호출할 실행 유닛. 조건부 업데이트를 실행하고 결과를 shared_state에 기록합니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    
    # [수정] shared_state에서 직접 update_column_name을 가져옵니다.
    update_column = shared_state.get('update_column_name')
    if not update_column:
        logger.error(" [!!] 내부 오류: 업데이트할 컬럼 이름이 지정되지 않았습니다.")
        return False # 작업 실패

    source_path = paths.get_staging_master_file()
    target_path = paths.get_master_file()

    # [수정] _run_conditional_copy_engine 대신, 미리보기 기능이 통합된 새 엔진을 사용합니다.
    # 단, 다중 모드에서는 미리보기를 건너뛰고 바로 실행합니다.
    report_data, _ = _run_conditional_update_engine(
        source_path, target_path,
        match_columns=['source_file', 'id', 'type'],
        update_columns=[update_column],
        is_preview=False, # 다중 모드에서는 미리보기 없이 바로 실행
        is_test_run=is_test_run
    )

    # shared_state에 결과 누적
    if 'report_data' not in shared_state:
        shared_state['report_data'] = []
    shared_state['report_data'].append(report_data)
    
    return True # 작업 성공

def _run_conditional_update_engine(source_path, target_path, match_columns, update_columns, is_preview=True, is_test_run=False):
    """
    [신규 통합 엔진] 조건부 업데이트의 분석(미리보기)과 실제 실행을 모두 담당합니다.
    is_preview 플래그에 따라 동작이 결정됩니다.
    """
    logger = LoggerService.get_logger()
    base_path = os.path.dirname(target_path)
    
    source_data = csv_file_service.load_rows_from_csv(source_path)
    
    # [리팩토링] MasterFileService를 통해 타겟(마스터) 데이터를 가져옴
    master_service = MasterFileService(base_path, csv_file_service)
    target_data = master_service.get_data()

    report_data = {
        'source_path': source_path,
        'target_path': target_path,
        'updated_count': 0,
        'no_change_count': 0,
        'target_missing_match': 0,
        'source_total': len(source_data),
        'target_initial_total': len(target_data),
        'operation_skipped': False
    }

    if not source_data or not target_data:
        report_data['operation_skipped'] = True
        return report_data, None # 분석/실행할 데이터 없음

    source_index = {tuple(row.get(mc, '') for mc in match_columns): row for row in source_data}
    
    updated_count = 0
    no_change_count = 0
    target_missing_match = 0
    new_target_data = [] # is_preview=False일 때만 사용될 리스트

    # [★★★★★ 핵심 로직: 분석과 실행의 통합 ★★★★★]
    # 타겟 데이터를 기준으로 순회
    for target_row in target_data:
        key = tuple(target_row.get(mc, '') for mc in match_columns)
        source_row = source_index.get(key)
        
        row_to_keep = target_row.copy() # 기본적으로는 원본 행 유지
        
        if source_row:
            is_updated_in_row = False
            for col in update_columns:
                source_value = source_row.get(col)
                target_value = row_to_keep.get(col)
                if target_value != source_value:
                    row_to_keep[col] = source_value
                    is_updated_in_row = True
            
            if is_updated_in_row:
                updated_count += 1
            else:
                no_change_count += 1
        
        if not is_preview:
            new_target_data.append(row_to_keep)

    # 소스에만 있는 항목 수 계산 (리포트용)
    target_keys_set = {tuple(row.get(mc, '') for mc in match_columns) for row in target_data}
    for source_key in source_index.keys():
        if source_key not in target_keys_set:
            target_missing_match += 1

    report_data['updated_count'] = updated_count
    report_data['no_change_count'] = no_change_count
    report_data['target_missing_match'] = target_missing_match
    
    if updated_count == 0:
        report_data['operation_skipped'] = True

    # [실행 모드] is_preview가 False이고, 변경 사항이 있을 때만 파일 쓰기
    if not is_preview and not report_data['operation_skipped']:
        logger.info(f" -> 성공적으로 '{os.path.basename(target_path)}' 파일의 {updated_count}개 행을 업데이트합니다.")
        master_service.save_data(new_target_data, is_test_run=is_test_run)
    
    return report_data, new_target_data if not is_preview else None


def run_push_to_master_menu(base_path, is_test_run):
    """
    [v8.4 - 최종 리팩토링] 7-6. 스테이징에서 마스터로 내보내기 메뉴.
    [마에스트로 수정] 이 함수는 더 이상 실행 로직을 담당하지 않고, 사용자 선택에 대한 정보를 반환합니다.
    """
    logger = LoggerService.get_logger()
    
    # --- [수정] 메뉴 출력 부분은 동일하게 유지 ---
    print("\n" + "="*60)
    print(" [ 7-6. 스테이징에서 마스터 파일로 내보내기 ]")
    print("\n어떤 작업을 수행하시겠습니까?\n")
    print("  1. 자동 병합: 번역 완료된 항목('s' 제외)을 마스터로 병합")
    print("  2. 조건부 업데이트 (text_en만) 싱글/다중 지원")
    print("  3. 조건부 업데이트 (text_kr만) 싱글/다중 지원")
    print("  4. 전체 복사: 마스터 파일을 스테이징 파일 내용으로 완전 리셋")
    print("  ────────────────────────────────────────────────────────────")
    print("  5. 't' 처리: 't'로 표시된 항목을 마스터로 이동")
    print("  6. 'x' 처리: 'x'로 표시된 항목을 트래시로 이동")
    print("\n  9. (정리) 마스터와 중복된 항목 스테이징에서 제거")
    print("     └─ 마스터 파일과 완전히 동일한 항목을 스테이징에서 삭제합니다.")
    print("="*60)
    
    prompt = "\n>> 원하는 작업 번호를 선택하세요 (ESC: 뒤로, q: 종료): "
    choice = prompt_for_input(prompt, valid_choices=['1', '2', '3', '4', '5', '6', '9'])

    if choice is UserInput.ESC or choice is UserInput.QUIT:
        return None # 작업 취소를 의미

    # --- [핵심 수정] 실행 로직 대신, 선택에 따른 작업 정보를 딕셔너리로 반환 ---
    if choice == '1':
        return {'action': 'auto_merge'}
    elif choice == '2':
        return {'action': 'conditional_update', 'column': 'text_en'}
    elif choice == '3':
        return {'action': 'conditional_update', 'column': 'text_kr'}
    elif choice == '4':
        return {'action': 'full_copy'}
    elif choice == '5':
        return {'action': 'process_t_flag'}
    elif choice == '6':
        return {'action': 'process_x_flag'}
    elif choice == '9':
        # 이 기능은 즉시 실행되고 다른 흐름을 타지 않으므로, 직접 실행 후 no-op 반환
        _run_remove_master_duplicates_from_staging_engine(base_path, is_test_run)
        return {'action': 'noop'} # No-operation, 이미 작업 완료됨
    
    return None


def _run_delete_by_condition_engine(base_path, is_test_run):
    """
    [엔진 v2] 7-7. 스테이징 파일에서 특정 조건에 맞는 행을 삭제합니다.
    (기존 _run_delete_empty_rows_engine 확장)
    - text_en 또는 text_kr이 비어있는 행 삭제
    - Translatable이 'orphan'인 행 삭제
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    staging_path = paths.get_staging_master_file()

    staging_data = csv_file_service.load_rows_from_csv(staging_path)
    if not staging_data:
        logger.warning(" -> 스테이징 파일이 비어있거나 존재하지 않습니다.")
        return

    # 1. 사용자에게 삭제 조건 선택 UI 제공
    print("\n어떤 조건의 행을 삭제하시겠습니까?\n")
    print("  1. 'text_en' 컬럼이 비어있는 행")
    print("  2. 'text_kr' 컬럼이 비어있는 행")
    print("  3. 'Translatable' 컬럼이 'orphan'인 행")
    
    prompt_col = "\n>> 원하는 작업 번호를 선택하세요 (ESC/q: 뒤로): "
    choice = prompt_for_input(prompt_col, valid_choices=['1', '2', '3'])
    
    if choice is UserInput.ESC or choice is UserInput.QUIT:
        logger.info(" -> 작업을 취소했습니다.")
        return

    # 2. 선택에 따른 필터링 조건 설정
    kept_rows = []
    deleted_rows = []
    filter_description = ""

    if choice == '1' or choice == '2':
        target_column = 'text_en' if choice == '1' else 'text_kr'
        filter_description = f"'{target_column}' 컬럼이 비어있는 모든 행"
        for row in staging_data:
            if (row.get(target_column) or '').strip():
                kept_rows.append(row)
            else:
                deleted_rows.append(row)
    elif choice == '3':
        target_column = 'Translatable'
        target_value = 'orphan'
        filter_description = f"'{target_column}' 컬럼이 '{target_value}'인 모든 행"
        for row in staging_data:
            if (row.get(target_column) or '').strip().lower() == target_value:
                deleted_rows.append(row)
            else:
                kept_rows.append(row)

    deleted_count = len(deleted_rows)
    if deleted_count == 0:
        logger.info(f"\n -> 조건에 맞는 항목을 찾지 못했습니다. 파일이 변경되지 않았습니다.")
        return

    # 3. 사용자에게 미리보기 및 최종 확인
    print("\n" + "="*60)
    print(" [ 작업 미리보기: 조건부 항목 삭제 ]")
    print("-" * 60)
    print(f"  - 대상 파일: '{os.path.basename(staging_path)}'")
    print(f"  - 삭제 기준: {filter_description}")
    print(f"  - 삭제될 행의 수: {deleted_count}개")
    print(f"  - 작업 후 남는 행의 수: {len(kept_rows)}개")
    print("="*60)

    prompt_confirm = "\n>> 정말로 위 항목들을 삭제하시겠습니까? (Enter/y, ESC/n): "
    choice_confirm = prompt_for_input(prompt_confirm, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

    if choice_confirm != 'y':
        logger.info(" -> 작업을 취소했습니다.")
        return

    # 4. 파일 쓰기
    csv_file_service.write_rows_to_csv(
        staging_path,
        kept_rows,
        headers=STAGING_FILE_HEADERS,
        create_backup_on_write=True,
        is_test_run=is_test_run
    )
    logger.info(f"\n -> 작업 완료! {deleted_count}개의 행을 스테이징 파일에서 삭제했습니다.")


def run_conditional_delete_from_staging_menu(base_path, is_test_run):
    """
    (v4.26.28 수정됨) 7-77. 스테이징 파일에서 조건에 맞는 데이터를 삭제하는 기능. (구 7-7번)
    이제 CsvFileService를 사용하여 파일 입출력을 처리합니다.
    [마에스트로 수정] _select_columns_ui 호출 시 필요한 available_columns 인자 누락 오류를 수정.
    """
    logger = LoggerService.get_logger()

    if USE_DYNAMIC_FILE_PATHS:
        folder_name = os.path.basename(base_path)
        staging_path = os.path.join(base_path, f"{folder_name}{STAGING_MASTER_FILENAME_SUFFIX}")
    else:
        staging_path = os.path.join(base_path, f"mod{STAGING_MASTER_FILENAME_SUFFIX}")

    staging_data = csv_file_service.load_rows_from_csv(staging_path)
    if not staging_data:
        logger.warning(" -> 스테이징 파일이 비어있거나 존재하지 않습니다.")
        return

    available_columns = list(staging_data[0].keys()) if staging_data else []
    
    if not available_columns:
        logger.warning(" -> 스테이징 파일에 유효한 컬럼(헤더) 정보가 없습니다. 작업을 중단합니다.")
        return
    
    filter_col = _select_columns_ui("어떤 컬럼을 기준으로 삭제할 행을 필터링할까요?", 
                                    available_columns=available_columns,
                                    allow_multiple=False)

    if filter_col is None:
        logger.info(" -> 컬럼 선택이 취소되었습니다.")
        return
    
    unique_values = sorted(list(set(row.get(filter_col, '') for row in staging_data)))
    
    print(f"\n'{filter_col}' 컬럼에 포함된 고유 값 목록:")
    for i, val in enumerate(unique_values, 1):
        display_val = val[:60] + '...' if len(val) > 60 else val
        print(f"  [{i}] {display_val}")
    
    value_choices_str = prompt_for_input("\n>> 삭제할 값의 번호를 공백으로 구분하여 입력하세요 (ESC/q: 뒤로): ").strip()
    
    if value_choices_str is UserInput.ESC or value_choices_str is UserInput.QUIT:
        logger.info(" -> 값 선택이 취소되었습니다.")
        return

    try:
        chosen_indices = [int(i) - 1 for i in value_choices_str.split()]
        values_to_delete = {unique_values[i] for i in chosen_indices if 0 <= i < len(unique_values)}
    except ValueError:
        logger.error(" [!] 유효한 숫자를 입력해야 합니다."); return
    
    if not values_to_delete:
        logger.warning(" [!] 선택된 값이 없습니다."); return
    
    new_data = [row for row in staging_data if row.get(filter_col) not in values_to_delete]
    
    deleted_count = len(staging_data) - len(new_data)
    
    print("\n" + "="*60)
    print(" [ 작업 미리보기 ]")
    print(f"  [ 필터 기준 ] 컬럼: '{filter_col}'")
    print("  [ 삭제 대상 ] 선택된 값:")
    for val in sorted(list(values_to_delete)):
        display_val = val[:40] + '...' if len(val) > 40 else val
        print(f"    - {display_val}")
    print("-" * 60)
    logger.info(f" -> 위 조건에 따라 총 {deleted_count}개의 행이 삭제될 예정입니다.")
    print("="*60)

    if deleted_count == 0: 
        logger.info(" -> 삭제할 항목이 없어 작업을 종료합니다.")
        return

    prompt = "\n>> 정말로 삭제하시겠습니까? (Enter/y: 예, ESC/n: 아니오): "
    choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')
    if choice == 'y':
        csv_file_service.write_rows_to_csv(staging_path, new_data, headers=STAGING_FILE_HEADERS, create_backup_on_write=True, is_test_run=is_test_run)
        logger.info(f" -> 성공적으로 {deleted_count}개 행을 삭제했습니다.")
    else:
        logger.info(" -> 작업을 취소했습니다.")


def _run_deduplication_ui_controller(file_path, is_test_run):
    """
    [신규 UI 컨트롤러] 중복 제거 기능의 전체 UI 흐름을 제어합니다.
    DeduplicationService를 호출하여 분석을 위임하고, 사용자 입력을 받아
    최종적으로 처리된 데이터 리스트를 반환합니다. (파일 저장 X)
    """
    logger = LoggerService.get_logger()

    file_data = csv_file_service.load_rows_from_csv(file_path)
    if not file_data:
        logger.warning(f" -> 대상 파일 '{os.path.basename(file_path)}'에 데이터가 없습니다.")
        return None

    # --- 1단계: 중복 기준 선택 (UI) ---
    available_columns = ['source_file', 'id', 'id_base', 'type', 'text_en', 'text_kr']
    key_cols = _select_columns_ui("어떤 컬럼을 기준으로 중복을 감지할까요? (추천 조합 안내 포함)", available_columns)
    if key_cols is None:
        logger.info(" -> 컬럼 선택이 취소되었습니다."); return None

    # --- 2단계: 데이터 분석 (서비스 위임) ---
    service = DeduplicationService(file_data, key_cols)
    analysis = service.analyze()
    duplicates = analysis['duplicates']
    unique_rows = analysis['uniques']

    if not duplicates:
        logger.info(f" -> '{', '.join(key_cols)}' 기준 중복 항목을 찾지 못했습니다."); return None

    logger.info(f"\n총 {len(duplicates)}개의 중복 그룹을 발견했습니다.")

    # --- 3단계: 작업 대상 필터링 (UI) ---
    filtered_duplicates = duplicates
    filter_choice = get_user_input_with_special_keys("\n>> 특정 값으로 작업 대상을 제한하시겠습니까? (Enter/y: 예, ESC/n: 아니오): ").lower()
    if filter_choice in ('', 'y'):
        filter_col = _select_columns_ui("어떤 컬럼의 값을 기준으로 필터링할까요?", available_columns, allow_multiple=False)
        if filter_col:
            unique_values_source = (row.get(filter_col, '') for group in duplicates.values() for row in group)
            if filter_col == 'id_base':
                unique_values_source = (re.sub(r'\[\d+\]$', '', row.get('id', '')) for group in duplicates.values() for row in group)
            unique_values = sorted(list(set(unique_values_source)))
            
            print(f"\n'{filter_col}' 컬럼에 포함된 고유 값 목록:")
            for i, val in enumerate(unique_values, 1): print(f"  [{i}] {val}")
            
            value_choices_str = get_user_input_with_special_keys("\n>> 작업할 대상 값의 번호를 공백으로 구분하여 입력하세요 (전체: all 또는 Enter): ").strip().lower()
            
            if value_choices_str not in ('__quit__', '__esc__', 'all', ''):
                try:
                    chosen_indices = [int(i) - 1 for i in value_choices_str.split()]
                    values_to_process = {unique_values[i] for i in chosen_indices if 0 <= i < len(unique_values)}

                    filtered_duplicates = {}
                    for key, group in duplicates.items():
                        first_item_value = group[0].get(filter_col, '')
                        if filter_col == 'id_base': first_item_value = re.sub(r'\[\d+\]$', '', group[0].get('id', ''))
                        if first_item_value in values_to_process: filtered_duplicates[key] = group
                    
                    logger.info(f" -> 필터링 완료. {len(filtered_duplicates)}개의 중복 그룹을 처리합니다.")
                except ValueError:
                    logger.error(" [!] 유효한 숫자를 입력해야 합니다. 필터링을 건너뜁니다.")

    if not filtered_duplicates:
        logger.info(f" -> 선택된 필터에 해당하는 중복 항목이 없습니다."); return None

    # --- 4단계: 중복 그룹 해결 (UI) ---
    final_data = list(unique_rows)
    processed_keys = set()
    quit_flag = False

    for i, (key, items) in enumerate(filtered_duplicates.items(), 1):
        display_header()
        print(f"\n[ 중복 그룹 처리 ({i}/{len(filtered_duplicates)}) ]")
        print(f"  - 대상 파일: {os.path.basename(file_path)}")
        print(f"  - 기준: {', '.join(f'{k}={v}' for k, v in zip(key_cols, key))}")
        print("-"*60)
        
        for j, item_row in enumerate(items, 1):
            print(f"  [{j}] id: {item_row.get('id', 'N/A')}, type: {item_row.get('type', 'N/A')}, text_en: \"{item_row.get('text_en', '')[:40]}...\"")
        
        while True:
            choice_str = get_user_input_with_special_keys("\n>> 남길 항목의 번호를 선택하세요 (q/ESC: 중단): ").strip().lower()
            if choice_str in ('__quit__', '__esc__'):
                quit_flag = True; break
            try:
                choice_idx = int(choice_str) - 1
                if 0 <= choice_idx < len(items):
                    final_data.append(items[choice_idx]); processed_keys.add(key); break
                else: logger.warning(" [!] 목록에 없는 번호입니다.")
            except ValueError: logger.warning(" [!] 유효한 숫자를 입력하세요.")
        if quit_flag: break
            
    if quit_flag:
        logger.info("\n -> 사용자 요청으로 작업을 중단했습니다."); return None

    for key, group in duplicates.items():
        if key not in processed_keys:
            final_data.extend(group)

    return final_data

def _run_deduplicate_master_file_wrapper(is_test_run=False, base_path=None, shared_state=None):
    """
    [리팩토링됨] execute_task를 위한 래퍼. UI 컨트롤러를 호출하고 결과를 마스터 파일에 저장합니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    master_file_path = paths.get_master_file()

    # 1. UI 컨트롤러 호출하여 사용자 상호작용 및 데이터 재구성
    final_data = _run_deduplication_ui_controller(master_file_path, is_test_run)

    # 2. 사용자가 작업을 취소하지 않은 경우에만 파일 저장
    if final_data is None:
        logger.info(" -> 중복 제거 작업이 완료되지 않았거나 취소되었습니다.")
        return False # 작업 미수행으로 execute_task에 알림

    # 3. MasterFileService를 사용하여 안전하게 저장
    initial_count = len(csv_file_service.load_rows_from_csv(master_file_path))
    deleted_count = initial_count - len(final_data)
    
    if deleted_count > 0:
        logger.info(f"\n -> 총 {deleted_count}개의 중복 행을 제거할 예정입니다. 마스터 파일을 업데이트합니다...")
        master_service = MasterFileService(base_path, csv_file_service)
        master_service.save_data(final_data, is_test_run=is_test_run)
        logger.info(f" -> 작업 완료! 마스터 파일이 성공적으로 업데이트되었습니다.")
    else:
        logger.info("\n -> 사용자 선택에 따라 제거된 항목이 없습니다. 파일이 변경되지 않았습니다.")

    return True # 작업 성공

def run_deduplicate_staging_menu(base_path, is_test_run):
    """[리팩토링됨] 7-8. 스테이징 파일 내 중복 데이터를 제거하는 컨트롤러."""
    logger = LoggerService.get_logger()
    
    if USE_DYNAMIC_FILE_PATHS:
        folder_name = os.path.basename(base_path)
        staging_path = os.path.join(base_path, f"{folder_name}{STAGING_MASTER_FILENAME_SUFFIX}")
    else:
        staging_path = os.path.join(base_path, f"mod{STAGING_MASTER_FILENAME_SUFFIX}")

    _run_deduplication_ui_controller(staging_path, is_test_run)


def _run_fill_kr_from_master_engine(base_path, is_test_run):
    """
    [v2.3 - UI 상세화] 마스터 파일의 번역을 참조하여 스테이징 파일의 빈 text_kr을 채웁니다.
    리포트에 대상 파일과 컬럼 정보를 명시합니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    
    master_file_path = paths.get_master_file()
    staging_file_path = paths.get_staging_master_file()

    logger.info("="*60)
    logger.info("7-3. 스테이징 파일 번역 채우기를 시작합니다...")

    # 1. 마스터 파일에서 번역 라이브러리 생성
    master_data = csv_file_service.load_rows_from_csv(master_file_path)
    if not master_data:
        logger.warning(f" -> 번역을 가져올 마스터 파일 '{os.path.basename(master_file_path)}'에 데이터가 없습니다.")
        return

    master_translation_map = {}
    for row in master_data:
        text_en_to_find = row.get('text_en', '')
        translatable_status = (row.get('Translatable') or '').strip().lower()
        row_type = row.get('type', '')
        found_kr = row.get('text_kr', '')
        
        if found_kr.strip():
            converted_kr = _convert_kr_for_staging(found_kr, row_type)
            key = (text_en_to_find, translatable_status)
            master_translation_map[key] = converted_kr
            
    logger.info(f" -> 마스터 라이브러리에서 {len(master_translation_map)}개의 고유한 번역문(Translatable 상태 포함)을 로드했습니다.")

    # 2. 스테이징 파일 로드 및 처리
    staging_data = csv_file_service.load_rows_from_csv(staging_file_path)
    if not staging_data:
        logger.warning(f" -> 번역을 채울 스테이징 파일 '{os.path.basename(staging_file_path)}'에 데이터가 없습니다.")
        return

    updated_rows_count = 0
    rows_to_update_preview = []

    for row in staging_data:
        if not (row.get('text_kr') or '').strip():
            text_en_to_find = row.get('text_en', '')
            translatable_status_in_staging = (row.get('Translatable') or '').strip().lower()
            
            key_to_lookup = (text_en_to_find, translatable_status_in_staging)
            found_kr = master_translation_map.get(key_to_lookup)
            
            if found_kr:
                row['text_kr'] = found_kr
                updated_rows_count += 1
                if len(rows_to_update_preview) < 5:
                    rows_to_update_preview.append({'text_en': text_en_to_find[:50] + '...', 'text_kr': found_kr[:50] + '...'})
    
    if updated_rows_count == 0:
        logger.info("\n -> 마스터 라이브러리에서 가져올 수 있는 새로운 번역이 없습니다.")
        return

    # 3. [핵심 수정] 표준 리포트 프레임워크를 사용한 미리보기 생성 및 렌더링
    report_bundle = {
        "header": {
            "report_title": "작업 미리보기: 번역 채우기",
            "target_name": get_mod_display_name(base_path),
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "summary_lines": [
                {"label": "대상 파일", "value": f"'{os.path.basename(staging_file_path)}'"},
                {"label": "업데이트 컬럼", "value": f"'text_kr' 컬럼 ({updated_rows_count}개 항목)"}
            ]
        },
        "sections": []
    }

    if rows_to_update_preview:
        example_content = []
        for item in rows_to_update_preview:
            example_content.append({
                "label": "EN",
                "value": item['text_en'],
                "label_prefix": "- ",
                "level": 1
            })
            example_content.append({
                "label": "KR",
                "value": item['text_kr'],
                "label_prefix": "  ",  # 들여쓰기 2칸
                "level": 1
            })
        
        report_bundle["sections"].append({
            "section_title": "적용 예시",
            "section_type": "key_value_list",
            "content": example_content
        })

    _render_standard_report(report_bundle)

    # 4. 사용자 최종 확인
    prompt = f"\n>> 위 내용으로 '{os.path.basename(staging_file_path)}' 파일을 업데이트하시겠습니까? (Enter/y, ESC/n): "
    choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

    if choice != 'y':
        logger.info(" -> 작업을 취소했습니다.")
        return

    # 5. 파일 쓰기
    csv_file_service.write_rows_to_csv(staging_file_path, staging_data, headers=STAGING_FILE_HEADERS, create_backup_on_write=True, is_test_run=is_test_run)
    logger.info(f"\n -> 작업 완료! 스테이징 파일의 {updated_rows_count}개 항목에 번역을 채웠습니다.")


def run_pull_untranslated_to_staging(base_path, is_test_run):
    """
    (v4.26.28 수정됨) 'missing', 'empty_kr', 그리고 'master_empty_kr' 파일에서 
    번역이 채워진 항목을 스테이징 파일로 가져와 추가(append)합니다.
    [마에스트로 최종 수정] 사용자가 직접 소스 파일을 선택하도록 UI를 추가합니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    
    # 1. 잠재적 소스 파일 경로 정의
    potential_sources = {
        "신규 항목 파일 (Export 결과)": paths.get_missing_file(),
        "기존 누락 항목 파일 (Export 결과)": paths.get_empty_kr_file(),
        "마스터 누락 항목 파일 (9-8번 결과)": paths.get_master_empty_kr_file()
    }
    staging_file = paths.get_staging_master_file()

    # 2. [마에스트로 수정] 실제로 존재하는 파일만 찾아서 선택 목록을 만듭니다.
    available_files = []
    for description, path in potential_sources.items():
        if os.path.exists(path):
            available_files.append({"description": description, "path": path})

    if not available_files:
        logger.warning("\n -> 스테이징으로 가져올 수 있는 작업 파일이 없습니다.")
        return

    # 3. [마에스트로 수정] 사용자에게 파일 선택 UI를 제공합니다.
    print("\n" + "="*60)
    print(" [ 7-1. 작업 파일 스테이징으로 가져오기 ]")
    print("\n어떤 파일에서 번역이 완료된 항목을 가져오시겠습니까?\n")
    for i, file_info in enumerate(available_files, 1):
        print(f"  [{i}] {file_info['description']} ({os.path.basename(file_info['path'])})")
    
    prompt = "\n>> 원하는 파일의 번호를 공백으로 구분하여 입력하세요 (예: 1 3). ESC: 뒤로: "
    choice_str = prompt_for_input(prompt, allow_empty=True)

    if choice_str is UserInput.ESC or choice_str is UserInput.QUIT:
        logger.info(" -> 작업을 취소했습니다.")
        return

    try:
        selected_indices = [int(i) - 1 for i in choice_str.split()]
        selected_files_to_process = [available_files[i] for i in selected_indices if 0 <= i < len(available_files)]
    except ValueError:
        logger.error(" [!] 유효한 숫자를 입력해야 합니다."); return
    
    if not selected_files_to_process:
        logger.warning(" [!] 선택된 파일이 없습니다. 작업을 종료합니다.")
        return

    # 4. [마에스트로 수정] 사용자가 선택한 파일들만 대상으로 데이터를 추출합니다.
    rows_to_integrate = []
    logger.info(" -> 선택된 파일에서 번역이 완료된 항목들을 수집합니다...")
    for file_info in selected_files_to_process:
        path = file_info['path']
        data = csv_file_service.load_rows_from_csv(path)
        found = [row for row in data if row.get('text_kr', '').strip()]
        if found:
            for row_to_add in found:
                row_to_add['Translatable'] = ''
            rows_to_integrate.extend(found)
            logger.info(f"  - '{os.path.basename(path)}'에서 {len(found)}개 항목 발견.")

    if not rows_to_integrate:
        logger.warning("\n -> 선택된 파일들에서 스테이징으로 가져올 번역 완료 항목이 없습니다.")
        return
        
    # 5. 기존의 미리보기 및 병합 로직을 그대로 사용합니다.
    print("\n" + "="*60)
    print(" [ 작업 미리보기 ]")
    print(f"  - 총 {len(rows_to_integrate)}개의 번역 완료 항목이 발견되었습니다.")
    print(f"  - 이 항목들을 '{os.path.basename(staging_file)}' 파일에 추가(append)합니다.")
    print("="*60)
    
    prompt_confirm = "\n>> 작업을 계속 진행하시겠습니까? (Enter/y, ESC/n): "
    choice_confirm = get_user_input_with_special_keys(prompt_confirm).lower()

    if choice_confirm not in ('', 'y'):
        logger.info(" -> 작업을 취소했습니다.")
        return
        
    added_count = csv_file_service.append_rows_to_csv_without_duplicates(staging_file, rows_to_integrate, headers=STAGING_FILE_HEADERS, create_backup_on_write=True, is_test_run=is_test_run)

    logger.info(f"\n -> 성공! 총 {added_count}개의 새로운 항목을 '{os.path.basename(staging_file)}'에 추가했습니다.")



def _run_clear_staging_to_trash_engine(base_path, is_test_run):
    """
    (CsvFileService 적용) 스테이징 파일의 모든 내용을 트래시로 옮기고, 스테이징 파일을 비웁니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    
    staging_file = paths.get_staging_master_file()
    trash_file = paths.get_purge_trash_file()
    
    items_to_trash = csv_file_service.load_rows_from_csv(staging_file)
    
    if not items_to_trash:
        logger.warning(f" -> 스테이징 파일 '{os.path.basename(staging_file)}'이 비어있어 처리할 항목이 없습니다.")
        return
        
    print("\n" + "!"*60)
    print(" [ 작업 미리보기 ] - 스테이징 전체 비우기")
    logger.warning(" [주의] 이 작업은 스테이징 파일의 모든 내용을 지웁니다.")
    print(f"  - '{os.path.basename(staging_file)}'의 {len(items_to_trash)}개 항목 전체를")
    print(f"    '{os.path.basename(trash_file)}' 파일로 이동(추가)합니다.")
    print(f"  - 작업 후 '{os.path.basename(staging_file)}' 파일은 비워집니다.")
    print("!"*60)
    
    prompt = "\n>> 정말로 스테이징 파일을 비우고 모든 내용을 트래시로 옮기시겠습니까? (Enter/y, ESC/n): "
    choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

    if choice != 'y':
        logger.info(" -> 작업을 취소했습니다.")
        return

    logger.info(" -> 작업을 시작합니다...")
    added_count = csv_file_service.append_rows_to_csv_without_duplicates(
        trash_file, 
        items_to_trash, 
        headers=OUTPUT_HEADERS, 
        is_test_run=is_test_run
    )
    logger.info(f" -> '{os.path.basename(trash_file)}'에 {added_count}개의 새로운 항목을 추가했습니다.")
    
    logger.info(f" -> '{os.path.basename(staging_file)}' 파일을 비웁니다...")
    csv_file_service.write_rows_to_csv(staging_file, [], headers=OUTPUT_HEADERS, create_backup_on_write=True, is_test_run=is_test_run)

    logger.info("\n -> 작업 완료! 스테이징 파일이 성공적으로 정리되었습니다.")


def run_staging_purge_menu(base_path, is_test_run):
    """[컨트롤러] 스테이징 파일 정리(부분 또는 전체) 메뉴를 표시하고 실행합니다."""
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    staging_file = paths.get_staging_master_file()
    trash_file = paths.get_purge_trash_file()

    if not os.path.exists(staging_file):
        logger.error(f" [!] 작업을 시작하기 전에 스테이징 파일('{os.path.basename(staging_file)}')이 필요합니다.")
        return

    print("\n" + "="*60)
    print(" [ 7-6. 스테이징 정리 작업 ]")
    print("\n어떤 작업을 수행하시겠습니까?\n")
    print("--- [ 부분 정리 ] ---")
    print(" 1. 정수 및 실수 항목만 트래시로 이동")
    print(" 2. 퍼센트 형식 항목만 트래시로 이동")
    print(" 3. 모든 숫자/퍼센트 항목을 트래시로 이동")
    print("\n--- [ 전체 정리 ] ---")
    print(" 4. 남은 항목 전체를 트래시로 이동 (스테이징 비우기)")

    prompt = "\n>> 원하는 작업 번호를 선택하세요 (ESC/q: 뒤로): "
    choice = prompt_for_input(
        prompt,
        valid_choices=['1', '2', '3', '4']
    )

    if choice is UserInput.ESC or choice is UserInput.QUIT:
        return

    if choice in ('1', '2', '3'):
        filters_to_apply = set()
        if choice == '1': filters_to_apply.add('numeric')
        elif choice == '2': filters_to_apply.add('percentage')
        elif choice == '3': filters_to_apply.add('numeric'); filters_to_apply.add('percentage')
        
        # 숫자 분리 로직을 담당하는 범용 UI 컨트롤러 호출
        _run_purge_numeric_ui_controller(staging_file, trash_file, filters_to_apply, is_test_run, create_backup=False)

    elif choice == '4':
        # 전체 비우기 로직을 담당하는 엔진 호출
        _run_clear_staging_to_trash_engine(base_path, is_test_run)

    elif choice in ('__esc__', '__quit__'):
        return

    else:
        logger.warning(" [!] 잘못된 선택입니다.")


def _run_staging_purge_wrapper(is_test_run, base_path, shared_state):
    """[래퍼] 7-0. 실행 환경에 따라 UI를 보여주거나 '전체 비우기' 엔진을 바로 실행."""
    if shared_state and shared_state.get('is_multi_mode'):
        # 다중 모드에서는 '전체 비우기' 엔진을 직접 호출
        return _run_clear_staging_to_trash_engine(base_path, is_test_run)
    else:
        # 단일 모드에서는 기존 UI 메뉴 호출
        run_staging_purge_menu(base_path, is_test_run)
        return True

def _run_pull_to_staging_full_copy_engine(base_path, is_test_run):
    """[엔진] 7-2. Merged 파일의 내용으로 스테이징 파일을 전체 덮어쓰는 핵심 로직."""
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    source_path = paths.get_merged_file()
    target_path = paths.get_staging_master_file()

    source_data = csv_file_service.load_rows_from_csv(source_path)
    # Translatable 열 추가
    if source_data:
        for row in source_data:
            row['Translatable'] = ''
            
    csv_file_service.write_rows_to_csv(
        target_path,
        source_data,
        headers=STAGING_FILE_HEADERS,
        create_backup_on_write=True,
        is_test_run=is_test_run
    )
    logger.info(f" -> 성공적으로 '{os.path.basename(target_path)}' 파일을 생성/덮어썼습니다.")
    return True

def _run_pull_to_staging_wrapper(is_test_run, base_path, shared_state):
    """[래퍼] 7-2. 실행 환경(단일/다중)에 따라 UI를 보여주거나 엔진을 바로 실행."""
    # shared_state 딕셔너리에 'is_multi_mode' 키가 있다면 다중 모드 실행으로 간주
    if shared_state and shared_state.get('is_multi_mode'):
        # 다중 모드에서는 엔진을 직접 호출
        return _run_pull_to_staging_full_copy_engine(base_path, is_test_run)
    else:
        # 단일 모드에서는 기존 UI 메뉴 호출
        run_pull_to_staging_menu(base_path, is_test_run)
        return True # UI 메뉴는 자체적으로 pause를 관리하므로 항상 True 반환


def _run_push_to_master_wrapper(is_test_run, base_path, shared_state):
    """[래퍼 v3] 7-6. shared_state의 sub_action에 따라 적절한 엔진을 실행."""
    sub_action = shared_state.get('sub_action')
    paths = PathManager(base_path)
    source_path = paths.get_staging_master_file()
    target_path = paths.get_master_file()
    trash_path = paths.get_purge_trash_file()
    
    if sub_action == '1':
        # [수정] shared_state 인자 전달
        return _run_merge_completed_to_master_engine(source_path, target_path, is_test_run, shared_state)
    elif sub_action == '2':
        sync_successful, is_skipped = _sync_engine_overwrite(source_path, target_path, is_test_run)
        
        if sync_successful:
            _run_sync_overwrite_auditor(source_path, target_path, is_test_run, is_skipped)
            return True
        else:
            return False
    # elif sub_action == '3': ...
    elif sub_action == '4':
        # [수정] shared_state 인자 전달
        return _run_t_flag_to_master_engine(source_path, target_path, is_test_run, shared_state) 
    elif sub_action == '5':
        # [수정] shared_state 인자 전달
        return _run_x_flag_to_trash_engine(source_path, trash_path, is_test_run, shared_state)
    
    # 단일 모드 실행 시 (sub_action이 없음)
    run_push_to_master_menu(base_path, is_test_run)
    return True

def _run_full_copy_with_ui(paths, is_test_run):
    """7-6-4. 전체 복사 기능의 UI와 실행 로직을 담당하는 헬퍼 함수."""
    logger = LoggerService.get_logger()
    source_path = paths.get_staging_master_file()
    target_path = paths.get_master_file()
    print("\n" + "!"*70)
    logger.warning(f" [!! 주의 !!] 이 작업은 '{os.path.basename(target_path)}' 파일을 완전히 덮어씁니다.")
    print("-" * 70)
    print(f"  - 원본 (스테이징): '{os.path.basename(source_path)}'")
    print(f"  - 대상 (마스터)  : '{os.path.basename(target_path)}'")
    print("!"*70)
    confirm_prompt = "\n>> 정말로 덮어쓰기를 진행하시겠습니까? (Enter/y, ESC/n): "
    confirm_choice = prompt_for_input(confirm_prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')
    if confirm_choice == 'y':
        sync_successful, is_skipped = _sync_engine_overwrite(source_path, target_path, is_test_run)
        if sync_successful:
            _run_sync_overwrite_auditor(source_path, target_path, is_test_run, is_skipped)
    else:
        logger.info(" -> 작업을 취소했습니다.")
    pause_for_user()

def _convert_kr_for_staging(text_kr, item_type):
    """
    [신규 헬퍼] 마스터 파일에서 가져온 text_kr을 Staging 파일의 표준 형식(|n| 태그)으로 변환합니다.
    """
    if item_type.lower().startswith('text'):
        # item_type이 'text'로 시작하는 경우에만 |n|으로 변환합니다.
        return standardize_newlines(text_kr, tag='|n|')
    return text_kr

def _run_normalize_multiline_text_engine(staging_file_path, is_test_run=False):
    """
    [신규 엔진 7-9-3] 스테이징 파일의 'type: text' 계열 항목에 포함된
    실제 줄바꿈 문자를 NEWLINE_TAG_TEXT_TYPE ('\\n')으로 변환합니다.
    """
    logger = LoggerService.get_logger()
    staging_data = csv_file_service.load_rows_from_csv(staging_file_path)
    
    report = {'updated_count': 0, 'processed_count': 0, 'examples': []}
    if not staging_data:
        logger.warning(f" -> 스테이징 파일 '{os.path.basename(staging_file_path)}'에 데이터가 없습니다.")
        return

    normalized_data = []
    updated_count = 0
    processed_count = 0
    
    for row in staging_data:
        row_copy = row.copy()
        row_type = row_copy.get('type', '').strip().lower()
        base_type = row_type.split(':')[0]

        if base_type in NORMALIZE_QUOTES_TARGET_TYPES:
            processed_count += 1
            original_kr = row_copy.get('text_kr', '')
            original_en = row_copy.get('text_en', '')
            
            # standardize_newlines는 \r\n, \r을 모두 \n으로 바꾼 후 태그로 변환합니다.
            normalized_kr = standardize_newlines(original_kr, tag=NEWLINE_TAG_TEXT_TYPE)
            normalized_en = standardize_newlines(original_en, tag=NEWLINE_TAG_TEXT_TYPE)
            
            is_updated = False
            if original_kr != normalized_kr:
                row_copy['text_kr'] = normalized_kr
                is_updated = True
            if original_en != normalized_en:
                row_copy['text_en'] = normalized_en
                is_updated = True
            
            if is_updated:
                updated_count += 1
                if len(report['examples']) < 3:
                    report['examples'].append({
                        'id': row_copy.get('id'),
                        'before': original_kr.replace('\n', '\\n')[:50],
                        'after': normalized_kr.replace('\n', '\\n')[:50]
                    })
        
        normalized_data.append(row_copy)
        
    report['updated_count'] = updated_count
    report['processed_count'] = processed_count

    if updated_count == 0:
        logger.info("\n -> 분석 결과, 줄바꿈 정규화가 필요한 항목을 찾지 못했습니다.")
        return

    # 미리보기 출력
    print("\n" + "="*70)
    print(" [ 작업 미리보기: 'type: text' 줄바꿈 정규화 ]")
    print("-" * 70)
    print(f"  - 대상 파일: '{os.path.basename(staging_file_path)}'")
    print(f"  - 총 {report['processed_count']}개의 'text' 계열 항목 중, {report['updated_count']}개 항목의 줄바꿈을 '\\n'으로 변환합니다.")
    if report['examples']:
        print("\n  - 변환 예시 (최대 3개, text_kr 기준):")
        for ex in report['examples']:
            print(f"    - ID: {ex.get('id', 'N/A')}")
            print(f"      변경 전: {ex['before']}")
            print(f"      변경 후: {ex['after']}")
    print("="*70)

    # 사용자 확인
    prompt_confirm = "\n>> 위 내용으로 스테이징 파일을 업데이트하시겠습니까? (Enter/y, ESC/n): "
    choice_confirm = prompt_for_input(prompt_confirm, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

    if choice_confirm != 'y':
        logger.info(" -> 작업을 취소했습니다.")
        return

    # 파일 쓰기
    csv_file_service.write_rows_to_csv(
        staging_file_path,
        normalized_data,
        headers=STAGING_FILE_HEADERS,
        create_backup_on_write=True,
        is_test_run=is_test_run
    )

    logger.info(f"\n -> 작업 완료! 스테이징 파일의 {updated_count}개 항목에 포함된 줄바꿈을 정규화했습니다.")

def _run_denormalize_newline_tags_engine(staging_file_path, is_test_run=False):
    """
    [신규 엔진 7-9-4] 스테이징 파일의 'type: text' 계열 항목에 포함된
    NEWLINE_TAG_TEXT_TYPE ('\\n') 문자열을 실제 줄바꿈 문자로 변환합니다.
    """
    logger = LoggerService.get_logger()
    staging_data = csv_file_service.load_rows_from_csv(staging_file_path)
    
    report = {'updated_count': 0, 'processed_count': 0, 'examples': []}
    if not staging_data:
        logger.warning(f" -> 스테이징 파일 '{os.path.basename(staging_file_path)}'에 데이터가 없습니다.")
        return

    normalized_data = []
    updated_count = 0
    processed_count = 0
    
    for row in staging_data:
        row_copy = row.copy()
        row_type = row_copy.get('type', '').strip().lower()
        base_type = row_type.split(':')[0]

        if base_type in NORMALIZE_QUOTES_TARGET_TYPES:
            processed_count += 1
            original_kr = row_copy.get('text_kr', '')
            original_en = row_copy.get('text_en', '')
            
            denormalized_kr = original_kr.replace(NEWLINE_TAG_TEXT_TYPE, '\n')
            denormalized_en = original_en.replace(NEWLINE_TAG_TEXT_TYPE, '\n')
            
            is_updated = False
            if original_kr != denormalized_kr:
                row_copy['text_kr'] = denormalized_kr
                is_updated = True
            if original_en != denormalized_en:
                row_copy['text_en'] = denormalized_en
                is_updated = True
            
            if is_updated:
                updated_count += 1
                if len(report['examples']) < 3:
                    report['examples'].append({
                        'id': row_copy.get('id'),
                        'before': original_kr.replace('\n', '\\n')[:50],
                        'after': denormalized_kr.replace('\n', '\\n')[:50]
                    })
        
        normalized_data.append(row_copy)
        
    report['updated_count'] = updated_count
    report['processed_count'] = processed_count

    if updated_count == 0:
        logger.info(f"\n -> 분석 결과, '\\n' 태그를 포함하여 여러 줄로 펼칠 항목을 찾지 못했습니다.")
        return

    # 미리보기 출력
    print("\n" + "="*70)
    print(" [ 작업 미리보기: 'type: text' 여러 줄로 펼치기 ]")
    print("-" * 70)
    print(f"  - 대상 파일: '{os.path.basename(staging_file_path)}'")
    print(f"  - 총 {report['processed_count']}개의 'text' 계열 항목 중, {report['updated_count']}개 항목의 '\\n' 태그를 실제 줄바꿈으로 변환합니다.")
    if report['examples']:
        print("\n  - 변환 예시 (최대 3개, text_kr 기준):")
        for ex in report['examples']:
            print(f"    - ID: {ex.get('id', 'N/A')}")
            print(f"      변경 전: {ex['before']}")
            print(f"      변경 후: {ex['after']}")
    print("="*70)

    # 사용자 확인
    prompt_confirm = "\n>> 위 내용으로 스테이징 파일을 업데이트하시겠습니까? (Enter/y, ESC/n): "
    choice_confirm = prompt_for_input(prompt_confirm, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

    if choice_confirm != 'y':
        logger.info(" -> 작업을 취소했습니다.")
        return

    # 파일 쓰기
    csv_file_service.write_rows_to_csv(
        staging_file_path,
        normalized_data,
        headers=STAGING_FILE_HEADERS,
        create_backup_on_write=True,
        is_test_run=is_test_run
    )

    logger.info(f"\n -> 작업 완료! 스테이징 파일의 {updated_count}개 항목에 포함된 '\\n' 태그를 실제 줄바꿈으로 변환했습니다.")

def run_normalization_manager_menu(base_path, is_test_run):
    """
    [v-latest 최종 수정] |n| 마이그레이션 로직을 7-9-1 기능에 종속시키고,
    메모리 기반 데이터 처리로 버그를 해결합니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    staging_file_path = paths.get_staging_master_file()

    if not os.path.exists(staging_file_path):
        logger.error(f" [!] 작업을 시작하기 전에 스테이징 파일('{os.path.basename(staging_file_path)}')이 필요합니다.")
        return

    print("\n" + "="*60)
    print(" [ 7-9. 데이터 정규화 관리자 ]")
    print("\n어떤 정규화 작업을 수행하시겠습니까?\n")
    print("  1. 'type: text' 항목 정규화 (외곽 따옴표 추가)")
    print("     └─ text_en에만 있는 외곽 따옴표를 text_kr에도 추가합니다.")
    print("\n  2. 'type: text' 항목 한 줄로 정규화 (줄바꿈 -> '\\n')")
    print("     └─ 셀 내에 실제 줄바꿈이 포함된 경우, 이를 '\\n' 문자열로 변환합니다.")
    print("\n  3. 'type: text' 항목 여러 줄로 펼치기 ('\\n' -> 줄바꿈)")
    print("     └─ '\\n' 문자열을 실제 줄바꿈으로 변환하여 편집기에서 여러 줄로 표시되게 합니다.")
    print('\n'+"-"*90)
    print("\n  9. [주의] 'type: json' 항목 정규화 (이스케이프 문자 변환)")
    print("     └─ 스프레드시트에서 복사된 '\\\"', '\\n' 등을 실제 문자로 변환합니다.")
    
    prompt_mode = "\n>> 원하는 작업 번호를 선택하세요 (ESC: 뒤로): "
    choice = prompt_for_input(prompt_mode, valid_choices=['1', '2', '3', '4'])

    if choice is UserInput.ESC or choice is UserInput.QUIT:
        logger.info(" -> 작업을 취소했습니다.")
        return

    final_data_to_write = None
    operation_title = ""
    final_report = {}

    if choice == '1':
        operation_title = "'type: text' 계열 정규화 (외곽 따옴표)"
        logger.info(f"\n -> '{operation_title}' 작업을 위해 스테이징 파일을 분석 중입니다...")
        
        # 1. 따옴표 정규화 분석 및 데이터 로드
        report, normalized_data = _run_normalize_text_kr_quotes_engine(staging_file_path, is_test_run=True)
        
        if report['updated_count'] == 0:
            logger.info("\n -> 분석 결과, 따옴표 정규화가 필요한 항목을 찾지 못했습니다.")
        else:
            print("\n" + "="*70)
            print(f" [ 작업 미리보기: {operation_title} ]")
            print("-" * 70)
            print(f"  - 대상 파일: '{os.path.basename(staging_file_path)}'")
            print(f"  - 총 {report['processed_count']}개의 대상 타입 항목 중, {report['updated_count']}개 항목이 변경됩니다.")
            if report.get('updated_by_type'):
                print("    └─ [ 변경될 항목 상세 내역 ]")
                for type_name, count in sorted(report['updated_by_type'].items()):
                    print(f"       - {type_name}: {count}개")
            if report['examples']:
                print("\n  - 변경 예시 (최대 3개):")
                for ex in report['examples']:
                    print(f"    - ID: {ex.get('id', 'N/A')}")
                    print(f"      변경 전: {ex['before']}")
                    print(f"      변경 후: {ex['after']}")
            print("="*70)
            
            prompt_confirm = "\n>> 위 내용으로 스테이징 파일을 업데이트하시겠습니까? (Enter/y, ESC/n): "
            choice_confirm = prompt_for_input(prompt_confirm, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

            if choice_confirm != 'y':
                logger.info(" -> 따옴표 정규화 작업을 취소했습니다.")
                # 마이그레이션 단계로 넘어가지 않고 즉시 함수 종료
                return

        # 실제 데이터 로드 (분석에서 변경사항이 없었더라도 마이그레이션을 위해 필요)
        _, normalized_data = _run_normalize_text_kr_quotes_engine(staging_file_path)

        # [핵심] 마이그레이션 단계
        logger.info("\n -> 추가 작업 확인: 레거시 줄바꿈 태그('|n|') 검사 중...")
        migration_report, _ = _run_legacy_newline_migration_engine(normalized_data, is_preview=True)
        
        final_data_to_write = normalized_data

        if migration_report['updated_count'] > 0:
            print("\n" + "!"*70)
            logger.warning(" [ 추가 작업 발견: 레거시 데이터 마이그레이션 ]")
            print("-" * 70)
            print(f"  - 스테이징 파일에서 {migration_report['updated_count']}개의 레거시 줄바꿈 태그('|n|')를 발견했습니다.")
            if migration_report['examples']:
                print("  - 변환 예시:")
                for ex in migration_report['examples']:
                    print(f"    - ID: {ex.get('id', 'N/A')}")
                    print(f"      변경 전: {ex['before']}")
                    print(f"      변경 후: {ex['after']}")
            print("!"*70)
            
            prompt_migrate = "\n>> 이 항목들을 새로운 표준('\\n')으로 변환하시겠습니까? (Enter/y, ESC/n): "
            choice_migrate = prompt_for_input(prompt_migrate, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

            if choice_migrate == 'y':
                _, migrated_data = _run_legacy_newline_migration_engine(normalized_data, is_preview=False)
                final_data_to_write = migrated_data
                logger.info(f"\n -> 마이그레이션 완료! {migration_report['updated_count']}개 항목의 줄바꿈 태그를 변환했습니다.")
            else:
                logger.info(" -> 마이그레이션 작업을 건너뛰었습니다.")
        else:
            logger.info(" -> 발견된 레거시 줄바꿈 태그가 없습니다.")
        
        # 최종 리포트 데이터는 두 작업의 결과를 합산해야 함
        final_report = report.copy()
        final_report['updated_count'] += migration_report.get('updated_count', 0)
    
    elif choice == '2':
        _run_normalize_multiline_text_engine(staging_file_path, is_test_run)
        return

    elif choice == '3':
        _run_denormalize_newline_tags_engine(staging_file_path, is_test_run)
        return

    elif choice == '9':
        operation_title = "'type: json' 정규화 (이스케이프)"
        logger.info(f"\n -> '{operation_title}' 작업을 위해 스테이징 파일을 분석 중입니다...")
        report, _ = _run_normalize_json_kr_engine(staging_file_path, is_test_run=True)
        
        if report['updated_count'] == 0:
            logger.info("\n -> 분석 결과, 정규화가 필요한 항목을 찾지 못했습니다.")
            return

        print("\n" + "="*70)
        print(f" [ 작업 미리보기: {operation_title} ]")
        print("-" * 70)
        print(f"  - 대상 파일: '{os.path.basename(staging_file_path)}'")
        print(f"  - 총 {report['processed_count']}개의 대상 타입 항목 중, {report['updated_count']}개 항목이 변경됩니다.")
        if report['examples']:
            print("\n  - 변경 예시 (최대 3개):")
            for ex in report['examples']:
                print(f"    - ID: {ex.get('id', 'N/A')}")
                print(f"      변경 전: {ex['before']}")
                print(f"      변경 후: {ex['after']}")
        print("="*70)

        prompt_confirm = "\n>> 위 내용으로 스테이징 파일을 업데이트하시겠습니까? (Enter/y, ESC/n): "
        choice_confirm = prompt_for_input(prompt_confirm, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

        if choice_confirm != 'y':
            logger.info(" -> 작업을 취소했습니다.")
            return
            
        final_report, final_data_to_write = _run_normalize_json_kr_engine(staging_file_path)

    # --- 최종 파일 쓰기 및 리포트 (모든 케이스 공통) ---
    if final_data_to_write is not None:
        logger.info("\n -> 실제 파일 업데이트를 시작합니다...")
        csv_file_service.write_rows_to_csv(
            staging_file_path,
            final_data_to_write,
            headers=STAGING_FILE_HEADERS,
            create_backup_on_write=True,
            is_test_run=is_test_run
        )

        print("\n" + "="*70)
        print(f" [ 종합 리포트: {operation_title} ]")
        print("-" * 70)
        print(f"  - 작업 대상 파일: '{os.path.basename(staging_file_path)}'")
        print(f"  - 총 {final_report['processed_count']}개의 대상 타입 항목 중, {final_report['updated_count']}개 항목을 업데이트했습니다.")
        if final_report.get('updated_by_type'):
            print("    └─ [ 업데이트된 항목 상세 내역 ]")
            for type_name, count in sorted(final_report['updated_by_type'].items()):
                print(f"       - {type_name}: {count}개")
        print("-" * 70)
        if is_test_run:
            print("  - [!!] 테스트 모드로 실행되어 실제 파일은 변경되지 않았습니다.")
        else:
            print("  - 작업이 성공적으로 완료되었습니다.")
        print("="*70)
    else:
        logger.info("\n -> 변경 사항이 없거나 작업이 취소되어 파일이 업데이트되지 않았습니다.")


def _run_copy_master_to_staging_engine(base_path, is_test_run, shared_state=None):
    """
    [신규 엔진] 7-3. 마스터 파일의 모든 내용을 스테이징 파일로 전체 복사합니다.
    Translatable 열을 포함한 모든 필드를 그대로 가져오고 덮어씁니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    master_file_path = paths.get_master_file()
    staging_file_path = paths.get_staging_master_file()

    logger.info("="*60)
    logger.info("7-3. 마스터 파일 -> 스테이징으로 전체 복사를 시작합니다...")

    master_data = csv_file_service.load_rows_from_csv(master_file_path)
    if not master_data:
        logger.warning(f" -> 마스터 파일 '{os.path.basename(master_file_path)}'에 데이터가 없어 복사할 항목이 없습니다.")
        return False
    
    # 1. 미리보기 및 사용자 확인
    print("\n" + "!"*70)
    logger.warning(" [!! 경고 !!] 이 작업은 기존 스테이징 파일의 내용을 모두 삭제하고 덮어씁니다.")
    print("-" * 70)
    print(f"  - 마스터 파일('{os.path.basename(master_file_path)}')의 모든 내용을")
    print(f"  - 스테이징 파일('{os.path.basename(staging_file_path)}')에 완전히 덮어씁니다.")
    print(f"  - 총 {len(master_data)}개의 항목이 복사됩니다.")
    print("  - Translatable 상태를 포함한 모든 정보가 그대로 가져와집니다.")
    print("!"*70)

    prompt = "\n>> 정말로 스테이징 파일을 마스터 파일 내용으로 덮어쓰시겠습니까? (Enter/y, ESC/n): "
    choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

    if choice != 'y':
        logger.info(" -> 작업을 취소했습니다.")
        return False

    # 2. 스테이징 파일 업데이트 (덮어쓰기)
    # CsvFileService.write_rows_to_csv는 자동으로 백업을 생성합니다.
    csv_file_service.write_rows_to_csv(
        staging_file_path,
        master_data, # 마스터 파일의 모든 데이터 (Translatable 포함)
        headers=STAGING_FILE_HEADERS, # STAGING_FILE_HEADERS를 명시적으로 사용
        create_backup_on_write=True,
        is_test_run=is_test_run
    )

    logger.info(f"\n -> 작업 완료! '{os.path.basename(staging_file_path)}'에 {len(master_data)}개의 항목을 복사했습니다.")
    return True


def _run_pull_from_master_to_staging_engine(base_path, is_test_run, shared_state=None):
    """
    [신규 엔진] 7-4. 마스터 파일과 스테이징 파일을 비교하여,
    마스터에만 있는 항목들을 스테이징 파일로 가져와 추가합니다.
    [마에스트로 수정] 마스터에서 가져온 text_kr을 Staging 표준(|n| 태그)으로 변환합니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    master_file_path = paths.get_master_file()
    staging_file_path = paths.get_staging_master_file()

    logger.info("="*60)
    logger.info("7-4. 마스터 -> 스테이징으로 누락 항목 가져오기를 시작합니다...")

    master_data = csv_file_service.load_rows_from_csv(master_file_path)
    if not master_data:
        logger.warning(f" -> 마스터 파일 '{os.path.basename(master_file_path)}'에 데이터가 없어 가져올 항목이 없습니다.")
        return False
    
    staging_data = csv_file_service.load_rows_from_csv(staging_file_path)
    # 스테이징 파일이 없거나 비어 있어도 진행 가능 (새로 추가하면 되므로)

    # 1. 스테이징 항목 키 셋 생성 (Translatable 제외)
    staging_keys_set = {
        (row.get('source_file', ''), row.get('id', ''), row.get('type', ''), row.get('text_en', ''))
        for row in staging_data
    }

    # 2. 가져올 항목 선별 및 변환
    items_to_pull = []
    for master_row in master_data:
        # 마스터 항목의 고유 식별자 생성
        master_key = (
            master_row.get('source_file', ''),
            master_row.get('id', ''),
            master_row.get('type', ''),
            master_row.get('text_en', '')
        )
        
        # 스테이징에 없는 항목만 가져옴
        if master_key not in staging_keys_set:
            master_row_type = master_row.get('type', '')
            
            # [핵심 수정] text_kr에 Staging 표준 변환 적용
            if master_row.get('text_kr', '').strip():
                 converted_kr = _convert_kr_for_staging(master_row['text_kr'], master_row_type)
                 master_row['text_kr'] = converted_kr
                 
            master_row_copy = master_row.copy()
            items_to_pull.append(master_row_copy) 

    if not items_to_pull:
        logger.info(" -> 마스터 파일에만 있고 스테이징 파일에는 없는 새로운 항목이 없습니다.")
        return False
    
    # 3. 미리보기 및 사용자 확인
    print("\n" + "="*70)
    print(" [ 작업 미리보기: 마스터 -> 스테이징으로 누락 항목 가져오기 ]")
    print("-" * 70)
    print(f"  - 마스터 파일에서 총 {len(items_to_pull)}개의 누락된 항목을 발견했습니다.")
    print(f"  - 이 항목들은 스테이징 파일('{os.path.basename(staging_file_path)}')에 추가됩니다.")
    print("  - Translatable 상태를 포함한 모든 정보가 그대로 가져와집니다.")
    print("="*70)

    prompt = "\n>> 위 내용으로 스테이징 파일을 업데이트하시겠습니까? (Enter/y, ESC/n): "
    choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

    if choice != 'y':
        logger.info(" -> 작업을 취소했습니다.")
        return False

    # 4. 스테이징 파일 업데이트
    added_count = csv_file_service.append_rows_to_csv_without_duplicates(
        staging_file_path,
        items_to_pull,
        headers=STAGING_FILE_HEADERS, # STAGING_FILE_HEADERS를 명시적으로 사용
        create_backup_on_write=True,
        is_test_run=is_test_run
    )

    logger.info(f"\n -> 작업 완료! 스테이징 파일에 {added_count}개의 새로운 항목을 추가했습니다.")
    return True


def _run_normalize_text_kr_quotes_engine(staging_file_path, is_test_run=False):
    """
    [v2.11 - UndefinedVariable 버그 수정] 'en_rstrip', 'kr_rstrip' 변수가
    정의되지 않아 발생한 오류를 해결하고, 후행 서식 보정 로직을 안정화합니다.
    """
    logger = LoggerService.get_logger()
    staging_data = csv_file_service.load_rows_from_csv(staging_file_path)
    
    report = {
        'updated_count': 0,
        'processed_count': 0,
        'examples': [],
        'processed_by_type': defaultdict(int),
        'updated_by_type': defaultdict(int)
    }
    if not staging_data:
        return report, staging_data

    # ... (get_quote_parts 헬퍼 함수는 동일) ...
    def get_quote_parts(text):
        lead_ws_len = len(text) - len(text.lstrip())
        lead_ws = text[:lead_ws_len]
        
        trail_ws_len = len(text) - len(text.rstrip())
        trail_ws = text[len(text) - trail_ws_len:]
        
        content_stripped_ws = text.strip()
        
        lead_q = ''
        temp_content = content_stripped_ws
        while temp_content.startswith("'") or temp_content.startswith('"'):
            lead_q += temp_content[0]
            temp_content = temp_content[1:]

        trail_q = ''
        while temp_content.endswith("'") or temp_content.endswith('"'):
            trail_q = temp_content[-1] + trail_q
            temp_content = temp_content[:-1]
            
        core_content = temp_content
        return lead_ws, lead_q, core_content, trail_q, trail_ws

    normalized_data = []
    
    for row in staging_data:
        row_copy = row.copy()
        row_type = row_copy.get('type', '').strip().lower()
        base_type = row_type.split(':')[0]

        if base_type in NORMALIZE_QUOTES_TARGET_TYPES:
            report['processed_count'] += 1
            report['processed_by_type'][base_type] += 1
            
            text_en = row_copy.get('text_en', '')
            original_kr = row_copy.get('text_kr', '')

            if not original_kr.strip():
                normalized_data.append(row_copy)
                continue

            # --- 1단계: 기본 외곽 따옴표/공백 모방 ---
            en_lead_ws, en_lead_q, _, en_trail_q, en_trail_ws = get_quote_parts(text_en)
            kr_lead_ws, kr_lead_q, kr_content, kr_trail_q, kr_trail_ws = get_quote_parts(original_kr)
            
            should_update = False
            new_lead_q = kr_lead_q
            new_trail_q = kr_trail_q
            
            if en_lead_q:
                if not kr_lead_q:
                    new_lead_q = en_lead_q
                    should_update = True
                elif len(en_lead_q) < len(kr_lead_q):
                    new_lead_q = en_lead_q
                    should_update = True

            if en_trail_q:
                if not kr_trail_q:
                    new_trail_q = en_trail_q
                    should_update = True
                elif len(en_trail_q) < len(kr_trail_q):
                    new_trail_q = en_trail_q
                    should_update = True
                
            intermediate_kr = original_kr
            if should_update:
                intermediate_kr = f"{en_lead_ws}{new_lead_q}{kr_content}{new_trail_q}{en_trail_ws}"

            final_kr = intermediate_kr

            # --- 2단계: 후행 서식 보정 ---
            # [ 핵심 수정: 변수 할당 추가 ]
            en_rstrip = text_en.rstrip()
            kr_rstrip = intermediate_kr.rstrip()

            if en_rstrip.endswith('"\n') and not kr_rstrip.endswith('"\n'):
                final_kr = kr_rstrip + '"\n'
            elif en_rstrip.endswith('"\\n') and not kr_rstrip.endswith('"\\n'):
                final_kr = kr_rstrip + '"\\n'

            if original_kr != final_kr:
                report['updated_count'] += 1
                report['updated_by_type'][base_type] += 1
                
                if len(report['examples']) < 3:
                    report['examples'].append({
                        'id': row_copy.get('id'),
                        'before': original_kr.replace('\n', '\\n')[:50],
                        'after': final_kr.replace('\n', '\\n')[:50]
                    })
                row_copy['text_kr'] = final_kr
        
        normalized_data.append(row_copy)
        
    return report, normalized_data


def _run_purge_numeric_ui_for_staging(staging_file_path, filters, is_test_run):
    """[컨트롤러 - CsvFileService 적용] 스테이징 파일에서 숫자 항목을 '제거'하는 작업의 흐름을 제어합니다."""
    logger = LoggerService.get_logger()
    
    staging_data = csv_file_service.load_rows_from_csv(staging_file_path)
    if not staging_data:
        logger.warning(f" -> 스테이징 파일 '{os.path.basename(staging_file_path)}'에 데이터가 없습니다.")
        return

    kept_rows, removed_rows, _ = _filter_and_split_by_rules_engine(staging_data, filters)
            
    if not removed_rows:
        logger.info("\n -> 제거할 숫자 전용 항목을 찾지 못했습니다. 파일이 변경되지 않았습니다.")
        return

    # 2. 사용자에게 미리보기 및 확인 (UI 로직)
    print("\n" + "!"*60)
    print(" [ 작업 미리보기 ]")
    logger.warning(" [주의] 이 작업은 항목을 별도 파일에 저장하지 않고 영구적으로 제거합니다.")
    print(f"  - 유지될 항목: {len(kept_rows)}개")
    print(f"  - 제거될 항목: {len(removed_rows)}개")
    print("!"*60)
    
    prompt = "\n>> 위 내용으로 스테이징 파일을 업데이트하시겠습니까? (Enter/y, ESC/n): "
    choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

    if choice == 'y':
        logger.info(" -> 작업을 시작합니다...")
        csv_file_service.write_rows_to_csv(
            staging_file_path,
            kept_rows,
            headers=OUTPUT_HEADERS,
            create_backup_on_write=True,
            is_test_run=is_test_run
        )
        logger.info(f" -> 작업 완료! {len(removed_rows)}개 항목을 스테이징 파일에서 제거했습니다.")
    else:
        logger.info(" -> 작업을 취소했습니다.")


def _run_purge_numeric_from_staging_engine(base_path, is_test_run):
    """[엔진] 사용자에게 숫자 유형을 묻고, 스테이징 파일에서 해당 항목을 분리합니다."""
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    staging_file = paths.get_staging_master_file()
    trash_file = paths.get_purge_trash_file()
    
    if not os.path.exists(staging_file):
        logger.error(f" [!] 스테이징 파일 '{os.path.basename(staging_file)}'을(를) 찾을 수 없습니다.")
        return

    # print 문은 상위 컨트롤러에서 처리하므로 여기서는 제거
    choice = get_user_input_with_special_keys("\n>> 원하는 작업 번호를 선택하세요 (ESC/q: 뒤로): ").strip()
    
    filters_to_apply = set()

    if choice == '1': filters_to_apply.add('numeric')
    elif choice == '2': filters_to_apply.add('percentage')
    elif choice == '3': filters_to_apply.add('numeric')
    elif choice in ('__esc__', '__quit__'): return
    
    if not filters_to_apply:
        logger.warning(" [!] 잘못된 선택입니다.")
        return

    _run_purge_numeric_ui_controller(staging_file, trash_file, filters_to_apply, is_test_run, create_backup=False)

# ┃
# ┃      ▲ ▲ ▲ [ 7번 기능: 스테이징 마스터 파일 관리 ] ▲ ▲ ▲    
# ┃
# ┗────────────────────────────────────────────────────────────────┘


def _run_purge_by_blacklist_engine(target_file_path, blacklist_keys, is_test_run, file_description):
    """
    [v-최종 리팩토링] 대상 파일에서 블랙리스트 항목을 제거하는 UI 컨트롤러.
    마스터 파일 수정 시 MasterFileService를 사용하여 안정성을 보장합니다.
    """
    logger = LoggerService.get_logger()
    
    base_path = os.path.dirname(target_file_path)
    paths = PathManager(base_path)
    is_master_file = (target_file_path == paths.get_master_file())

    if not os.path.exists(target_file_path):
        logger.info(f" -> 건너뛰기: 대상 파일 '{os.path.basename(target_file_path)}'이(가) 없습니다.")
        return False

    # --- 1. 데이터 분석 (파일 쓰기 없음) ---
    kept_rows = []
    analysis_report = {}
    
    if is_master_file:
        # [핵심 변경 1] MasterFileService를 통해 분석
        master_service = MasterFileService(base_path, csv_file_service)
        kept_rows, analysis_report = master_service.purge_by_blacklist(blacklist_keys)
    else:
        # 기타 파일(예: _merged_kr.csv)은 기존 방식대로 직접 분석
        target_data = csv_file_service.load_rows_from_csv(target_file_path)
        if not target_data:
            logger.info(f" -> 건너뛰기: 대상 파일 '{os.path.basename(target_file_path)}'이(가) 비어있습니다.")
            return False
        
        removed_count = 0
        for row in target_data:
            row_key = (row.get('source_file',''), row.get('id',''), row.get('type',''), text_processor_service.process(row.get('text_en','')))
            if row_key not in blacklist_keys:
                kept_rows.append(row)
            else:
                removed_count += 1
        
        analysis_report = {'removed_count': removed_count, 'kept_count': len(kept_rows)}

    deleted_count = analysis_report.get('removed_count', 0)

    if deleted_count == 0:
        logger.info(f"\n -> '{os.path.basename(target_file_path)}' 파일에는 제거할 트래시 항목이 없습니다.")
        return False
    
    # --- 2. 사용자 확인 UI ---
    print("\n" + "-"*60)
    print(f" [ {file_description} 정리 미리보기 ]")
    print(f"  - 대상 파일: '{os.path.basename(target_file_path)}'")
    print(f"  - 삭제될 항목: {deleted_count}개")
    print(f"  - 유지될 항목: {analysis_report.get('kept_count', 0)}개")
    print("-" * 60)
    prompt = f">> 위 내용으로 '{os.path.basename(target_file_path)}' 파일을 업데이트하시겠습니까? (Enter/y, ESC/n): "
    choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

    if choice != 'y':
        logger.info(" -> 작업을 취소했습니다.")
        return False

    # --- 3. 파일 쓰기 실행 ---
    if is_master_file:
        # [핵심 변경 2] MasterFileService를 통해 안전하게 저장 (자동 백업 포함)
        master_service.save_data(kept_rows, is_test_run=is_test_run)
    else:
        # 기타 파일은 CsvFileService를 통해 저장
        target_data = csv_file_service.load_rows_from_csv(target_file_path) # 헤더 정보 유지를 위해 재로드
        headers = list(target_data[0].keys()) if target_data else MASTER_FILE_HEADERS # 헤더가 없으면 기본값 사용
        csv_file_service.write_rows_to_csv(target_file_path, kept_rows, headers=headers, create_backup_on_write=True, is_test_run=is_test_run)
    
    logger.info(f" -> 작업 완료! {deleted_count}개 항목을 파일에서 제거했습니다.")
    return True

def _analyze_master_options_normalization(master_data):
    """
    [신규 엔진] 마스터 데이터에서 'options' 타입 항목의 포맷을 분석하고,
    정규화가 필요한 경우 변경된 전체 데이터 리스트를 반환합니다.
    변경이 없으면 None을 반환합니다. (파일 I/O 없음)
    """
    if not master_data:
        return None, 0

    updated_rows_count = 0
    normalized_data = []
    has_changes = False
    
    for row in master_data:
        row_copy = row.copy()
        row_type = row_copy.get('type', '')
        
        if row_type.startswith('options:'):
            original_en = row_copy.get('text_en', '')
            original_kr = row_copy.get('text_kr', '')
            
            cleaned_en = _clean_and_strip_quotes(original_en)
            cleaned_kr = _clean_and_strip_quotes(original_kr)
            
            if original_en != cleaned_en or original_kr != cleaned_kr:
                row_copy['text_en'] = cleaned_en
                row_copy['text_kr'] = cleaned_kr
                updated_rows_count += 1
                has_changes = True
        
        normalized_data.append(row_copy)

    return (normalized_data, updated_rows_count) if has_changes else (None, 0)

def _run_normalize_master_options_engine(is_test_run, base_path, shared_state=None):
    """
    [래퍼로 리팩토링됨] 'options' 포맷 정규화의 UI 흐름과 최종 저장을 담당합니다.
    """
    logger = LoggerService.get_logger()
    master_service = MasterFileService(base_path, csv_file_service)
    master_data = master_service.get_data()

    logger.info("="*60)
    logger.info("9-11. 마스터 파일 'options' 포맷 정규화를 시작합니다...")

    if not master_data:
        logger.warning(f" -> 마스터 파일 '{os.path.basename(master_service.get_path())}'에 데이터가 없어 작업을 중단합니다.")
        return False

    # 1. 핵심 엔진 호출하여 분석
    final_data, updated_count = _analyze_master_options_normalization(master_data)

    if final_data is None:
        logger.info("\n -> 모든 'options' 항목이 이미 최신 포맷입니다. 파일이 변경되지 않았습니다.")
        return False

    # 2. 사용자 확인 UI
    print("\n" + "="*70)
    print(" [ 작업 미리보기: 마스터 파일 'options' 포맷 정규화 ]")
    print("-" * 70)
    print(f"  - 대상 파일: '{os.path.basename(master_service.get_path())}'")
    print(f"  - 총 {len(master_data)}개 항목 중, 포맷이 다른 {updated_count}개 항목을 업데이트합니다.")
    print("  - 이 작업은 파일 내용을 영구적으로 변경합니다.")
    print("="*70)

    prompt = "\n>> 위 내용으로 마스터 파일을 업데이트하시겠습니까? (Enter/y, ESC/n): "
    choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

    if choice != 'y':
        logger.info(" -> 작업을 취소했습니다.")
        return False

    # 3. 파일 저장
    master_service.save_data(final_data, is_test_run=is_test_run)
    logger.info(f"\n -> 작업 완료! {updated_count}개 항목을 정규화하여 마스터 파일을 업데이트했습니다.")
    return True

def run_report_refresh_task(is_test_run, base_path, shared_state):
    """[신규 래퍼] extract_and_merge를 '리포트 전용 모드'로 실행합니다."""
    logger = LoggerService.get_logger()
    logger.info("리포트 갱신 작업을 시작합니다. (분석 전용, 주요 파일은 변경되지 않음)")
    
    # Export와 동일한 로직을 사용하되, report_only 플래그를 True로 설정
    return extract_and_merge(
        is_test_run=is_test_run,
        base_path=base_path,
        shared_state=shared_state,
        report_only=True
    )

def _extract_items_by_translatable_status(base_path, status_to_extract, output_file_path, is_test_run):
    """
    (신규 엔진) 마스터 파일에서 지정된 `Translatable` 상태의 항목을 필터링하여
    별도의 검토 파일로 추출합니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    master_file_path = paths.get_master_file()
    
    logger.info("="*60)
    logger.info(f"'{status_to_extract}' 상태 항목 추출을 시작합니다...")

    master_data = csv_file_service.load_rows_from_csv(master_file_path)
    if not master_data:
        logger.warning(f" -> 마스터 파일 '{os.path.basename(master_file_path)}'에 데이터가 없어 추출할 항목이 없습니다.")
        return

    items_for_review = []
    if status_to_extract == 'True':
        items_for_review = [row for row in master_data if row.get('Translatable', '').strip().lower() == 'true']
    elif status_to_extract == 'False':
        # 'False' 상태는 'false' 문자열 또는 공백 모두를 포함하여 필터링
        items_for_review = [row for row in master_data if row.get('Translatable', '').strip().lower() in ('false', '')]

    if not items_for_review:
        logger.info(f" -> 마스터 파일에 '{status_to_extract}' 상태인 항목이 없습니다. 파일을 생성하지 않습니다.")
        # 만약 이전에 생성된 검토 파일이 있다면 삭제
        if os.path.exists(output_file_path):
            if not is_test_run: os.remove(output_file_path)
            logger.info(f" -> 기존의 '{os.path.basename(output_file_path)}' 파일을 삭제했습니다.")
        return

    # --- 사용자에게 미리보기 및 확인 ---
    print("\n" + "="*70)
    print(f" [ '{status_to_extract}' 상태 항목 추출 미리보기 ]")
    print("-" * 70)
    print(f"  - 원본 마스터 파일: '{os.path.basename(master_file_path)}'")
    print(f"  - 추출 대상 항목 수: {len(items_for_review)}개")
    print("-" * 70)
    print(f"  -> 이 항목들은 '{os.path.basename(output_file_path)}' 파일로 생성됩니다.")
    print("     (파일 생성 후, 'Translatable' 컬럼은 비워져 새로운 결정을 기다립니다.)")
    print("="*70)

    prompt = "\n>> 위 내용으로 작업을 진행하시겠습니까? (Enter/y: 예, ESC/n: 아니오): "
    choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

    if choice != 'y':
        logger.info(" -> 작업을 취소했습니다.")
        return

    # --- 재검토 파일 생성 ---
    for row in items_for_review:
        row['Translatable'] = '' 

    csv_file_service.write_rows_to_csv(
        output_file_path, items_for_review, headers=REVIEW_NEEDED_HEADERS, create_backup_on_write=False, is_test_run=is_test_run
    )
    logger.info(f" -> '{os.path.basename(output_file_path)}' 파일에 {len(items_for_review)}개 항목을 기록했습니다.")
    logger.info(f"\n -> 생성된 '{os.path.basename(output_file_path)}' 파일을 확인하여, 'Translatable' 컬럼을 편집하고 0번 메뉴로 처리하십시오.")



def _run_extract_empty_kr_from_master_engine(is_test_run, base_path, shared_state=None):
    """
    [v2.2 - 검토 기능 강화] 마스터 파일에서 text_kr이 비어있는 모든 항목을 추출하여
    'Translatable' 열을 포함한 검토용 파일로 생성하고, 사용자 선택에 따라 이동/복사합니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)

    master_service = MasterFileService(base_path, csv_file_service)
    master_data = master_service.get_data()

    output_file_path = paths.get_master_empty_kr_file()
    
    logger.info("="*60)
    logger.info("9-7. 마스터에서 번역 없는 항목 추출을 시작합니다...")

    if not master_data:
        logger.warning(f" -> 마스터 파일 '{os.path.basename(master_service.get_path())}'에 데이터가 없어 추출할 항목이 없습니다.")
        return False

    master_data_no_x = [row for row in master_data if row.get('Translatable', '').strip().lower() != 'x']
    empty_kr_rows = [row for row in master_data_no_x if not (row.get('text_kr') or '').strip()]
    kept_rows = [row for row in master_data_no_x if (row.get('text_kr') or '').strip()]
    # [수정] 'x' 항목을 최종 유지 목록에 다시 포함시켜야 데이터 유실 방지
    x_items = [row for row in master_data if row.get('Translatable', '').strip().lower() == 'x']
    final_kept_rows = kept_rows + x_items


    if not empty_kr_rows:
        logger.info(f" -> 마스터 파일에 번역이 비어있는 항목이 없습니다. 파일을 생성하지 않습니다.")
        if os.path.exists(output_file_path):
            if not is_test_run: os.remove(output_file_path)
            logger.info(f" -> 기존의 '{os.path.basename(output_file_path)}' 파일을 삭제했습니다.")
        return False

    # 추출된 항목의 'Translatable' 값을 비워 새로운 결정을 기다리는 상태로 만듭니다.
    rows_for_review_file = []
    for row in empty_kr_rows:
        review_row = row.copy()
        review_row['Translatable'] = ''
        rows_for_review_file.append(review_row)

    # --- 1. 사용자에게 처리 방식 선택 UI 제공 ---
    print("\n" + "="*70)
    print(" [ 번역 없는 항목 발견 ]")
    print(f"  - 마스터 파일에서 총 {len(rows_for_review_file)}개의 번역 없는 항목을 발견했습니다.")
    print("-" * 70)
    print("\n어떻게 처리하시겠습니까?\n")
    print("  1. 복사만 하기 (Copy Only): 마스터 파일은 그대로 두고, 새 파일에만 기록합니다. (안전)")
    print("  2. 이동하기 (Move): 새 파일에 기록하고, 마스터 파일에서는 이 항목들을 제거합니다.")

    prompt_mode = "\n>> 원하는 작업 번호를 선택하세요 (ESC: 뒤로): "
    mode_choice = prompt_for_input(prompt_mode, valid_choices=['1', '2'])

    if mode_choice is UserInput.ESC or mode_choice is UserInput.QUIT:
        logger.info(" -> 작업을 취소했습니다.")
        return False

    # --- 2. 선택에 따른 미리보기 및 최종 확인 ---
    if mode_choice == '1': # 복사 모드
        print("\n" + "="*70)
        print(" [ 작업 미리보기: 복사 ]")
        print("-" * 70)
        print(f"  - {len(rows_for_review_file)}개 항목을 '{os.path.basename(output_file_path)}' 파일에 복사합니다.")
        print(f"  - 마스터 파일('{os.path.basename(master_service.get_path())}')은 변경되지 않습니다.")
        print("="*70)
        prompt_confirm = "\n>> 위 내용으로 복사 작업을 진행하시겠습니까? (Enter/y, ESC/n): "
        choice_confirm = prompt_for_input(prompt_confirm, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

        if choice_confirm != 'y':
            logger.info(" -> 작업을 취소했습니다."); return False

        csv_file_service.write_rows_to_csv(output_file_path, rows_for_review_file, headers=REVIEW_NEEDED_HEADERS, is_test_run=is_test_run)
        logger.info(f"\n -> 복사 완료! '{os.path.basename(output_file_path)}' 파일에 {len(rows_for_review_file)}개 항목을 기록했습니다.")

    elif mode_choice == '2': # 이동 모드
        print("\n" + "!"*70)
        print(" [ !! 작업 미리보기: 이동 (마스터 파일 수정) !! ]")
        print("!" * 70)
        print(f"  - {len(rows_for_review_file)}개 항목을 '{os.path.basename(output_file_path)}' 파일로 이동합니다.")
        print(f"  - 마스터 파일('{os.path.basename(master_service.get_path())}')에서는 이 항목들이 제거됩니다.")
        print(f"    (원본 {len(master_data)}개 -> 변경 후 {len(final_kept_rows)}개)")
        print("!"*70)
        prompt_confirm = "\n>> 정말로 마스터 파일을 수정하고 이동 작업을 진행하시겠습니까? (Enter/y, ESC/n): "
        choice_confirm = prompt_for_input(prompt_confirm, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

        if choice_confirm != 'y':
            logger.info(" -> 작업을 취소했습니다."); return False
            
        # 1. 새 파일에 쓰기
        csv_file_service.write_rows_to_csv(output_file_path, rows_for_review_file, headers=REVIEW_NEEDED_HEADERS, is_test_run=is_test_run)
        
        # [★★★★★ 핵심 수정 2: 서비스 메서드 호출로 교체 ★★★★★]
        master_service.save_data(final_kept_rows, is_test_run=is_test_run)
        
        logger.info(f"\n -> 이동 완료! {len(rows_for_review_file)}개 항목을 새 파일로 옮기고 마스터 파일을 업데이트했습니다.")

    logger.info(f"\n -> 생성된 '{os.path.basename(output_file_path)}' 파일을 열어 번역을 채우거나, 'Translatable' 열을 편집한 후 '0번 메뉴'로 처리할 수 있습니다.")
    return True


def _run_merge_trash_to_master_engine(is_test_run, base_path, shared_state=None):
    """[신규 엔진] 9-0. 트래시 파일의 내용을 마스터 파일 하단에 병합합니다."""
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)

    master_service = MasterFileService(base_path, csv_file_service)
    master_data = master_service.get_data()
    
    trash_file_path = paths.get_purge_trash_file()

    logger.info("="*60)
    logger.info("9-0. 트래시 파일 -> 마스터 파일 병합을 시작합니다...")

    trash_data = csv_file_service.load_rows_from_csv(trash_file_path)

    if not trash_data:
        logger.warning(f" -> 트래시 파일 '{os.path.basename(trash_file_path)}'에 데이터가 없어 작업을 중단합니다.")
        return False
    if not master_data:
        logger.warning(f" -> 마스터 파일 '{os.path.basename(master_service.get_path())}'이 비어있습니다. 먼저 마스터 파일을 생성하세요.")
        return False

    # 1. 중복 제거를 위해 마스터 데이터의 키 셋 생성
    master_keys_set = {
        (row.get('source_file', ''), row.get('id', ''), row.get('type', ''), row.get('text_en', ''))
        for row in master_data
    }

    # 2. 트래시 데이터에서 마스터에 없는 항목만 선별 및 전처리
    items_to_add = []
    for trash_row in trash_data:
        trash_key = (trash_row.get('source_file', ''), trash_row.get('id', ''), trash_row.get('type', ''), trash_row.get('text_en', ''))
        if trash_key not in master_keys_set:
            processed_row = trash_row.copy()
            processed_row['Translatable'] = 'x' # Translatable 값을 'x'로 강제 설정
            items_to_add.append(processed_row)

    if not items_to_add:
        logger.info(" -> 트래시 파일에 있는 모든 항목이 이미 마스터 파일에 존재합니다. 추가할 새로운 항목이 없습니다.")
        return False
    
    # 3. 미리보기 및 사용자 확인
    print("\n" + "="*70)
    print(" [ 작업 미리보기: 트래시 -> 마스터로 병합 ]")
    print("-" * 70)
    print(f"  - 트래시 파일에서 발견된 {len(trash_data)}개 항목 중,")
    print(f"  - 마스터 파일에 없는 새로운 {len(items_to_add)}개 항목을 마스터 파일 하단에 추가합니다.")
    print("  - 추가되는 모든 항목은 'Translatable: x'로 설정됩니다.")
    print("="*70)

    prompt = "\n>> 위 내용으로 마스터 파일을 업데이트하시겠습니까? (Enter/y, ESC/n): "
    choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

    if choice != 'y':
        logger.info(" -> 작업을 취소했습니다.")
        return False

    # 4. 데이터 재구성 및 파일 쓰기
    logger.info(" -> 마스터 파일에 새로운 트래시 항목을 추가합니다...")
    
    final_master_data = master_data + items_to_add

    master_service.save_data(final_master_data, is_test_run=is_test_run)

    logger.info(f"\n -> 작업 완료! {len(items_to_add)}개의 새로운 'x' 항목을 마스터 파일에 추가했습니다.")
    return True


def _run_re_evaluate_by_status_controller(is_test_run, base_path, shared_state=None):
    """
    (v4.26.XX 재설계) 9-7. `Translatable` 상태별 항목 검토 기능의 컨트롤러.
    사용자에게 'True' 또는 'False' 상태 중 어떤 것을 추출할지 선택받습니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)

    print("\n" + "="*60)
    print(" [ 9-7. `Translatable` 상태별 항목 검토 ]")
    print("\n어떤 상태의 항목을 추출하여 검토하시겠습니까?\n")
    print("  1. 'True' (승인된 항목) -> '{MASTER_TRUE_REVIEW_FILENAME_SUFFIX}' 파일로 추출")
    print("  2. 'False' (비활성 항목) -> '{MASTER_FALSE_REVIEW_FILENAME_SUFFIX}' 파일로 추출")

    prompt = "\n>> 원하는 작업 번호를 선택하세요 (ESC/q: 뒤로): "
    choice = prompt_for_input(prompt, valid_choices=['1', '2'])
    
    if choice is UserInput.ESC or choice is UserInput.QUIT:
        logger.info(" -> 작업을 취소했습니다.")
        return False # False를 반환하여 execute_task가 "작업 미수행"으로 인지하도록 함

    if choice == '1':
        status_to_extract = 'True'
        output_file_path = paths.get_master_true_review_file()
    elif choice == '2':
        status_to_extract = 'False'
        output_file_path = paths.get_master_false_review_file()

    # 새로운 엔진 함수 호출
    _extract_items_by_translatable_status(
        base_path, status_to_extract, output_file_path, is_test_run
    )
# ┃
# ┃
# ┗────────────────────────────────────────────────────────────────

def _display_master_review_report(report_data, base_path):
    """
    9-6. 마스터 파일 필터링 리포트용 '데이터 빌더'.
    [v-latest UI 수정] 이모지를 ASCII 문자로 변경합니다.
    """
    def bp(file_suffix):
        return os.path.basename(f"...{file_suffix}")

    # --- 1. Report Bundle 데이터 구조 생성 ---
    report_bundle = {
        "header": {
            "report_title": "마스터 파일 필터링 리포트",
            "target_name": os.path.basename(base_path),
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "summary_lines": [
                {"label": "최종 마스터 항목 수", "value": f"{report_data.get('final_master_item_count', 0)}개"},
                {"label": "검토 필요 항목 수", "value": f"{report_data.get('review_needed_count', 0)}개"},
                {"label": "제거된 항목 수", "value": f"{report_data.get('removed_count', 0)}개"}
            ]
        },
        "sections": []
    }

    # --- 섹션 1: 초기 상태 ---
    initial_section_content = [
        {"label": "✔ 총 분석 대상 항목", "value": f"{report_data.get('initial_master_item_count', 0)}개", "level": 1},
    ]
    if report_data.get('skipped_by_translatable_count', 0) > 0:
        initial_section_content.append(
            {"label": "└─ (필터 면제) 'Translatable: True' 항목", "value": f"{report_data.get('skipped_by_translatable_count', 0)}개", "level": 2}
        )
    report_bundle["sections"].append({
        "section_title": "단계 1: 마스터 파일 초기 상태",
        "section_type": "key_value_list",
        "content": initial_section_content
    })

    # --- 섹션 2: 필터링 및 분류 결과 ---
    classification_section_content = []
    if report_data.get('review_needed_count', 0) > 0:
        classification_section_content.append(
            {"label": "검토 필요 (코드 의심, 번역 있음)", "label_prefix": "[*] ", "value": f"{report_data.get('review_needed_count', 0)}개", "level": 1}
        )
    if report_data.get('removed_count', 0) > 0:
        classification_section_content.append(
            {"label": "제거 대상 (번역 불가 항목)", "label_prefix": "[-] ", "value": f"{report_data.get('removed_count', 0)}개", "level": 1}
        )
        if report_data.get('removed_reasons'):
            sorted_reasons = sorted(report_data['removed_reasons'].items(), key=lambda item: item[1], reverse=True)
            for reason_key, count in sorted_reasons:
                classification_section_content.append({
                    "label_key": reason_key,
                    "translate_label": True,
                    "value": f"{count}개",
                    "level": 2,
                    "label_prefix": "   └─ "
                })
    classification_section_content.append(
        {"label": "유지 (필터 통과)", "label_prefix": "[+] ", "value": f"{report_data.get('kept_count', 0)}개", "level": 1}
    )
    report_bundle["sections"].append({
        "section_title": "단계 2: 필터링 및 분류 결과",
        "section_type": "key_value_list",
        "content": classification_section_content
    })
    
    # --- 섹션 3: 최종 출력 파일 요약 ---
    output_section_content = [
        {"label": f"✅ {bp(MASTER_FILENAME_SUFFIX)}", "value": f"{report_data.get('final_master_item_count', 0)}개 행 (업데이트됨)", "level": 1}
    ]
    if report_data.get('review_needed_count', 0) > 0:
        output_section_content.insert(0, {"label": f"📝 {bp(MASTER_REVIEW_NEEDED_FILENAME_SUFFIX)}", "value": f"{report_data.get('review_needed_count', 0)}개 행", "level": 1})
    if report_data.get('purged_added_count', 0) > 0:
        output_section_content.insert(1, {"label": f"🗑️ {bp(MASTER_PURGED_FILENAME_SUFFIX)}", "value": f"{report_data.get('purged_added_count', 0)}개 행 추가", "level": 1})
    report_bundle["sections"].append({
        "section_title": "단계 3: 최종 출력 파일 요약",
        "section_type": "key_value_list",
        "content": output_section_content
    })

    # --- 2. 범용 리포트 렌더러 호출 (번역 사전 전달) ---
    _render_standard_report(report_bundle, translations=REASON_TRANSLATIONS)


def _run_master_file_filter_and_review(is_test_run, base_path, shared_state=None):
    """
    (v4.26.37 수정됨) 9-6. 마스터 파일을 필터링 및 검토하는 기능.
    [핵심 버그 수정] _filter_and_split_by_rules_engine 결과 합치기 로직을 수정했습니다.
    """
    logger = LoggerService.get_logger()
    logger.info("="*60)
    logger.info("9-6. 마스터 파일 필터링 및 검토를 시작합니다...")

    paths = PathManager(base_path)

    master_service = MasterFileService(base_path, csv_file_service)
    master_data = master_service.get_data()

    master_review_file_path = paths.get_master_review_needed_file()
    master_purged_file_path = paths.get_master_purged_file()

    if not master_data:
        logger.info(f" -> 마스터 파일 '{os.path.basename(master_service.get_path())}'에 데이터가 없습니다. 검토할 항목이 없습니다.")
        return

    # --- 리포트 데이터 구조 초기화 ---
    report = {
        'initial_master_item_count': len(master_data),
        'skipped_by_translatable_count': 0,
        'review_needed_count': 0,
        'removed_count': 0,
        'kept_count': 0,
        'purged_added_count': 0,
        'final_master_item_count': 0,
        'removed_reasons': defaultdict(int),
    }

    kept_from_master, review_needed_from_master, removed_from_master = [], [], []
    filtered_for_review_data = []
    for row in master_data:
        if row.get('Translatable', '').strip().lower() == 'true':
            kept_from_master.append(row)
            report['skipped_by_translatable_count'] += 1
        else:
            filtered_for_review_data.append(row)

    _kept, _review_needed, _removed = _filter_and_split_by_rules_engine(
        filtered_for_review_data,
        filters_to_apply={'numeric', 'percentage', 'script_code_patterns'}
    )
    
    kept_from_master.extend(_kept)
    review_needed_from_master.extend(_review_needed)
    removed_from_master.extend(_removed)

    for removed_row in removed_from_master:
        reason = removed_row.get('removal_reason', 'Unknown')
        report['removed_reasons'][reason] += 1
        if 'removal_reason' in removed_row:
            del removed_row['removal_reason'] 

    report['review_needed_count'] = len(review_needed_from_master)
    report['removed_count'] = len(removed_from_master)
    report['kept_count'] = len(kept_from_master)
    report['final_master_item_count'] = len(kept_from_master)

    _display_master_review_report(report, base_path)

    # 실제 변경사항이 없다면 사용자 확인 없이 종료
    if not review_needed_from_master and not removed_from_master:
        logger.info(" -> 마스터 파일에 적용할 새로운 변경 사항이 없습니다. 작업을 종료합니다.")
        if os.path.exists(master_review_file_path):
            if not is_test_run: os.remove(master_review_file_path)
            logger.info(f" -> '{os.path.basename(master_review_file_path)}' 파일을 삭제했습니다.")
        return


    prompt = "\n>> 위 내용으로 작업을 진행하시겠습니까? (Enter/y: 예, ESC/n: 아니오): "
    choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

    if choice != 'y':
        logger.info(" -> 작업을 취소했습니다.")
        return

    # --- 마스터 검토 파일 생성 (review_needed_from_master만) ---
    if review_needed_from_master:
        cleaned_review_needed_rows = []
        for row in review_needed_from_master:
            row_copy = row.copy()
            if 'removal_reason' in row_copy:
                del row_copy['removal_reason']
            row_copy['Translatable'] = ''
        cleaned_review_needed_rows = []
        for row in review_needed_from_master:
            row_copy = row.copy()
            if 'removal_reason' in row_copy:
                del row_copy['removal_reason']
            row_copy['Translatable'] = ''
            cleaned_review_needed_rows.append(row_copy)
        csv_file_service.write_rows_to_csv(
            master_review_file_path, cleaned_review_needed_rows, headers=REVIEW_NEEDED_HEADERS, create_backup_on_write=False, is_test_run=is_test_run
        )
        logger.info(f" -> '{os.path.basename(master_review_file_path)}' 파일에 {len(review_needed_from_master)}개 항목을 기록했습니다.")
    else:
        if os.path.exists(master_review_file_path):
            if not is_test_run: os.remove(master_review_file_path)
            logger.info(f" -> 검토 필요 항목이 없어 '{os.path.basename(master_review_file_path)}' 파일을 삭제했습니다.")

    # --- 마스터 퍼지(purged) 파일 생성/추가 (removed_from_master만) ---
    purged_added_count = 0
    if removed_from_master:
        purged_rows_with_flag = []
        for row in removed_from_master:
            row_copy = row.copy()
            row_copy['Translatable'] = ''
            if 'removal_reason' in row_copy:
                del row_copy['removal_reason']
            purged_rows_with_flag.append(row_copy)
        purged_added_count = csv_file_service.append_rows_to_csv_without_duplicates(
            master_purged_file_path, purged_rows_with_flag, headers=REVIEW_NEEDED_HEADERS, create_backup_on_write=True, is_test_run=is_test_run
        )
        report['purged_added_count'] = purged_added_count
        logger.info(f" -> '{os.path.basename(master_purged_file_path)}' 파일에 {purged_added_count}개의 새로운 삭제 항목을 추가했습니다.")
    else:
        logger.info(" -> 삭제된 항목 기록 파일에 추가할 새로운 내용이 없습니다.")

    # --- 마스터 파일 업데이트 ---
    if review_needed_from_master or removed_from_master:
        logger.info(f" -> 마스터 파일 '{os.path.basename(master_service.get_path())}'을(를) 업데이트합니다.")
        
        # [★★★★★ 핵심 수정 2: 서비스 메서드 호출로 교체 ★★★★★]
        master_service.save_data(kept_from_master, is_test_run=is_test_run)

    else:
        logger.info(" -> 마스터 파일은 변경되지 않았습니다.")
    
    _display_master_review_report(report, base_path)


# ┏────────────────────────────────────────────────────────────────┐
#
#          [ 주요 기능 핵심 엔진 로직 ]
#
# ┗────────────────────────────────────────────────────────────────┘


def _purge_numeric_engine(master_file_path, trash_file_path, filters, is_test_run=False):
    """
    (v4.26.28 수정됨) 마스터 파일에서 지정된 필터에 따라 숫자 전용 항목을 분리합니다.
    이제 CsvFileService를 사용하여 파일 입출력을 처리합니다.
    """
    logger = LoggerService.get_logger()
    
    master_data = csv_file_service.load_rows_from_csv(master_file_path)
    if not master_data:
        logger.warning(f" -> 원본 마스터 파일 '{os.path.basename(master_file_path)}'에 데이터가 없습니다.")
        return

    kept_rows, trashed_rows, _ = _filter_and_split_by_rules_engine(
        master_data,
        filters_to_apply=filters
    )
        
    if not trashed_rows:
        logger.info(f"\n -> '{os.path.basename(master_file_path)}'에서 분리할 숫자 전용 항목을 찾지 못했습니다. 파일이 변경되지 않았습니다.")
        return

    print("\n" + "="*60)
    print(" [ 작업 미리보기 ]")
    print(f"  - 원본 파일: '{os.path.basename(master_file_path)}'")
    print(f"  - 유지될 항목: {len(kept_rows)}개")
    print(f"  - 분리될 항목 (트래시): {len(trashed_rows)}개")
    print("="*60)
    
    prompt = "\n>> 위 내용으로 마스터 파일을 업데이트하고 트래시 파일에 추가하시겠습니까? (Enter/y, ESC/n): "
    choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

    if choice in ('', 'y'):
        logger.info(" -> 작업을 시작합니다...")
        # 마스터 파일 업데이트 (kept_rows만 남김)
        csv_file_service.write_rows_to_csv(
            master_file_path, kept_rows, headers=OUTPUT_HEADERS, create_backup_on_write=True, is_test_run=is_test_run
        )
        # 트래시 파일에 추가 (trashed_rows)
        added_count = csv_file_service.append_rows_to_csv_without_duplicates(
            trash_file_path, trashed_rows, headers=OUTPUT_HEADERS, create_backup_on_write=True, is_test_run=is_test_run
        )
        logger.info(f" -> 작업 완료! {len(kept_rows)}개 항목을 '{os.path.basename(master_file_path)}' 파일에 유지하고,")
        logger.info(f"    '{os.path.basename(trash_file_path)}' 파일에 {added_count}개의 새로운 항목을 추가/기록했습니다.")
        return True
    else:
        logger.info(" -> 작업을 취소했습니다.")
        return False

def _run_purge_numeric_wrapper(is_test_run, base_path, shared_state):
    """
    [신규 래퍼] execute_task가 숫자 항목 분리 엔진을 호출할 수 있도록 합니다.
    shared_state에서 사용자가 선택한 필터 정보를 받아 엔진에 전달합니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    master_file = paths.get_master_file()
    trash_file = paths.get_purge_trash_file()

    filters_to_apply = shared_state.get('filters_to_apply')
    if not filters_to_apply:
        logger.error(" [!] 내부 오류: 숫자 분리를 위한 필터 정보가 전달되지 않았습니다.")
        return False # 작업 실패

    # 기존 엔진 함수를 그대로 호출
    _run_purge_numeric_ui_controller(master_file, trash_file, filters_to_apply, is_test_run)
    return True # 엔진이 자체적으로 UI와 pause를 관리하므로, 여기서는 성공만 반환

def run_purge_numeric_from_master_menu(base_path, is_test_run):
    """
    [UI 컨트롤러로 리팩토링됨] 사용자에게 숫자 제거 옵션을 묻고,
    선택된 필터 그룹(set)을 반환합니다. 실제 실행은 하지 않습니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    master_file = paths.get_master_file()
    
    if not os.path.exists(master_file):
        logger.error(f" [!] 마스터 파일 '{os.path.basename(master_file)}'을(를) 찾을 수 없습니다.")
        return None

    print("\n [ 9-4. 마스터에서 숫자 전용 항목 분리 ]\n")
    print("어떤 종류의 숫자 항목을 분리하시겠습니까?\n")
    print("1. 정수 및 실수 (예: 123, -10.5)")
    print("2. 퍼센트 형식 (예: 50%, -12.5%)")
    print("3. 위 모든 종류")

    choice = prompt_for_input("\n>> 원하는 작업 번호를 선택하세요 (ESC/q: 뒤로): ").strip()
    
    filters_to_apply = set()

    if choice == '1':
        filters_to_apply.add('numeric')
    elif choice == '2':
        filters_to_apply.add('percentage')
    elif choice == '3':
        filters_to_apply.add('numeric')
        filters_to_apply.add('percentage')
    elif choice in ('__esc__', '__quit__'):
        return None
    
    if not filters_to_apply:
        logger.warning(" [!] 잘못된 선택입니다.")
        return None

    return filters_to_apply


def _run_purge_numeric_ui_controller(master_file_path, trash_file_path, filters, is_test_run, create_backup=True):
    """
    (v4.26.28 수정됨) 숫자 항목 분리 작업의 전체 흐름(로드, 엔진 호출, UI, 저장)을 제어합니다.
    이제 CsvFileService를 사용하여 파일 입출력을 처리합니다.
    """
    logger = LoggerService.get_logger()
    source_filename = os.path.basename(master_file_path)

    base_path = os.path.dirname(master_file_path)
    master_service = MasterFileService(base_path, csv_file_service)
    master_data = master_service.get_data()

    if not master_data:
        logger.warning(f" -> 원본 파일 '{source_filename}'에 데이터가 없습니다.")
        return False # 작업 실패

    kept_rows, trashed_rows, _ = _filter_and_split_by_rules_engine(
        master_data,
        filters_to_apply=filters # _filter_and_split_by_rules_engine은 이제 3번째 인자로 removed_rows를 반환하지만, 여기서는 무시
    )
            
    if not trashed_rows:
        logger.info(f"\n -> '{source_filename}'에서 분리할 숫자 전용 항목을 찾지 못했습니다. 파일이 변경되지 않았습니다.")
        return False # 작업 수행 안 됨

    print("\n" + "="*60)
    print(" [ 작업 미리보기 ]")
    print(f"  - 원본 파일: '{source_filename}'")
    print(f"  - 유지될 항목: {len(kept_rows)}개")
    print(f"  - 분리될 항목 (트래시): {len(trashed_rows)}개")
    print("="*60)
    
    prompt = "\n>> 위 내용으로 마스터 파일을 업데이트하고 트래시 파일에 추가하시겠습니까? (Enter/y, ESC/n): "
    choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

    if choice in ('', 'y'):
        logger.info(" -> 작업을 시작합니다...")

        master_service.save_data(kept_rows, is_test_run=is_test_run)        
        
        # 트래시 파일에 추가 (trashed_rows)
        added_count = csv_file_service.append_rows_to_csv_without_duplicates(
            trash_file_path, trashed_rows, headers=OUTPUT_HEADERS, create_backup_on_write=True, is_test_run=is_test_run
        )
        
        logger.info(f" -> 작업 완료! {len(kept_rows)}개 항목을 '{source_filename}' 파일에 유지하고,")
        logger.info(f"    '{os.path.basename(trash_file_path)}' 파일에 {added_count}개의 새로운 항목을 추가/기록했습니다.")
        return True
    else:
        logger.info(" -> 작업을 취소했습니다.")
        return False


def _filter_and_split_by_rules_engine(data_rows, filters_to_apply):
    """
    (v4.26.29 수정됨) 'text_en'을 기준으로 필터링하며,
    1. POST_FILTER_EXCLUSION_RULES (review_needed)
    2. is_translatable()이 False를 반환해야 하는 항목 (removed)
    두 가지 기준에 따라 항목들을 분류합니다.
    [핵심 개선] text_kr이 있는 경우, 번역 불가 항목도 '삭제' 대신 '검토 필요'로 분류하여 데이터 유실을 방지합니다.
    (kept_rows, review_needed_rows, removed_rows) 튜플 반환.
    """
    if not data_rows:
        return [], [], []

    kept_rows, review_needed_rows, removed_rows = [], [], []

    # 정규식 패턴 정의 (is_translatable과 동일하게 유지)
    numeric_pattern = re.compile(r"[-+]?[\d,]+(\.\d+)?")
    percentage_pattern = re.compile(r"[-+]?[\d,]+(\.\d+)?%")
    script_code_patterns_list = [ # 이름 변경 (conflict 방지)
        (r'^\s*\$[a-zA-Z0-9_.]+\s*=\s*.+$', 'Assignment'), # $변수 = 값 할당 (예: $player.credits = 1000)
        (r'^\s*(Call|FireAll|FireBest|AdjustRep|RemoveOption|AddRemoveAnyItem|BeginMission|EndConversation|ShowPersonVisual|SetPersonHidden|AddCredits|RemoveCommodity|DoCanAffordCheck)\s+.*', 'FunctionCall'), # 함수 호출/명령어 (SetTextHighlights 제외)
        (r'^\s*\$global\..*$', 'GlobalVar'), # $global 변수 단독 사용
        (r'^\s*\$player\..*$', 'PlayerVar'), # $player 변수 단독 사용
        (r'^\s*BeginConversation\s', 'BeginConversation'), # BeginConversation으로 시작
        (r'^\s*SetOptionColor\s', 'SetOptionColor'), # SetOptionColor로 시작
        (r'^\s*ShowImageVisual\s', 'ShowImageVisual'), # ShowImageVisual로 시작
        (r'T\sH\sR\sE\sA\sT', 'ThreatPattern'), # 'T H R E A T' 패턴 (스크립트 패턴으로 간주)
        (r'^[\d,]+$', 'PureNumberString'), # 쉼표로 구성된 숫자 (예: 1,000) (스크립트 패턴으로 간주)
    ]
    
    # 단일 $변수 필터링용
    single_dollar_var_pattern = re.compile(r'^\s*\$[a-zA-Z0-9_.]+\s*$')
    # RGB(A) 컬러 코드 형식 (예: "255, 128, 0, 255")
    rgb_color_pattern = re.compile(r'^\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}(?:\s*,\s*\d{1,3})?$')


    for row in data_rows:
        text_en = row.get('text_en', '').strip()
        item_type = row.get('type', '').lower().split(':')[0]
        has_text_kr = bool(row.get('text_kr', '').strip())
        
        # [우선 순위 1] is_translatable()이 False를 반환해야 하는 명백한 '번역 불가' 항목
        # 즉, 1차 필터링 단계에서 걸러졌어야 하지만, 어떤 이유로든 통과한 항목들.
        # 이들은 'removed_rows'로 분류하여, 추후 제거될 수 있도록 합니다.
        is_code_or_pure_number = False
        removal_reason = "Unknown" # 제거 사유 초기화
        text_no_quotes = text_en.strip('"') # 따옴표 제거 후 검사

        # 1-1. 순수 숫자/퍼센트
        if ('numeric' in filters_to_apply or 'percentage' in filters_to_apply) and text_no_quotes:
            if 'numeric' in filters_to_apply and numeric_pattern.fullmatch(text_no_quotes) and not any(c.isalpha() for c in text_no_quotes):
                is_code_or_pure_number = True
                removal_reason = 'NumericOnly'
            if not is_code_or_pure_number and 'percentage' in filters_to_apply and percentage_pattern.fullmatch(text_no_quotes) and not any(c.isalpha() for c in text_no_quotes):
                is_code_or_pure_number = True
                removal_reason = 'PercentageOnly'
        
        # 1-2. RGB(A) 컬러 코드 형식
        if not is_code_or_pure_number and rgb_color_pattern.fullmatch(text_no_quotes):
            is_code_or_pure_number = True
            removal_reason = 'RgbColorCode'

        # 1-3. 스크립트 코드 패턴 (is_translatable의 script_code_patterns와 유사)
        if not is_code_or_pure_number and 'script_code_patterns' in filters_to_apply:
            for pattern, reason_name in script_code_patterns_list:
                if re.search(pattern, text_en, re.IGNORECASE | re.DOTALL): # text_en 전체를 대상으로 search
                    is_code_or_pure_number = True
                    removal_reason = reason_name
                    break
        
        # 1-4. 단일 $변수 (is_translatable의 단일 $변수 필터와 유사)
        if not is_code_or_pure_number and single_dollar_var_pattern.fullmatch(text_en):
            is_code_or_pure_number = True
            removal_reason = 'SingleDollarVariable'
        
        # 1-5. NON_TRANSLATABLE_STRINGS (단일 단어/기호 등)
        if not is_code_or_pure_number and text_en.lower() in NON_TRANSLATABLE_STRINGS:
            is_code_or_pure_number = True
            removal_reason = 'NonTranslatableString'

        # --- is_code_or_pure_number 최종 판단 ---
        if is_code_or_pure_number:
            row_copy = row.copy() # 원본 데이터 변경 방지
            row_copy['removal_reason'] = removal_reason # 제거 사유 추가
            if has_text_kr:
                review_needed_rows.append(row_copy)
            else:
                removed_rows.append(row_copy)
            continue # 다음 항목으로 넘어갑니다. (더 이상 검토할 필요 없음)


        # [우선 순위 2] POST_FILTER_EXCLUSION_RULES에 정의된 '애매한 코드성' 항목
        # 이들은 'review_needed_rows'로 분류하여, 사용자의 수동 검토를 기다립니다.
        is_review_needed = False
        rules_for_type = POST_FILTER_EXCLUSION_RULES.get(item_type)

        if rules_for_type:
            for segment in text_en.split(SCRIPT_TEXT_DELIMITER):
                segment_to_check = segment.strip()
                if not segment_to_check:
                    continue
                
                for pattern in rules_for_type:
                    if re.search(pattern, segment_to_check, re.IGNORECASE | re.DOTALL):
                        is_review_needed = True
                        break
                if is_review_needed:
                    break
        
        # --- is_review_needed 최종 판단 ---
        if is_review_needed:
            review_needed_rows.append(row)
        else:
            kept_rows.append(row)
            
    return kept_rows, review_needed_rows, removed_rows


def _run_sync_logic_wrapper(is_test_run=False, base_path=None, shared_state=None):
    """execute_task를 위한 래퍼 함수. 단일 모드에 대한 동기화 메뉴를 표시."""
    # 기존 _run_sync_sub_menu의 로직과 동일
    logger = LoggerService.get_logger()
    
    paths = PathManager(base_path)
    merged_file = paths.get_merged_file()
    master_file = paths.get_master_file()

    # execute_task가 이미 유효성 검사를 했으므로 여기서는 메뉴만 표시
    print("\n [ 9-1. 마스터 파일 동기화 ]\n")
    print(f"  - 대상 모드: {get_mod_display_name(base_path)}")
    print(f"  - 원본 (최신): {os.path.basename(merged_file)}")
    print(f"  - 대상 (마스터): {os.path.basename(master_file)}\n")
    print("1. 자동 동기화 (덮어쓰기) [권장]")
    print("2. 수동 병합 (충돌 해결) [고급]")
    
    sync_choice = get_user_input_with_special_keys("\n>> 원하는 작업 번호를 선택하세요 (ESC/q: 다음 모드/뒤로): ").strip()
    if sync_choice in ('__esc__', '__quit__'): return

    if sync_choice == '1':
        _sync_engine_overwrite(merged_file, master_file, is_test_run)
    elif sync_choice == '2':
        _run_manual_sync_logic(merged_file, master_file, is_test_run)

def _run_rename_logic_batch(is_test_run, base_path):
    """9-2. 마스터 파일 이름 변경을 일괄적으로 처리하는 전체 로직."""
    logger = LoggerService.get_logger()
    
    if OLD_MASTER_FILENAME_SUFFIX == MASTER_FILENAME_SUFFIX:
        logger.error("\n [!] 설정 오류: USER SETTINGS에서 'OLD_MASTER_FILENAME_SUFFIX'와 'MASTER_FILENAME_SUFFIX'가 동일합니다.")
        return

    rename_plan = []
    conflict_list = []
    
    all_subdirs = [d for d in os.listdir(base_path) if os.path.isdir(os.path.join(base_path, d)) and d not in MOD_FOLDERS_TO_EXCLUDE]
    
    for mod_name in all_subdirs:
        mod_path = os.path.join(base_path, mod_name)
        paths = PathManager(mod_path)
        
        old_path = paths.get_old_master_file()
        new_path = paths.get_master_file()

        if os.path.isfile(old_path):
            if os.path.isfile(new_path):
                conflict_list.append(mod_path)
            else:
                rename_plan.append({'base_path': mod_path, 'old_path': old_path, 'new_path': new_path})

    print("\n" + "="*60)
    print(" [ 마스터 파일 이름 일괄 변경 미리보기 ]\n")
    print(" USER SETTINGS에 따라 다음 파일 이름 변경을 시도합니다:")
    print(f"   - 이전 이름 접미사: '{OLD_MASTER_FILENAME_SUFFIX}'")
    print(f"   - 새 이름 접미사  : '{MASTER_FILENAME_SUFFIX}'")
    print("-" * 60)

    if not rename_plan and not conflict_list:
        logger.warning("\n -> 이전 이름으로 설정된 마스터 파일을 찾을 수 없습니다.")
        return
        
    if rename_plan:
        print(f"\n [ 변경 대상 파일 (총 {len(rename_plan)}개) ]")
        for task in rename_plan:
            print(f"  - .../{os.path.join(os.path.basename(task['base_path']), os.path.basename(task['old_path']))}  ->  .../{os.path.basename(task['new_path'])}")
    
    if conflict_list:
        print(f"\n [ !! 충돌 발견 (총 {len(conflict_list)}개) - 작업 건너뜀 !! ]")
        for mod_path in conflict_list:
             logger.warning(f"  - '{os.path.basename(mod_path)}' 폴더에는 새 이름의 파일이 이미 존재하여 건너뜁니다.")
    
    print("="*60)

    confirm = get_user_input_with_special_keys("\n>> 정말로 위 변경 작업을 진행하시겠습니까? (Enter/y, ESC/n): ").lower()
    if confirm not in ('y', ''):
        logger.info(" -> 작업을 취소했습니다.")
        return
        
    logger.info("\n -> 파일 이름 변경 작업을 시작합니다...")
    success_count = 0
    for task in rename_plan:
        old_path, new_path = task['old_path'], task['new_path']
        logger.info(f"  - '{os.path.basename(old_path)}' -> '{os.path.basename(new_path)}'")
        if not is_test_run:
            try:
                os.rename(old_path, new_path)
                success_count += 1
            except OSError as e:
                logger.error(f"    [오류] 파일 이름 변경 실패: {e}")
    
    if not is_test_run:
        logger.info(f"\n -> 총 {success_count}개의 파일 이름을 성공적으로 변경했습니다.")
    else:
        logger.info(f"\n -> [테스트 모드] 총 {len(rename_plan)}개의 파일 이름 변경을 시뮬레이션했습니다.")



def _run_rename_logic(is_test_run=False, base_path=None, shared_state=None):
    """[엔진] 단일 모드 폴더에 대한 마스터 파일 이름 변경을 수행합니다."""
    logger = LoggerService.get_logger()
    
    # 이 함수는 다중 모드 컨트롤러 내부에서 호출되므로, 
    # 실제 파일 작업은 shared_state['rename_plan']이 생성된 후에만 수행됩니다.
    # 여기서는 계획에 따라 이름 변경만 실행합니다.
    if shared_state and 'rename_plan' in shared_state:
        plan = shared_state['rename_plan']
        
        # base_path에 해당하는 계획 찾기
        task = next((item for item in plan if item['base_path'] == base_path), None)
        
        if task:
            old_path = task['old_path']
            new_path = task['new_path']
            logger.info(f" -> '{os.path.basename(old_path)}' -> '{os.path.basename(new_path)}'")
            if not is_test_run:
                try:
                    os.rename(old_path, new_path)
                except OSError as e:
                    logger.error(f"  [오류] 파일 이름 변경 실패: {e}")


# ┏────────────────────────────────────────────────────────────────┐

#   run_sync_master_file 함수를 _run_manual_sync_logic 으로 교체

# ┗────────────────────────────────────────────────────────────────┘

# 9번 마스터 파일 수동 동기화 기능 (4.18.0 버전)
def _run_manual_sync_logic(merged_file_path, master_file_path, is_test_run):
    """[엔진] 두 CSV 파일 간의 충돌을 사용자 UI를 통해 수동으로 병합합니다."""
    logger = LoggerService.get_logger()
    logger.info("="*60)
    logger.info("9-2. 마스터 파일 수동 동기화(병합)를 시작합니다...")

    base_path = os.path.dirname(master_file_path)
    master_service = MasterFileService(base_path, csv_file_service)
    
    cache = _load_check_cache(base_path)
    if not cache:
        pause_for_user()
        return

    merged_data_map = cache['existing_data_map']
    master_data_map = { 
        (row['source_file'], row['id'], row['type'], text_processor_service.process(row.get('text_en', ''))): 
        (text_processor_service.process(row.get('text_en', '')), text_processor_service.process(row.get('text_kr', ''))) 
        for row in master_service.get_data() 
    }

    # 3-tuple (source, id, type)을 기준으로 그룹화
    grouped_merged_items = defaultdict(dict)
    for k, v_tuple in merged_data_map.items():
        grouped_merged_items[k[:3]][k[3]] = v_tuple[1]
    grouped_master_items = defaultdict(dict)
    for k, v_tuple in master_data_map.items():
        grouped_master_items[k[:3]][k[3]] = v_tuple[1]
    all_loc_keys = sorted(list(set(grouped_merged_items.keys()) | set(grouped_master_items.keys())))
    conflicts = []
    for loc_key in all_loc_keys:
        merged_versions = grouped_merged_items.get(loc_key, {})
        master_versions = grouped_master_items.get(loc_key, {})
        if merged_versions and master_versions and merged_versions != master_versions:
            conflicts.append({'loc_key': loc_key, 'merged_versions': merged_versions, 'master_versions': master_versions})

    if not conflicts:
        logger.info(" -> 수동으로 해결해야 할 충돌 항목이 없습니다. 자동 동기화를 권장합니다.")
        return

    logger.warning(" [알림] 아래 위치에서 내용 충돌이 발견되었습니다:")
    for item in conflicts:
        logger.warning(f"  - {item['loc_key']}")

    confirm = input(">> 모든 충돌 항목을 최신(_merged_kr) 버전으로 덮어쓰시겠습니까? (y/n): ").strip().lower()
    if confirm != 'y':
        logger.info(" -> 수동 병합을 취소했습니다.")
        return

    final_master_map = dict(master_data_map)
    for item in conflicts:
        loc_key = item['loc_key']
        keys_to_delete = [k for k in final_master_map if k[:3] == loc_key]
        for k in keys_to_delete:
            del final_master_map[k]
        for en, kr in item['merged_versions'].items():
            final_master_map[(*loc_key, en)] = (en, kr)

    # --- 최종 파일 쓰기 ---
    try:
        # [수정 2] 데이터를 CSV 형식에 맞게 변환
        final_data_list = []
        sorted_final_data = sorted(final_master_map.items())
        for key_4_tuple, (text_en, text_kr) in sorted_final_data:
            final_data_list.append({
                'source_file': key_4_tuple[0], 'id': key_4_tuple[1], 
                'type': key_4_tuple[2], 'text_en': text_en, 'text_kr': text_kr
            })

        master_service.save_data(final_data_list, is_test_run=is_test_run)
        
        logger.info(" -> 수동 병합(덮어쓰기)을 완료했습니다.")
    except Exception as e:
        logger.error(f"  [오류] 마스터 파일 업데이트 중 오류 발생: {e}")

# ┏────────────────────────────────────────────────────────────────┐
#
#                    [ 메인 컨트롤러 ]
#
# ┗────────────────────────────────────────────────────────────────┘

def get_all_valid_files_for_export(src_folder, base_path):
    """Export 가능한 모든 유효한 파일의 상대 경로 리스트를 반환합니다."""
    logger = LoggerService.get_logger()
    valid_files = set()
    
    # [핵심 추가 1] JSON 화이트리스트 필터 가져오기
    json_whitelist = PROCESSING_RULES.get('INCLUDE_ONLY_JSON_FILES', set())

    for dirpath, _, filenames in os.walk(src_folder):
        for filename in filenames:
            full_path = os.path.join(dirpath, filename)
            relative_path = os.path.relpath(full_path, src_folder).replace('\\', '/')
            
            if is_file_excluded(relative_path, for_export=True):
                continue
            
            is_csv = filename.lower().endswith(CSV_FILE_EXTENSIONS)
            is_json = filename.lower().endswith(JSON_FILE_EXTENSIONS)
            is_skill = filename.lower().endswith(SKILL_FILE_EXTENSIONS)
            is_system = filename.lower().endswith(SYSTEM_FILE_EXTENSIONS)
            
            # [핵심 추가 2] JSON 파일인 경우, 화이트리스트에 있는지 먼저 확인합니다.
            if is_json and relative_path not in json_whitelist:
                logger.debug(f"  [DEBUG-FILTER] '{relative_path}'는 JSON 화이트리스트에 없어 건너뜀.")
                continue # 화이트리스트에 없으면 바로 건너뜀
            
            rules = get_rules_for_file(relative_path, base_path)
            
            if rules and (rules.get('parser') or rules.get('mode')):
                valid_files.add(relative_path)
            elif is_csv or is_json or is_skill or is_system:
                valid_files.add(relative_path)
            else:
                logger.debug(f"  [DEBUG-EXPORT] '{relative_path}'는 알려진 확장자가 아니거나 파서 규칙이 없어 건너뜀.")
    
    return sorted(list(valid_files))


def _run_file_specific_export_test(base_path, target_files, is_test_run):
    """지정된 파일에 대해 Export 테스트를 실행합니다."""
    logger = LoggerService.get_logger()
    logger.info(f"\n>>> 지정 파일 Export 테스트를 시작합니다. (대상: {len(target_files)}개 파일) <<<")
    
    src_folder = os.path.join(base_path, SOURCE_DATA_FOLDER)
    
    # extract_all_text_to_map 호출 시 target_files 전달
    latest_data_map, _, _ = extract_all_text_to_map(base_path, src_folder, target_files=target_files, mod_root_path=base_path)

    logger.info("-> Export 테스트 결과 요약 (로그):")
    if latest_data_map:
        for key, value in latest_data_map.items():
            logger.info(f"  - '{key[0]}' | ID: '{key[1]}' | Type: '{key[2]}' | EN: '{value[:50]}...'")
        logger.info(f"  ... 총 {len(latest_data_map)}개 항목 추출됨.")
    else:
        logger.info("  -> 추출된 텍스트 항목이 없습니다.")

    logger.info("\n>>> 지정 파일 Export 테스트 완료. <<<")

    
def _run_file_specific_apply_test(base_path, target_files, translation_file_path, is_test_run):
    """지정된 파일에 대해 Apply 테스트를 실행합니다."""
    logger = LoggerService.get_logger()
    logger.info(f"\n>>> 지정 파일 Apply 테스트를 시작합니다. (대상: {len(target_files)}개 파일) <<<")

    # [핵심 수정] apply_all_translations는 이제 내부적으로 ExecutionContext를 통해
    # 필요한 데이터를 스스로 로드하므로, translation_map을 미리 로드하여 전달할 필요가 없습니다.
    # is_test_run=True이므로 실제 파일 생성/수정은 없습니다.
    apply_all_translations(
        is_test_run=is_test_run, 
        base_path=base_path, 
        shared_state=None, 
        target_files=target_files, 
        mod_root_path=base_path
    )

    logger.info("\n>>> 지정 파일 Apply 테스트 완료. <<<")


def run_file_specific_test(base_path, is_test_run):
    # [수정] 로그 서비스 설정: 별도 로그 파일 사용
    logger = LoggerService.setup(log_filename=FILE_SPECIFIC_TEST_LOG_FILENAME, level=LOGGING_LEVEL, is_test_run=True, log_dir=base_path)
    
    # 단일 모드 확인
    is_single_root = ValidationService(base_path).for_export()
    if not is_single_root:
        logger.warning("-> 지정 파일 테스트는 현재 폴더가 유효한 모드 루트일 때만 가능합니다.")
        pause_for_user()
        return

    # 1. Export 대상 파일 목록 생성
    source_folder_path = os.path.join(base_path, SOURCE_DATA_FOLDER)
    export_candidate_files = get_all_valid_files_for_export(source_folder_path, base_path)

    # 2. Apply 대상 파일 목록 생성 (translation_source_kr.csv 또는 _merged_kr.csv 기준)
    if USE_DYNAMIC_FILE_PATHS:
        current_folder_name = os.path.basename(base_path)
        translation_file_path = os.path.join(base_path, f"{current_folder_name}{APPLY_TRANSLATION_FILENAME_SUFFIX}")
    else:
        translation_file_path = os.path.join(base_path, APPLY_TRANSLATION_FILENAME_STATIC)
    
    # ExecutionContext를 생성하고 files_to_translate 속성을 통해 Apply 대상 파일 목록을 가져옵니다.
    temp_context = ExecutionContext(base_path)
    # temp_context.files_to_translate에 접근하는 순간 _load_apply_data가 호출됩니다.
    apply_candidate_files_set = temp_context.files_to_translate 
    apply_candidate_files = sorted(list(apply_candidate_files_set))

    # [★★★★★ 핵심 수정 ★★★★★]
    # 누락되었던 변수 정의 코드를 다시 추가합니다.
    all_test_files_list = sorted(list(set(export_candidate_files + apply_candidate_files)))
    all_test_files_map = {f_path: i+1 for i, f_path in enumerate(all_test_files_list)}

    # 이전에 선택했던 파일들을 저장할 집합
    previously_selected_relative_paths = set()

    while True: # 파일 선택 및 작업 선택 반복 루프
        # [수정] 화면 클리어 제거: 이 부분의 os.system('cls'/'clear') 호출을 제거합니다.

        # 대신, 매번 헤더만 다시 출력하여 로그가 누적되도록 합니다.
        print("\n\n" + "=" * 60) # 이전 로그와 구분될 수 있도록 구분선 추가
        display_header()
        print("\n [ 0-3. 지정 파일 테스트 ]\n")
        print(f"  [현재 모드]: {os.path.basename(base_path)}\n")

        if not all_test_files_list:
            logger.warning("-> 테스트할 유효한 파일을 찾을 수 없습니다. (data_en 폴더 또는 번역 파일 확인)")
            pause_for_user()
            return

        print("-" * 50)
        print(" 테스트 가능한 파일 목록:")
        print("-" * 50)
        for i, f_path in enumerate(all_test_files_list):
            num_display = all_test_files_map[f_path]
            export_tag = "[E]" if f_path in export_candidate_files else "   "
            apply_tag = "[A]" if f_path in apply_candidate_files else "   "
            selected_tag = "[V]" if f_path in previously_selected_relative_paths else "   " 
            print(f"  [{num_display:>3}] {selected_tag}{export_tag}{apply_tag} {f_path}")
        print("-" * 50)
        
        print("\n>> 테스트할 파일의 번호를 선택하세요 (공백으로 구분, 예: 1 5 12)")
        print(">> c: 선택 초기화 | q: 테스트 메뉴로 돌아가기")
        if previously_selected_relative_paths:
            print(f"   (현재 선택된 파일 수: {len(previously_selected_relative_paths)}개)")


        user_input = input("\n선택: ").strip().lower()
        if user_input == 'q':
            return # 테스트 메뉴로 돌아가기
        elif user_input == 'c':
            previously_selected_relative_paths.clear()
            logger.info("-> 선택된 파일 목록을 초기화했습니다.")
            pause_for_user()
            continue # 파일 선택 화면 다시 표시

        # 사용자 입력에 따라 previously_selected_relative_paths 갱신
        try:
            input_parts = user_input.split()
            if not input_parts: # 입력 없이 Enter만 쳤을 경우, 이전 선택 유지하고 작업 선택으로 넘어감
                if not previously_selected_relative_paths:
                    logger.warning(" [!] 선택된 유효한 파일이 없습니다. 다시 선택해주세요.")
                    pause_for_user()
                    continue
            else: # 새롭게 선택된 파일 번호를 처리
                newly_selected_temp_set = set()
                for part in input_parts:
                    idx = int(part) - 1 
                    if 0 <= idx < len(all_test_files_list):
                        newly_selected_temp_set.add(all_test_files_list[idx])
                    else:
                        logger.warning(f" [!] 잘못된 파일 번호입니다: {part}")
                        
                previously_selected_relative_paths = newly_selected_temp_set
        except ValueError:
            logger.warning(" [!] 잘못된 입력입니다. 숫자를 공백으로 구분하여 입력하거나 'c', 'q'를 입력하세요.")
            pause_for_user()
            continue
        
        selected_test_files = list(previously_selected_relative_paths)

        if not selected_test_files:
            logger.warning(" [!] 선택된 유효한 파일이 없습니다. 다시 선택해주세요.")
            pause_for_user()
            continue

        while True: # 작업 선택 반복 루프
            # [수정] 화면 클리어 제거: 이 부분의 os.system('cls'/'clear') 호출을 제거합니다.
            print("\n\n" + "=" * 60) # 이전 로그와 구분될 수 있도록 구분선 추가
            display_header()
            print("\n [ 0-3. 지정 파일 테스트 - 작업 선택 ]\n")
            print(" 선택된 파일:")
            for f_path in selected_test_files:
                print(f"  - {f_path}")
            print("\n>> 어떤 작업을 테스트하시겠습니까?")
            print("1. Export 테스트")
            print("2. Apply 테스트")
            print("3. 파일 선택으로 돌아가기")
            print("q: 테스트 메뉴로 돌아가기")

            task_choice = input("\n선택: ").strip().lower()
            if task_choice == 'q': return
            elif task_choice == '3': break

            if task_choice == '1':
                _run_file_specific_export_test(base_path, selected_test_files, is_test_run)
                pause_for_user()
                break
            elif task_choice == '2':
                _run_file_specific_apply_test(base_path, selected_test_files, translation_file_path, is_test_run)
                pause_for_user()
                break
            else:
                logger.warning(" [!] 잘못된 입력입니다.")
                pause_for_user()

def _confirm_deployment_list(mod_list, logger):
    """주어진 모드 목록을 표시하고 사용자에게 배포 여부를 확인받습니다."""
    if not mod_list:
        logger.warning("\n -> 배포할 유효한 모드를 찾지 못했습니다.")
        pause_for_user()
        return False

    print("\n" + "!"*60)
    logger.warning(" [!!] 다음의 모든 유효 모드에 대해 'Deploy All'을 실행합니다.")
    print("-" * 60)
    for mod_name in mod_list:
        print(f"  - {mod_name}")
    print("!"*60)
    
    # [핵심 수정] 프롬프트와 입력 방식을 변경합니다.
    prompt = "\n>> 정말로 전체 배포를 진행하시겠습니까? (Enter/y: 예, ESC/n: 아니오): "
    choice = get_user_input_with_special_keys(prompt).lower()

    # [핵심 수정] Enter('') 또는 'y'일 경우에만 진행하고, 나머지는 모두 취소 처리합니다.
    if choice in ('y', ''):
        logger.info(" -> 사용자 확인. 전체 배포를 시작합니다.")
        return True
    else:
        logger.info(" -> 전체 배포 작업을 취소했습니다.")
        pause_for_user()
        return False


def resolve_execution_targets(mode_name, validation_check):
    """
    [전략가 v5 - 최종판] 전달받은 validation_check를 유일한 기준으로 사용하여 실행 계획을 수립하고,
    실패 시 명확한 피드백을 제공합니다.
    """
    logger = LoggerService.get_logger()
    script_exec_path = os.getcwd()
    search_root = os.path.abspath(MOD_SEARCH_ROOT_PATH)

    # [핵심] 이제 버그 함수 대신, 각 기능에 맞는 올바른 validation_check를 직접 사용합니다.
    is_valid_single_mod_root = validation_check(script_exec_path)
    is_multi_mode_enabled = PROCESS_MULTIPLE_MODS_AUTO

    if is_valid_single_mod_root:
        # [시나리오 1: 정상] 현재 위치가 유효하면 즉시 단일 모드로 실행합니다.
        print("─" * 100)
        logger.info(f">>> 현재 폴더가 유효한 {mode_name} 루트로 감지되어 단일 모드로 실행합니다. <<<")
        return ('SINGLE', [script_exec_path])
    
    # --- [핵심 개선] 현재 위치가 유효하지 않을 때의 처리 ---
    
    print("─" * 100)
    logger.warning(f">>> [알림] 현재 폴더는 '{mode_name}' 작업을 수행하기 위한 조건을 만족하지 않습니다. <<<")
    
    # 각 기능에 맞는 구체적인 힌트를 제공합니다.
    mode = mode_name.split()[0]
    if mode == 'Apply':
        paths = PathManager(script_exec_path)
        expected_file = os.path.basename(paths.get_apply_source_file())
        logger.warning(f"    (힌트: Apply 작업에 필요한 '{expected_file}' 파일이 없는 것 같습니다.)")
    elif mode in ['Export', 'Check', 'Forward', 'Consolidate']:
        logger.warning(f"    (힌트: 작업에 필요한 '{SOURCE_DATA_FOLDER}' 폴더 또는 관련 CSV 파일이 없는 것 같습니다.)")
    
    if is_multi_mode_enabled:
        prompt = "\n>> 하위 폴더에서 유효한 모드를 탐색하여 다중 모드로 계속 진행하시겠습니까? (Enter/y: 예, ESC/n: 아니오): "
        choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')
                
        if choice not in ('y', ''):
            logger.info(" -> 작업을 취소했습니다.")
            return ('NONE', [])
        
        logger.info(f"\n>>> 다중 모드 자동 {mode_name} 모드로 전환하여 실행합니다. <<<")
        logger.info(f"  -> 탐색 시작 경로: {search_root}")
        
        if not os.path.isdir(search_root):
            logger.error(f" [!] 설정된 모드 탐색 경로를 찾을 수 없습니다: {search_root}")
            return ('NONE', [])

        all_subdirs = [d for d in os.listdir(search_root) if os.path.isdir(os.path.join(search_root, d)) and d not in MOD_FOLDERS_TO_EXCLUDE and (not MOD_USE_PREFIX_FILTER or d.startswith(MOD_FOLDER_PREFIX))]
        valid_mod_paths = [os.path.join(search_root, mod_name) for mod_name in sorted(all_subdirs) if validation_check(os.path.join(search_root, mod_name))]
        
        if not valid_mod_paths:
            logger.warning(f"\n>>> 하위 폴더에서도 처리할 유효한 모드를 찾지 못했습니다. <<<")
            return ('NONE', [])
            
        return ('MULTI', valid_mod_paths)
    else:
        logger.error(f">>> [실행 불가] 다중 모드 자동 탐색이 비활성화되어 있어 작업을 계속할 수 없습니다. <<<")
        return ('NONE', [])


def execute_task(task_function, validation_check, log_filename, mode_name, is_test_run, shared_state_override=None, clear_screen_after_task=False):
    """
    [실행기 v3.3] clear_screen_after_task 기본값을 False로 변경하여 로그를 보존합니다.
    """
    script_exec_path = os.getcwd()
    logger = LoggerService.setup(log_filename, level=LOGGING_LEVEL, is_test_run=is_test_run, log_dir=script_exec_path)
    
    execution_mode, target_paths = resolve_execution_targets(mode_name, validation_check)

    if execution_mode == 'NONE':
        logger.info(f"{mode_name} 작업을 종료합니다.\n")
        pause_for_user(clear_screen=clear_screen_after_task)
        return

    if shared_state_override is not None:
        shared_state = shared_state_override
    else:
        shared_state = {'auto_confirm_all': False, 'quit_all': False}
    
    is_multi_mode = (execution_mode == 'MULTI' and len(target_paths) > 1)
    if is_multi_mode:
        # ... (이 부분의 다중 모드 설정 로직은 동일하여 생략) ...
        shared_state['is_multi_mode'] = True
        print("\n" + "="*60)
        logger.info(f" [ 다중 모드 일괄 처리 안내 ]")
        logger.info(f" '{mode_name}' 작업을 총 {len(target_paths)}개의 모드에 대해 실행합니다.")
        if mode_name == "Pull from Merged to Staging":
            logger.warning("   ▶ 모든 모드에 대해 [전체 복사] 방식으로 일괄 적용됩니다.")
            shared_state['sub_action'] = 'full_copy'
        elif mode_name == "Push to Master":
            action_info = run_push_to_master_menu(script_exec_path, is_test_run)
            if not action_info or action_info.get('action') == 'noop':
                logger.info(" -> 작업을 취소했거나 추가 작업이 없어 종료합니다.")
                pause_for_user()
                return
            shared_state['action_info'] = action_info
        elif mode_name == "Staging Purge":
            action_info = run_staging_purge_menu(script_exec_path, is_test_run)
            if not action_info:
                logger.info(" -> 작업을 취소했습니다.")
                pause_for_user()
                return
            shared_state['action_info'] = action_info
        prompt = "\n>> 위 설정으로 모든 모드에 대한 작업을 계속 진행하시겠습니까? (Enter/y, ESC/n): "
        choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')
        if choice != 'y':
            logger.info(" -> 작업을 취소했습니다.")
            pause_for_user()
            return

    if mode_name == "Deploy All":
        mod_names_to_confirm = [os.path.basename(p) for p in target_paths]
        if not _confirm_deployment_list(mod_names_to_confirm, logger): 
            return

    task_performed_count = 0
    # [핵심 수정] task_function의 반환 값을 저장할 변수
    last_task_result = None 

    for i, mod_path in enumerate(target_paths):
        if shared_state.get('quit_all', False):
            logger.warning(f"\n>>> 사용자 요청으로 남은 {len(target_paths) - i}개 모드 처리를 중단했습니다. <<<")
            break

        if is_multi_mode:
            logger.info(f"\n{'=' * 25} 처리 시작: [ {os.path.basename(mod_path)} ] ({i+1}/{len(target_paths)}) {'=' * 25}")
        
        try:
            # [핵심 수정] 반환 값을 result 변수에 저장
            result = task_function(is_test_run=is_test_run, base_path=mod_path, shared_state=shared_state)
            last_task_result = result # 마지막 실행 결과 저장
            if result is not False:
                task_performed_count += 1
        except Exception as e:
            logger.critical(f"!!! '{os.path.basename(mod_path)}' 처리 중 심각한 오류 발생: {e} !!!", exc_info=True)
            last_task_result = None # 오류 발생 시 결과 초기화

    # [핵심 수정] task_function이 UI 처리를 직접 했는지 확인
    if last_task_result == 'UI_HANDLED':
        # 로거 정리만 하고 함수 종료 (pause_for_user 호출 안 함)
        flush_and_sync_all_loggers()
        LoggerService.close_aux_loggers()
        return

    # --- 이하 로직은 last_task_result가 'UI_HANDLED'가 아닐 때만 실행됨 ---
    if task_performed_count > 0:
        if is_multi_mode and shared_state.get('report_data'):
            if mode_name.startswith("Conditional"):
                _display_conditional_update_report(shared_state['report_data'], shared_state['update_column_name'], is_test_run)
        
        logger.info(f"총 {task_performed_count}개의 모드에 대해 {mode_name} 작업을 완료했습니다.")
        if is_test_run:
            print("\n" + "="*60)
            logger.info(f"  ▶▶▶▶▶    [ 알림 ] '{mode_name}' 실행이 완료되었습니다.     ◀◀◀◀◀")
            logger.info("  ▶▶▶▶▶        실제 파일은 생성되거나 수정되지 않았습니다.     ◀◀◀◀◀")
            print("="*60)
    
    flush_and_sync_all_loggers()
    LoggerService.close_aux_loggers()
    
    pause_for_user(clear_screen=clear_screen_after_task)


GLOBAL_EXIT_COMMAND = 'q'

def display_header():
    """스크립트의 공통 헤더를 출력합니다."""
    print("=" * 60)
    print("      스타섹터 번역 추출 및 적용 도구 (Export / Apply / Deploy)      ")
    print(f"      Ver. {SCRIPT_VERSION}")
    print("=" * 60)

def display_main_menu():
    """[리팩토링됨] 그룹화된 새로운 메인 메뉴 옵션을 출력합니다."""
    display_header()

    exec_path = os.getcwd()
    search_root = os.path.abspath(MOD_SEARCH_ROOT_PATH)

    print(f"\n [ 스크립트 실행 위치 ]: {_get_short_path(exec_path)}")
    if exec_path != search_root:
        print(f" [ 모드 탐색 시작 위치 ]: {_get_short_path(search_root)}")
    
    # --- 알림 메시지 (pending file) ---
    paths = PathManager(os.getcwd())
    pending_file_path = paths._get_path(PENDING_MERGE_FILENAME_SUFFIX, PENDING_MERGE_FILENAME_STATIC)
    if os.path.exists(pending_file_path):
        print("\n" + "!"*20 + " [ 알림 ] " + "!"*20)
        print(f"   '{os.path.basename(pending_file_path)}' 파일에 병합 대기 중인 번역이 있습니다.")
        print("   -> 5번(스테이징) 메뉴를 통해 마스터 파일에 통합할 수 있습니다.")
        print("!"*50)

    print("\n ◈ 원하는 작업의 번호를 입력하세요 (도움말: 1?).\n")

    print("--- [ 0. 빠른 적용 ] ------------------------------------------------")    
    print("  0. 액션 플래그 처리 (검토 파일 정리)")
    print(" 00. 리포트 갱신 (Export 결과 미리보기)\n")
    print(" 11. 번역 작업 파일 -> 스테이징으로 전송")
    print("    └─ '{MISSING_TRANSLATION_FILENAME}'의 번역을 스테이징으로 보냅니다.\n".format(
        MISSING_TRANSLATION_FILENAME=_get_short_path(MISSING_TRANSLATION_FILENAME)
    ))
    print(" 50. Merged -> 스테이징 수동 동기화")
    print("    └─ '{MERGED_FILENAME_SUFFIX}'의 내용을 스테이징으로 지능형 병합합니다.\n".format(
        MERGED_FILENAME_SUFFIX=_get_short_path(MERGED_FILENAME_SUFFIX)
    ))

    print("--- [ 1. 핵심 워크플로우 ] -------------------------------------------")
    print("  1. Export (텍스트 추출 및 병합)")
    print("  2. Apply (번역 적용)")
    print("  3. Deploy All (전체 모드 배포)")
    print("  4. Selective Deploy (선택 모드 배포)\n")

    print("--- [ 2. 데이터 관리 ] -----------------------------------------------")
    print("  5. 스테이징 파일 관리자")
    print("  6. 마스터 파일 관리자")
    print("  7. 역추출 도구 ( data_kr 폴더에서 번역 추출 )\n")

    print("--- [ 3. 고급 도구 ] -------------------------------------------------")
    print("  r. Reverse Sync : 모드의 Data 파일 가져오기 (모드 원본 -> 스크립트 폴더)")
    print("  f. Forward Sync : 모드의 Data 파일 내보내기 (모드 원본 <- 스크립트 폴더)")
    print("  m. 모드 정보 동기화 (mod_info.json)")
    print("  t. 테스트 메뉴")
    print("----------------------------------------------------------------------")
    print(f" q. 종료")
    print("\n [ 도움말: [번호]? 또는 help [주제] (예: help workflow) ]\n")

def display_test_menu():
    """테스트 메뉴 옵션을 출력합니다."""
    display_header()
    print("\n테스트할 기능을 선택하세요:\n")
    print("1. Export 테스트\n")
    print("2. Apply 테스트\n")
    print("3. 지정 파일 테스트\n")

def flush_and_sync_all_loggers():
    """
    [복원] LoggerService에 등록된 모든 로거(메인 및 보조)의 버퍼를 플러시하고,
    OS 파일 시스템 캐시를 디스크에 강제로 동기화합니다.
    """
    # 메인 로거와 모든 보조 로거를 함께 처리
    all_loggers = [LoggerService._logger] + list(LoggerService._aux_loggers.values())
    
    for logger in all_loggers:
        if logger:
            for handler in logger.handlers:
                try:
                    if isinstance(handler, logging.FileHandler):
                        handler.flush()
                        os.fsync(handler.stream.fileno())
                except Exception as e:
                    print(f"경고: 로거 핸들러 동기화 중 오류 발생: {e}")


class SafeDict(dict):
    """
    str.format_map()과 함께 사용하기 위한 안전한 딕셔너리.
    찾는 키가 없을 경우, 오류 대신 키 이름을 그대로 반환합니다.
    """
    def __missing__(self, key):
        return f'{{{key}}}'

def _format_help_message(message, context):
    """
    (v4.26.38 수정됨) 주어진 컨텍스트 딕셔너리를 사용하여 도움말 문자열의 플레이스홀더를 치환합니다.
    context 인자가 None일 경우를 대비한 방어 로직을 추가했습니다.
    """
    # [핵심 수정] context가 None일 경우 빈 딕셔너리를 사용하도록 합니다.
    safe_context = context if context is not None else {}
    return message.format_map(SafeDict(safe_context))


def _display_help_for_key(help_key, help_dict, context):
    """지정된 키와 딕셔너리를 사용하여 포맷팅된 도움말을 출력합니다."""
    if help_key in help_dict:
        title, message_template = help_dict[help_key]
        formatted_message = _format_help_message(message_template, context)

        print("\n" + "="*60)
        print(f" [ 도움말: {title} ]")
        print("-" * 60)
        print(formatted_message)
        # --- [핵심 수정] ---
        # 도움말 표시 후에는 화면을 정리하는 것이 좋으므로 True를 명시합니다.
        pause_for_user(clear_screen=True)
        # --- [수정 끝] ---
        return True
    else:
        print(f"\n [!] '{help_key}'에 대한 도움말을 찾을 수 없습니다.")
        pause_for_user(clear_screen=True) # 오류 메시지 후에도 화면 정리
        return False
    
def _run_merge_completed_to_master_wrapper(is_test_run=False, base_path=None, shared_state=None):
    """
    [컨트롤러로 리팩토링됨] 스테이징에서 완료된 항목을 마스터 파일로 병합하는
    작업의 UI 흐름을 제어합니다. 모든 핵심 로직은 MasterFileService에 위임됩니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    staging_path = paths.get_staging_master_file()
    
    # 1. 서비스 및 데이터 로드
    master_service = MasterFileService(base_path, csv_file_service)
    staging_data = csv_file_service.load_rows_from_csv(staging_path)
    
    if not staging_data:
        logger.warning(f" -> 스테이징 파일 '{os.path.basename(staging_path)}'에 데이터가 없어 병합할 수 없습니다.")
        # [수정] pause_for_user()는 execute_task 레벨에서 관리하므로 여기서 호출하지 않습니다.
        return False

    # --- [핵심 수정] ---
    # intelligent_merge 호출 시, 모든 필수 및 옵셔널 인자를 명시적으로 전달합니다.
    # 5-0 메뉴는 항상 사용자 확인을 거쳐야 하므로 skip_confirmation=False로 설정합니다.
    success = master_service.intelligent_merge(
        source_data=staging_data, 
        is_test_run=is_test_run,
        shared_state=shared_state,
        skip_confirmation=False
    )
    # --- [수정 끝] ---
    
    if not success:
        # 작업이 취소되었거나 변경 사항이 없었음을 의미합니다.
        # pause_for_user()는 execute_task가 호출하므로 여기서는 False만 반환합니다.
        return False
    else:
        # 작업이 성공적으로 완료되었음을 의미합니다.
        return True

class ReverseExtractorService:
    """
    [신규 서비스] 역추출(Reverse-Extract)의 핵심 비즈니스 로직(분석 및 분류)을 전담합니다.
    파일 I/O와 무관하게 순수한 데이터 처리만을 수행합니다.
    """
    def __init__(self, map_en, map_kr):
        self.map_en = map_en
        self.map_kr = map_kr
        self.logger = LoggerService.get_logger()

    def execute(self):
        """
        data_en 맵과 data_kr 맵을 비교하여 'success', 'mismatch', 'orphan' 그룹으로 분류하고
        그 결과를 딕셔너리로 반환합니다.
        """
        self.logger.info(" -> 데이터 비교 및 분류를 시작합니다...")
        
        extracted_success = []
        mismatched_items = []
        orphaned_items = []
        
        # 3-tuple 키를 기준으로 data_en의 모든 text_en 버전을 집합으로 관리
        map_en_by_location = defaultdict(set)
        for (src, i, t), en in self.map_en.items():
            map_en_by_location[(src, i, t)].add(en)

        for (src, i, t), kr_text_raw in self.map_kr.items():
            loc_key = (src, i, t)
            
            if loc_key in map_en_by_location:
                en_versions_set = map_en_by_location[loc_key]
                if kr_text_raw in en_versions_set:
                    continue # 번역 안된 항목은 무시
                
                if REVERSE_EXTRACT_GENERATE_MISMATCH_FILE:
                    new_en_text_representative = next(iter(en_versions_set), "")
                    mismatched_items.append({
                        'source_file': src, 'id': i, 'type': t,
                        'old_text_en': 'N/A (Original English may have changed)',
                        'new_text_en': new_en_text_representative,
                        'found_text_kr': kr_text_raw
                    })
            else:
                orphaned_items.append({
                    'source_file': src, 'id': i, 'type': t,
                    'text_en': kr_text_raw,
                    'text_kr': kr_text_raw
                })

        for (src, i, t), en_text_raw in self.map_en.items():
            kr_text_raw = self.map_kr.get((src, i, t))
            if kr_text_raw and en_text_raw != kr_text_raw:
                 extracted_success.append({
                    'source_file': src, 'id': i, 'type': t,
                    'text_en': en_text_raw,
                    'text_kr': kr_text_raw
                })
        
        return {
            'success': extracted_success,
            'mismatch': mismatched_items,
            'orphan': orphaned_items
        }

class OrphanRecoveryService:
    """
    [신규 서비스] 고아 데이터 복구의 핵심 비즈니스 로직(분석 및 분류)을 전담합니다.
    표준 데이터 추출기(extract_all_text_to_map)를 재사용하여 코드 중복을 제거합니다.
    """
    def __init__(self, orphan_rows):
        self.orphan_rows = orphan_rows
        self.logger = LoggerService.get_logger()
        # orphan_scoped_logger는 컨트롤러 레벨에서 메시지를 관리하도록 변경

    def execute(self, base_path):
        """
        고아 항목들을 파일별로 그룹화하고, 각 파일의 최신 data_en 정보를 기준으로
        text_en 복구를 시도합니다. 복구된 항목과 실패한 항목을 분류하여 반환합니다.
        """
        recovered_items, unrecovered_items = [], []
        src_folder = os.path.join(base_path, SOURCE_DATA_FOLDER)
        
        grouped_orphans = defaultdict(list)
        for row in self.orphan_rows:
            grouped_orphans[row['source_file']].append(row)
            
        orphan_scoped_logger.log(f"총 {len(self.orphan_rows)}개 항목을 {len(grouped_orphans)}개 파일로 그룹화하여 처리 시작...", base_path=base_path)

        for relative_path, rows_for_file in grouped_orphans.items():
            orphan_scoped_logger.log(f"\n[ENGINE] 파일 처리 시작: {relative_path} ({len(rows_for_file)}개 항목)", base_path=base_path)
            full_path = os.path.join(src_folder, relative_path.replace('/', os.sep))
            
            if not os.path.exists(full_path):
                orphan_scoped_logger.log("  [ENGINE] -> 실패: 원본 data_en 파일이 존재하지 않음.", base_path=base_path)
                unrecovered_items.extend(rows_for_file)
                continue

            # [핵심 변경] 표준 extract_all_text_to_map을 force_process_files 옵션과 함께 사용하여
            # is_file_excluded 규칙을 우회하고 해당 파일만 강제로 처리합니다.
            map_en_for_file, _, _ = extract_all_text_to_map(
                base_path, src_folder, force_process_files={relative_path}, mod_root_path=base_path
            )
            
            orphan_scoped_logger.log(f"  [ENGINE] <- extract_all_text_to_map 반환. 추출된 항목 수: {len(map_en_for_file)}", base_path=base_path)

            if not map_en_for_file:
                orphan_scoped_logger.log("  [ENGINE] 추출 실패로 결론. 이 파일의 모든 항목을 '실패' 처리.", base_path=base_path)
                unrecovered_items.extend(rows_for_file)
                continue
            
            for row in rows_for_file:
                location_key = (row['source_file'], row['id'], row['type'])
                found_en = map_en_for_file.get(location_key)

                if found_en is not None:
                    row['text_en'] = found_en
                    recovered_items.append(row)
                    orphan_scoped_logger.log(f"    -> 성공: ID '{row['id']}', Type '{row['type']}' 복원 완료.", base_path=base_path)
                else:
                    unrecovered_items.append(row)
                    orphan_scoped_logger.log(f"    -> 실패: ID '{row['id']}', Type '{row['type']}' 매칭 실패.", base_path=base_path)
        
        return {
            'recovered': recovered_items,
            'unrecovered': unrecovered_items
        }

class DeduplicationService:
    """
    [신규 서비스] 중복 데이터 탐지 및 분석의 핵심 로직을 전담합니다.
    UI 상호작용 없이 순수한 데이터 처리만을 수행합니다.
    """
    def __init__(self, data_rows, key_cols):
        self.data_rows = data_rows
        self.key_cols = key_cols
        self.logger = LoggerService.get_logger()

    def analyze(self):
        """
        주어진 데이터를 key_cols 기준으로 그룹화하여,
        중복 그룹과 고유 항목으로 분류하여 반환합니다.
        """
        if not self.data_rows:
            return {'duplicates': {}, 'uniques': []}

        grouped_data = defaultdict(list)
        for row in self.data_rows:
            key_components = []
            for col in self.key_cols:
                if col == 'id_base':
                    id_val = row.get('id', '')
                    base_id_val = re.sub(r'\[\d+\]$', '', id_val)
                    key_components.append(base_id_val)
                else:
                    key_components.append(row.get(col, ''))
            key = tuple(key_components)
            grouped_data[key].append(row)
        
        duplicates = {k: v for k, v in grouped_data.items() if len(v) > 1}
        unique_rows = [v[0] for k, v in grouped_data.items() if len(v) == 1]
        
        self.logger.debug(f"DeduplicationService: {len(duplicates)}개 중복 그룹, {len(unique_rows)}개 고유 항목 발견.")
        
        return {
            'duplicates': duplicates,
            'uniques': unique_rows
        }

def _save_reverse_extract_artifacts(classified_data, paths, is_test_run):
    """
    [신규 I/O 엔진] ReverseExtractorService가 분류한 데이터를 받아
    각각의 _rev_... .csv 파일로 저장하는 책임을 가집니다.
    """
    logger = LoggerService.get_logger()
    logger.info(" -> 분석 결과를 파일로 저장합니다...")

    success_file = paths.get_reverse_extract_success_file()
    mismatch_file = paths.get_reverse_extract_mismatch_file()
    orphan_file = paths.get_reverse_extract_orphan_file()

    # Success 파일 저장
    csv_file_service.write_rows_to_csv(
        success_file, classified_data['success'], headers=OUTPUT_HEADERS, is_test_run=is_test_run
    )
    
    # Mismatch 파일 저장 (설정에 따라)
    if REVERSE_EXTRACT_GENERATE_MISMATCH_FILE:
        mismatch_headers = ['source_file', 'id', 'type', 'old_text_en', 'new_text_en', 'found_text_kr']
        csv_file_service.write_rows_to_csv(
            mismatch_file, classified_data['mismatch'], headers=mismatch_headers, is_test_run=is_test_run
        )

    # Orphan 파일 저장
    csv_file_service.write_rows_to_csv(
        orphan_file, classified_data['orphan'], headers=OUTPUT_HEADERS, is_test_run=is_test_run
    )

def _run_sync_with_trash_wrapper(is_test_run, base_path, shared_state=None):
    """
    [신규 래퍼] 9-10. 트래시 파일과 모든 주요 파일을 동기화(정리)하는 로직을 캡슐화합니다.
    """
    logger = LoggerService.get_logger()
    paths = PathManager(base_path)
    trash_file_path = paths.get_purge_trash_file()
    
    logger.info("="*60)
    logger.info("9-10. 트래시 파일과 동기화를 시작합니다...")

    if not os.path.exists(trash_file_path):
        logger.warning("\n -> 트래시 파일이 없어 동기화할 수 없습니다.")
        return False

    trash_data_map = load_data_for_check(trash_file_path)
    trash_keys = set(trash_data_map.keys())
    
    files_to_purge = [
        (paths.get_master_file(), "마스터 파일"),
        (paths.get_merged_file(), "Merged 파일")
    ]
    
    # [핵심] any()를 사용하여 변경이 한 번이라도 발생했는지 추적
    any_change_made = any(
        _run_purge_by_blacklist_engine(file_path, trash_keys, is_test_run, description)
        for file_path, description in files_to_purge
    )
    
    if not any_change_made:
        logger.info("\n -> 모든 주요 파일이 이미 트래시와 동기화된 상태입니다.")
    
    return True

class UIController:
    """
    스크립트의 모든 사용자 인터페이스(메뉴, 프롬프트, 도움말)를 중앙에서 관리하는 컨트롤러 클래스.
    """
    def __init__(self, base_path, csv_service, paths, is_test_run=False):
        self.base_path = base_path
        self.is_test_run = is_test_run
        self.logger = LoggerService.get_logger()
        self.csv_service = csv_service
        self.paths = paths
        
        self.selective_deploy_service = SelectiveDeployService(
            search_root_path=MOD_SEARCH_ROOT_PATH,
            config_filename=SELECTIVE_DEPLOY_CONFIG
        )

        # --- UI 관련 데이터 중앙화 ---
        self.SETTINGS_CONTEXT = self._build_settings_context()
        
        # 모든 도움말 메시지를 하나의 딕셔너리로 통합합니다.
        self.HELP_MESSAGES = self._get_main_help_messages()
        self.HELP_MESSAGES.update(self._get_sub_help_messages())
        
        self.MENU_ACTIONS = self._get_menu_actions()
        self.TEST_MENU_ACTIONS = self._get_test_menu_actions()

    def _build_settings_context(self):
        """
        도움말 메시지 포맷팅에 사용될 모든 USER SETTINGS 변수를 담은
        컨텍스트 딕셔너리를 생성합니다.
        """
        return {
            # 고정값들
            "SOURCE_DATA_FOLDER": SOURCE_DATA_FOLDER,
            "TRANSLATED_DATA_FOLDER": TRANSLATED_DATA_FOLDER,
            "DESTINATION_BASE_PATH": DESTINATION_BASE_PATH,
            "STAGING_OUTPUT_FOLDER": STAGING_OUTPUT_FOLDER,

            # Export 관련 접미사
            "MASTER_FILENAME_SUFFIX": MASTER_FILENAME_SUFFIX,
            "OLD_MASTER_FILENAME_SUFFIX": OLD_MASTER_FILENAME_SUFFIX,
            "MERGED_FILENAME_SUFFIX": MERGED_FILENAME_SUFFIX,
            "MISSING_TRANSLATION_FILENAME": MISSING_TRANSLATION_FILENAME,
            "EMPTY_KR_FILENAME_SUFFIX": EMPTY_KR_FILENAME_SUFFIX,
            "FILTERED_ITEMS_FILENAME_SUFFIX": FILTERED_ITEMS_FILENAME_SUFFIX,
            
            # Apply 관련 접미사
            "APPLY_TRANSLATION_FILENAME_SUFFIX": APPLY_TRANSLATION_FILENAME_SUFFIX,
            
            # Reverse-Extract 관련 접미사
            "REVERSE_EXTRACT_SUCCESS_SUFFIX": REVERSE_EXTRACT_SUCCESS_SUFFIX,
            
            # Staging 관련 접미사
            "STAGING_MASTER_FILENAME_SUFFIX": STAGING_MASTER_FILENAME_SUFFIX,
            
            # Purge 및 검토 관련 접미사
            "PURGE_TRASH_FILENAME_SUFFIX": PURGE_TRASH_FILENAME_SUFFIX,
            "MASTER_REVIEW_NEEDED_FILENAME_SUFFIX": MASTER_REVIEW_NEEDED_FILENAME_SUFFIX,
            "MASTER_PURGED_FILENAME_SUFFIX": MASTER_PURGED_FILENAME_SUFFIX,
            "MASTER_TRUE_REVIEW_FILENAME_SUFFIX": MASTER_TRUE_REVIEW_FILENAME_SUFFIX,
            "REVIEW_NEEDED_FILENAME_SUFFIX": REVIEW_NEEDED_FILENAME_SUFFIX,
            "MASTER_EMPTY_KR_FILENAME_SUFFIX": MASTER_EMPTY_KR_FILENAME_SUFFIX,
            "MASTER_FALSE_REVIEW_FILENAME_SUFFIX": MASTER_FALSE_REVIEW_FILENAME_SUFFIX,
            
            # POST_FILTER_EXCLUSION_RULES는 딕셔너리이므로 직접 포함하기보다
            # 필요한 경우 별도로 참조하는 것이 좋습니다. 여기서는 생략합니다.
        }

    def _get_main_help_messages(self):
        # 기존 HELP_MESSAGES 딕셔너리
        return {
        '0': ("액션 플래그 처리 (Process Action Flags)",
            "모든 검토 파일의 'Translatable' 열을 읽어 항목을 자동으로 정리합니다.\n"
            "이 기능은 파일 종류에 따라 일부 동작이 제한될 수 있습니다.\n\n"
            "사용법:\n"
            " 1. 처리할 검토 파일을 엽니다.\n"
            " 2. 각 항목의 'Translatable' 열에 원하는 액션을 입력합니다.\n"
            "    - 's': 항목을 스테이징 파일('{STAGING_MASTER_FILENAME_SUFFIX}')로 이동합니다. (모든 검토 파일에서 사용 가능)\n"
            "    - 'x': 항목을 트래시(삭제 보관소) 파일로 이동시킵니다. (모든 검토 파일에서 사용 가능)\n"
            "    - 'true' (또는 't'): 항목을 마스터 파일('{MASTER_FILENAME_SUFFIX}')로 직접 통합/복구합니다.\n"
            "      [!!] 이 기능은 마스터 관련 검토 파일에서만 작동합니다. (아래 목록 참조)\n"
            "    - (공백, 'false' 등 다른 값): 항목을 처리하지 않고 파일에 그대로 남겨둡니다.\n"
            " 3. 파일을 저장하고 이 메뉴(0번)를 실행합니다.\n\n"
            "--- [ 처리 대상 파일 상세 (모두 Translatable 컬럼 사용) ] ---\n\n"
            "> Export 검토 파일 ('true' 사용 불가)\n"
            "  - 파일 이름: '...{REVIEW_NEEDED_FILENAME_SUFFIX}'\n"
            "  - 생성 시점: 1. Export 실행 시, 코드성 의심 항목이 발생했을 때 생성됩니다.\n"
            "  - 역할: Export 과정의 불확실한 항목을 처리하는 임시 파일입니다.\n\n"
            "> 마스터 파일 검토 파일 ('true' 사용 가능)\n"
            "  - 파일 이름: '...{MASTER_REVIEW_NEEDED_FILENAME_SUFFIX}'\n"
            "  - 생성 시점: 9-6. 마스터 파일 필터링 및 검토 실행 시 생성됩니다.\n"
            "  - 역할: 마스터 파일의 품질 유지를 위해 의심 항목을 검토하는 파일입니다.\n\n"
            "> 승인 항목 재검토 파일 ('true' 사용 가능)\n"
            "  - 파일 이름: '...{MASTER_TRUE_REVIEW_FILENAME_SUFFIX}'\n"
            "  - 생성 시점: 9-7. 승인 항목 재검토 실행 시 생성됩니다.\n"
            "  - 역할: 이미 승인된 항목의 상태를 변경하거나 제거하기 위한 파일입니다.\n\n"
            "> 삭제된 항목 백업 파일 ('true' 사용 가능)\n"
            "  - 파일 이름: '...{MASTER_PURGED_FILENAME_SUFFIX}'\n"
            "  - 생성 시점: 9-6. 마스터 파일 필터링 및 검토 실행 시 자동 삭제된 항목이 백업됩니다.\n"
            "  - 역할: 자동 삭제된 항목에 대한 최종 검토 및 복구 기회를 제공하는 안전장치 파일입니다."
        ),
        '1': ("Export (텍스트 추출 및 병합)", 
            "현재 모드의 '{SOURCE_DATA_FOLDER}' 폴더를 스캔하여 번역 가능한 모든 텍스트를 추출합니다.\n"
            "추출된 텍스트는 '{MASTER_FILENAME_SUFFIX}' 등과 병합하여,\n"
            "최종 작업 파일인 '{MERGED_FILENAME_SUFFIX}'와 번역이 필요한\n"
            "'{MISSING_TRANSLATION_FILENAME}' 파일을 생성/업데이트합니다."),
        '11': ("'번역 작업' -> '최종 병합' 파일로 전송",
            "사용자가 '{MISSING_TRANSLATION_FILENAME}' 파일에 채워넣은 번역을\n"
            "'{MERGED_FILENAME_SUFFIX}' 파일로 안전하게 병합합니다."),
        '2': ("Apply (번역 적용)",
            "'{APPLY_TRANSLATION_FILENAME_SUFFIX}' 파일의 번역문을 사용하여 '{SOURCE_DATA_FOLDER}'의 내용을 번역하고,\n"
            "그 결과물을 '{TRANSLATED_DATA_FOLDER}' 폴더에 새로 생성합니다."),
        '3': ("Deploy All (전체 배포)",
            "탐색 경로 내에서 '{TRANSLATED_DATA_FOLDER}' 폴더를 가진 모든 유효한 모드를 찾아\n"
            "게임의 mods 폴더('{DESTINATION_BASE_PATH}')로 복사(배포)합니다."),
        '4': ("Selective Deploy (선택적 배포)",
            "미리 설정된 모드 목록에 대해서만 'Deploy' 작업을 실행합니다.\n"
            "자주 업데이트하는 특정 모드들만 게임('{DESTINATION_BASE_PATH}')에 빠르게 적용할 때 유용합니다."),
        '5': ("Check (번역 일관성 검사)",
            "최신 '{SOURCE_DATA_FOLDER}' 내용과 '{MERGED_FILENAME_SUFFIX}'를 비교하여\n"
            "불일치/고아 항목이 있는지 검사하고 보고서를 생성합니다."),
        '6': ("'data'에서 번역 역추출 (Reverse-Extract)",
            "이미 번역이 적용된 '{TRANSLATED_DATA_FOLDER}' 폴더를 분석하여\n"
            "'{REVERSE_EXTRACT_SUCCESS_SUFFIX}' 등의 번역 라이브러리를 생성하는 강력한 기능입니다."),
        '7': ("스테이징 파일 관리",
            "실험적인 번역 변경사항을 '{STAGING_MASTER_FILENAME_SUFFIX}'라는 별도 파일에서 안전하게\n"
            "관리하고, 기본 작업 파일이나 마스터 파일과 데이터를 주고받는 기능입니다."),
        '77':("스테이징 적용 미리보기",
            "'{MERGED_FILENAME_SUFFIX}'와 '{STAGING_MASTER_FILENAME_SUFFIX}'를 합친 최종 결과를\n"
            "'{STAGING_OUTPUT_FOLDER}' 폴더에 생성하여 게임 내에서 미리 확인하는 기능입니다."),
        '8': ("Update Merged File (기본 작업 파일 정리)",
            "5번 Check로 발견된 불일치/고아 항목들을 '{MERGED_FILENAME_SUFFIX}' 파일에서 안전하게 정리합니다."),
        '9': ("마스터 번역 파일 관리",
            "작업 파일('{MERGED_FILENAME_SUFFIX}')과 장기 보관용 마스터 파일('{MASTER_FILENAME_SUFFIX}')을\n"
            "동기화하거나, 파일 이름을 변경하고, 중복 항목을 제거하는 등 유지보수 작업을 수행합니다.\n\n"
            "또한, 마스터 파일에 잘못 포함된 숫자 전용 항목(예: '123', '50%')을\n"
            "별도의 '{PURGE_TRASH_FILENAME_SUFFIX}' 파일로 안전하게 분리하여 마스터 파일의 품질을 관리합니다."),
        't': ("테스트 메뉴",
            "실제 파일은 변경하지 않는 '테스트 모드'로 주요 기능(Export, Apply)을 실행하여\n"
            "스크립트의 동작이나 설정이 올바른지 안전하게 확인할 수 있습니다."),
        'f': ("Forward Sync",
            "[고급] 로컬 작업 폴더의 '{SOURCE_DATA_FOLDER}'를 실제 게임의 'mods/모드명/data' 폴더에\n"
            "강제로 덮어씌웁니다. 게임 경로: '{DESTINATION_BASE_PATH}'"),
        'r': ("Reverse Sync",
            "게임 mods 폴더('{DESTINATION_BASE_PATH}')에 설치된 최신 모드의 'data' 폴더를\n"
            "로컬 작업 폴더의 '{SOURCE_DATA_FOLDER}'로 가져옵니다. 모드 업데이트 시 사용합니다."),
        'm': ("모드 정보 동기화",
            "게임 mods 폴더('{DESTINATION_BASE_PATH}')에 설치된 모드의 'mod_info.json' 파일을\n"
            "로컬 작업 폴더로 가져와 동기화합니다."),
        }

    def _get_sub_help_messages(self):
            """하위 메뉴들에 대한 도움말 메시지를 반환합니다."""
            return {
            '0': ("액션 플래그 처리 (Process Action Flags)",
                "모든 검토 파일의 'Translatable' 열을 읽어 항목을 자동으로 정리합니다.\n"
                "이 기능은 파일 종류에 따라 동작이 달라지므로, 아래 상세 설명을 참고하십시오.\n\n"
                "사용법:\n"
                " 1. 처리할 검토 파일을 엽니다. (예: '{FILTERED_ITEMS_FILENAME_SUFFIX}')\n"
                " 2. 각 항목의 'Translatable' 열에 원하는 액션을 입력합니다.\n"
                "    - 's': 항목을 스테이징 파일('{STAGING_MASTER_FILENAME_SUFFIX}')로 이동합니다.\n"
                "    - 'x': 항목을 트래시(삭제 보관소) 파일('{PURGE_TRASH_FILENAME_SUFFIX}')로 이동시킵니다.\n"
                "    - 'true' (또는 't'): 항목의 상태를 '승인'으로 변경하고, 대상 파일로 즉시 통합합니다.\n"
                "    - (공백, 'false' 등 다른 값): 항목을 처리하지 않고 파일에 그대로 남겨둡니다.\n"
                " 3. 파일을 저장하고 이 메뉴(0번)를 실행하여 해당 파일을 선택합니다.\n\n"
                "--- [ 파일 종류별 'true'/'t' 플래그 동작 상세 ] ---\n\n"
                "> 마스터 통합 대상 (Master Integration Target):\n"
                "  - 대상 파일들:\n"
                "    - '{FILTERED_ITEMS_FILENAME_SUFFIX}'\n"
                "    - '{MASTER_REVIEW_NEEDED_FILENAME_SUFFIX}'\n"
                "    - '{MASTER_TRUE_REVIEW_FILENAME_SUFFIX}'\n"
                "    - '{MASTER_PURGED_FILENAME_SUFFIX}'\n"
                "    - '{MASTER_EMPTY_KR_FILENAME_SUFFIX}'\n"
                "    - '{MASTER_FALSE_REVIEW_FILENAME_SUFFIX}'\n"
                "  - 동작: 't'로 표시된 항목은 **즉시 마스터 파일('{MASTER_FILENAME_SUFFIX}')에 'Translatable: True' 상태로 추가**됩니다.\n\n"
                "> 마스터 검토 대상 (Master Review Target):\n"
                "  - 대상 파일: '{REVIEW_NEEDED_FILENAME_SUFFIX}'\n"
                "  - 동작: 't'로 표시된 항목은 마스터 파일로 직접 통합되지 않고, **'마스터 검토' 파일('{MASTER_REVIEW_NEEDED_FILENAME_SUFFIX}')로 이동**하여\n"
                "    마스터 파일 통합 전 추가적인 검토 단계를 거칩니다."
            ),
        '6-10': ("'Translatable: x' 항목 처리",
                "'{MASTER_FILENAME_SUFFIX}' 파일에서 'Translatable' 열의 값이 'x'인 항목들을 찾습니다.\n\n"
                "이 항목들을 '{PURGE_TRASH_FILENAME_SUFFIX}' 파일로 **복사(Copy)**하거나, 마스터 파일에서 **제거(Move)**하고\n"
                "트래시 파일에 추가하여 관리할 수 있습니다.\n\n"
                "[주요 동작]\n"
                " - 복사: 'x' 항목을 트래시 파일에 추가하고, 마스터 파일은 변경하지 않습니다.\n"
                " - 이동: 'x' 항목을 트래시 파일에 추가하고, 마스터 파일에서는 해당 항목을 제거합니다.\n\n"
                "트래시 파일은 중복 없이 누적 관리되며, 모든 값이 동일한 항목은 덮어쓰기 없이 유지됩니다."
                ),
        # ----------------------------------------------------------------------
        # [ 7번 스테이징 관리자 메뉴 도움말 업데이트 ]
        # ----------------------------------------------------------------------
        '7-0': ("지능형 자동 병합 (Push to Master)",
                "스테이징 파일('{STAGING_MASTER_FILENAME_SUFFIX}')에서 완료된 모든 번역 작업을\n"
                "최종 보관용인 마스터 파일('{MASTER_FILENAME_SUFFIX}')로 안전하게 병합(Push)합니다.\n"
                "이것은 스테이징 작업의 가장 마지막 단계이며, 가장 중요한 기능입니다.\n\n"
                "[주요 동작]\n"
                " - 신규 항목: 마스터에 새로 추가됩니다.\n"
                " - 번역 업데이트: 기존 마스터 항목의 'text_kr'을 업데이트합니다.\n"
                " - 원문(text_en) 변경: 기존 마스터 항목을 **'Orphan'**으로 처리하고, 변경된 항목을 신규로 추가합니다.\n\n"
                "실행 전, 변경될 모든 항목의 상세 내역이 '{MASTER_MERGE_PREVIEW_FILENAME_SUFFIX}' 파일로 출력됩니다."
                ),
        '7-1': ("마스터 라이브러리로 번역 채우기",
                "'{MASTER_FILENAME_SUFFIX}' 파일을 번역 사전처럼 사용하여,\n"
                "'{STAGING_MASTER_FILENAME_SUFFIX}' 파일에 있는 항목 중 'text_kr'이 비어있는 곳을 자동으로 채웁니다.\n\n"
                "이 기능은 'text_en' 값이 정확히 일치하는 경우에만 작동하므로,\n"
                "이전에 번역했던 동일한 문장을 다시 번역하는 수고를 덜어줍니다."),
        '7-2': ("데이터 정규화 (따옴표/이스케이프 교정)",
                "CSV 편집기나 스프레드시트(예: 구글 시트)에서 데이터를 편집하고 다시 가져오는 과정에서\n"
                "발생할 수 있는 다양한 서식(Formatting) 문제를 자동으로 교정하는 강력한 유지보수 도구입니다.\n\n"
                "[사용 가능한 정규화 작업]\n"
                " 1. 'type: text' 항목: 'text_en'을 기준으로 'text_kr'에 누락된 외곽 따옴표를 추가합니다.\n"
                " 2. 'type: json' 항목: '\\\"', '\\n' 등 잘못된 이스케이프 문자를 실제 문자로 변환합니다."),
        '7-3': ("중복 항목 제거",
                "'{STAGING_MASTER_FILENAME_SUFFIX}' 파일 내에서 동일한 ID를 가진 중복 항목이 있을 경우,\n"
                "어떤 버전을 남길지 직접 선택하여 데이터를 정리합니다."),
        '7-4': ("Merged 파일과 지능형 동기화",
                "최신 Export 결과물인 '{MERGED_FILENAME_SUFFIX}'의 내용을 스테이징 파일('{STAGING_MASTER_FILENAME_SUFFIX}')에\n"
                "안전하게 지능형 병합(Intelligent Merge)합니다. Export 직후 자동으로 실행되는 동기화와 동일하게 동작합니다."),
        '7-5': ("마스터 파일에서 가져오기 (전체 덮어쓰기)",
                "'{MASTER_FILENAME_SUFFIX}' 파일의 모든 내용으로 '{STAGING_MASTER_FILENAME_SUFFIX}'을/를 완전히 덮어씁니다.\n"
                "스테이징 파일을 마스터와 동일하게 초기화하거나, 백업본으로 복원할 때 사용합니다."),
        '7-6': ("마스터 파일에서 누락된 항목만 가져오기",
                "'{MASTER_FILENAME_SUFFIX}' 파일과 '{STAGING_MASTER_FILENAME_SUFFIX}' 파일을 비교하여,\n"
                "스테이징에만 없는 항목들을 마스터에서 골라와 추가(append)합니다."),
        '7-7': ("번역된 작업 파일에서 가져오기",
                "'{MISSING_TRANSLATION_FILENAME}' 또는 '{EMPTY_KR_FILENAME_SUFFIX}' 등 번역 작업을 위해 생성된 파일들에서\n"
                "번역이 완료된(text_kr이 채워진) 항목들만 스테이징 파일('{STAGING_MASTER_FILENAME_SUFFIX}')로 가져옵니다."),
        '7-8': ("조건부 항목 삭제",
                "'{STAGING_MASTER_FILENAME_SUFFIX}' 파일 내에서 특정 조건(예: 'text_kr'이 비어있는 모든 행)에\n"
                "일치하는 행들을 선택하여 안전하게 제거합니다. 잘못 가져온 데이터를 정리할 때 유용합니다."),
        '7-9': ("스테이징 정리 메뉴 (Purge & Clear)",
                "스테이징 파일('{STAGING_MASTER_FILENAME_SUFFIX}')에 대한 마무리 작업을 수행합니다.\n\n"
                " - 부분 정리 (1-3): 번역 가치가 없는 숫자 항목만 골라 트래시 파일('{PURGE_TRASH_FILENAME_SUFFIX}')로 보냅니다.\n"
                " - 전체 정리 (4): 스테이징 파일에 남아있는 모든 항목을 트래시 파일로 옮기고,\n"
                "   스테이징 파일을 깨끗하게 비워 다음 작업을 준비합니다."),
        '9-1': ("마스터 파일 동기화",
                "최신 작업 결과물인 '{MERGED_FILENAME_SUFFIX}'의 내용과\n"
                "영구 보관용인 '{MASTER_FILENAME_SUFFIX}'의 내용을 비교하고 동기화합니다.\n"
                " - 자동 동기화: _merged 파일의 내용으로 _MASTER 파일을 완전히 덮어씁니다. (간단하고 확실함)\n"
                " - 수동 병합: 두 파일 간 내용 충돌이 발생할 경우, 각 충돌 항목마다 어떤 버전을 남길지 직접 선택합니다. (고급)"),
        '9-2': ("마스터 파일 이름 일괄 변경",
                "USER SETTINGS에 정의된 이전 마스터 파일 이름 형식(OLD_MASTER_FILENAME_SUFFIX)을 가진 모든 파일을 찾아\n"
                "새로운 형식(MASTER_FILENAME_SUFFIX)으로 안전하게 변경합니다."),
        '9-3': ("마스터 파일 내 중복 제거",
                "'{MASTER_FILENAME_SUFFIX}' 파일 내에서 동일한 위치 정보(source, id, type)를 가졌지만\n"
                "내용(text_en)이 다른 중복 항목 그룹을 찾아, 어떤 버전을 최종적으로 남길지 선택하여 파일을 정리합니다."),
        '9-4': ("마스터에서 숫자 전용 항목 분리",
                "'{MASTER_FILENAME_SUFFIX}' 파일에 포함된, 번역할 필요가 없는 순수 숫자/퍼센트 항목들을 찾아\n"
                "'{PURGE_TRASH_FILENAME_SUFFIX}' 파일로 분리(제거)하여 마스터 파일의 품질을 향상시킵니다."),
        '9-5': ("트래시 파일과 동기화 (모든 주요 파일 정리)",
                "'{PURGE_TRASH_FILENAME_SUFFIX}' 파일의 내용을 '삭제 블랙리스트'로 사용합니다.\n\n"
                "이 기능은 다음 주요 파일들을 검사하여:\n"
                " - '{MASTER_FILENAME_SUFFIX}'\n"
                " - '{MERGED_FILENAME_SUFFIX}'\n\n"
                "블랙리스트에 포함된 모든 항목을 해당 파일들에서 영구적으로 제거합니다.\n"
                "이를 통해 한번 '트래시'로 분류된 항목이 다른 작업 파일에 남아있는 문제를\n"
                "일괄적으로 정리하여 데이터의 일관성을 완벽하게 유지합니다."),
        '9-6': ("마스터 파일 필터링 및 검토", # <--- 새로운 도움말 추가
                "'{MASTER_FILENAME_SUFFIX}' 파일을 검사하여 다음 항목들을 분류합니다:\n"
                " - '검토 필요' 항목: '{POST_FILTER_EXCLUSION_RULES}'에 정의된 규칙에 따라 코드성이 의심되지만,\n"
                "   번역 가능한 텍스트가 포함되어 있을 수 있는 항목들.\n"
                "   (이 항목들은 '{MASTER_REVIEW_NEEDED_FILENAME_SUFFIX}' 파일로 이동합니다.)\n"
                " - '삭제 대상' 항목: 'is_translatable()' 함수가 명백히 번역 불가하다고 판단하는\n"
                "   (순수 숫자, 스크립트 코드 등) 항목들.\n"
                "   (이 항목들은 '{MASTER_PURGED_FILENAME_SUFFIX}' 파일로 기록되고 마스터 파일에서 제거됩니다.)\n"
                " - 'Translatable: True' 항목은 이 필터링에서 면제됩니다. (반복 검토 방지)\n\n"
                "이 기능을 통해 마스터 번역 파일의 품질을 주기적으로 관리하고 정리할 수 있습니다."),
        '9-7': ("승인 항목 재검토", # <--- 새로운 도움말 추가
                "'{MASTER_FILENAME_SUFFIX}' 파일에서 'Translatable: True'로 표시된 모든 항목을\n"
                "'{MASTER_TRUE_REVIEW_FILENAME_SUFFIX}' 파일로 추출하여 다시 검토합니다.\n\n"
                "이 파일에서 다음 작업을 수행할 수 있습니다:\n"
                " - 'action_flag'에 'x' 입력: 해당 항목은 '트래시' 파일로 이동되고 마스터에서 제거됩니다.\n"
                " - 'Translatable' 컬럼의 값을 'False' 또는 공백으로 변경: 마스터 파일에서 해당 항목의 '승인' 상태를 해제하여,\n"
                "   다음 '9-6 마스터 파일 필터링 및 검토' 시 다시 일반 검토 대상으로 분류되도록 합니다.\n\n"
                "한번 승인된 항목이라도 문제가 발생했을 때, 안전하게 재검토하고 수정할 수 있는 중요한 기능입니다."),
        '9-8': ("(기능 제거됨)",
                "이 기능은 현재 버전에서 제거되었습니다."),
        '9-9': ("(기능 제거됨)",
                "이 기능은 현재 버전에서 제거되었습니다."),
        '9-11': ("마스터 파일 'options' 포맷 정규화",
                "'{MASTER_FILENAME_SUFFIX}' 파일의 모든 내용을 스캔하여 'type'이 'options'로 시작하는 항목을 찾습니다.\n\n"
                "이 기능은 해당 항목들의 'text_en'과 'text_kr' 필드에 포함된 불필요한 외부 따옴표(예: '\"\"...\"\"')를\n"
                "모두 제거하여, 스크립트의 최신 데이터 포맷으로 영구적으로 업데이트(정리)합니다.\n\n"
                "과거 버전 스크립트로 생성된 마스터 파일의 데이터 일관성을 확보하고,\n"
                "향후 발생할 수 있는 데이터 포맷 관련 버그를 예방하는 데 매우 유용한 유지보수 기능입니다."),

        'workflow': ("추천 번역 워크플로우",
            "이 스크립트를 사용한 가장 일반적이고 안정적인 번역 작업 흐름은 다음과 같습니다.\n\n"
            "1. (최초 1회 또는 모드 업데이트 시)\n"
            "   - `r` (Reverse Sync): 게임 폴더의 최신 원본 `data`를 로컬 `data_en`으로 가져옵니다.\n\n"
            "2. (번역 작업 시작)\n"
            "   - `1` (Export): `data_en`에서 텍스트를 추출하여 작업 파일(`..._merged_kr.csv` 등)을 생성합니다.\n\n"
            "3. (번역 진행)\n"
            "   - 생성된 `...《11》_NEW_EMPTY_KR...csv` 파일의 `text_kr` 열을 채워 번역을 진행합니다.\n\n"
            "4. (번역 내용 통합)\n"
            "   - `5` (스테이징 관리자) -> `1`: 작업한 파일을 스테이징으로 가져옵니다.\n"
            "   - `5` (스테이징 관리자) -> `6`: 스테이징의 내용을 최종 마스터 파일로 병합(Push)합니다.\n\n"
            "5. (게임 적용 및 테스트)\n"
            "   - `2` (Apply): 최신 마스터 파일의 번역을 `data` 폴더에 적용합니다.\n"
            "   - `3` (Deploy): 생성된 `data` 폴더를 실제 게임의 모드 폴더로 복사합니다.\n\n"
            "6. (주기적인 품질 관리)\n"
            "   - `6` (마스터 관리자) 메뉴의 기능들을 사용하여 마스터 파일을 깨끗하게 유지합니다."
        ),
        'staging': ("스테이징 파일({STAGING_MASTER_FILENAME_SUFFIX})이란?",
            "스테이징 파일은 최종 마스터 파일(`{MASTER_FILENAME_SUFFIX}`)에 변경사항을 적용하기 전,\n"
            "다양한 소스(Export 결과, 수동 번역 등)의 데이터를 모으고, 검토하고, 정규화하는 '중간 작업 영역'입니다.\n\n"
            "[주요 역할]\n"
            " - 데이터 통합: 여러 `_...kr.csv` 파일의 내용을 하나로 모읍니다.\n"
            " - 데이터 정제: `7-9. 데이터 정규화` 기능으로 따옴표나 줄바꿈 문제를 해결합니다.\n"
            " - 안전한 검토: 마스터 파일에 직접 영향을 주지 않고 변경 내역을 미리 확인할 수 있습니다.\n\n"
            "스테이징을 거치면, 예측 가능하고 검증된 데이터만 마스터 파일에 병합되므로 데이터의 안정성이 크게 향상됩니다."
        ),
        'master': ("마스터 파일({MASTER_FILENAME_SUFFIX})이란?",
            "마스터 파일은 스크립트의 '단일 진실 공급원(Single Source of Truth)' 역할을 하는 가장 중요한 번역 자산입니다.\n"
            "모든 번역 작업의 최종 결과물은 이 파일에 누적되어 영구적으로 보관됩니다.\n\n"
            "[주요 특징]\n"
            " - 최종 보관소: 모든 번역의 최종본이 저장됩니다.\n"
            " - `Apply`의 기준: `2. Apply` 기능은 기본적으로 이 마스터 파일의 `text_kr`을 사용하여 번역을 적용합니다.\n"
            " - 상태 관리: `Translatable` 열을 통해 각 항목의 상태('True', 'x', 'orphan' 등)를 관리하여\n"
            "   번역 워크플로우를 정밀하게 제어할 수 있습니다.\n\n"
            "`9. 마스터 파일 관리자` 메뉴는 이 중요한 파일을 안전하고 깨끗하게 유지하기 위한 다양한 도구를 제공합니다."
        ),
            }

    def _get_menu_actions(self):
        """[v2] 메뉴 액션 정의를 딕셔너리 구조로 변경하여 유연성을 확보합니다."""
        return {
            '00': {
                'name': "Report Refresh",
                'func': run_report_refresh_task,
                'validation': lambda p: ValidationService(p).for_export(),
                'log': 'log_report_refresh.txt',
                'clear_screen': False
            },
            '1': {
                'name': "Export",
                'func': extract_and_merge,
                'validation': lambda p: ValidationService(p).for_export(),
                'log': EXPORT_LOG_FILENAME
            },
            '2': {
                'name': "Apply",
                'func': apply_all_translations,
                'validation': lambda p: ValidationService(p).for_apply(),
                'log': APPLY_LOG_FILENAME
            },
            '3': {
                'name': "Deploy All",
                'func': deploy_mod_data,
                'validation': lambda p: ValidationService(p).for_deploy(),
                'log': COPY_LOG_FILENAME
            },
            '11': {
                'name': "Push Missing to Staging",
                'func': _run_push_missing_to_merged_engine,
                'validation': lambda p: os.path.isfile(PathManager(p).get_missing_file()), # missing 파일만 있어도 실행 가능
                'log': 'log_push_missing.txt',
                'clear_screen': False
            },
            '50': {
                'name': "Manual Sync Merged to Staging",
                'func': run_post_export_sync_check,
                'validation': lambda p: os.path.isfile(PathManager(p).get_merged_file()), # merged 파일만 있어도 실행 가능
                'log': 'log_manual_sync.txt',
                'clear_screen': False
            },
            '77': {
                'name': "Staging to Master Auto-Merge",
                'func': _run_merge_completed_to_master_wrapper,
                'validation': lambda p: os.path.exists(PathManager(p).get_staging_master_file()),
                'log': 'log_intelligent_merge.txt'
            },
            'f': {
                'name': "Forward",
                'func': run_forward_sync,
                'validation': lambda p: ValidationService(p).for_forward_sync(),
                'log': FORWARD_SYNC_LOG_FILENAME
            },
            'r': {
                'name': "Reverse",
                'func': run_reverse_sync,
                'validation': lambda p: ValidationService(p).for_reverse_sync(),
                'log': REVERSE_SYNC_LOG_FILENAME
            },
            'm': {
                'name': "ModInSync",
                'func': run_mod_info_sync,
                'validation': lambda p: ValidationService(p).for_mod_info_sync(),
                'log': None
            },
        }

    def _get_test_menu_actions(self):
        # 기존 TEST_MENU_ACTIONS 딕셔너리
        return {
            '1': ("Export 테스트", extract_and_merge, lambda p: ValidationService(p).for_export(), EXPORT_LOG_FILENAME),
            '2': ("Apply 테스트", apply_all_translations, lambda p: ValidationService(p).for_apply(), APPLY_LOG_FILENAME),
        }

    def run_main_loop(self):
        """스크립트의 메인 UI 루프를 실행합니다."""
        main_menu_active = True
        
        while True:
            if main_menu_active:
                display_main_menu()
                prompt = f"선택 (0,00,11,50, 1-4, 5-7, f,r,m,t, '{GLOBAL_EXIT_COMMAND}' 종료): "
            else:
                display_test_menu()
                prompt = f"테스트 선택 (1-3, ESC/'{GLOBAL_EXIT_COMMAND}'로 종료): "

            choice = prompt_for_input(prompt,
                                      allow_empty=True,
                                      help_dict=self.HELP_MESSAGES,
                                      help_context=self.SETTINGS_CONTEXT
                                      )

            if choice is UserInput.QUIT:
                self.logger.info("프로그램을 종료합니다.")
                break

            if main_menu_active and choice == 't':
                main_menu_active = False
                continue
            if not main_menu_active and choice is UserInput.ESC:
                main_menu_active = True
                continue

            is_test = not main_menu_active
            actions = self.TEST_MENU_ACTIONS if is_test else self.MENU_ACTIONS

            if choice in actions:
                action_config = actions[choice]
                
                mode_name = action_config.get('name')
                task_func = action_config.get('func')
                validation_func = action_config.get('validation')
                log_file = action_config.get('log')
                clear_screen = action_config.get('clear_screen', True)

                execute_task(
                    task_func, 
                    validation_func, 
                    log_file, 
                    mode_name, 
                    is_test,
                    clear_screen_after_task=clear_screen
                )
            
            elif main_menu_active:
                if choice == '0':
                    self.run_action_flag_processor_menu()
                elif choice == '4':
                    self.run_selective_deploy_menu()
                elif choice == '5':
                    self.run_staging_menu()
                elif choice == '6':
                    self.run_master_menu()
                elif choice == '7':
                    self.run_reverse_extraction_menu()
            elif is_test and choice == '3':
                run_file_specific_test(self.base_path, is_test_run=True)

    def _handle_push_to_master_menu(self):
        """UI 핸들러: 7-0 (지능형 자동 병합)"""
        execute_task(
            _run_merge_completed_to_master_wrapper,
            lambda p: os.path.exists(PathManager(p).get_staging_master_file()),
            'log_intelligent_merge.txt',
            "Intelligent Staging Merge",
            self.is_test_run
        )

    def _handle_fill_kr_from_master(self):
        """UI 핸들러: 7-1 (번역 채우기)"""
        _run_fill_kr_from_master_engine(self.base_path, self.is_test_run)
        pause_for_user()

    def _handle_normalization_menu(self):
        """UI 핸들러: 7-2 (데이터 정규화)"""
        run_normalization_manager_menu(self.base_path, self.is_test_run)
        pause_for_user()

    def _handle_deduplicate_staging(self):
        """UI 핸들러: 7-3 (중복 제거)"""
        run_deduplicate_staging_menu(self.base_path, self.is_test_run)
        pause_for_user()

    def _handle_pull_from_merged_menu(self):
        """UI 핸들러: 7-4 (Merged에서 가져오기)"""
        # 다중 모드에서는 이 기능이 전체 복사로 동작하므로 execute_task 사용
        execute_task(
            _run_pull_to_staging_wrapper,
            lambda p: os.path.isfile(PathManager(p).get_merged_file()),
            'log_pull_to_staging.txt',
            "Pull from Merged to Staging",
            self.is_test_run
        )

    def _handle_copy_master_to_staging(self):
        """UI 핸들러: 7-5 (마스터에서 전체 복사)"""
        _run_copy_master_to_staging_engine(self.base_path, self.is_test_run)
        pause_for_user()
        
    def _handle_pull_missing_from_master(self):
        """UI 핸들러: 7-6 (마스터에서 누락 항목 가져오기)"""
        _run_pull_from_master_to_staging_engine(self.base_path, self.is_test_run)
        pause_for_user()
        
    def _handle_pull_untranslated_to_staging(self):
        """UI 핸들러: 7-7 (작업 파일에서 가져오기)"""
        run_pull_untranslated_to_staging(self.base_path, self.is_test_run)
        pause_for_user()

    def _handle_delete_by_condition(self):
        """UI 핸들러: 7-8 (조건부 삭제)"""
        _run_delete_by_condition_engine(self.base_path, self.is_test_run)
        pause_for_user()

    def _handle_purge_staging_menu(self):
        """UI 핸들러: 7-9 (스테이징 정리 메뉴)"""
        execute_task(
            _run_staging_purge_wrapper,
            lambda p: os.path.isfile(PathManager(p).get_staging_master_file()),
            'log_staging_purge.txt',
            "Staging Purge",
            self.is_test_run
        )

    def run_staging_menu(self):
        """
        [v3.1] 각 기능 실행 후 메인 메뉴로 복귀하도록 수정합니다.
        """
        while True:
            display_header()
            
            # --- 새로운 메뉴 UI 출력 ---
            print("\n" + "="*70)
            print(f"{'[':^26} 5. 스테이징 파일 관리자 {']':^27}")
            print("="*70)

            print("\n--- [ 스테이징 -> 마스터로 내보내기 (Push to Master) ] ---------------")
            print("      (가장 중요하고 마지막에 수행하는 작업입니다)\n")
            print(" 0. 지능형 자동 병합 (Push to Master)")
            print("    └─[?] 스테이징의 검증된 작업을 최종 마스터 파일에 안전하게 병합합니다.")

            print("\n--- [ 데이터 준비: 정제 및 관리 (Refine & Manage) ] ------------------\n")
            print(" 1. 마스터 라이브러리로 번역 채우기")
            print("    └─[?] 스테이징의 빈 번역(text_kr)란을 마스터 파일 기준으로 자동 완성합니다.")
            print("\n 2. 데이터 정규화 (따옴표/이스케이프 교정)")
            print("    └─[?] 스프레드시트 작업 중 발생한 서식 오류를 자동으로 수정합니다.")
            print("\n 3. 중복 항목 제거")
            print("    └─[?] 동일한 ID를 가진 중복 항목을 찾아 하나만 남기고 정리합니다.")

            print("\n--- [ 데이터 준비: 외부에서 가져오기 (Pull from External) ] ----------\n")
            print(" 4. Merged 파일과 지능형 동기화 (Export 후 수동 실행)")
            print("    └─[?] 최신 Export 결과('{MERGED_FILENAME_SUFFIX}')를 스테이징 파일('{STAGING_MASTER_FILENAME_SUFFIX}')에\n"
                  "          안전하게 지능형 병합합니다.")
            print("\n 5. 마스터 파일에서 가져오기 (전체 덮어쓰기)")
            print("    └─[?] 마스터 파일의 전체 내용으로 스테이징 파일을 초기화합니다.")
            print("\n 6. 마스터 파일에서 누락된 항목만 가져오기")
            print("    └─[?] 스테이징에 없는 마스터 파일의 항목만 골라서 추가합니다.")
            print("\n 7. 번역된 작업 파일에서 가져오기")
            print("    └─[?] 번역이 완료된 작업 파일(_...EMPTY_KR... 등)의 내용을 스테이징에 추가합니다.")

            print("\n--- [ 데이터 정리 (Cleanup) ] -----------------------------------------\n")
            print(" 8. 조건부 항목 삭제")
            print("    └─[?] 'text_kr'이 비어있거나 'orphan' 상태인 항목 등을 선택하여 삭제합니다.")
            print("\n 9. 스테이징 정리 메뉴 (Purge & Clear)")
            print("    └─[?] 숫자 전용 항목을 분리하거나, 작업 완료 후 스테이징 전체를 비웁니다.")
            print("\n──────────────────────────────────────────────────────────────────────")

            prompt = "\n>> 원하는 작업 번호를 선택하세요 (0-9), ESC: 뒤로, q: 종료): "
            choice = prompt_for_input(
                prompt,
                valid_choices=['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
                help_dict=self.HELP_MESSAGES,
                help_context=self.SETTINGS_CONTEXT,
                help_key_prefix="7-"
            )

            if choice is UserInput.ESC or choice is UserInput.QUIT:
                return

            if choice == '0':
                self._handle_push_to_master_menu()
                return # 메인 메뉴로 복귀
            elif choice == '1':
                self._handle_fill_kr_from_master()
                return # 메인 메뉴로 복귀
            elif choice == '2':
                self._handle_normalization_menu()
                return # 메인 메뉴로 복귀
            elif choice == '3':
                self._handle_deduplicate_staging()
                return # 메인 메뉴로 복귀
            elif choice == '4':
                self._handle_pull_from_merged_menu()
                return # 메인 메뉴로 복귀
            elif choice == '5':
                self._handle_copy_master_to_staging()
                return # 메인 메뉴로 복귀
            elif choice == '6':
                self._handle_pull_missing_from_master()
                return # 메인 메뉴로 복귀
            elif choice == '7':
                self._handle_pull_untranslated_to_staging()
                return # 메인 메뉴로 복귀
            elif choice == '8':
                self._handle_delete_by_condition()
                return # 메인 메뉴로 복귀
            elif choice == '9':
                self._handle_purge_staging_menu()
                return # 메인 메뉴로 복귀

    def run_master_menu(self):
        """[v2.0] 각 기능 실행 후 메인 메뉴로 복귀하도록 수정합니다."""
        paths = PathManager(self.base_path)

        while True:
            display_header()
            print("\n [ 6. 마스터 번역 파일 관리 ]\n") # 메뉴 번호 수정
            
            # --- 메뉴 항목 출력 (기존과 동일) ---
            print("  ─── [ 핵심 작업: 동기화 및 정리 ] ───────────────────────────────────\n")
            print("  >> [1] : 마스터 파일 동기화 (Sync with _merged_kr.csv)")
            print("           - " + _format_help_message("'{MERGED_FILENAME_SUFFIX}'의 최신 내용을 '{MASTER_FILENAME_SUFFIX}'에 병합합니다.", self.SETTINGS_CONTEXT))
            print()
            print("  >> [2] : 마스터 파일 이름 일괄 변경 (Batch Rename)")
            print("           - " + _format_help_message("'{OLD_MASTER_FILENAME_SUFFIX}'을(를) '{MASTER_FILENAME_SUFFIX}'(으)로 변경합니다.", self.SETTINGS_CONTEXT))
            print()
            print("  >> [3] : 마스터 파일 내 중복 제거 (Deduplicate Master File)")
            print("           - " + _format_help_message("'{MASTER_FILENAME_SUFFIX}' 내에서 동일한 항목이 여러 버전일 경우 정리합니다.", self.SETTINGS_CONTEXT))
            print()
            print("  ─── [ 고급 유지보수: 필터링 및 검토 ] ───────────────────────────────────\n")
            print("  >> [4] : 마스터에서 숫자 전용 항목 분리 (Purge Numeric-only)")
            print("           - " + _format_help_message("숫자/퍼센트 항목을 '{PURGE_TRASH_FILENAME_SUFFIX}' 파일로 옮겨 마스터를 정리합니다.", self.SETTINGS_CONTEXT))
            print()
            print("  >> [5] : 마스터 파일 필터링 및 검토 (Filter & Review)")
            print("           - " + _format_help_message("코드 의심 항목을 '{MASTER_REVIEW_NEEDED_FILENAME_SUFFIX}' 파일로 분리하여 검토합니다.", self.SETTINGS_CONTEXT))
            print()
            print("  >> [6] : `Translatable` 상태별 항목 검토 (Re-evaluate by Status)")
            print("           - " + _format_help_message("'True' 또는 'False' 상태인 항목만 추출하여 재검토합니다.", self.SETTINGS_CONTEXT))
            print()
            print("  >> [7] : 마스터에서 번역 없는 항목 추출 (Extract Empty KR)")
            print("           - " + _format_help_message("'text_kr'이 비어있는 항목을 '{MASTER_EMPTY_KR_FILENAME_SUFFIX}' 파일로 추출합니다.", self.SETTINGS_CONTEXT))
            print()
            print("  >> [8] : (기능 임시 제거)")
            # print("           - " + _format_help_message("'Translatable: x' 항목을 '{PURGE_TRASH_FILENAME_SUFFIX}' 파일로 보냅니다.", self.SETTINGS_CONTEXT))
            print()
            print("  >> [9] : (기능 임시 제거)")
            # print("           - " + _format_help_message("'Translatable: x' 항목들을 마스터 파일의 맨 아래로 재정렬합니다.", self.SETTINGS_CONTEXT))
            print()
            print("  ─── [ 'x' 항목 및 트래시 관리 ] ──────────────────────────────────────\n")
            print("  >> [10]: 'Translatable: x' 항목 처리")
            print("           - " + _format_help_message("마스터 파일의 'x' 항목을 트래시 파일로 복사하거나 이동합니다.", self.SETTINGS_CONTEXT))
            print()
            print("  >> [11]: 트래시 파일 -> 마스터로 병합 (Merge Trash to Master)")
            print("           - " + _format_help_message("'{PURGE_TRASH_FILENAME_SUFFIX}'의 항목을 'x' 상태로 마스터 파일에 추가합니다.", self.SETTINGS_CONTEXT))
            print()
            # print("  >> [12]: 트래시 파일과 동기화 (모든 주요 파일 정리)")
            print("  >> [12]: (기능 임시 제거)")
            # print("           - " + _format_help_message("'{PURGE_TRASH_FILENAME_SUFFIX}'를 기준으로 모든 주요 파일에서 해당 항목을 제거합니다.", self.SETTINGS_CONTEXT))
            print()
            print("  >> [13]: 마스터 파일 'options' 포맷 정규화 (Normalize 'options' Data)")
            print("           - 'options' 타입 항목의 text_en/kr에서 불필요한 따옴표를 영구적으로 제거합니다.")
            print()

            prompt = "\n>> 원하는 작업 번호를 선택하세요 (0-11, 도움말: 5?, ESC/뒤로): "
            choice = prompt_for_input(
                prompt, 
                valid_choices=['0','1','2','3','4','5','6','7','8','9','10', '11'],
                help_dict=self.HELP_MESSAGES, 
                help_key_prefix="9-", 
                allow_empty=True
            )

            if choice is UserInput.ESC or choice is UserInput.QUIT:
                break 

            if choice and choice.endswith('?'):
                continue
            
            # [핵심] 모든 액션이 self.base_path와 self.is_test_run을 사용하도록 수정
            if choice == '1':
                self.logger.info(" -> '마스터 파일 동기화'를 시작합니다...")
                execute_task(_run_sync_logic_wrapper, lambda p: ValidationService(p).for_sync(), None, "Sync", self.is_test_run)
                return # 메인 메뉴로 복귀
            elif choice == '2':
                _run_rename_logic_batch(self.is_test_run, self.base_path)
                pause_for_user()
                return # 메인 메뉴로 복귀
            elif choice == '3':
                self.logger.info(" -> '마스터 파일 내 중복 제거'를 시작합니다...")
                execute_task(_run_deduplicate_master_file_wrapper, lambda p: ValidationService(p).for_sync(), None, "DeduplicateMaster", self.is_test_run)
                return
            elif choice == '4':
                # 1. UI 함수를 호출하여 사용자 선택(필터)을 받음
                filters = run_purge_numeric_from_master_menu(self.base_path, self.is_test_run)
                
                # 2. 사용자가 유효한 필터를 선택한 경우에만 execute_task 실행
                if filters:
                    shared_state_for_task = {'filters_to_apply': filters}
                    execute_task(
                        task_function=_run_purge_numeric_wrapper,
                        validation_check=lambda p: os.path.isfile(PathManager(p).get_master_file()),
                        log_filename='log_master_purge.txt',
                        mode_name="Purge Numeric from Master",
                        is_test_run=self.is_test_run,
                        shared_state_override=shared_state_for_task
                    )
                
                # execute_task가 pause를 관리하고, 사용자가 취소한 경우에도
                # 마스터 메뉴 루프를 빠져나가야 하므로 return을 유지합니다.
                return
            elif choice == '5': 
                self.logger.info(" -> '마스터 파일 필터링 및 검토'를 시작합니다...")
                execute_task(_run_master_file_filter_and_review, lambda p: os.path.isfile(paths.get_master_file()), MASTER_REVIEW_LOG_FILENAME, "MasterReview", self.is_test_run)
                return
            elif choice == '6':
                self.logger.info(" -> '`Translatable` 상태별 항목 검토'를 시작합니다...")
                execute_task(_run_re_evaluate_by_status_controller, lambda p: os.path.isfile(paths.get_master_file()), MASTER_REVIEW_LOG_FILENAME, "ReevaluateByStatus", self.is_test_run)
                return
            elif choice == '7':
                execute_task(_run_extract_empty_kr_from_master_engine, lambda p: os.path.isfile(paths.get_master_file()), None, "ExtractEmptyKR", self.is_test_run)
                return
            elif choice == '8':
                self.logger.info(" -> 6-8번 기능은 현재 버전에서 임시 제거되었습니다. 이전 메뉴로 돌아갑니다.")
                pause_for_user()
                continue
            elif choice == '9':
                self.logger.info(" -> 6-9번 기능은 현재 버전에서 임시 제거되었습니다. 이전 메뉴로 돌아갑니다.")
                pause_for_user()
                continue
            elif choice == '10':
                self.logger.info(" -> 'Translatable: x' 항목 처리를 시작합니다...")
                master_service = MasterFileService(self.base_path, csv_file_service)
                x_flag_service = MasterXFlagService(self.base_path, csv_file_service, master_service, paths)
                x_flag_service.process_x_flags(self.is_test_run)
                return
            elif choice == '11':
                self.logger.info(" -> '트래시 파일 -> 마스터로 병합'을 시작합니다...")
                execute_task(_run_merge_trash_to_master_engine, lambda p: os.path.isfile(paths.get_master_file()) and os.path.isfile(paths.get_purge_trash_file()), None, "MergeTrashToMaster", self.is_test_run)
                return
            elif choice == '12':
                self.logger.info(" -> 6-8번 기능은 현재 버전에서 임시 제거되었습니다. 이전 메뉴로 돌아갑니다.")
                # self.logger.info(" -> '트래시 파일과 동기화'를 시작합니다...")
                # execute_task(
                #     task_function=_run_sync_with_trash_wrapper,
                #     validation_check=lambda p: os.path.isfile(PathManager(p).get_purge_trash_file()),
                #     log_filename='log_trash_sync.txt',
                #     mode_name="Sync with Trash file",
                #     is_test_run=self.is_test_run
                # )
                return
            elif choice == '13':
                self.logger.info(" -> '마스터 파일 'options' 포맷 정규화'를 시작합니다...")
                execute_task(
                    task_function=_run_normalize_master_options_engine,
                    validation_check=lambda p: os.path.isfile(PathManager(p).get_master_file()),
                    log_filename='log_master_normalize.txt',
                    mode_name="Normalize Master Options",
                    is_test_run=self.is_test_run
                )
                return
            
    def run_reverse_extraction_menu(self):
        """[로직 이전] 6번. 'data'에서 번역 역추출 기능의 UI 및 흐름을 제어합니다."""
        paths = PathManager(self.base_path)
        orphan_file_path = paths.get_reverse_extract_orphan_file()
        success_file_path = paths.get_reverse_extract_success_file()
        recovered_file_path = paths.get_reverse_extract_recovered_file()

        while True:
            is_success_file_ready = os.path.exists(success_file_path)
            is_merge_ready = is_success_file_ready and os.path.exists(recovered_file_path)

            display_header()
            print("\n [ 6. 'data'에서 번역 역추출 ]\n")
            
            print(f" > 1. ◀ 기본 폴더에서 추출 ('{TRANSLATED_DATA_FOLDER.lstrip('./\\\\')}')")
            
            alt_folder_name_setting = REVERSE_EXTRACT_ALT_SOURCE_FOLDER.lstrip('./\\')
            if alt_folder_name_setting:
                print(f" > 2. ◀ 설정된 대체 폴더에서 추출 ('{alt_folder_name_setting}')")
            else:
                print(" > 2. (설정된 대체 폴더 없음)")
            
            print(f"\n > 3. ◀ 성공한 역추출 결과를 작업 파일로 Push")
            print(f"    └─ '{os.path.basename(success_file_path)}' -> '{os.path.basename(paths.get_missing_file())}'")
            if not is_success_file_ready:
                print(f"       (알림: '{os.path.basename(success_file_path)}' 파일 없음. 1 또는 2번 선행 필요)")
            
            # 메뉴 항목을 단순화하고 명확하게 변경
            print(f"\n > 4. ◀ 성공한 역추출 결과를 스테이징으로 지능형 병합")
            print(f"    └─ '{os.path.basename(success_file_path)}' -> '{os.path.basename(paths.get_staging_master_file())}'")
            if not is_success_file_ready:
                print(f"       (알림: '{os.path.basename(success_file_path)}' 파일 없음. 1 또는 2번 선행 필요)")
                
            print("\n > 5. (임시 메뉴 - 기능 통합 예정)")

            choice = prompt_for_input("\n>> 원하는 작업 번호를 선택하세요 (1-5), ESC/돌아가기 : ", valid_choices=['1', '2', '3', '4'])

            if choice is UserInput.ESC or choice is UserInput.QUIT:
                self.logger.info(" -> 메인 메뉴로 돌아갑니다.")
                break

            if choice in ('1', '2'):
                target_kr_folder_name = TRANSLATED_DATA_FOLDER.lstrip('./\\\\')
                if choice == '2':
                    if not alt_folder_name_setting:
                        self.logger.warning(" [!] 설정된 대체 폴더가 없어 선택할 수 없습니다.")
                        pause_for_user()
                        continue
                    target_kr_folder_name = alt_folder_name_setting

                kr_folder_path = os.path.join(self.base_path, target_kr_folder_name)
                print(f"\n[작업 정보] 번역 소스 폴더: '{os.path.abspath(kr_folder_path)}'")
                
                confirm = prompt_for_input(f"\n>> '{target_kr_folder_name}' 폴더를 분석하여 검토용 파일을 생성/덮어쓰시겠습니까? (Enter/y, ESC/n): ", valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')
                if confirm != 'y':
                    self.logger.info(" -> 작업을 취소했습니다.")
                    continue

                run_reverse_extraction(self.is_test_run, self.base_path, shared_state=None, source_kr_folder=kr_folder_path)
                pause_for_user()
                return
            elif choice == '3':
                if not os.path.exists(paths.get_reverse_extract_success_file()):
                    self.logger.warning(f" [!] 원본 파일 '{os.path.basename(paths.get_reverse_extract_success_file())}'이(가) 없어 실행할 수 없습니다.")
                else:
                    _run_push_success_to_missing_engine(self.base_path, self.is_test_run)
                pause_for_user()
                return
            elif choice == '4':
                if not os.path.exists(paths.get_reverse_extract_success_file()):
                    self.logger.warning(f" [!] 원본 파일 '{os.path.basename(paths.get_reverse_extract_success_file())}'이(가) 없어 실행할 수 없습니다.")
                    pause_for_user()
                else:
                    execute_task(
                        _run_merge_reverse_success_to_staging_wrapper,
                        lambda p: os.path.isfile(PathManager(p).get_reverse_extract_success_file()),
                        'log_merge_reverse_to_staging.txt',
                        "Merge Reverse Success to Staging",
                        self.is_test_run
                    )
                return

            elif choice == '5':
                 self.logger.info(" [알림] 이 기능은 향후 다른 메뉴와 통합될 예정입니다.")
                 pause_for_user()

    def run_selective_deploy_menu(self):
        """[로직 이전] 4번. 선택적 배포 기능의 메인 메뉴를 제어합니다."""
        deployable_mods = self.selective_deploy_service.get_deployable_mods()
        is_multi_mode_env = PROCESS_MULTIPLE_MODS_AUTO and len(deployable_mods) >= 2

        if not is_multi_mode_env:
            print("\n" + "!"*60)
            self.logger.warning(" [알림] '선택적 배포'는 다중 모드 환경 전용 기능입니다.")
            print("-" * 60)
            print("  이 기능은 여러 개의 모드 폴더 중에서 일부만 선택하여 배포할 때 사용됩니다.")
            print("\n  현재 환경에서는 '3. Deploy All' 기능을 사용하시는 것을 권장합니다.")
            print("!"*60)
            pause_for_user()
            return

        selected_mods = self.selective_deploy_service.load_targets()
        
        print("\n" + "="*60)
        print("\n [ 4. 선택적 배포 (Selective Deploy) ]\n")
        print("-" * 20 + " [ 현재 선택된 모드 ] " + "-" * 20)
        if not selected_mods:
            print("없음")
        else:
            for i in range(0, len(selected_mods), 3): print("   ".join(selected_mods[i:i+3]))
        print("-" * 52)
        
        print("\n1. 선택된 모드 배포 시작")
        print("2. 배포 대상 모드 설정")
        
        prompt = "\n>> 선택 (1-2, ESC: 뒤로, q: 종료): "
        choice = prompt_for_input(prompt, valid_choices=['1', '2'])

        if choice is UserInput.ESC or choice is UserInput.QUIT:
            return

        if choice == '1':
            self._start_selective_deployment()
        elif choice == '2':
            self._configure_selective_deploy_targets()

    def _start_selective_deployment(self):
        """[내부 헬퍼] 설정 파일에 지정된 모드들에 대해 배포를 실행합니다."""
        targets = self.selective_deploy_service.load_targets()
        if not targets:
            self.logger.warning("\n -> 배포 대상으로 선택된 모드가 없습니다. 먼저 '2. 배포 대상 모드 설정'을 실행해주세요.")
            pause_for_user()
            return

        print("\n" + "="*60)
        self.logger.info("선택된 다음 모드에 대해 배포를 시작합니다:")
        for target in targets: print(f"  - {target}")
        
        prompt = "\n>> 계속하시겠습니까? (Enter/y: 예, ESC/n: 아니오): "
        choice = prompt_for_input(prompt, valid_choices=['y', 'n'], allow_empty=True, default_on_empty='y')

        if choice != 'y':
            self.logger.info(" -> 배포 작업을 취소했습니다.")
            return

        for mod_name in targets:
            mod_path = os.path.join(self.base_path, mod_name)
            if os.path.isdir(mod_path):
                self.logger.info(f"\n{'=' * 25} 배포 시작: [ {mod_name} ] {'=' * 25}")
                deploy_mod_data(is_test_run=self.is_test_run, base_path=mod_path, shared_state=None)
            else:
                self.logger.warning(f" [!] '{mod_name}' 폴더를 찾을 수 없어 건너뜁니다.")
        
        pause_for_user()

    def _configure_selective_deploy_targets(self):
        """[내부 헬퍼] 사용자가 배포할 모드를 선택하고 관리하는 UI를 처리합니다."""
        all_mods_in_search_path = self.selective_deploy_service.get_deployable_mods()
        registered_mods = self.selective_deploy_service.load_targets()

        while True:
            display_header()
            print("\n[ 배포 대상 모드 설정 ]\n")
            
            if not all_mods_in_search_path:
                search_root = self.selective_deploy_service.search_root
                print(" [ 알림: 유효 모드 없음 ]")
                print(f"   탐색 경로 '{_get_short_path(search_root)}'에서")
                print("   배포 가능한 하위 모드 폴더를 찾을 수 없습니다.")
                print("   ('data' 폴더가 있고 이름 규칙을 따르는 폴더가 있는지 확인하세요.)\n")
            
            unregistered_mods = sorted([mod for mod in all_mods_in_search_path if mod not in registered_mods])
            
            print("-" * 20 + " [ 미등록 모드 ] " + "-" * 20)
            if not unregistered_mods:
                print("모든 유효한 모드가 등록되었습니다.")
            else:
                max_len = max((len(mod) for mod in unregistered_mods), default=20)
                num_columns = 3
                for i, mod in enumerate(unregistered_mods):
                    print(f'[{i+1:>2}] {mod:<{max_len}}   ', end='')
                    if (i + 1) % num_columns == 0 or (i + 1) == len(unregistered_mods):
                        print()
                print('\n')

            print("\n" + "-" * 20 + " [ 등록된 모드 ] " + "-" * 20)
            if not registered_mods:
                print("현재 등록된 모드가 없습니다.")
            else:
                for i, mod in enumerate(sorted(registered_mods)):
                    print(f'[-{i+1:>2}] {mod}')
            
            print("\n" + "="*60)
            print(" [ 조작 방법 ]")
            print("  - 추가: 추가할 모드의 번호를 입력 (예: 1 5 12)")
            print("  - 제거: 제거할 모드의 번호를 '-'와 함께 입력 (예: -3 -7)")
            print("\n  - 저장 후 돌아가기: [Enter]")
            print("  - 저장하지 않고 돌아가기: [ESC]")
            print("="*60)
            
            user_input = prompt_for_input("\n>> 입력: ", allow_empty=True)

            if user_input is UserInput.ESC:
                self.logger.info(" -> 변경사항을 저장하지 않고 이전 메뉴로 돌아갑니다.")
                break
            if user_input == '':
                # [수정] 서비스 메서드 호출로 변경
                self.selective_deploy_service.save_targets(registered_mods)
                self.logger.info(" -> 변경사항을 저장했습니다.")
                break

            parts = user_input.split()
            current_registered_sorted = sorted(registered_mods)
            for part in parts:
                try:
                    if part.startswith('-'):
                        idx = int(part[1:]) - 1
                        if 0 <= idx < len(current_registered_sorted):
                            mod_to_remove = current_registered_sorted[idx]
                            if mod_to_remove in registered_mods:
                                registered_mods.remove(mod_to_remove)
                                self.logger.info(f" -> '{mod_to_remove}'를 목록에서 제거했습니다.")
                        else:
                             self.logger.warning(f" [!] 잘못된 제거 번호: {part}")
                    else:
                        idx = int(part) - 1
                        if 0 <= idx < len(unregistered_mods):
                            mod_to_add = unregistered_mods[idx]
                            if mod_to_add not in registered_mods:
                                registered_mods.append(mod_to_add)
                                self.logger.info(f" -> '{mod_to_add}'를 목록에 추가했습니다.")
                        else:
                            self.logger.warning(f" [!] 잘못된 추가 번호: {part}")
                except ValueError:
                    self.logger.warning(f" [!] 잘못된 입력 형식: '{part}'")

    def run_action_flag_processor_menu(self):
        """
        [v2.0] 0번. 액션 플래그 처리 기능의 UI 및 흐름을 제어합니다.
        ActionFlagProcessorService를 사용하여 모든 핵심 로직을 위임합니다.
        """
        self.logger.info(" -> '액션 플래그 처리' 메뉴를 시작합니다.")
        paths = PathManager(self.base_path)
        
        # 0. 필수 서비스 초기화 (ActionFlagProcessorService에 주입)
        master_service = MasterFileService(self.base_path, self.csv_service)
        
        # 1. 사용 가능한 검토 파일 동적 탐색
        potential_files = {
            "'Export 검토 (코드 의심)' 파일": self.paths.get_review_needed_file(),
            "'Export 필터링' 검토 파일": self.paths.get_filtered_items_file(),
            "'마스터 검토' 파일": self.paths.get_master_review_needed_file(),
            "'승인 항목 재검토' 파일": self.paths.get_master_true_review_file(),
            "'삭제된 항목 백업' 파일": self.paths.get_master_purged_file(),
            "'마스터 번역 없는 항목' 파일": self.paths.get_master_empty_kr_file(),
            "'비활성 항목 검토' 파일": self.paths.get_master_false_review_file(),
        }
        
        available_files = {str(i+1): (desc, path) for i, (desc, path) in enumerate(potential_files.items()) if os.path.exists(path)}

        if not available_files:
            self.logger.warning(" -> 처리할 검토 파일이 현재 존재하지 않습니다.")
            return

        print("\n [ 0. 액션 플래그 처리 ]\n")
        print("이 기능은 지정된 파일의 'Translatable' 열을 읽어 자동으로 항목을 정리합니다.\n")
        print("처리할 파일을 선택하세요:\n")
        
        for key, (desc, path) in available_files.items():
            print(f"{key}. {desc} ({os.path.basename(path)})")
            
        prompt = "\n>> 작업할 파일의 번호를 선택하세요 (ESC/q: 뒤로): "
        choice = prompt_for_input(prompt, valid_choices=list(available_files.keys()))
        
        if choice is UserInput.ESC or choice is UserInput.QUIT:
            return
                    
        _, file_to_process_path = available_files[choice]
        
        # 2. ActionFlagProcessorService 인스턴스 생성 및 파일 처리
        processor = ActionFlagProcessorService(
            self.base_path, self.is_test_run, self.logger,
            master_service, self.csv_service
        )

        if not processor.process_file(file_to_process_path):
            return

        # 3. 미리보기 및 사용자 확인
        if not processor._display_preview_and_confirm():
            return

        # 4. 실제 액션 실행
        processor._execute_actions()

        report_bundle = processor._generate_report_bundle()
        _render_standard_report(report_bundle, translations=REASON_TRANSLATIONS)
        
        pause_for_user()
        return

def main():
    """스크립트의 주 진입점 (Application Entry Point)."""
    # 1. 전역 서비스 초기화
    LoggerService.setup(log_filename=None, level=LOGGING_LEVEL)
    
    global csv_file_service
    csv_file_service = CsvFileService(
        output_encoding=OUTPUT_FILE_ENCODING,
        input_encoding=INPUT_FILE_ENCODING,
        create_backup=CREATE_BACKUP_FILE
    )

    try:
        # 2. UI 컨트롤러 생성 및 실행
        current_path = os.getcwd()
        paths_manager = PathManager(current_path)
        ui_controller = UIController(base_path=current_path, csv_service=csv_file_service, paths=paths_manager)
        ui_controller.run_main_loop()

    finally:
        # 3. 프로그램 종료 시 정리 작업
        print("\n로깅 시스템을 안전하게 종료합니다...")
        logging.shutdown()


if __name__ == "__main__":
    main()